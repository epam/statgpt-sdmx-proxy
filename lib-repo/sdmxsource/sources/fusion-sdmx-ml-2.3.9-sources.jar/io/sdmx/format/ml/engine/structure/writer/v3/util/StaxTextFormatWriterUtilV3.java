package io.sdmx.format.ml.engine.structure.writer.v3.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.constants.TEXT_TYPE;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.base.TextFormatBean;
import io.sdmx.format.ml.constant.SDMX_NAMESPACE;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxTextFormatWriterUtilV3 {

	public static void writeTextFormat(TextFormatBean textFormatBean, StaxWriter writer, String elementName) {
		writeTextFormat(textFormatBean, writer, elementName, true);
	}
	
    public static void writeTextFormat(TextFormatBean textFormatBean, StaxWriter writer, String elementName, boolean includeMultiLingual) {
        if(textFormatBean != null) {
            Map<String, String> attributes = new HashMap<>();
            addToMap(attributes, "decimals", textFormatBean.getDecimals());
            addToMap(attributes, "maxLength", textFormatBean.getMaxLength());
            addToMap(attributes, "minLength", textFormatBean.getMinLength());
            addToMap(attributes, "endTime", textFormatBean.getEndTime());
            addToMap(attributes, "endValue", textFormatBean.getEndValue());
            addToMap(attributes, "interval", textFormatBean.getInterval());
            addToMap(attributes, "maxValue", textFormatBean.getMaxValue());
            addToMap(attributes, "minValue", textFormatBean.getMinValue());
            if (includeMultiLingual) {
            	addToMap(attributes, "isMultiLingual", textFormatBean.getMultiLingual());
            }
            addToMap(attributes, "pattern", textFormatBean.getPattern());
            addToMap(attributes, "isSequence", textFormatBean.getSequence());
            addToMap(attributes, "startTime", textFormatBean.getStartTime());
            addToMap(attributes, "startValue", textFormatBean.getStartValue());
            addToMap(attributes, "textType", textFormatBean.getTextType());
            addToMap(attributes, "timeInterval", textFormatBean.getTimeInterval());

            SDMX_STRUCTURE_TYPE parentStructureType = null;
            SDMXBean parent = textFormatBean.getParent();
            if (parent != null && parent.getParent() != null) {
                parentStructureType = parent.getParent().getStructureType();
            }

            // Output the attributes if there are any or this is the TimeDimension
            if(attributes.size() > 0 || SDMX_STRUCTURE_TYPE.TIME_DIMENSION == parentStructureType) {
                writer.writeStartElement(SDMX_NAMESPACE.STRUCTURE_3.getNamespace(), elementName);
                writer.writeAttributes(attributes);
                writer.writeEndElement();
            }
        }
    }

	private static void addToMap(Map<String, String> attributes, String attributeName, TEXT_TYPE textType) {
		if(textType != null) {
			attributes.put(attributeName, textType.getSdmx21Value());
		}
	}

	private static void addToMap(Map<String, String> attributes, String attributeName, BigInteger bi) {
		if(bi != null) {
			attributes.put(attributeName, bi.toString());
		}
	}

	private static void addToMap(Map<String, String> attributes, String attributeName, BigDecimal dec) {
		if(dec != null) {
			attributes.put(attributeName, dec.toString());
		}
	}

	private static void addToMap(Map<String, String> attributes, String attributeName, String str) {
		if(str != null) {
			attributes.put(attributeName, str.toString());
		}
	}

	private static void addToMap(Map<String, String> attributes, String attributeName, SdmxDate date) {
		if(date != null) {
			attributes.put(attributeName, date.getDateInSdmxFormat());
		}
	}

	private static void addToMap(Map<String, String> attributes, String attributeName, TERTIARY_BOOL bool) {
		if(bool.isSet()) {
			attributes.put(attributeName, Boolean.toString(bool.isTrue()));
		}
	}
}
