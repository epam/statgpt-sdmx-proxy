package io.sdmx.format.ml.model;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.MIME_TYPE;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.SDMXML_VERSION;
import io.sdmx.utils.core.format.FormatDetailsImpl;

public class SdmxMLMetadataFormat implements IMetadataFormat, IFusionSingleton {
	private static final long serialVersionUID = 1L;
	private SDMXML_VERSION mlVersion;
	private FormatDetails formatDetails;
	
	private static Map<SDMXML_VERSION, SdmxMLMetadataFormat> formats = new HashMap<>();

	public SdmxMLMetadataFormat(SDMXML_VERSION version) {
		this.mlVersion = version;
		formatDetails = new FormatDetailsImpl("sdmx-ml v"+version.getVersion(), 
											  MIME_TYPE.APPLICATION_XML, false, 
											  "application/vnd.sdmx.metadata+xml;version="+version.getVersion());
	}
	
	
	public static SdmxMLMetadataFormat getInstance(SDMXML_VERSION version) {
		SdmxMLMetadataFormat format = null;
		synchronized(formats) {
			format = SdmxMLMetadataFormat.formats.get(version);
		}
		if(format == null) {
			
			format = new SdmxMLMetadataFormat(version);
			synchronized(formats) {
				formats.put(version, format);
			}
		}
		return format;
	
    }

	public SDMXML_VERSION getVersion() {
		return mlVersion;
	}

    public void destroyInstance() {
    	formats = new HashMap<>();
    }

	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}
}
