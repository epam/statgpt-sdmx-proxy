package io.sdmx.format.ml.engine.structure.writer.v1;

import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.SdmxConstants;
import io.sdmx.api.sdmx.manager.output.SchemaLocationManager;
import io.sdmx.api.sdmx.manager.retrieval.HeaderRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.ContactBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.base.TextTypeWrapper;
import io.sdmx.api.sdmx.model.beans.mapping.StructureSetBean;
import io.sdmx.api.sdmx.model.beans.validityperiod.ValidatableBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.api.sdmx.model.header.PartyBean;
import io.sdmx.core.sdmx.api.engine.structure.StructureWriterEngine;
import io.sdmx.core.sdmx.api.model.structure.IExternalMaintainableLinks;
import io.sdmx.core.sdmx.engine.structure.AbstractStructureWriterEngine;
import io.sdmx.core.sdmx.util.StructureWriterUtil;
import io.sdmx.format.ml.api.engine.StaxMaintainableWriterEngine;
import io.sdmx.format.ml.engine.structure.writer.v1.codelist.StaxCodelistWriterEngineV1;
import io.sdmx.format.ml.engine.structure.writer.v1.conceptscheme.StaxConceptSchemeWriterEngineV1;
import io.sdmx.format.ml.engine.structure.writer.v1.dsd.StaxDsdWriterEngineV1;
import io.sdmx.format.ml.engine.structure.writer.v1.orgscheme.StaxAgencySchemeWriterEngineV1;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxTextWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxContactWriterUtil;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.im.util.ItemValidityPeriodHelper;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.Namespace;
import io.sdmx.utils.core.xml.StaxWriter;

@SuppressWarnings("rawtypes")
public abstract class StaxAbstractStructureWriterEngineV1 extends AbstractStructureWriterEngine implements StructureWriterEngine {
	private SDMX_SCHEMA ouputVersion;

	private SchemaLocationManager schemaLocationManager = SingletonStore.getSingleton(SchemaLocationManager.class, false);
	private HeaderRetrievalManager headerRetrievalManager = SingletonStore.getSingleton(HeaderRetrievalManager.class, false);

	private Map<SDMX_STRUCTURE_TYPE, StaxMaintainableWriterEngine> writerEngines = new HashMap<>();
	protected Namespace messageNs;
	protected Namespace structureNs;
	protected Namespace commonNs;
	protected Namespace registryNs;
	protected boolean prettyPrint = false;

	public StaxAbstractStructureWriterEngineV1(SDMX_SCHEMA ouputVersion,
			Namespace messageNs,
			Namespace structureNs,
			Namespace commonNs,
			Namespace registryNs) {
		super(true, SDMX_STRUCTURE_TYPE.AGENCY_SCHEME,
					 SDMX_STRUCTURE_TYPE.CODE_LIST,
					 SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME,
					 SDMX_STRUCTURE_TYPE.DSD);
		this.ouputVersion = ouputVersion;
		this.messageNs = messageNs;
		this.structureNs = structureNs;
		this.commonNs = commonNs;
		this.registryNs = registryNs;

		writerEngines.put(SDMX_STRUCTURE_TYPE.AGENCY_SCHEME, StaxAgencySchemeWriterEngineV1.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.CODE_LIST, StaxCodelistWriterEngineV1.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME, StaxConceptSchemeWriterEngineV1.getInstance());
		writerEngines.put(SDMX_STRUCTURE_TYPE.DSD, StaxDsdWriterEngineV1.getInstance());
	}

	@Override
	public void writeStructure(MaintainableBean bean, IExternalMaintainableLinks additionalLinks, OutputStream out) {
		StructureWriterUtil.writeStructure(this, bean, additionalLinks, out);
	}

	@Override
	public void writeStructures(SdmxBeans beans, Map<IURNMaintainable<?>, IExternalMaintainableLinks> additionalLinks, OutputStream out) {
		StaxWriter writer = null;
		try {
			writer = new StaxWriter(out, getSchemaLocation(), prettyPrint, messageNs, structureNs, commonNs);
			writeStructuresInternal(writer, beans, out);
		} finally {
		    if (writer != null) {
		        writer.close();
		    }
		}
	}

	private String getSchemaLocation() {
		String messageSchema = messageNs.getNamespaceURL();
		String schemaName = SdmxConstants.getSchemaName(messageSchema);
		if(schemaLocationManager != null) {
			return messageSchema + " " + schemaLocationManager.getSchemaLocation(ouputVersion) + schemaName;
		}
		return null;
	}

	protected void writeStructuresInternal(StaxWriter writer, SdmxBeans beans, OutputStream out) {
		writer.startDocument(messageNs, getDocumentRoot());
		writeHeader(writer, beans.getHeader(), true);
		afterHeader(writer, beans.getAction());

		writeOrganisations(writer, beans);
		writeStructures(writer, "CodeLists", beans, SDMX_STRUCTURE_TYPE.CODE_LIST);
		writeStructures(writer, "Concepts", beans, SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME);
		writeStructures(writer, "KeyFamilies", beans, SDMX_STRUCTURE_TYPE.DSD);
	}

	protected abstract String getDocumentRoot();

	protected abstract void afterHeader(StaxWriter writer, DATASET_ACTION action);

	protected void writeHeader(StaxWriter writer, HeaderBean header, boolean includeReceiver) {
		if(header == null && headerRetrievalManager != null) {
			header = headerRetrievalManager.getHeader();
		}
		if(header == null) {
			header = new HeaderBeanImpl("ZZZ");
		}
		//TODO Header
		writer.writeStartElement(messageNs, "Header");
		writer.writeElement(messageNs, "ID", header.getId());
		writer.writeElement(messageNs, "Test", Boolean.toString(header.isTest()));

		Date prepared = header.getPrepared() != null ? header.getPrepared() : new Date();
		// The Prepared date must be in ISO 8601 Zulu Time
		writer.writeElement(messageNs, "Prepared", DateUtil.formatDate(prepared) + "Z");
		writer.writeStartElement(messageNs, "Sender");
		writer.writeAttribute("id", header.getSender().getId());
		writer.writeEndElement();  //End Sender
		if(includeReceiver || getDocumentRoot().equals("RegistryInterface")) {
			// Write Receiver

			if(ObjectUtil.validCollection(header.getReceiver())) {
				// If this is a registry message, there may only be one receiver, otherwise there can be multiple.
				if (getDocumentRoot().equals("RegistryInterface")) {
					// Only write the first
				    writeReceiver(writer, header.getReceiver().get(0));
				} else {
					// Write all receivers
					List<PartyBean> allReceivers = header.getReceiver();
					for (PartyBean partyBean : allReceivers) {
					    writeReceiver(writer, partyBean);
					}
				}

			} else {
				// Write "default" receiver
				writeReceiver(writer, "not_supplied");
			}
		}

		writer.writeEndElement();  //End Header
	}

	private void writeReceiver(StaxWriter writer, PartyBean partyBean) {
        writer.writeStartElement(messageNs, "Receiver");
        writer.writeAttribute("id", partyBean.getId());

        // Write names if present
        List<TextTypeWrapper> names = partyBean.getName();
        if (ObjectUtil.validCollection(names)) {
            StaxTextWriterUtilV2.writeTextTypes(names, writer, "Name");
        }

        // Write contacts if present
        List<ContactBean> contacts = partyBean.getContacts();
        if (ObjectUtil.validCollection(contacts)) {
            StaxContactWriterUtil.writeContactForReceiver(contacts, writer);
        }

        writer.writeEndElement();  //End Receiver
    }

    private void writeReceiver(StaxWriter writer, String receiverId) {
		writer.writeStartElement(messageNs, "Receiver");
		writer.writeAttribute("id", receiverId);
		writer.writeEndElement();  //End Receiver
	}

	private void writeOrganisations(StaxWriter writer, SdmxBeans beans) {
		if(ObjectUtil.validCollection(beans.getAgenciesSchemes())
				|| ObjectUtil.validCollection(beans.getDataProviderSchemes())
				|| ObjectUtil.validCollection(beans.getDataConsumerSchemes())
				|| ObjectUtil.validCollection(beans.getOrganisationUnitSchemes())) {
			if (beans.getAgenciesSchemes().size() > 0) {
			    writeStructures(writer, beans, SDMX_STRUCTURE_TYPE.AGENCY_SCHEME);
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void writeStructures(StaxWriter writer, String startNode,
			SdmxBeans beans,
			SDMX_STRUCTURE_TYPE structureType) {
		if(ObjectUtil.validCollection(beans.getMaintainables(structureType))) {
			StaxMaintainableWriterEngine writerEngine = getWriterEngine(structureType);
			writer.writeStartElement(messageNs, startNode);
			for(MaintainableBean maint : beans.getMaintainables(structureType)) {
                if (maint instanceof ValidatableBean) {
                    maint = ItemValidityPeriodHelper.potentiallyMutateIt((ValidatableBean<?>) maint);
                } else if (maint instanceof StructureSetBean) {
                    maint = ItemValidityPeriodHelper.potentiallyMutateIt((StructureSetBean) maint);
                }
                writerEngine.writeMaintainable(maint, null, writer);
            }

			writer.writeEndElement();
		}
	}

	/**
	 * For use with structures which are grouped for example agency schemes, data provider schemes, content constrains
	 * @param beans
	 * @param staxWriter
	 * @param structureType
	 */
	@SuppressWarnings("unchecked")
	private void writeStructures(StaxWriter writer, SdmxBeans beans,
			SDMX_STRUCTURE_TYPE structureType) {
		if(ObjectUtil.validCollection(beans.getMaintainables(structureType))) {
			StaxMaintainableWriterEngine writerEngine = getWriterEngine(structureType);
			for(MaintainableBean maint : beans.getMaintainables(structureType)) {
				writerEngine.writeMaintainable(maint, null, writer);
			}
		}
	}

	protected StaxMaintainableWriterEngine getWriterEngine(SDMX_STRUCTURE_TYPE structureType) {
		StaxMaintainableWriterEngine writerEngine = writerEngines.get(structureType);
		if(writerEngine == null) {
			throw new SdmxNotImplementedException("No support for writing structure '"+structureType.getType()+"' in version '"+this.ouputVersion+"'");
		}
		return writerEngine;
	}
}
