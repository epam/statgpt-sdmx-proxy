package io.sdmx.format.ml.engine.structure.writer.v2.dsd;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.GroupBean;
import io.sdmx.api.sdmx.model.beans.datastructure.MeasureListBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.singleton.IFusionSingleton;
import io.sdmx.format.ml.constant.StaxStructureWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v2.AbstractV2Writer;
import io.sdmx.format.ml.engine.structure.writer.v2.util.StaxAnnotableWriterUtilV2;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxAnnotableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxIdentifiableWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRefUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxRepresentationWriterUtil;
import io.sdmx.format.ml.engine.structure.writer.v21.util.StaxTextFormatWriterUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.xml.StaxWriter;

public class StaxDsdWriterEngineV2 extends AbstractV2Writer<DataStructureBean> implements IFusionSingleton {
	private static StaxDsdWriterEngineV2 INSTANCE;

	//Private constructor - lazy load instance
	private StaxDsdWriterEngineV2() {}

	public static StaxDsdWriterEngineV2 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxDsdWriterEngineV2();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

	@Override
	protected String getRootNodeName() {
		return "KeyFamily";
	}

	@Override
	protected void writeMaintainableInternal(DataStructureBean maint, StaxWriter writer) {
		writer.writeStartElement(NS, "Components");
		writeDimensionList(maint.getDimensions(), writer, true);
		writeDimensionList(maint.getDimensions(SDMX_STRUCTURE_TYPE.TIME_DIMENSION), writer, false);
		writeGroups(maint.getGroups(), writer);
		writePrimaryMeasure(maint.getPrimaryMeasure(), writer);
		// TODO - cross sectional Measure
		// Write CrossSectionalMeasure
		writeAttributeList(maint, maint.getAttributeList(), writer);
		// TODO - cross measure list
//		writeMeasureList(maint.getMeasureList(), writer);
//		StaxAnnotableWriterUtilV2.writeAnnotations(maint.getAnnotations(), writer);
		writer.writeEndElement(); //End DataStructureComponents
	}

    private void writeDimensionList(List<DimensionBean> list, StaxWriter writer, boolean excludeTime) {
        if(list == null) {
            return;
        }

        for(DimensionBean dim : list) {
            if (excludeTime && dim.isTimeDimension()) {
                continue;
            }
            Map<String, String> attrs = new HashMap<>();
            ICrossReferenceBean<?> conceptRef = dim.getConceptRef();
            if (conceptRef != null) {
                attrs.put("conceptRef", conceptRef.getReference().getFullIdentifiableId());
                attrs.put("conceptVersion", conceptRef.getReference().getVersion().toString());
                attrs.put("conceptSchemeRef", conceptRef.getReference().getMaintainableId());
                attrs.put("conceptSchemeAgency", conceptRef.getReference().getAgencyId());
            }

            RepresentationBean representation = dim.getRepresentation();
            if (representation != null) {
                ICrossReferenceBean<?> representation2 = representation.getRepresentation();
                if (representation2 != null) {
                    attrs.put("codelist", representation2.getReference().getMaintainableId());
                    attrs.put("codelistAgency", representation2.getReference().getAgencyId());
                    attrs.put("codelistVersion", representation2.getReference().getVersion().toString());
                }
            }

            if (dim.isMeasureDimension()) {
                attrs.put("isMeasureDimension", "true");
            }
            if (dim.isFrequencyDimension()) {
                attrs.put("isFrequencyDimension", "true");
            }

            String outputDimensionNode;
            if (dim.isTimeDimension()) {
                outputDimensionNode = "TimeDimension";
            } else {
                outputDimensionNode = "Dimension";
            }
            writer.writeElement(NS, outputDimensionNode, attrs);

            if (dim.getRepresentation() != null && dim.getRepresentation().getTextFormat() != null) {
                StaxTextFormatWriterUtil.writeTextFormat(dim.getRepresentation().getTextFormat(), writer, "TextFormat");
            }
            StaxAnnotableWriterUtilV2.writeAnnotations(dim.getAnnotations(), writer);

            writer.writeEndElement(); //End Dimension
        }
    }

    private void writePrimaryMeasure(PrimaryMeasureBean primaryMeasure, StaxWriter writer) {
        if (primaryMeasure == null) {
            return;
        }

        Map<String, String> attrs = new HashMap<>();
        ICrossReferenceBean<?> conceptRef = primaryMeasure.getConceptRef();
        if (conceptRef != null) {
            attrs.put("conceptRef", conceptRef.getReference().getFullIdentifiableId());
            attrs.put("conceptVersion", conceptRef.getReference().getVersion().toString());
            attrs.put("conceptSchemeRef", conceptRef.getReference().getMaintainableId());
            attrs.put("conceptSchemeAgency", conceptRef.getReference().getAgencyId());
        }

        writer.writeElement(NS, "PrimaryMeasure", attrs);

        if (primaryMeasure.getRepresentation() != null && primaryMeasure.getRepresentation().getTextFormat() != null) {
            StaxTextFormatWriterUtil.writeTextFormat(primaryMeasure.getRepresentation().getTextFormat(), writer, "TextFormat");
        }
        StaxAnnotableWriterUtilV2.writeAnnotations(primaryMeasure.getAnnotations(), writer);

        writer.writeEndElement(); //End Dimension
    }

	private void writeComponent(ComponentBean comp, StaxWriter writer, String attrId, String attrVal) {
		Map<String, String> attributes = StaxIdentifiableWriterUtil.getAttributes(comp);
		attributes.put(attrId, attrVal);
		writer.writeAttributes(attributes);
		StaxAnnotableWriterUtil.writeBean(comp, writer);
		StaxRefUtil.writeReference(comp.getConceptRef().getReference(), writer, "ConceptIdentity");
		if(comp.getRepresentation() != null) {
			StaxRepresentationWriterUtil.writeRepresentation(comp.getRepresentation(), writer, "LocalRepresentation", false);
		}
	}

	private void writeGroups(List<GroupBean> groups, StaxWriter writer) {
		if(ObjectUtil.validCollection(groups)) {
			for(GroupBean groupBean : groups) {
			    Map<String, String> attrs = new HashMap<>();
			    attrs.put("id", groupBean.getId());
                writer.writeElement(StaxStructureWriterUtil.STRCUTURE_NS, "Group", attrs);

				for(String dimRef : groupBean.getDimensionRefs()) {
					writer.writeStartElement(NS, "DimensionRef");
					writer.writeElementText(dimRef);
					writer.writeEndElement();
				}
				StaxAnnotableWriterUtilV2.writeAnnotations(groupBean.getAnnotations(), writer);
				writer.writeEndElement(); //End Group
			}
		}
	}

	private void writeAttributeList(DataStructureBean buildFrom, AttributeListBean attrList, StaxWriter writer) {
        if(attrList == null || attrList.getAttributes() == null || attrList.getAttributes().size() == 0) {
            return;
        }

        for(AttributeBean attr : attrList.getAttributes()) {
            Map<String, String> attrs = new HashMap<>();

            ICrossReferenceBean<?> conceptRef = attr.getConceptRef();
            if (conceptRef != null) {
                attrs.put("conceptRef", conceptRef.getReference().getFullIdentifiableId());
                attrs.put("conceptVersion", conceptRef.getReference().getVersion().toString());
                attrs.put("conceptSchemeRef", conceptRef.getReference().getMaintainableId());
                attrs.put("conceptSchemeAgency", conceptRef.getReference().getAgencyId());
            }

            if (attr.getRepresentation() != null) {
                ICrossReferenceBean rep = attr.getRepresentation().getRepresentation();
                if (rep != null) {
                    attrs.put("codelist", rep.getReference().getMaintainableId());
                    attrs.put("codelistAgency", rep.getReference().getAgencyId());
                    attrs.put("codelistVersion", rep.getReference().getVersion().toString());
                }
            }

            String attachmentLevelStr;
            String attachmentGrp = null;
            ATTRIBUTE_ATTACHMENT_LEVEL attachmentLevel = attr.getAttachmentLevel();
            switch(attachmentLevel) {
            case DATA_SET:
                attachmentLevelStr = "DataSet";
                break;
            case OBSERVATION:
                attachmentLevelStr = "Observation";
                break;
            case GROUP:
                attachmentLevelStr = "Group";
                attachmentGrp = attr.getAttachmentGroup();
                break;
            case DIMENSION_GROUP:
                attachmentLevelStr = "Series";

                // This series level attachment could be "group"
                List<String> dimensionReferences = attr.getDimensionReferences();
                for(GroupBean grp : buildFrom.getGroups()) {
                    if(grp.getDimensionRefs().containsAll(dimensionReferences) && dimensionReferences.containsAll(grp.getDimensionRefs())) {
                        attachmentLevelStr = "Group";
                        attachmentGrp = grp.getId();
                        break;
                    }
                }

                break;
            default:
                throw new SdmxSemmanticException("Unknown attachment level: " + attachmentLevel);
            }

            attrs.put("attachmentLevel", attachmentLevelStr);
            String assignmentStatus = attr.isMandatory() ? "Mandatory" : "Conditional";
            attrs.put("assignmentStatus", assignmentStatus);

            if (attr.isTimeFormat()) {
                attrs.put("isTimeFormat", "true");
            }

            writer.writeElement(NS, "Attribute", attrs);

            if (attr.getRepresentation() != null && attr.getRepresentation().getTextFormat() != null) {
                StaxTextFormatWriterUtil.writeTextFormat(attr.getRepresentation().getTextFormat(), writer, "TextFormat");
            }

            if (attachmentLevelStr.equals("Group")) {
                writer.writeElement(NS, "AttachmentGroup", attachmentGrp);
            }

            // TODO - AttachmentMeasure

            StaxAnnotableWriterUtilV2.writeAnnotations(attr.getAnnotations(), writer);

            writer.writeEndElement(); // End Attribute
        }
    }

	private void writeMeasureList(MeasureListBean measList, StaxWriter writer) {
		if(measList == null) {
			return;
		}
		StaxIdentifiableWriterUtil.writeBean(measList, "MeasureList", writer);

		PrimaryMeasureBean pm = measList.getPrimaryMeasure();
		StaxIdentifiableWriterUtil.writeBean(pm, "PrimaryMeasure", writer);
		StaxRefUtil.writeReference(pm.getConceptRef().getReference(), writer, "ConceptIdentity");
		if(pm.getRepresentation() != null) {
			StaxRepresentationWriterUtil.writeRepresentation(pm.getRepresentation(), writer, "LocalRepresentation", false);
		}
		writer.writeEndElement(); //End PrimaryMeasure
		writer.writeEndElement(); //End MeasureList
	}
}
