package io.sdmx.format.ml.engine.structure.reader.v20.util;

import io.sdmx.api.xml.IStaxReader;
import io.sdmx.api.sdmx.model.mutable.base.MaintainableMutableBean;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxIdentifiableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxNameableUtil;

public class StaxMaintainableUtilV2 {

    /**
     * For SDMX 2.0 maintainable beans, processes the expected maintainable attributes ("validFrom", "agencyId", etc)
     * and the Identifiable values ("ID", etc)  as well as processing any Names and Descriptions.
     * Expected start node: The high-level INDIVIDUAL Maintainable Structure (e.g. CategoryScheme, Dataflow, etc)
     * Will leave this method on the next node after the Description
     * @param bean the bean to populate
     * @param reader the StaxReader to obtain the information from
     */
	public static void processBean(MaintainableMutableBean bean, IStaxReader reader) {
		StaxMaintainableUtil.processAttributes(bean, reader);
        StaxIdentifiableUtil.processAttributes(bean, reader);
        reader.moveNextNode();
        while(StaxNameableUtil.processNode(bean, reader)) {
            //Processing Nodes
            reader.moveNextNode();
        }
	}
}
