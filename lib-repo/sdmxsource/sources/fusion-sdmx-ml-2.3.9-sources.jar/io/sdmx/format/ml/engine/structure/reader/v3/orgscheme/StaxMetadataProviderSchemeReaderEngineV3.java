package io.sdmx.format.ml.engine.structure.reader.v3.orgscheme;

import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderMutableBean;
import io.sdmx.api.sdmx.model.mutable.base.IMetadataProviderSchemeMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxItemSchemeUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.MetadataProviderMutableBean;
import io.sdmx.im.mutable.base.MetadataProviderSchemeMutableBean;
import io.sdmx.utils.core.application.FusionBeanStore;

public class StaxMetadataProviderSchemeReaderEngineV3 extends StaxAbstractOrgansiationReaderV3<IMetadataProviderSchemeMutableBean> {
	private static StaxMetadataProviderSchemeReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxMetadataProviderSchemeReaderEngineV3() {}

	public static StaxMetadataProviderSchemeReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxMetadataProviderSchemeReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }
	
	@Override
	public String getContainerNodeName() {
        return "MetadataProviderSchemes";
    }
    
    @Override
    protected String getRootNodeName() {
        return "MetadataProviderScheme";
    }
    
	@Override
    protected IMetadataProviderSchemeMutableBean processMaintainable(IStaxReader reader) {
	    IMetadataProviderSchemeMutableBean dpScheme = new MetadataProviderSchemeMutableBean();
        StaxItemSchemeUtil.processBean(dpScheme, reader);

        //Expected position is now Agency
        String elementName = reader.getElementName();
        while(reader.isStartElement()) {
            if(!elementName.equals("MetadataProvider")) {
                StaxStructureUtil.throwUnexpectedNodeException(reader);
            }
            processDataProvider(dpScheme, reader);
            reader.moveNextNode();
        }
        return dpScheme;
    }

	private void processDataProvider(IMetadataProviderSchemeMutableBean beanToPopulate, IStaxReader reader) {
		IMetadataProviderMutableBean provider = new MetadataProviderMutableBean();
		beanToPopulate.addItem(provider);
		super.processOrganisation(provider, reader);
	}
}
