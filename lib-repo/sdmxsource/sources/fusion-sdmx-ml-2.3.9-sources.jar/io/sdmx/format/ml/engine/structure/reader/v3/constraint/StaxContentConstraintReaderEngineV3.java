package io.sdmx.format.ml.engine.structure.reader.v3.constraint;

import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.TERTIARY_BOOL;
import io.sdmx.api.sdmx.model.mutable.base.TimeRangeMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.ContentConstraintMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.CubeRegionMutableBean;
import io.sdmx.api.sdmx.model.mutable.registry.KeyValuesMutable;
import io.sdmx.api.sdmx.model.mutable.registry.ReleaseCalendarMutableBean;
import io.sdmx.api.xml.IStaxReader;
import io.sdmx.format.ml.engine.structure.reader.v21.util.StaxMaintainableUtil;
import io.sdmx.format.ml.util.StaxStructureUtil;
import io.sdmx.im.mutable.base.TimeRangeMutableBeanImpl;
import io.sdmx.im.mutable.registry.ContentConstraintMutableBeanImpl;
import io.sdmx.im.mutable.registry.CubeRegionMutableBeanImpl;
import io.sdmx.im.mutable.registry.KeyValuesMutableImpl;
import io.sdmx.im.mutable.registry.ReleaseCalendarMutableBeanImpl;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.StringUtil;

public class StaxContentConstraintReaderEngineV3 extends StaxAbstractConstraintReaderEngineV3<ContentConstraintMutableBean> {
	private static StaxContentConstraintReaderEngineV3 INSTANCE;

	//Private constructor - lazy load instance
	private StaxContentConstraintReaderEngineV3() {}
	public static StaxContentConstraintReaderEngineV3 getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new StaxContentConstraintReaderEngineV3();
			FusionBeanStore.registerInstance(INSTANCE);
		}
		return INSTANCE;
	}

	@Override
    public void destroyInstance() {
        INSTANCE = null;
    }

    @Override
    public String getContainerNodeName() {
        return "DataConstraints";
    }
    
    @Override
    protected String getRootNodeName() {
        return "DataConstraint";
    }
    
    @Override
    protected ContentConstraintMutableBean processMaintainable(IStaxReader reader) {
		ContentConstraintMutableBean constraint = new ContentConstraintMutableBeanImpl();

		String constraintType = reader.getAttributeValue(null, "role");
		if (!ObjectUtil.validString(constraintType)) {
			throw new SdmxSemmanticException("Missing 'role' attribute. Expecting 'role' attribute with the value of 'Actual' or 'Allowed'");
		}
		if (constraintType.equals("Actual")) {
			constraint.setIsDefiningActualDataPresent(true);
		} else if(constraintType.equals("Allowed")) {
			constraint.setIsDefiningActualDataPresent(false);
		} else {
			throw new SdmxSemmanticException("Illegal 'role' value: '" + constraintType + "', expecting 'Actual' or 'Allowed'");
		}

		StaxMaintainableUtil.processBean(constraint, reader);

		CubeRegionMutableBean includedCubeRegion = new CubeRegionMutableBeanImpl();
		CubeRegionMutableBean excludedCubeRegion = new CubeRegionMutableBeanImpl();
		while(reader.isStartElement()) {
			String elementName = reader.getElementName();
			if(elementName.equals("ConstraintAttachment")) {
				constraint.setConstraintAttachment(processConstraintAttachment(reader));
			} else if(elementName.equals("DataKeySet")) {
				processDataKeySet(reader, constraint);
			} else if(elementName.equals("CubeRegion")) {
				processCubeRegion(reader, includedCubeRegion, excludedCubeRegion);
				constraint.setIncludedCubeRegion(includedCubeRegion);
				constraint.setExcludedCubeRegion(excludedCubeRegion);
			} else if(elementName.equals("ReleaseCalendar")) {
				constraint.setReleaseCalendar(processReleaseCalandar(reader));
			}  else {
				StaxStructureUtil.throwUnexpectedNodeException(reader);
			}
			reader.moveNextNode();
		}
		return constraint;
	}

	private ReleaseCalendarMutableBean processReleaseCalandar(IStaxReader reader) {
		ReleaseCalendarMutableBean returnBean = new ReleaseCalendarMutableBeanImpl();

		while(reader.moveNextNode()) {
			String elementName = reader.getElementName();
			if(reader.isStartElement()) {
				if(elementName.equals("Periodicity")) {
					returnBean.setPeriodicity(reader.getElementText());
				} else if(elementName.equals("Offset")) {
					returnBean.setOffset(reader.getElementText());
				} else if(elementName.equals("Tolerance")) {
					returnBean.setTolerance(reader.getElementText());
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(elementName.equals("ReleaseCalendar")) {
				break;
			}
		}
		return returnBean;
	}


	private void processCubeRegion(IStaxReader reader,
			CubeRegionMutableBean includedCubeRegion,
			CubeRegionMutableBean excludedCubeRegion) {

		boolean isIncluded = StaxStructureUtil.getAttributeAsBoolean(reader.getAttributes(), "include", false, true);

		String exitElement = reader.getElementName();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				TERTIARY_BOOL isStillIncluded = StaxStructureUtil.getAttributeAsTeritaryBoolean(reader.getAttributes(), "include", false);
				if(nodeName.equals("KeyValue")) {
					KeyValuesMutable keyValues = processCubeRegionKeyValues(reader);
					if(isIncluded) {
						if(isStillIncluded.isSet() && !isStillIncluded.isTrue()) {
							excludedCubeRegion.addKeyValues(keyValues);
						} else {
							includedCubeRegion.addKeyValues(keyValues);
						}
					} else {
						if(isStillIncluded.isSet() && !isStillIncluded.isTrue()) {
							includedCubeRegion.addKeyValues(keyValues);
						} else {
							excludedCubeRegion.addKeyValues(keyValues);
						}
					}
				} else if(nodeName.equals("Component")) {
					KeyValuesMutable attrValues = processCubeRegionKeyValues(reader);
					if(isIncluded) {
						if(isStillIncluded.isSet() && !isStillIncluded.isTrue()) {
							excludedCubeRegion.addAttributeValue(attrValues);
						} else {
							includedCubeRegion.addAttributeValue(attrValues);
						}
					} else {
						if(isStillIncluded.isSet() && !isStillIncluded.isTrue()) {
							includedCubeRegion.addAttributeValue(attrValues);
						} else {
							excludedCubeRegion.addAttributeValue(attrValues);
						}
					}
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals(exitElement)) {
				break;
			}
		}
	}

	private KeyValuesMutable processCubeRegionKeyValues(IStaxReader reader) {
		KeyValuesMutable returnBean = new KeyValuesMutableImpl();
		returnBean.setId(StaxStructureUtil.getAttribute(reader.getAttributes(), "id", true));
		returnBean.setRemovePrefix(StaxStructureUtil.getAttributeAsBoolean(reader.getAttributes(), "removePrefix", false, false));
		String exitElement = reader.getElementName();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("Value")) {
					Map<String, String> attributes = reader.getAttributes();
					String elText = reader.getElementText();
					elText = StringUtil.cleanString(elText);
					String cascade = attributes.get("cascadeValues");
					String validFrom = attributes.get("validFrom");
					String validTo = attributes.get("validTo");
					returnBean.setValidity(elText, validFrom, validTo);
					if(cascade == null || cascade.equals("false")) {
						returnBean.addValue(elText);
					} else if(cascade.equals("excluderoot")) {
						returnBean.addCascade(elText);
					} else if(cascade.equals("true")) {
						returnBean.addCascade(elText);
						returnBean.addValue(elText);
					} else {
						throw new SdmxSemmanticException("Unexpected cascadeValues value: "+cascade+", expecitng 'true', 'false' or 'excluderoot'");
					}
				} else if(nodeName.equals("TimeRange")) {
					returnBean.setTimeRange(processTimeRange(reader));
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals(exitElement)) {
				break;
			}
		}
		return returnBean;
	}
	private TimeRangeMutableBean processTimeRange(IStaxReader reader) {
		TimeRangeMutableBean returnBean = new TimeRangeMutableBeanImpl();

		String exitElement = reader.getElementName();
		while(reader.moveNextNode()) {
			String nodeName = reader.getElementName();
			if(reader.isStartElement()) {
				if(nodeName.equals("BeforePeriod")) {
					returnBean.setStartDate(SdmxDateImpl.getSdmxDate(reader.getElementText()));
					returnBean.setIsRange(false);
				} else if(nodeName.equals("AfterPeriod")) {
					returnBean.setEndDate(SdmxDateImpl.getSdmxDate(reader.getElementText()));
					returnBean.setIsRange(false);
				}  else if(nodeName.equals("StartPeriod")) {
					returnBean.setStartDate(SdmxDateImpl.getSdmxDate(reader.getElementText()));
					returnBean.setIsRange(true);
				}  else if(nodeName.equals("EndPeriod")) {
					returnBean.setEndDate(SdmxDateImpl.getSdmxDate(reader.getElementText()));
					returnBean.setIsRange(true);
				} else {
					StaxStructureUtil.throwUnexpectedNodeException(reader);
				}
			} else if(nodeName.equals(exitElement)) {
				break;
			}
		}
		return returnBean;
	}
}
