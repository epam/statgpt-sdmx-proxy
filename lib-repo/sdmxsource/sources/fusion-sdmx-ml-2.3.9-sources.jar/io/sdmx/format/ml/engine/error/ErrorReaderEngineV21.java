package io.sdmx.format.ml.engine.error;

import java.util.ArrayList;
import java.util.List;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.IErrorReaderEngine;
import io.sdmx.api.sdmx.model.error.ISdmxError;
import io.sdmx.im.error.SdmxError;
import io.sdmx.utils.core.xml.StaxReader;

public class ErrorReaderEngineV21 implements IErrorReaderEngine {
	public static final IErrorReaderEngine INSTANCE  = new ErrorReaderEngineV21();
	
	
	private ErrorReaderEngineV21() {}


	@Override
	/**
	 * /**
	 * Readers an SDMX Error Response
	 * <mes:Error xsi:schemaLocation="http://www.sdmx.org/resources/sdmxml/schemas/v2_1/message https://registry.sdmx.org/schemas/v2_1/SDMXMessage.xsd">
		<mes:ErrorMessage code="100">
			<com:Text>
				Error message 1
			</com:Text>
			<com:Text>
				Error message 2
			</com:Text>
		</mes:ErrorMessage>
		</mes:Error>

	 * @param th
	 * @param exceptionCode
	 * @param writer
	 */
	public ISdmxError readError(ReadableDataLocation rdl) {
		StaxReader staxReader = new StaxReader(rdl);
		staxReader.jumpToNode("ErrorMessage");  

		int errorCodeInt = 0;
		try {
			String errorCode = staxReader.getAttributeValue(null, "code");
			if(errorCode != null) {
				errorCodeInt = Integer.parseInt(errorCode);
			}
		} catch(Throwable th) {
			//unable to read erorr code
		}
		
		List<String> errorText = new ArrayList<>();
		while(staxReader.moveNextStartNode()) {
			errorText.add(staxReader.getElementText());
		}
		return new SdmxError(null, errorCodeInt, errorText);
	}

}
