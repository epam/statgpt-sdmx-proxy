package io.sdmx.fusion.reporttemplate.api.manager;

/**
 * Allows Agencies to make their templates public (any user can create one) or private (only data providers can create one)
 */
public interface ReportTemplateSecurityManager {

	/**
	 * Make the agency template secure or not (boolean)
	 * @param agency agencyId
	 * @param secure true to disable (public access) false to enable (secure)
	 */
	void setDisableSecurity(boolean secure);
	
	/**
	 * Returns agency security settings for template generation
	 * @return
	 */
	boolean isSecurityDisabled();
	
}
