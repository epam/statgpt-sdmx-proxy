package io.sdmx.fusion.reporttemplate.api.model.template;

import java.util.List;

import io.sdmx.fusion.reporttemplate.api.model.template.IInstructionSheetTextArea;
import io.sdmx.utils.xlsx.api.model.IExcelWorksheet;

/**
 * A documentation only sheet providing instructional text for the user
 */
public interface IReportingTemplateInstructionSheet extends IExcelWorksheet {
	
	
	/**
	 * @return optional worksheet title
	 */
	String getTitle();
	
	/**
	 * @return immutable list of text areas
	 */
	List<IInstructionSheetTextArea> getTextArea();
	
}
