package io.sdmx.fusion.reporttemplate.api.model.pivottable;

public enum CELL_TYPE {
	HEADER_TITLE(1),
	HEADER_VALUE(2),
	OBSERVATION(3),
	OBSERVATION_ATTRIBUTE(4),
	OBSERVATION_NO_DATA(5);
	
	private int asNumber;

	private CELL_TYPE(int ordinal) {
		this.asNumber = ordinal;
	}

	public int getAsNumber() {
		return asNumber;
	}
}
