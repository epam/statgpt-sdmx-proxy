package io.sdmx.fusion.reporttemplate.engine;

import org.apache.poi.ss.usermodel.HorizontalAlignment;
import io.sdmx.fusion.reporttemplate.api.model.template.IInstructionSheetTextArea;
import io.sdmx.fusion.reporttemplate.api.model.template.IReportingTemplateInstructionSheet;
import io.sdmx.utils.xlsx.api.model.FusionCell;
import io.sdmx.utils.xlsx.api.model.ICellStyle;
import io.sdmx.utils.xlsx.api.model.IFontStyle;
import io.sdmx.utils.xlsx.api.model.IFontStyle.FONT_COLOUR;
import io.sdmx.utils.xlsx.api.model.IFusionExcelStyles;
import io.sdmx.utils.xlsx.api.model.SheetProperties;
import io.sdmx.utils.xlsx.api.model.SimpleExcelWriter;
import io.sdmx.utils.xlsx.model.CellImpl;
import io.sdmx.utils.xlsx.model.FontStyle;
import io.sdmx.utils.xlsx.model.FusionCellStyle;
import io.sdmx.utils.xlsx.model.SheetPropertiesImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * 
 *
 */
public class ExcelInstructionSheetWriter {


	/**
	 * Instruction sheet built by:
	 * 1. Creating Worksheet (password protection optional)
	 * 2. Make column A thin to provide a left margin
	 * 3. Skip row 1 to provide a top margin
	 * 4. White out all the cells on the worksheet in the visible space (40 across and 50 down to be sure)
	 * 
	 * 
	 * @param sheet
	 * @param writer
	 */
	public static void writeInstructionSheet(IReportingTemplateInstructionSheet sheet, SimpleExcelWriter writer, IFusionExcelStyles styles, String sheetPassword) {
		setUpSheet(sheet, writer, styles, sheetPassword);
		//3. Skip the first row (0) start on row 1
		int rowIdx = 1;
		int colIdx = 1;
		
		int width = 1;
		for(IInstructionSheetTextArea textArea : sheet.getTextArea()) {
			if(textArea.getColWidth() > width) {
				width = textArea.getColWidth();
			}
		}
		
		if(ObjectUtil.validString(sheet.getTitle())) {
			FusionCell cell = new CellImpl(colIdx, rowIdx, sheet.getTitle());
			cell.setColspan(width);
			
			IFontStyle font = new FontStyle(FONT_COLOUR.WHITE, 20, true);
			font.setFontName("Segoe UI");
			ICellStyle cellStyle = new FusionCellStyle("is_title");
			cellStyle.setFontStyle(font);
			cellStyle.setHexColour("#C00000");
			cellStyle.setTextAlignment(HorizontalAlignment.CENTER);
			cell.setStyle(cellStyle);
			
			writer.writeCell(cell);
			rowIdx++;
			writer.setRowHeight(rowIdx, 9);
			rowIdx++;
		}
		for(IInstructionSheetTextArea textArea : sheet.getTextArea()) {
			FusionCell cell = new CellImpl(colIdx, rowIdx, textArea.getContent());
			cell.setMarkdown(true);
			cell.setColspan(textArea.getColWidth());
			cell.setRowspan(textArea.getColHeight());
			cell.setStyle(textArea.getContentStyle());
			cell.setBorderStyle(textArea.getBorderStyle());
			writer.writeCell(cell);
			rowIdx = rowIdx + textArea.getColHeight();
			writer.setRowHeight(rowIdx, 9);
			rowIdx++;
		}
	}

	/**
	 * 1. Creating Worksheet (password protection optional)
	 * 2. Make column A thin to provide a left margin
	 * 3. White out all the cells on the worksheet in the visible space (40 across and 50 down to be sure)
	 */
	private static void setUpSheet(IReportingTemplateInstructionSheet sheet, SimpleExcelWriter writer, IFusionExcelStyles styles, String sheetPassword) {
		//Create Worksheet
		SheetProperties properties = new SheetPropertiesImpl(sheet.getName());
		properties.setSheetPassword(sheetPassword); 

		//2. Made Column A Thin
		properties.addColumnWidth(0, 800);  //800=22pixels 14chars=100px   7.1px per char=258
//		properties.setDefaultRowHeight(19);

		writer.createWorkSheet(properties);
		
		int toRow = 15;
		for(IInstructionSheetTextArea textArea : sheet.getTextArea()) {
			toRow += textArea.getColHeight()+1;
		}
		if(toRow < 50) {
			toRow = 50;
		}
		
		//4. White out all cells in visible space
		writer.writeCells(0, toRow, 0, 40, styles.getBackgroundColourStyle());
	}

}
