package io.sdmx.fusion.reporttemplate.engine;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.manager.structure.ConstraintRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplate;
import io.sdmx.fusion.reporttemplate.model.reporttemplate.ReportingTemplateImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * This output is built form a report template, the template series is derived from the constraints, not the data.
 * <p/>
 * The template is populated with observations from the written data.
 * <p/>
 * Worksheets are included even if they do not have data written for them.
 * <p/>
 * The startDataset method MUST have a provision agreement written for it, unless:
 * a) A Data Provider is passed in on the constructor
 * b) There is only one Provision Agreement for the given Dataflow
 */
public class ReportTemplateFullDataWriterEngine extends AbstractReportTemplateDataWriter {
	private ReportingTemplateBean reportTemplateBean;
	private ConstraintRetrievalManager constraintRetrievalManager;
	private IURNSingle<DataProviderBean> providerRef;
	private Map<IURNMaintainable<DataflowBean>, List<Observation>> observationsForFlow = new HashMap<>();
	
	private ReportingTemplate reportTemplate;
	
	public ReportTemplateFullDataWriterEngine(ReportingTemplateBean reportTemplateBean, 
											SdmxBeanRetrievalManager beanRetrievalManager,
											ConstraintRetrievalManager constraintRetrievalManager,
										  SdmxSuperBeanRetrievalManager superBeanRetrievalManager, 
										  IURNSingle<DataProviderBean> providerRef,
										  OutputStream out) {
		super(beanRetrievalManager, superBeanRetrievalManager, true, out);
		this.reportTemplateBean = reportTemplateBean;
		this.constraintRetrievalManager = constraintRetrievalManager; 
		this.providerRef = providerRef;
	}
	
	@Override
	protected ReportingTemplateBean getReportTemplateBean() {
		return reportTemplateBean;
	}



	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		super.startDataset(structures, header, datasetAttributes, annotations);
		if(providerRef == null && structures.getProvisionAgreement() == null) {
			terminateWriter();
			throw new SdmxSemmanticException("Can not generate Report Template, unknown Data Provider");
		}
		if(providerRef == null) {
			providerRef = structures.getProvisionAgreement().getDataproviderRef().getReference();
		}
	}

	@Override
	protected void flushWorksheet() {
		if(this.flow != null && ObjectUtil.validCollection(this.obsList)) {
			if(flows != null) {
				for(DataflowBean flow : flows) {
					observationsForFlow.put(flow.getURN(), this.obsList);
				}
			} 
			observationsForFlow.put(flow.getURN(), this.obsList);
		}
		this.obsList = new ArrayList<>();
	}

	@Override
	protected void closeInternal() {
		boolean hasData = false;
		for(IURNMaintainable<DataflowBean> sRef : observationsForFlow.keySet()) {
			if(ObjectUtil.validCollection(observationsForFlow.get(sRef))) {
				hasData = true;
				break;
			}
		}
		if(!hasData) {
			throw new SdmxNoResultsException("No data for the report template '"+reportTemplateBean.getShortURN()+"' was written");
		}
	
		reportTemplate = new ReportingTemplateImpl(reportTemplateBean, 
				  beanRetrievalManager, 
				  this.superBeanRetrievalManager, 
				  constraintRetrievalManager, 
				  providerRef, 
				  observationsForFlow,
				  null, 
				  -1);
	}

	@Override
	protected ReportingTemplate getReportTemplate() {
		return reportTemplate;
	}
}
