package io.sdmx.fusion.reporttemplate.model.worksheet;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;

public class TransientHierarchy {
	private CodeBean codeBean;
	private Set<TransientHierarchy> childCodes = new HashSet<TransientHierarchy>();
	private boolean isDisplayOnly;

	public TransientHierarchy(CodeBean codeBean, boolean isDisplayOnly) {
		this.codeBean = codeBean;
	}
	
	public TransientHierarchy addChild(CodeBean code, boolean isDisplayOnly) {
		TransientHierarchy h = new TransientHierarchy(code, isDisplayOnly);
		childCodes.add(h);
		return h;
	}

	public CodeBean getCodeBean() {
		return codeBean;
	}

	public Set<TransientHierarchy> getChildCodes() {
		return childCodes;
	}

	public boolean isDisplayOnly() {
		return isDisplayOnly;
	}
}
