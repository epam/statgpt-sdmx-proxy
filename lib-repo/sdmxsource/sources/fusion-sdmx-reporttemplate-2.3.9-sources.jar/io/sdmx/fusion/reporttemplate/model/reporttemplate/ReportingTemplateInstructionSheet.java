package io.sdmx.fusion.reporttemplate.model.reporttemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.fusion.reporttemplate.api.model.template.IInstructionSheetTextArea;
import io.sdmx.fusion.reporttemplate.api.model.template.IReportingTemplateInstructionSheet;
import io.sdmx.fusion.reporttemplate.model.worksheet.InstructionSheetTextArea;
import io.sdmx.utils.xlsx.api.model.ICellStyle;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionSheetBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionTextBean;

/**
 *  Immutable implementation of IReportingTemplateInstructionSheet
 *
 */
public class ReportingTemplateInstructionSheet implements IReportingTemplateInstructionSheet {
	private String name;
	private String title;
	private List<IInstructionSheetTextArea> textArea = new ArrayList<>();
	
	
	/**
	 * Build from bean and style of each content area
	 * @param instructionSheet
	 * @param contentStyle
	 */
	public ReportingTemplateInstructionSheet(ReportTemplateInstructionSheetBean instructionSheet, ICellStyle contentStyle) {
		this.name = instructionSheet.getName();
		this.title = instructionSheet.getTitle();
		for(ReportTemplateInstructionTextBean currentInstruction : instructionSheet.getInstructions()) {
			textArea.add(new InstructionSheetTextArea(currentInstruction, contentStyle));
		}
	}

	public ReportingTemplateInstructionSheet(String name, String title, List<IInstructionSheetTextArea> textArea) {
		this.name = name;
		this.title = title;
		if(textArea == null) {
			textArea = Collections.EMPTY_LIST;	
		} else {
			this.textArea = Collections.unmodifiableList(textArea);
		}
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getTitle() {
		return title;
	}
	
	@Override
	public List<IInstructionSheetTextArea> getTextArea() {
		return textArea;
	}
	
}
