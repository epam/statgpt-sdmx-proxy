package io.sdmx.fusion.reporttemplate.api.model.template;

import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.utils.xlsx.api.model.IExcelWorksheet;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateConditionalAttributeBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;

public interface ReportingTemplateWorksheet extends IExcelWorksheet {

	/**
	 * @return the parent ReportingTemplate to which this worksheet belongs
	 */
	ReportingTemplate getReportingTemplate();
	
	/**
	 * Max width, measured in characters which roughly relates to excels number system (not pixels, the one with no name when resizing a column)
	 * @return max width of the columns, or null if not specified.
	 */
	Integer getColMaxWidth();
	
	/**
	 * @return the data structure for this worksheet
	 */
	DataStructureBean getDataStructureBean();
	
	/**
	 * @return the dataflow for this worksheet
	 */
	DataflowBean getDataflowBean();
	
	/**
	 * @return the provision agreement for this worksheet - may be null
	 */
	ProvisionAgreementBean getProvisionAgreementBean();
	
	/**
	 * @return a set of validation schemes which are related to the Dataflow
	 */
	Set<ValidationSchemeBean> getValidationSchemes();
	
	/**
	 * @return true if there are time periods which need to be created for each series
	 */
	boolean hasTimePeriods();
	
	/**
	 * Returns a hierarchy used for a ValidationRule
	 * @param urn
	 * @return Hierarchy or null if none found that match the URN
	 */
	HierarchyBean getHierarchy(String urn);
	
	/**
	 * @return the series that will be generated for this report template
	 */
	ReportingTemplateSeries getSeries();
	
	/**
	 * @return the dimension, mapped to code - these represent the fixed values for this worksheet
	 */
	Map<ReportingTemplateComponent, EnumeratedItemBean> getFixedDimensions();
	
	/**
	 * Returns the dimensions to include in the worksheet in the header, allowing the user to enter its value separately for the whole table.
	 * This method may not return null
	 * @return a Map
	 */
	Map<String, ReportTemplateVariableDimension> getVariableDimensions();
	
	/**
	 * Returns a map of attributes mapped to code. These represent the fixed values for this worksheet
	 * @return a Map
	 */
	Map<ReportingTemplateComponent, EnumeratedItemBean> getFixedAttributes();
	
	/**
	 * Returns a Set of attributes to include in the report (the same table as the observation table) - this will not return null
	 * @return a Set
	 */
	Set<ReportingTemplateComponent> getAttributesInReport();
	
	/**
	 * Returns a Set of observation attributes to include in the worksheet as a separate table - this will not return null
	 * @return a Set
	 */
	Set<ReportingTemplateComponent> getObsAttributesInSeparateTable();
	
	/**
	 * Returns a Set of series attributes to include in the worksheet as a separate table - this will not return null
	 * @return a Set
	 */
	Set<ReportingTemplateComponent> getSeriesAttributesInSeparateTable();
	
	/**
	 * Returns a Set of observation  attributes to include in the worksheet as a separate worksheet - this will not return null
	 * @return a Set
	 */
	Set<ReportingTemplateComponent> getObsAttributesInSeparateWorksheet();
	
	/**
	 * @return the attribute which is represented by colour, or null if none are represented by colour
	 */
	ReportingTemplateColouredAttribute getColourAttribute();
	
	/**
	 * Returns the conditional rules for the attribute with the given id
	 * @param attributeId
	 * @return a List
	 */
	List<ReportingTemplateConditionalAttributeBean> getConditionalAttributes();
	
	/**
	 * @return the Dimensions that make up the Table Rows - along with additional metadata, including the Coding Scheme
	 */
	List<ReportingTemplateDimension> getTableRows(boolean includeTime);
	
	/**
	 * Returns a List of Table Columns - these make up the table heading
	 * @return a List
	 */
	List<ReportingTemplateDimension> getTableColumns(boolean includeTime);
	
	/**
	 * @param dim
	 * @return true if the dimension is used in the table header
	 */
	boolean isInTableHead(DimensionBean dim);
	
	/**
	 * @param dim
	 * @return true if the dimension is used in the table row
	 */
	boolean isInTableRow(DimensionBean dim);
	
	/**
	 * @param dim
	 * @return true if the dimension id is marked for exclusion if fixed
	 */
	boolean isExcludeDimension(String dimId);
	
	/**
	 * @return an int array of dimension indexes that make up the table columns (thead)
	 */
	int[] getTableColumnDimensions(boolean includeTime);
	

	/**
	 * @return an int array of dimension indexes that make up the table rows (tbody)
	 */
	int[] getTableRowDimensions(boolean includeTime);
	
	/**
	 * If not null, specifies the number of decimal places to round any numerical data to
	 * @return an Integer
	 */
	Integer getRoundDecimals();
	
	/**
	 * Returns the colour for the observation key
	 * @param obsKey
	 * @return a String of the colour
	 */
	String getObsColour(String[] obsKey);
	
	/**
	 * True will include a table at the end of the worksheet which duplicates the observation table, but includes
	 * checking formula to ensure any validation scheme rules are checked, i.e A1 > B1 will result in error in the checking table if not true.
	 * <p/>
	 * A checking table will not be output if there are no formula relevent to the table
	 * @return
	 */
	boolean includeFormulaCheckingTable();
	
	/**
	 * @return the series (or null) for the series key, in format [A,B,C,D]
	 */
	Keyable getSeries(String[] seriesKey);
	
	/**
	 * @return the observation (or null) for the observation key, in format [A,B,C,D,2008]
	 */
	Observation getObservation(String[] obsKey);
	
}
