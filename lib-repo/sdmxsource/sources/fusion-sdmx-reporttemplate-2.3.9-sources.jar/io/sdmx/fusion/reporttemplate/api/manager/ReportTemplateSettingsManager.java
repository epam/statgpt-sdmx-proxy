package io.sdmx.fusion.reporttemplate.api.manager;

/**
 * Allows the specification and retrieval of any settings that affect how Reporting Templates are created. 
 */
public interface ReportTemplateSettingsManager {

	/**
	 * Sets the maximum number of observations that can be returned in a Reporting Template.
	 * @param limit
	 */
	void setMaxObsLimit(int limit);
	
	/**
	 * Returns the maximum number of observations that can be returned in a Reporting Template. 
	 * @return
	 */
	int getMaxObsLimit();
	
}
