package io.sdmx.fusion.reporttemplate.api.model.pivottable;

import java.util.List;

/**
 * Describes a checking formula for a table cell
 *
 */
public interface ICellFormula {
	


	/**
	 * Returns the expression in the format a0 + a1 + a2 - (a3*a4);
	 * @return
	 */
	String getExpression();
	
	/**
	 * Returns the table cells that provide the inputs to the expression 
	 * @return
	 */
	List<TableCell> getExpressionInputs();
	
}
