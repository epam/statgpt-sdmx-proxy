package io.sdmx.fusion.reporttemplate.model.worksheet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.ICellFormula;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.TableCell;

public class TableCellFormula implements ICellFormula {
	
	private String expression;
	private List<TableCell> expressionInputs;

	public TableCellFormula(String expression, List<TableCell> expressionInputs) {
		if(expression == null) {
			throw new SdmxException("TableCellChecking missing required argument, expression");
		}
		if(expressionInputs == null) {
			expressionInputs = new ArrayList<>();
		}
		this.expression = expression;
		this.expressionInputs = Collections.unmodifiableList(expressionInputs);
	}

	@Override
	public String getExpression() {
		return expression;
	}

	@Override
	public List<TableCell> getExpressionInputs() {
		return expressionInputs;
	}

	@Override
	public String toString() {
		return "="+expression;
	}
}
