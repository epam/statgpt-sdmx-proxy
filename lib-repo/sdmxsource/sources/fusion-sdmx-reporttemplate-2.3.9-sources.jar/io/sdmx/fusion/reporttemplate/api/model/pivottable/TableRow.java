package io.sdmx.fusion.reporttemplate.api.model.pivottable;

import java.util.List;

import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateSeries;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateWorksheet;

/**
 * Represents a table row in excel
 */
public interface TableRow {

	/**
	 * Returns true if the Row is in the thead section, false if in the tbody
	 * @return
	 */
	boolean isTableHead();
	
	/**
	 * @param presentational set to true if this row has no cells with data
	 */
	void setPresentational(boolean presentational);
	
	/**
	 * @return true if this row is for presentational purposes only (there are no cells with data in this row)
	 */
	boolean isPresentational();
	
	/**
	 * Returns the row key which is an array of dimension id values that represents the row, for example ["UK","M","2009"] any missing dimensions (i.e they appear
	 * in the columns, are presented as null entries in the array e.g. ["UK",null ,"2009"] 
	 * @return
	 */
	String[] getRowKey();
	
	/**
	 * Returns the table cell at the given index
	 * @param idx
	 * @return
	 */
	TableCell getCellAtIndex(int idx);
	
	/**
	 * Returns the table cells
	 * @return
	 */
	List<TableCell> getTableCells();
	
	/**
	 * Adds a cell as a title cell, for example 'Counter Part Country' or 'Observation'
	 * @param value the cell value, to be presented to the user (the label)
	 * @param colspan the number of columns to merge to the right
	 * @param rowspan the number of rows to merge below
	 * @return
	 */
	TableCell addHeaderTitle(String value, int colspan, int rowspan);
	
	/**
	 * Adds a header value for a column, for example United Kingdom
	 * @param cellIndex
	 * @param value
	 * @param colspan
	 * @param rowspan
	 * @param partialKey - the partial key associated for this cell - for example [A,UK,null,null]
	 * @return
	 */
	TableCell addHeaderColValue(String value, int colspan, int rowspan, String[] partialKey);

	/**
	 * Adds a header value for a column, for example Derivatives
	 * @param value
	 * @param colspan
	 * @param rowspan
	 * @param partialKey - the partial key associated for this cell - for example [null, null,D,null]
	 * @return
	 */
	TableCell addHeaderRowValue(String value, int colspan, int rowspan, String[] partialKey);

	/**
	 * Adds an observation cell the cell will automatically be assigned with an index, which is a + 1 increment from the proceeding cell
	 * The cell will automatically be assigned with a cell series key, which will be determined from the combination of the key of the proceeding cell and parent cell
	 * 
	 * @return
	 */
	TableCell addObsCell(ReportingTemplateWorksheet series);
	
	/**
	 * Adds an observation cell with a value, or if null then no value
	 * @param value
	 * @return
	 */
	TableCell addObsCell(String value);
	
	/**
	 * Adds an observation attribute cell the cell will automatically be assigned with an index, which is a + 1 increment from the proceeding cell
	 * The cell will automatically be assigned with a cell series key, which will be determined from the combination of the key of the proceeding cell and parent cell
	 * 
	 * @return
	 */
	TableCell addObsAttribute(ReportingTemplateWorksheet ws, ReportingTemplateSeries series, String attributeId, int colspan);
}
