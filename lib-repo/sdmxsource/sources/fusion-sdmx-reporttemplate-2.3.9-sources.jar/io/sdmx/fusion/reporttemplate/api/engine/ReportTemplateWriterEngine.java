package io.sdmx.fusion.reporttemplate.api.engine;

import java.io.OutputStream;

import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplate;

/**
 * Responsible for writing an Report form based on on the Report Template
 */
public interface ReportTemplateWriterEngine {

	/**
	 * Writes the report form to the output Stream
	 * @param reportingTemplate
	 * @param includeMetadataForReading if true then metadata will be added to the workbook so it can be re-read back in.  If false the metadata will be exlucded
	 * @param password if supplied a non-null password then this will be used to protect the workbook
	 * @param out the output stream to write to
	 */
	void writeReportForm(ReportingTemplate reportingTemplate, boolean includeMetadataForReading, String password, OutputStream out);
	
}
