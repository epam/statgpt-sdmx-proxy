package io.sdmx.fusion.reporttemplate.api.model.pivottable;

import java.util.List;
import java.util.SortedSet;

import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;

/**
 * Describe the layout of the Excel table in terms of rows, and columns
 */
public interface PivotTableModel {
	
	enum TABLE_TYPE {
		OBS,
		OBS_ATTRIBUTE,
		SERIES_ATTRIBUTE,
		CHECKING
	}

	/**
	 * @return a sorted set of validation rules used in this model (sorted by rule Id)
	 */
	SortedSet<ValidationRuleBean> getValidationRules();
	
	/**
	 * @return true if the table has dimensions in the Header, iterating values across the columns
	 */
	boolean hasHeaderDimensions();

	/**
	 * @return true if the table has dimensions in the Rows, iterating down across the rows
	 */
	boolean hasRowDimensions();
	
	/**
	 */
	TABLE_TYPE getTableType();
	
	/**
	 * @return the attribute Ids which are included in this table
	 */
	String[] getAttributeIds();
	
	/**
	 * @return the size (number of characters) for each column in the model
	 */
	int[] getColumnWidths();

	
	/**
	 * @return a List of the table header rows
	 */
	List<TableRow> getTableRows();

	/**
	 * Adds a table row to the model
	 * @param isHeaderRow
	 * @return the added TableRow
	 */
	TableRow addTableRow(boolean isHeaderRow);
	
	/**
	 * @return a count of the total number of columns
	 */
	default int getColumnCount() {
		int colCount = 0;
		if(this.getTableRows().size() > 0) {
			for(TableCell tCell : this.getTableRows().get(0).getTableCells()) {
				colCount += tCell.getColspan();
			}
		}
		return colCount;
	}

	/**
	 * @return a count of the total number of rows that make up the head section
	 */
	default int getTHeadRowCount() {
		int i=0;
		for(TableRow tR : this.getTableRows()) {
			if(tR.isTableHead()) {
				i++;
			} else {
				return i;
			}
		}
		return i;
	}
}