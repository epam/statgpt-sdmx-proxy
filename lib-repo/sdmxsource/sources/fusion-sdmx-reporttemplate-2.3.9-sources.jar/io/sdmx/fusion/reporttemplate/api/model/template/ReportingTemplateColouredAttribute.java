package io.sdmx.fusion.reporttemplate.api.model.template;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;

/**
 * Represents an Attribute which is represented in the excel workbook by colour
 */
public interface ReportingTemplateColouredAttribute {
	
	/**
	 * Returns the attribute
	 * @return
	 */
	ReportingTemplateComponent getAttribute();

	/**
	 * Returns a map of attribute codes along with the colour that represent them
	 * @return
	 */
	Map<EnumeratedItemBean, String> getAttributeColorKey();
	
	/**
	 * @param hex
	 * @return code for the hex
	 */
	EnumeratedItemBean getColorCode(String hex);
	
	/**
	 * Returns the colour represented by the given series key
	 * @param seriesKey
	 * @return
	 */
	String getColour(String[] seriesKey);
	
}
