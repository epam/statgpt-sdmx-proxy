package io.sdmx.fusion.reporttemplate.model.reporttemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_DISPLAY;
import io.sdmx.api.sdmx.manager.structure.ConstraintRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ConstrainableBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateConditionalAttributeBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.constraint.ContentConstraintModel;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataflowSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.api.sdmx.model.superbeans.hierarchy.HierarchySuperBean;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportTemplateVariableDimension;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplate;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateColouredAttribute;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateComponent;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateDimension;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateSeries;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateWorksheet;
import io.sdmx.im.constraint.ContentConstraintModelImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class ReportingTemplateWorksheetImpl implements ReportingTemplateWorksheet {
	private static final Logger LOG = LoggerFactory.getLogger(ReportingTemplateWorksheetImpl.class);

	private ProvisionAgreementBean provisionBean;
	private DataflowBean dataflowBean;
	private DataStructureBean dataStructureBean;
	private String sheetName;

	private ReportingTemplateSeries reportingTemplateSeries;

	private List<ReportingTemplateDimension> rows;
	private List<ReportingTemplateDimension> cols;


	private List<ReportingTemplateDimension> rowsNoTime;
	private List<ReportingTemplateDimension> colsNoTime;
	private Map<String, ReportTemplateVariableDimension> variableDimensions;
	private Set<ReportingTemplateComponent> obsAttributesInReport = new TreeSet<>();
	private Map<ReportingTemplateComponent, EnumeratedItemBean> fixedDims;
	private Set<ReportingTemplateComponent> obsAttributesInSeparateTable = new TreeSet<>();
	private Set<ReportingTemplateComponent> obsAttributesInSeparateWorksheet = new TreeSet<>();
	private Set<ReportingTemplateComponent> seriesAttributesInSeparateTable = new TreeSet<>();
	private Map<ReportingTemplateComponent, EnumeratedItemBean> fixeAttrs;
	private List<ReportingTemplateConditionalAttributeBean> conditionalObsAttributes;

	private Set<String> dimRows = new HashSet<>();
	private Set<String> dimCols = new HashSet<>();
	private Set<String> excludeDimensions = new HashSet<>();


	private Set<ValidationSchemeBean> validationSchemes = new HashSet<>();
	private Map<String, HierarchyBean> hierarchyMap = new HashMap<>(); //Used to store HierarchyBean for validation

	private ReportingTemplateColouredAttribute colouredAttribute;

	private int maxObsLimit;   // Do not generate more then this number of observation cells
	private Integer roundDecimals;

	private List<String> timePeriods;

	private ReportingTemplate parent;
	private boolean includeFormulaCheckingTable;
	private Map<String, Observation> obsMap = new HashMap<>();
	private Map<String, Keyable> keyMap = new HashMap<>();
	private int keyLength;

	private ReportingTemplateWorksheetBean ws;

	/**
	 * Constructor where the series codes and time periods are known
	 * @param ws
	 * @param dsdSb
	 * @param seriesShortCodes
	 * @param timePeriods
	 * @param sbBeanRetrievalManager
	 */
	public ReportingTemplateWorksheetImpl(
			ReportingTemplate parent,
			ReportingTemplateWorksheetBean ws,
			ProvisionAgreementBean provision,
			DataflowBean dataflowBean,
			DataStructureBean dsd,
			List<Observation> observations,
			SdmxBeanRetrievalManager beanRetrievalManager,
			SdmxSuperBeanRetrievalManager sbBeanRetrievalManager) {
		this.provisionBean = provision;
		this.dataflowBean = dataflowBean;
		this.dataStructureBean = dsd;
		this.ws = ws;
		setParent(parent);
		readWorksheetBeanProperties(ws, beanRetrievalManager);
		Map<String, String> fixedDimenisons = new HashMap<>();
		DataStructureSuperBean dsdSb = sbBeanRetrievalManager.getDataStructureSuperBean(dsd.getURN());

		String[] dimIds = dsdSb.getBuiltFrom().getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION).stream().map(e -> e.getId()).toArray(String[]::new);
		int[] variableDims = new int[dimIds.length];
		for(int i=0; i < dimIds.length; i++) {
			variableDims[i] = i;
		}

		//only store series if series attributes are in the output
		boolean storeSeries = false;
		for(String attributeId : ws.getSeparateAttributes()) {
			AttributeBean attr = dsd.getAttribute(attributeId);
			if(attr != null && attr.getAttachmentLevel() == ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP) {
				storeSeries = true;
				break;
			}
		}

		Set<String> reportedTimePeriods = new HashSet<>();
		Set<String[]> validSeries = new HashSet<>();
		for(Observation currentObs : observations) {
			if(storeSeries) {
				keyMap.put(currentObs.getSeriesKey().getShortCode(), currentObs.getSeriesKey());
			}

			obsMap.put(currentObs.getShortCode(), currentObs);

			String[] shortCodeSplit;
			if (currentObs.hasObsTime()) {
			    // FR-4696 Do not split the time element
			    shortCodeSplit = SeriesUtil.splitKey(currentObs.getShortCode(), dsd.getDimensions().size());
			} else {
			    // Split on everything
			    shortCodeSplit = SeriesUtil.splitKey(currentObs.getShortCode());
			}
			keyLength = shortCodeSplit.length;
			reportedTimePeriods.add(currentObs.getDimensionValue());
			validSeries.add(shortCodeSplit);

			//Populate fixedDimensions Map
			for(int variableDim : variableDims) {
				String dimId = dimIds[variableDim];
				String dimVal = fixedDimenisons.get(dimId);
				if(dimVal == null) {
					fixedDimenisons.put(dimId, shortCodeSplit[variableDim]);
				} else if(!shortCodeSplit[variableDim].equals(dimVal)) {
					//No longer a variable dimension
					//Remove from Map
					fixedDimenisons.remove(dimId);

					//Remove from Array
					int[] newVariableDims = new int[variableDims.length - 1];

					for(int i=0, j=0; i < variableDims.length; i++) {
						if(variableDims[i] == variableDim) {
							continue;
						}
						newVariableDims[j] = variableDims[i];
						j++;
					}
					variableDims = newVariableDims;
				}
			}
		}
		timePeriods = new ArrayList<>();
		for(String timePeriod : reportedTimePeriods) {
			timePeriods.add(timePeriod);
		}
		Collections.sort(timePeriods);
		this.timePeriods = Collections.unmodifiableList(timePeriods);
		this.buildTemplateStructure(ws, dsdSb, validSeries, new HashMap<>(), sbBeanRetrievalManager, fixedDimenisons, false);
	}


	/**
	 * Builds a ReportingTemplateWorksheet. However if there are no series in this worksheet for the user, then null is returned.
	 * @param ws
	 * @param obs optional list of observations to pre-populate the worksheet with
	 * @param beanRetrievalManager
	 * @param sbBeanRetrievalManager
	 * @param constraintRetrievalManager
	 * @param provisionsForFlow
	 * @param maxObs
	 * @return
	 */
	static ReportingTemplateWorksheet getInstance(ReportingTemplate parent,
			ReportingTemplateWorksheetBean ws,
			List<Observation> obs,
			SdmxBeanRetrievalManager beanRetrievalManager,
			SdmxSuperBeanRetrievalManager sbBeanRetrievalManager,
			ConstraintRetrievalManager constraintRetrievalManager,
			List<String> timePeriods,
			TIME_FORMAT timeFormat,
			Map<String, ProvisionAgreementBean> provisionsForFlow,
			int maxObs) {
		ReportingTemplateWorksheetImpl rt = new ReportingTemplateWorksheetImpl(parent, ws, obs, beanRetrievalManager, sbBeanRetrievalManager, constraintRetrievalManager, timePeriods, timeFormat, provisionsForFlow, maxObs);
		if(rt.reportingTemplateSeries == null) {
			return null;
		}
		return rt;
	}


	/**
	 * Package protected constructor
	 */
	private ReportingTemplateWorksheetImpl(ReportingTemplate parent,
			ReportingTemplateWorksheetBean ws,
			List<Observation> observations,
			SdmxBeanRetrievalManager beanRetrievalManager,
			SdmxSuperBeanRetrievalManager sbBeanRetrievalManager,
			ConstraintRetrievalManager constraintRetrievalManager,
			List<String> timePeriods,
			TIME_FORMAT timeFormat,
			Map<String, ProvisionAgreementBean> provisionsForFlow,
			int maxObs) {
		setParent(parent);
		this.ws = ws;

		ICrossReferenceBean<DataflowBean> flowRef = ws.getDataflow();
		LOG.debug("Build Reporting Template from Dataflow: "+flowRef.getTargetUrn());
		DataflowSuperBean dfSb = sbBeanRetrievalManager.getDataflowSuperBean(flowRef.getReference());
		dataflowBean = dfSb.getBuiltFrom();
		readWorksheetBeanProperties(ws, beanRetrievalManager);
		this.timePeriods = Collections.unmodifiableList(timePeriods);
		this.maxObsLimit = maxObs;
		if(observations != null) {
			for(Observation currentObs : observations) {
				if(keyLength == 0) {
					keyLength = SeriesUtil.splitKey(currentObs.getShortCode()).length;
				}
				obsMap.put(currentObs.getShortCode(), currentObs);
			}
		}

		LOG.debug("Dataflow Reference: "+dataflowBean);
		ConstrainableBean constrainable = null;
		if(provisionsForFlow != null) {
			this.provisionBean = provisionsForFlow.get(dataflowBean.getUrn());
			constrainable = provisionBean;
		}
		if(this.provisionBean == null) {
			LOG.info("Can not create Worksheet '"+sheetName+"' for Provider as they have no Provision Agreement for Dataflow '"+dataflowBean.getUrn()+"");
			return;
		}
		if(constrainable == null) {
			constrainable = dataflowBean;
		}
		dataStructureBean = dfSb.getDataStructure().getBuiltFrom();

		Set<ContentConstraintBean> constraints = constraintRetrievalManager.getAllConstraintsDefiningAllowedData(constrainable);

		Map<String, String> fixedDimenisons = new HashMap<>();
		Map<String, Set<String>> variableDimensionsValidCodes = new HashMap<>();
		Set<String[]> validSeries = getValidSeries(ws, dfSb.getDataStructure(), constraints, fixedDimenisons, variableDimensionsValidCodes, timeFormat);
		if(validSeries.size() ==  0) {
			return;
		}
		LOG.info("Report Template '"+sheetName+"' Worksheet Size '"+validSeries.size()+"' Series");
		buildTemplateStructure(ws, dfSb.getDataStructure(), validSeries, variableDimensionsValidCodes, sbBeanRetrievalManager, fixedDimenisons, true);
	}


	private void setParent(ReportingTemplate parent) {
		this.parent = parent;
		this.includeFormulaCheckingTable = parent.includeFormulaCheckingSummary();

	}

	private void readWorksheetBeanProperties(ReportingTemplateWorksheetBean ws,
			SdmxBeanRetrievalManager beanRetrievalManager) {
		this.roundDecimals = ws.getRoundDecimals();
		this.sheetName = ws.getId();
		excludeDimensions = ws.getExcludeDimensions();
		this.conditionalObsAttributes = ws.getConditionalAttributes();

		for(ValidationSchemeBean validationScheme : beanRetrievalManager.getMaintainableBeans(URN.builder().build(ValidationSchemeBean.class))) {
			if(validationScheme.getAttachment().getTargetUrn().equals(dataflowBean.getUrn())) {
				for(ValidationRuleBean valRule : validationScheme.getItems()) {
					if(valRule.hasValidationHierarchy()) {
						ICrossReferenceBean<HierarchyBean> constraintRef = valRule.getValidationHierarchy().getHierarchyReference();
						HierarchyBean hierarchy = beanRetrievalManager.getBean(constraintRef.getReference());
						if(hierarchy != null) {
							hierarchyMap.put(hierarchy.getUrn(), hierarchy);
						} else {
							LOG.error("ValidationRule '"+valRule.getUrn()+"' references unresolvable constraint '"+constraintRef.getTargetUrn()+"'");
						}
					}
				}
				this.validationSchemes.add(validationScheme);
			}
		}

	}

	private void buildTemplateStructure(ReportingTemplateWorksheetBean ws,
			DataStructureSuperBean dsdSb,
			Set<String[]> validSeries,
			Map<String, Set<String>> variableDimensionsValidCodes,
			SdmxSuperBeanRetrievalManager sbBeanRetrievalManager,
			Map<String, String> fixedDimenisons,
			boolean outputDefaultColourCodes) {
		Set<Integer> variableIdexes = new HashSet<>();
		for(String dimId : ws.getVariableDimensions()) {
			int idx = dataStructureBean.getDimension(dimId).getPosition() - 1;
			variableIdexes.add(idx);
		}
		int i=0;
		Map<Integer, String> fixedDimensionsValues = new HashMap<>();
		Map<Integer, String> dimIdx = new HashMap<>();
		for(DimensionBean dim : dataStructureBean.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION)) {
			fixedDimensionsValues.put(i, null);
			dimIdx.put(i, dim.getId());
			i++;
		}

		//Process all series to determine if any are fixed based on the aplication of the constraints
		for(String[] currentSeries : validSeries) {
			if(fixedDimensionsValues.keySet().size() == 0) {
				break;
			}
			Set<Integer> removeSet = new HashSet<>();
			removeSet.addAll(variableIdexes);
			for(Integer currentDimIdx : fixedDimensionsValues.keySet()) {
				String codeId = currentSeries[currentDimIdx];
				String preVal = fixedDimensionsValues.get(currentDimIdx);
				if(preVal == null) {
					fixedDimensionsValues.put(currentDimIdx, codeId);
				} else if(!codeId.equals(preVal)) {
					removeSet.add(currentDimIdx);
				}
			}
			if(removeSet != null) {
				for(Integer toRemove : removeSet) {
					fixedDimensionsValues.remove(toRemove);
				}
			}
		}
		for(Integer currentDimIdx : fixedDimensionsValues.keySet()) {
			fixedDimenisons.put(dimIdx.get(currentDimIdx), fixedDimensionsValues.get(currentDimIdx));
		}

		reportingTemplateSeries = new ReportingTemplateSeriesImpl(validSeries, this.hasTimePeriods(), variableIdexes);
		fixedDims = getFixedDimensions(dsdSb, fixedDimenisons, ws);//  getFixedAttributess(dsdSb, ws.getFixedDimensions(), ws);
		fixeAttrs = getFixedAttributess(dsdSb, ws.getFixedAttributes(), ws);
		rows = getRowOrCols(dsdSb, ws.getTableRows(), fixedDimenisons, ws, validSeries, sbBeanRetrievalManager);
		rowsNoTime = new ArrayList<>();
		for(ReportingTemplateDimension dim : rows) {
			if(dim.getDimension().getComponent().getId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
				continue;
			}
			rowsNoTime.add(dim);
		}
		cols = getRowOrCols(dsdSb, ws.getTableCols(), fixedDimenisons, ws, validSeries, sbBeanRetrievalManager);
		colsNoTime = new ArrayList<>();
		for(ReportingTemplateDimension dim : cols) {
			if(dim.getDimension().getComponent().getId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
				continue;
			}
			colsNoTime.add(dim);
		}
		variableDimensions = new HashMap<>();
		for(String dimId : ws.getVariableDimensions()) {
			if(fixedDimenisons.containsKey(dimId)) {
				continue;
			}
			ReportingTemplateComponent reportingTemplateComponent = new ReportingTemplateComponentImpl(ws, dsdSb, dimId);

			Set<String> validCodeIds = variableDimensionsValidCodes.get(dimId);
			List<EnumeratedItemBean> validCodes = new ArrayList<>();
			EnumeratedListBean<EnumeratedItemBean> codelist = dsdSb.getDimensionById(dimId).getCodelist(true);
			if(codelist != null) {
				if(validCodeIds.contains("*")) {
					validCodes = codelist.getItems();
				} else {
					for(String codeId : validCodeIds) {
						EnumeratedItemBean code = codelist.getItemById(codeId);
						if(code != null) {
							validCodes.add(code);
						}
					}
				}
			}
			variableDimensions.put(dimId, new ReportTemplateVariableDimensionImpl(reportingTemplateComponent, validCodes));
		}

		dimRows = new HashSet<>();
		for(ReportingTemplateDimension rt : rows) {
			dimRows.add(rt.getDimension().getComponent().getId());
		}

		dimCols = new HashSet<>();
		for(ReportingTemplateDimension rt : cols) {
			dimCols.add(rt.getDimension().getComponent().getId());
		}

		if(this.hasTimePeriods() &&
				!dimRows.contains(DimensionBean.TIME_DIMENSION_FIXED_ID) &&
				!dimCols.contains(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
			rows.add(buildTimeDimension(ws, dsdSb, validSeries));
			dimRows.add(DimensionBean.TIME_DIMENSION_FIXED_ID);
		}

		//If there is a dimension which is not specified in the report template, add it to the row
		for(DimensionBean dim : dataStructureBean.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION)) {
			if(!dimRows.contains(dim.getId()) &&
					!dimCols.contains(dim.getId()) &&
					!ws.getVariableDimensions().contains(dim.getId()) &&
					!fixedDimenisons.containsKey(dim.getId())) {
				rows.add(buildReportingTemplateDimension(dsdSb, dim.getId(), fixedDimenisons, ws, validSeries, sbBeanRetrievalManager));
				dimRows.add(dim.getId());
			}
		}

		//Obs Attribute
		for(String attrId : ws.getVariableAttributes()) {
			ReportingTemplateComponent templateComponent = new ReportingTemplateComponentImpl(ws, dsdSb, attrId);
			obsAttributesInReport.add(templateComponent);
		}

		for(String attrId : ws.getSeparateAttributes()) {
			AttributeBean attr = dsdSb.getBuiltFrom().getAttribute(attrId);
			if(attr != null) {
				ReportingTemplateComponent templateComponent = new ReportingTemplateComponentImpl(ws, dsdSb, attrId);
				if(attr.getAttachmentLevel() == ATTRIBUTE_ATTACHMENT_LEVEL.OBSERVATION) {
					obsAttributesInSeparateTable.add(templateComponent);
				} else if(attr.getAttachmentLevel() == ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP) {
					seriesAttributesInSeparateTable.add(templateComponent);
				}
			}
		}

		for(String attrId : ws.getWorksheetAttributes()) {
			ReportingTemplateComponent templateComponent = new ReportingTemplateComponentImpl(ws, dsdSb, attrId);
			obsAttributesInSeparateWorksheet.add(templateComponent);
		}

		if(ws.getColourAttribute() != null) {
			ReportingTemplateComponent colourAttr = new ReportingTemplateComponentImpl(ws, dsdSb, ws.getColourAttribute().getAttributeId());
			if(ObjectUtil.validMap(this.obsMap)) {
				ReportingTemplateSeries rts = outputDefaultColourCodes ? reportingTemplateSeries : null;
				colouredAttribute = new ReportingTemplateColouredAttributeImpl(this.obsMap, rts, ws.getColourAttribute(), colourAttr, dsdSb);
			} else {
				colouredAttribute = new ReportingTemplateColouredAttributeImpl(reportingTemplateSeries, ws.getColourAttribute(), colourAttr, dsdSb);
			}
		}


		rows = Collections.unmodifiableList(rows);
		cols = Collections.unmodifiableList(cols);
		rowsNoTime = Collections.unmodifiableList(rowsNoTime);
		colsNoTime = Collections.unmodifiableList(colsNoTime);

		obsAttributesInReport = Collections.unmodifiableSet(obsAttributesInReport);
		fixedDims = Collections.unmodifiableMap(fixedDims);
		obsAttributesInSeparateTable = Collections.unmodifiableSet(obsAttributesInSeparateTable);
		obsAttributesInSeparateWorksheet = Collections.unmodifiableSet(obsAttributesInSeparateWorksheet);
		seriesAttributesInSeparateTable = Collections.unmodifiableSet(seriesAttributesInSeparateTable);
		fixeAttrs = Collections.unmodifiableMap(fixeAttrs);
		dimRows = Collections.unmodifiableSet(dimRows);
		dimCols = Collections.unmodifiableSet(dimCols);
		variableDimensions = Collections.unmodifiableMap(variableDimensions);
	}

	@Override
	public ReportingTemplate getReportingTemplate() {
		return parent;
	}

	@Override
	public Integer getColMaxWidth() {
		return ws.getColMaxWidth();
	}


	@Override
	public boolean includeFormulaCheckingTable() {
		return includeFormulaCheckingTable;
	}


	@Override
	public Keyable getSeries(String[] seriesKey) {
		if(seriesKey != null && keyMap.size() > 0) {
			String shortCode = SeriesUtil.toSeriesKey(seriesKey);
			return keyMap.get(shortCode);
		}
		return null;
	}


	@Override
	public Observation getObservation(String[] obsKey) {
		if(obsKey != null && obsMap.size() > 0) {
			String seriesKey = SeriesUtil.toSeriesKey(obsKey);
			if(obsKey.length < keyLength && this.parent.getReportingPeriod() != null) {
				//missing time period
				seriesKey+=":"+this.parent.getReportingPeriod().getDateInSdmxFormat();
			}
			return obsMap.get(seriesKey);
		}
		return null;
	}

	/**
	 * Returns the array of valid series for this set of constraints, variable dimensions are given a value of '*' in the return array
	 * @param flowConstraint
	 * @param dsdSb
	 * @param additionalConstraints
	 * @param templateFixedValues
	 * @param variableDimensionsValidCodes - to populate with valid codes for each variable dimension
	 * @return
	 */
	private Set<String[]> getValidSeries(ReportingTemplateWorksheetBean ws,
			DataStructureSuperBean dsdSb,
			Set<ContentConstraintBean> constraints,
			Map<String, String> templateFixedValues,
			Map<String, Set<String>> variableDimensionsValidCodes,
			TIME_FORMAT timeFormat) {

		Set<ContentConstraintModel> constraintModels = new HashSet<>();
		boolean hasSeriesConstraints = false;
		for(ContentConstraintBean constraint : constraints) {
			constraintModels.addAll(ContentConstraintModelImpl.build(constraint, dsdSb, true));
			if(constraint.hasIncludedSeries()) {
				hasSeriesConstraints = true;
			}
		}

		Map<String, Set<String>> validCodes = new HashMap<>();
		Set<String> missingDimensions = new HashSet<>();  //If a dimension is not coded, and is has not got fixed values in the master constraint

		for(DimensionSuperBean dim : dsdSb.getDimensions()) {
			if(dim.getBuiltFrom().isTimeDimension()) {
				continue;
			}

			Set<String> validValues = null;
			Set<String> excludedValues = new HashSet<>();;
			for(ContentConstraintModel constraintModel : constraintModels) {
				Set<String> constraintModelValidValues = constraintModel.getValidValues(dim.getId());
				Set<String> dimExcludedValues = constraintModel.getExcludedValues(dim.getId());
				if(dimExcludedValues != null) {
					excludedValues.addAll(dimExcludedValues);
				}
				if(constraintModelValidValues== null) {
					continue;
				} else  if(validValues == null) {
					validValues = new HashSet<>(constraintModelValidValues);
				} else {
					validValues.retainAll(constraintModelValidValues);
				}
			}


			//If we know the frequency, then set this as the only valid value for the frequency dimension
			if(timeFormat != null && dim.getId().equals("FREQ")) {
				EnumeratedListBean<EnumeratedItemBean> codelist = dim.getCodelist(true);
				if(codelist != null) {
					EnumeratedItemBean code = codelist.getItemById(timeFormat.getFrequencyCodeId());
					if(code != null) {
						if(validValues == null || validValues.contains(code.getId())) {
							validValues = new HashSet<>();
							validValues.add(code.getId());
						} else {
							validValues = new HashSet<>();
						}
					}
				}
			}

			//If the constraint does not restrict the values for this dimension, set them to the values from the codelist
			if(validValues == null) {
				EnumeratedListBean<EnumeratedItemBean> codelist = dim.getCodelist(true);
				if(codelist != null) {
					validValues = new HashSet<>();
					for(EnumeratedItemBean currentCode : codelist.getItems()) {
						validValues.add(currentCode.getId());
					}
				} else {
					//If there is not codelist, then we don't know what the possible values are
					missingDimensions.add(dim.getId());
				}
			}
			if(validValues != null) {
				validValues.removeAll(excludedValues);
				validCodes.put(dim.getId(), validValues);
			}
		}

		if(LOG.isTraceEnabled()) {
			LOG.trace("All Valid Codes before constraining:");
			for(String dimId : validCodes.keySet()) {
				LOG.trace(dimId+ " = " +validCodes.get(dimId));
			}
		}

		if(missingDimensions.size() > 0) {
			StringBuilder sb = new StringBuilder();
			String concat = "";
			for(String missingDimension : missingDimensions) {
				sb.append(concat + missingDimension);
				concat = ", ";
			}
			throw new IllegalArgumentException("Unable to output worksheet, uncoded dimensions "+sb.toString()+" do not define which values are valid for reporting");
		}
		if(LOG.isTraceEnabled()) {
			LOG.trace("Valid Codes after applying cube region:");
			for(String dimId : validCodes.keySet()) {
				LOG.trace(dimId+ " = " +validCodes.get(dimId));
			}
		}

		Set<String[]> validSeries = new HashSet<>();
		List<DimensionBean> dimensions = dsdSb.getBuiltFrom().getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION);
		int dimLength = dimensions.size();
		String[] dimIds = new String[dimLength];
		int i=0;
		for(DimensionBean dim : dimensions) {
			dimIds[i] = dim.getId();
			i++;
		}
		Set<String> variableDimensions = ws.getVariableDimensions();
		if(hasSeriesConstraints) {
			//Step 2a - if any of the constraints provide series restrictions, then use those restrictions to build the set of series for the worksheet
			for(String variableDim : variableDimensions) {
				variableDimensionsValidCodes.put(variableDim, validCodes.get(variableDim));
			}

			// Get all the included series restrictions from all of the contraints
			List<String[]> allSeriesRestrictions = new ArrayList<>();
			for(ContentConstraintModel constraint : constraintModels) {
				String[][] currentAllowableSeries = constraint.getAllowableSeries();
				if(currentAllowableSeries != null) {
					outer:
						for(String[] currentSeries : currentAllowableSeries) {
							for(int idx=0; idx < dimIds.length; idx++) {
								String dimValue = currentSeries[idx];
								String dimId = dimIds[idx];
								if(dimValue != null) {
									//Do not include the series if it does not match any restriction at the dimension codelist level
									Set<String> valid = validCodes.get(dimId);
									if(valid != null && !valid.contains(dimValue)) {
										//Do not include series it has been constrained out by a cube region
										continue outer;
									}
								}
							}
							allSeriesRestrictions.add(currentSeries);
						}
				}
			}
			//Clear any values in the variable indexes and store the valid codes for the variables so we can build a drop down
			for(String variableDim : variableDimensions) {
				int dimIdx = -1;
				for(int idx =0; i < dimIds.length; i++) {
					if(dimIds[idx].equals(variableDim)) {
						dimIdx = idx;
						break;
					}
				}
				if(dimIdx >=0) {
					for(String[] currentSeries : allSeriesRestrictions) {
						currentSeries[dimIdx] = null;
					}
				}
			}

			//Merge out any wildcards, to be left with either explicit or wildcaded series
			allSeriesRestrictions = SeriesUtil.mergeWildcardedSeries(allSeriesRestrictions);

			for(String[] currentSeriesRestriction : allSeriesRestrictions) {
				//1. Test this series against the valid cube regions
				int idx = 0;
				int wildcarded = 0;
				for(String dimId : dimIds) {
					if(variableDimensions.contains(dimId)) {
						//									variableDimensionsValidCodes.get(dimId).addAll(validCodes.get(dimId));
						currentSeriesRestriction[idx] = "*";
					} else if(currentSeriesRestriction[idx] == null) {
						wildcarded++;
					}
					idx++;
				}

				//4. If there are no wildcards, then add the new series to the list
				if(wildcarded == 0) {
					if(LOG.isTraceEnabled()) {
						String shortCode = SeriesUtil.toSeriesKey(currentSeriesRestriction, "*");
						LOG.trace("Include Series: "+ shortCode);
					}
					validSeries.add(currentSeriesRestriction);
				}  else {
					//4b Otherwise expand the series out
					//Step 3.2 Expand the series string array if necessary (if there are wildcarded dimensions)
					int[] expandDimensions = new int[wildcarded];

					//Expand series out
					int a=0;
					for(int x=0; x < currentSeriesRestriction.length; x++) {
						if(currentSeriesRestriction[x] == null) {
							expandDimensions[a] = x;
							a++;
						}
					}
					Set<String[]> toExpand = new HashSet<>();
					if(LOG.isTraceEnabled()) {
						LOG.trace("Expand Series: "+ SeriesUtil.toSeriesKey(currentSeriesRestriction));
					}
					toExpand.add(currentSeriesRestriction);
					for(int dimIdx : expandDimensions) {
						Set<String[]> expandedSeries = new HashSet<>();
						Set<String> allCodes = validCodes.get(dimIds[dimIdx]);
						for(String[] currentExpand : toExpand) {
							nextCode :
								for(String currentCodeId : allCodes) {
									String[] newArr = currentExpand.clone();
									newArr[dimIdx] = currentCodeId;

									String shortCode = SeriesUtil.toSeriesKey(newArr, "*");
									for(ContentConstraintModel constraintModel : constraintModels) {
										if(constraintModel.isExplicitlyExcludedShortCode(shortCode)) {
											//Do not include this short code
											continue nextCode;
										}
									}
									if(LOG.isTraceEnabled()) {
										LOG.trace("Include Series: "+ SeriesUtil.toSeriesKey(newArr));
									}
									expandedSeries.add(newArr);
									checkLimit(expandedSeries, true);
								}
						}
						toExpand = expandedSeries;
						checkLimit(toExpand, true);
					}
					validSeries.addAll(toExpand);
					checkLimit(validSeries, true);
				}
			}

//			ALTERNATIVE CONSTRAINT MECHANISM
//			//Step 2a - if any of the constraints provide series restrictions, then use those restrictions to build the set of series for the worksheet
//			for(String variableDim : variableDimensions) {
//				variableDimensionsValidCodes.put(variableDim, new HashSet<>());
//			}
//			//Allowable series keys layer on each other, for example
//			//[A,UK,FR]
//			//[A,DE,FR]
//			//[M,UK,FR]
//			//-- Layered with
//			//[*,UK,FR]
//			//-- Results in
//			//[A,UK,FR]
//			//[M,UK,FR]
//
//			for(ContentConstraintModel constraint : constraintModels) {
//				String[][] currentAllowableSeries = constraint.getAllowableSeries();
//				if(currentAllowableSeries != null) {
//
//					outer:
//					for(String[] currentSeriesRestriction : currentAllowableSeries) {
//						//1. Test this series against the valid cube regions
//						int idx = 0;
//						for(String dimId : dimIds) {
//							String dimValue = currentSeriesRestriction[idx];
//							Set<String> valid = validCodes.get(dimId);
//							idx++;
//							if(dimValue != null && valid != null && !valid.contains(dimValue)) {
//								//Do not include series it has been constrained out by a cube region
//								continue outer;
//							}
//						}
//
//						//2. Test the short code is valid across all other constraints
//						String shortCode = SeriesUtil.toSeriesKey(currentSeriesRestriction, "*");
//						for(ContentConstraintModel constraintModel : constraintModels) {
//							if(constraintModel == constraint) {
//								continue;
//							}
//							if(!constraintModel.isValidShortCode(shortCode)) {
//								continue outer;
//							}
//						}
//						//3. This series is a valid across all constraints.
//						//   Check wildcarded dimensions
//						//   Overwrite any series codes with wildcards if the dimension is variable
//						idx = 0;
//						int wildcarded = 0;
//						for(String dimId : dimIds) {
//							if(variableDimensions.contains(dimId)) {
//								variableDimensionsValidCodes.get(dimId).addAll(validCodes.get(dimId));
//								currentSeriesRestriction[idx] = "*";
//							} else if(currentSeriesRestriction[idx] == null) {
//								wildcarded++;
//							}
//							idx++;
//						}
//
//						//4. If there are no wildcards, then add the new series to the list
//						if(wildcarded == 0) {
//							if(LOG.isDebugEnabled()) {
//								LOG.debug("Include Series: "+ shortCode);
//							}
//							validSeries.add(currentSeriesRestriction);
//						}  else {
//							//4b Otherwise expand the series out
//							//Step 3.2 Expand the series string array if necessary (if there are wildcarded dimensions)
//							int[] expandDimensions = new int[wildcarded];
//
//							//Expand series out
//							int a=0;
//							for(int x=0; x < currentSeriesRestriction.length; x++) {
//								if(currentSeriesRestriction[x] == null) {
//									expandDimensions[a] = x;
//									a++;
//								}
//							}
//							Set<String[]> toExpand = new HashSet<>();
//							if(LOG.isDebugEnabled()) {
//								LOG.debug("Expand Series: "+ SeriesUtil.toSeriesKey(currentSeriesRestriction));
//							}
//							toExpand.add(currentSeriesRestriction);
//							for(int dimIdx : expandDimensions) {
//								Set<String[]> expandedSeries = new HashSet<>();
//								Set<String> allCodes = validCodes.get(dimIds[dimIdx]);
//								for(String[] currentExpand : toExpand) {
//									nextCode :
//										for(String currentCodeId : allCodes) {
//											Set<String> valid = validCodes.get(dimIds[dimIdx]);
//											if(valid != null && !valid.contains(currentCodeId)) {
//												//Do not include series it has been constrained out by a cube region
//												continue;
//											}
//											String[] newArr = currentExpand.clone();
//											newArr[dimIdx] = currentCodeId;
//
//											shortCode = SeriesUtil.toSeriesKey(newArr, "*");
//											for(ContentConstraintModel constraintModel : constraintModels) {
//												if(!constraintModel.isValidShortCode(shortCode)) {
//													continue nextCode;
//												}
//											}
//											if(LOG.isDebugEnabled()) {
//												LOG.debug("Include Series: "+ SeriesUtil.toSeriesKey(newArr));
//											}
//											expandedSeries.add(newArr);
//											checkLimit(expandedSeries, true);
//										}
//								}
//								toExpand = expandedSeries;
//								checkLimit(toExpand, true);
//							}
//							validSeries.addAll(toExpand);
//							checkLimit(validSeries, true);
//						}
//					}
//				}
//			}
		} else {
			//Step 2b - no series restrictions exist - build valid series of the information we already have about which codes are valid for each dimension
			Map<String, Set<String>> cubeRegionCodes = validCodes;
			int seriesSize = 1;
			for(String currentDimId : cubeRegionCodes.keySet()) {
				if(variableDimensions.contains(currentDimId)) {
					variableDimensionsValidCodes.put(currentDimId, cubeRegionCodes.get(currentDimId));
				} else {
					seriesSize *= cubeRegionCodes.get(currentDimId).size();
					if(seriesSize < 0) {
						throw new SdmxException("Reporting Template '"+this.getName()+"' could not be generated since the total number of cells exceeds '" + Integer.MAX_VALUE + "'");
					}
				}
			}
			if(maxObsLimit > 0 && seriesSize > maxObsLimit) {
				throw new SdmxException("Reporting Template '"+this.getName()+"' could not be generated since the total number of cells '" + seriesSize +"' exceeds the limit of '"+maxObsLimit+"' ");
			}
			String[][] series = new String[seriesSize][];
			for(i=0; i < seriesSize; i++) {
				series[i] = new String[dimLength];
			}
			for(int dimIdx = 0; dimIdx < dimIds.length; dimIdx++) {
				String dimId = dimIds[dimIdx];
				if(variableDimensions.contains(dimId)) {
					for(String[] currentSeries : series) {
						currentSeries[dimIdx] = "*";
					}
					continue;
				}
				Set<String> codes = cubeRegionCodes.get(dimId);
				if(codes.size() == 1) {
					String code = (String) codes.toArray()[0];
					for(String[] currentSeries : series) {
						currentSeries[dimIdx] = code;
					}
					continue;
				}

				int length = 1;  //number of times to print the code
				int repeat = 1;  //number of series to skip
				for(int dimIdx2 = dimIdx; dimIdx2 < dimIds.length; dimIdx2++) {
					String dimId2 = dimIds[dimIdx2];
					if(dimId.equals(dimId2)) {
						continue;
					}
					if(variableDimensions.contains(dimId2)) {
						continue;
					}
					length *= cubeRegionCodes.get(dimId2).size();
				}
				repeat = length * (codes.size() -1);
				int codeIdx = 0;
				for(String currentCode : codes) {
					int arrayIdx = codeIdx * length;
					while(arrayIdx < seriesSize) {
						for(int printed=0; printed < length;printed++) {
							series[arrayIdx][dimIdx] = currentCode;
							arrayIdx++;
						}
						arrayIdx = arrayIdx + repeat;
					}
					codeIdx++;
				}
			}
			for(i=0; i < seriesSize; i++) {
				String shortCode = SeriesUtil.toSeriesKey(series[i], "*");
				for(ContentConstraintModel constraintModel : constraintModels) {
					if(!constraintModel.isValidShortCode(shortCode)) {
						continue;
					}
				}
				validSeries.add(series[i]);
			}
		}

		if(LOG.isTraceEnabled()) {
			LOG.trace("Final Valid Series Size: "+ validSeries.size());
			for(String[] ser : validSeries) {
				LOG.trace("Valid Series: "+ SeriesUtil.toSeriesKey(ser));
			}
		}
		checkLimit(validSeries, false);
		if(hasTimePeriods()) {
			//Expand all the series for each time period
			if(maxObsLimit > 0 && (validSeries.size() * this.timePeriods.size()) > maxObsLimit) {
				String errMsg = "Reporting Template '"+this.getName()+"' could not be generated since the total number of cells '" +(validSeries.size() * this.timePeriods.size()) +"' exceeds the limit of '"+maxObsLimit+"' ";
				throw new SdmxException(errMsg);
			}
			Set<String[]> returnSeries = new HashSet<>();
			for(String[] currentSeries : validSeries) {
				String[] newArray = new String[currentSeries.length + 1];
				System.arraycopy(currentSeries, 0, newArray, 0, currentSeries.length);
				for(String timePeriod : this.timePeriods) {
					String[] cloneArray = newArray.clone();
					cloneArray[cloneArray.length-1] = timePeriod;
					returnSeries.add(cloneArray);
				}
			}
			return returnSeries;
		}
		return validSeries;
	}

	/**
	 * Ensures the number of series has not exceeded the limit for Excel Reporting Templates
	 * @param series
	 * @param isStillExpanding
	 */
	private void checkLimit(Set<String[]> series, boolean isStillExpanding) {
		if(maxObsLimit < 0 || series.size() <= maxObsLimit) {
			return;
		}

		String errMsg;
		if (isStillExpanding) {
			errMsg = "Reporting Template '"+this.getName()+"'  could not be generated since the limit of '"+maxObsLimit+"' has been exceeded.";
		} else {
			errMsg = "Reporting Template '"+this.getName()+"' could not be generated since the total number of cells '" + series.size() +"' exceeds the limit of '"+maxObsLimit+"' ";
		}
		throw new SdmxException(errMsg);
	}

	private List<ReportingTemplateDimension> getRowOrCols(DataStructureSuperBean dsdSb,
			List<String> dimIds,
			Map<String, String> fixedDimenisons,
			ReportingTemplateWorksheetBean ws,
			Set<String[]> seriesCodes,
			SdmxSuperBeanRetrievalManager sbBeanRetrievalManager) {
		List<ReportingTemplateDimension> returnArray = new ArrayList<>();
		for(String dimId : dimIds) {
			if(dimId.equals(DimensionBean.TIME_DIMENSION_FIXED_ID) && hasTimePeriods() == false) {
				continue;
			}
			ReportingTemplateDimension dim = buildReportingTemplateDimension(dsdSb, dimId, fixedDimenisons, ws, seriesCodes, sbBeanRetrievalManager);
			if(dim != null) {
				returnArray.add(dim);
			}
		}
		return returnArray;
	}

	private ReportingTemplateDimension buildTimeDimension(ReportingTemplateWorksheetBean ws, DataStructureSuperBean dsdSb, Set<String[]> seriesCodes) {
		ReportingTemplateComponent reportingTemplateComponent = new ReportingTemplateComponentImpl(ws, dsdSb, DimensionBean.TIME_DIMENSION_FIXED_ID);
		DimensionSuperBean dimSb = dsdSb.getDimensionById(DimensionBean.TIME_DIMENSION_FIXED_ID);
		return new ReportingTemplateDimensionImpl(reportingTemplateComponent, TEXT_DISPLAY.NAME, dimSb, seriesCodes, null, false);
	}

	private ReportingTemplateDimension buildReportingTemplateDimension(DataStructureSuperBean dsdSb,
			String dimId,
			Map<String, String> fixedDimenisons,
			ReportingTemplateWorksheetBean ws,
			Set<String[]> seriesCodes,
			SdmxSuperBeanRetrievalManager sbBeanRetrievalManager) {
		if(fixedDimenisons.containsKey(dimId)) {
			return null;
		}
		DimensionSuperBean dimSb = dsdSb.getDimensionById(dimId);

		ICrossReferenceBean<HierarchyBean> hRef = ws.getHierarhcyReferences().get(dimId);
		boolean implcitHierarchy = false;
		HierarchySuperBean hSb = null;
		if(hRef == null) {
			implcitHierarchy = ws.getImplicitHierarchices().contains(dimSb.getId());
		} else {
			hSb = sbBeanRetrievalManager.getHierarchicCodeListSuperBean(hRef.getReference());
		}
		TEXT_DISPLAY textDisplay = ws.getTextDisplay(dimId);
		ReportingTemplateComponent reportingTemplateComponent = new ReportingTemplateComponentImpl(ws, dsdSb, dimId);
		return new ReportingTemplateDimensionImpl(reportingTemplateComponent, textDisplay, dimSb, seriesCodes, hSb, implcitHierarchy);
	}

	private Map<ReportingTemplateComponent, EnumeratedItemBean> getFixedDimensions(DataStructureSuperBean dsdSb, Map<String, String> fixedVals, ReportingTemplateWorksheetBean ws) {
		Map<ReportingTemplateComponent, EnumeratedItemBean> returnMap = new HashMap<>();
		for(String compId : fixedVals.keySet()) {
			String codeId = fixedVals.get(compId);
			ComponentSuperBean<?> compSb = dsdSb.getComponentById(compId);
			EnumeratedItemBean code = compSb.getCodelist(true).getItemById(codeId);
			ReportingTemplateComponent templateComponent = new ReportingTemplateComponentImpl(ws, dsdSb, compId);
			returnMap.put(templateComponent, code);
		}
		return returnMap;
	}

	private Map<ReportingTemplateComponent, EnumeratedItemBean> getFixedAttributess(DataStructureSuperBean dsdSb, Set<String> compIds, ReportingTemplateWorksheetBean ws) {
		Map<ReportingTemplateComponent, EnumeratedItemBean> returnMap = new HashMap<>();
		for(String compId : compIds) {
			String codeId = ws.getFixedAttributeValue(compId);
			ComponentSuperBean<?> compSb = dsdSb.getComponentById(compId);
			EnumeratedItemBean code = compSb.getCodelist(true).getItemById(codeId);
			ReportingTemplateComponent templateComponent = new ReportingTemplateComponentImpl(ws, dsdSb, compId);
			returnMap.put(templateComponent, code);
		}
		return returnMap;
	}


	@Override
	public DataStructureBean getDataStructureBean() {
		return dataStructureBean;
	}

	@Override
	public DataflowBean getDataflowBean() {
		return dataflowBean;
	}

	@Override
	public ProvisionAgreementBean getProvisionAgreementBean() {
		return provisionBean;
	}

	@Override
	public Set<ValidationSchemeBean> getValidationSchemes() {
		return validationSchemes;
	}

	@Override
	public HierarchyBean getHierarchy(String urn) {
		return hierarchyMap.get(urn);
	}

	@Override
	public String getName() {
		return sheetName;
	}

	@Override
	public ReportingTemplateSeries getSeries() {
		return reportingTemplateSeries;
	}

	@Override
	public boolean hasTimePeriods() {
		return ObjectUtil.validCollection(timePeriods);
	}

	@Override
	public Map<ReportingTemplateComponent, EnumeratedItemBean> getFixedDimensions() {
		return fixedDims;
	}

	@Override
	public Map<ReportingTemplateComponent, EnumeratedItemBean> getFixedAttributes() {
		return fixeAttrs;
	}

	@Override
	public Set<ReportingTemplateComponent> getAttributesInReport() {
		return obsAttributesInReport;
	}

	@Override
	public Set<ReportingTemplateComponent> getObsAttributesInSeparateTable() {
		return obsAttributesInSeparateTable;
	}



	@Override
	public Set<ReportingTemplateComponent> getSeriesAttributesInSeparateTable() {
		return seriesAttributesInSeparateTable;
	}


	@Override
	public Set<ReportingTemplateComponent> getObsAttributesInSeparateWorksheet() {
		return obsAttributesInSeparateWorksheet;
	}

	@Override
	public ReportingTemplateColouredAttribute getColourAttribute() {
		return colouredAttribute;
	}

	@Override
	public Map<String, ReportTemplateVariableDimension> getVariableDimensions() {
		return variableDimensions;
	}

	@Override
	public List<ReportingTemplateConditionalAttributeBean> getConditionalAttributes() {
		return conditionalObsAttributes;
	}

	@Override
	public List<ReportingTemplateDimension> getTableRows(boolean includeTime) {
		if(includeTime) {
			return rows;
		}
		return rowsNoTime;
	}

	@Override
	public List<ReportingTemplateDimension> getTableColumns(boolean includeTime) {
		if(includeTime) {
			return cols;
		}
		return colsNoTime;
	}

	@Override
	public boolean isExcludeDimension(String dimId) {
		return this.excludeDimensions.contains(dimId);
	}

	@Override
	public boolean isInTableHead(DimensionBean dim) {
		return dimCols.contains(dim.getId());
	}

	@Override
	public boolean isInTableRow(DimensionBean dim) {
		return dimRows.contains(dim.getId());
	}

	@Override
	public int[] getTableColumnDimensions(boolean includeTime) {
		return getAggregatedDimensions(includeTime, false);
	}

	@Override
	public int[] getTableRowDimensions(boolean includeTime) {
		return getAggregatedDimensions(includeTime, true);
	}

	/**
	 * Returns an integer array of dimension indexes that appear in the rows/columns
	 * @param isRows
	 */
	private int[] getAggregatedDimensions(boolean includeTime, boolean isRows) {
		int[] aggregateDims = new int[isRows ? getTableRows(includeTime).size() : getTableColumns(includeTime).size()];
		int i = 0;
		if(isRows) {
			for(ReportingTemplateDimension tr : getTableRows(includeTime)) {
				aggregateDims[i] = ((DimensionBean)tr.getDimension().getComponent()).getPosition()-1;
				i++;
			}
		} else {
			for(ReportingTemplateDimension tr : getTableColumns(includeTime)) {
				aggregateDims[i] = ((DimensionBean)tr.getDimension().getComponent()).getPosition()-1;
				i++;
			}
		}
		return aggregateDims;
	}

	@Override
	public String getObsColour(String[] obsKey) {
		if(colouredAttribute != null) {
			return colouredAttribute.getColour(obsKey);
		}
		return null;
	}

	@Override
	public Integer getRoundDecimals() {
		return roundDecimals;
	}

	@Override
	public String toString() {
		return getName();
	}
}
