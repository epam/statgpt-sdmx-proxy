package io.sdmx.fusion.reporttemplate.api.model.template;

import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;

/**
 * Contains a Dimension and its associated Concept, so that both Ids and Names can be displayed to the user
 */
public interface ReportingTemplateComponent extends Comparable<ReportingTemplateComponent> {

	/**
	 * Returns the Dimension 
	 * @return
	 */
	ComponentBean getComponent();

	/**
	 * Returns the Concept for the Dimension
	 * @return
	 */
	ConceptBean getConcept();
	
	/**
	 * Returns the label
	 * @return
	 */
	String getLabel();
	
}
