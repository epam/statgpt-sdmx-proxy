package io.sdmx.fusion.reporttemplate.api.model.template;

import io.sdmx.utils.xlsx.api.model.ICellStyle;
import io.sdmx.utils.xlsx.constant.BORDER_STYLE;

/**
 * Builds a text area in the worksheet,
 * 
 * Optionally given a surrounding border
 * 
 */
public interface IInstructionSheetTextArea {

	/**
	 * @return text content for the sheet, simple markdown supported
	 */
	String getContent();
	
	/**
	 * @return style for the content
	 */
	ICellStyle getContentStyle();
	
	/**
	 * @return number of columns to merge to fit the content, text wrap is enabled
	 */
	int getColWidth();
	
	/**
	 * @return number of rows to merge to fit the content, text wrap is enabled
	 */
	int getColHeight();
	
	/**
	 * @return the style of border to use around the content
	 */
	BORDER_STYLE getBorderStyle();
	
	
}
