package io.sdmx.fusion.reporttemplate.engine;

import java.io.IOException;
import java.io.StringReader;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Pattern;

import org.apache.poi.ooxml.POIXMLProperties.CustomProperties;
import org.apache.poi.ss.util.CellAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openxmlformats.schemas.officeDocument.x2006.customProperties.CTProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.CONDITION;
import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.constants.SDMX_EDI_ATTRIBUTES;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.engine.DatasetCreationAware;
import io.sdmx.api.sdmx.exception.DataSetStructureReferenceException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.RepresentationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.sdmx.api.error.DataReaderExceptionHandler;
import io.sdmx.core.sdmx.engine.data.AbstractDataReaderEngine;
import io.sdmx.fusion.reporttemplate.model.reporttemplate.AttributeRule;
import io.sdmx.fusion.reporttemplate.model.worksheet.WorksheetIndex;
import io.sdmx.im.data.DatasetAttributes;
import io.sdmx.im.data.KeyableImpl;
import io.sdmx.im.data.ObservationImpl;
import io.sdmx.im.header.HeaderBeanImpl;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.collection.KeyValueImpl;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.object.NumberUtils;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;
import io.sdmx.utils.sdmx.collection.SdmxCollectionUtil;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.xlsx.util.POIUtils;

/**
 * Reads data from an excel spreadsheet by:
 *
 * 1. reading the custom metadata section to build a picture of rows and columns for each worksheet
 * 2. Creating a list of CellIndexes which maps a series key and optional attribute id to a cell in the worksheet
 * 3. Converting (collapsing) the multiple CellIndexes into Series one or more (if multi time period) observations
 * 4. Implementing the DataReaderEngine API which allows the user to walk the Series and Observations
 *
 */
public class ExcelReportingTemplateReader extends AbstractDataReaderEngine implements DataReaderEngine, DatasetCreationAware {
	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(ExcelReportingTemplateReader.class);
	private static final Pattern PATTERN = Pattern.compile("[0-9]+,[0-9]+,[0-9]+");
	private static final Pattern ROW_PATTERN = Pattern.compile("[0-9]+,r[0-9]+");
	private static final Pattern COL_PATTERN = Pattern.compile("[0-9]+,c[0-9]+");
	private static final Pattern VARIABLE_DIMENSION_PATTERN = Pattern.compile("[0-9]+,v,.+");
	private static final String GLOBAL_VARIABLE_DIMENSION_PATTERN = "gv,";  //dim idx  val->cellref
	private static final Pattern NO_HEAD_OBS_ATT_PATTERN = Pattern.compile("[0-9]+,nh_att,[0-9]+");
	private static final Pattern NO_HEAD_SERIES_ATT_PATTERN = Pattern.compile("[0-9]+,nh_satt,[0-9]+");
	private static final Pattern NO_HEAD_OBS_PATTERN = Pattern.compile("[0-9]+,nh_obs,[0-9]+");
	private static final Pattern OBS_ATT_START_PATTERN = Pattern.compile("[0-9]+,attstart");
	private static final Pattern SERIES_ATT_START_PATTERN = Pattern.compile("[0-9]+,sattstart");
	private static final Pattern DECIMAL_PATTERN = Pattern.compile("[0-9]+,DP");

	private boolean multipleReportingPeriods = false;
	private SdmxDate reportingPeriod;
	private XSSFWorkbook workbook;
	private XSSFSheet currentWorksheet;

	private int currentProvisionIndex = -1;

	private Map<IURNSingle<? extends IDSDRelatedBean>, ProvisionMetadata> provMetadataMap = new HashMap<>();
	private WorksheetMetadata currentSheetMetadata;

	private List<DimensionBean> currentDimensions;

	private Date templateCreationDate;

	private static DecimalFormat DEFAULT_FORMAT;
	static {
		// Use ENGLISH locale to enforce that a point is used as the decimal separator.
		DEFAULT_FORMAT = new DecimalFormat("0", DecimalFormatSymbols.getInstance(Locale.ENGLISH));
		DEFAULT_FORMAT.setMaximumFractionDigits(340); //340 = DecimalFormat.DOUBLE_FRACTION_DIGITS
	}

	private Map<String, WorksheetMetadata> worksheetMetadata = new HashMap<>();
	private Map<String, List<Integer>> provisionToWorksheets = new HashMap<>();  //A map of provision URN to worksheet indexes
	private List<String> provisionList = new ArrayList<>();  // a list of provisions in order they appear in the worksheet


	private ReadableDataLocation dataLocation;
	private DataModel currentDataModel;


	public ExcelReportingTemplateReader(ReadableDataLocation dataLocation,
										SdmxBeanRetrievalManager beanRetrieval,
										DataStructureBean defaultDsd,
										DataflowBean defaultDataflow,
										ProvisionAgreementBean defaultProvisionAgreement,
										DataReaderExceptionHandler exceptionHandler) {
		super(beanRetrieval, defaultDsd, defaultDataflow, defaultProvisionAgreement, exceptionHandler);
		try {
			this.dataLocation = dataLocation;
			workbook = new XSSFWorkbook(dataLocation.getInputStream());
		} catch (IOException e) {
			throw new RuntimeException("Could not read XLSX Workbook", e);
		}


		currentWorksheet = workbook.getSheet("Main");
		if(currentWorksheet != null) {
			String date = getCellValue(11,3);
			if(!ObjectUtil.validString(date)) {
				multipleReportingPeriods = true;
			} else {
				try {
					reportingPeriod = SdmxDateImpl.getSdmxDate(date);
				} catch(Throwable th) {
					throw new SdmxSemmanticException("Reporting Period '"+date+"' is not a valid SDMX Date (Cell D12 on the Main worksheet)");
				}
			}

			String dataProvider =  getCellValue(7,3);
			if(!ObjectUtil.validString(dataProvider)) {
				dataProvider = "unknown";
			}
			super.headerBean = new HeaderBeanImpl(dataProvider);
		} else {
			multipleReportingPeriods = true;
		}
		processCustomProperties(workbook.getProperties().getCustomProperties());
		processWorksheetPlacement();


		//currentWorksheet = workbook.getSheet("Main");

	}

	@Override
	public FormatDetails getFormatDetails() {
		return new FormatDetailsImpl("Excel Reporting Template", "xlsx", "application/vnd.fusion.excelreportingtemplate+xlsx;version=1.0", true, true);
	}

	/**
	 * Returns the date the excel template was created
	 * @return
	 */
	@Override
	public Date getCreationDate() {
		return templateCreationDate;
	}



	@Override
	public String getDataFormat() {
		return "XSLX";
	}

	@Override
	public DataReaderEngine createCopy() {
		return new ExcelReportingTemplateReader(dataLocation.copy(), beanRetrieval, defaultDsd, defaultDataflow, defaultProvisionAgreement, exceptionHandler);
	}
	
	@Override
	protected IDatasetAttributes lazyLoadDatasetAttributes() {
		return new DatasetAttributes(currentSheetMetadata.fixedDatasetAttributes);
	}

	@Override
	protected boolean moveNextDatasetInternal() {
		currentProvisionIndex++;
		if(currentProvisionIndex >= provisionList.size()) {
			return false;
		}
		try {
			String currentProvision = provisionList.get(currentProvisionIndex);
			this.currentDataModel = null;
			//Each provision may have more then one worksheet, a main worksheet and attribute worksheets
			for(Integer worksheetIdex : provisionToWorksheets.get(currentProvision)) {
				currentWorksheet = workbook.getSheetAt(worksheetIdex);
				String sheetName = getCellValue(0,2);
				currentSheetMetadata = worksheetMetadata.get(sheetName);
				if(currentDataModel == null) {
					//first pass
					super.setCurrentStructure(currentSheetMetadata.sRef);
					if(currentDsd == null) {
						throw new DataSetStructureReferenceException(currentSheetMetadata.sRef);
					}
					this.currentDataModel = currentSheetMetadata.createDataModel(currentDsd);
				} else {
					currentSheetMetadata.createDataModel(currentDsd, this.currentDataModel);
				}
			}
			if(this.currentDataModel == null) {
				return moveNextDatasetInternal();
			}
			this.currentDataModel.calculateConditionalAttributes();

			return true;
		} catch(IllegalArgumentException e) {
			return false;
		}
	}

	@Override
	protected boolean moveNextKeyableInternal() {
		return currentDataModel.moveNextSeries();
	}


	@Override
	protected boolean moveNextObservationInternal() {
		return currentDataModel == null ? false : currentDataModel.moveNextObs();
	}


	@Override
	protected Observation lazyLoadObservation() {
		return currentDataModel.currentObs;
	}

	@Override
	protected Keyable lazyLoadKey() {
		return currentDataModel.currentKey;
	}


	@Override
	public void reset() {
		super.reset();

		// Reset only the required fields
		this.currentWorksheet = workbook.getSheet("Main");
		this.currentProvisionIndex = -1;

		// Important to call "processCustomProperties" to ensure various properties are reset correctly
		processCustomProperties(workbook.getProperties().getCustomProperties());
		// No need to call "processWorksheetPlacement" as the fields it sets are already correct
	}

	@Override
	public List<FooterMessage> close() {
		if(workbook != null) {
			try {
				workbook.close();
			} catch (IOException e) {
				LOG.error("Error closing Excel Workbook Resource", e);
			}
		}
		if(dataLocation != null) {
			try {
				dataLocation.close();
			} catch (Throwable th) {
				LOG.error("Error closing ReadableDataLocation Resource", th);
			}
		}
		return null;
	}



	private void processCustomProperties(CustomProperties props) {
		CTProperty prop = props.getProperty("ExcelTemplateCreation");
		templateCreationDate = new Date(Long.parseLong(prop.getLpwstr()));

		Map<Integer,String> sheetMap = new HashMap<>();  //Sheet Index to Sheet Name held on cell C2
		Map<Integer, Set<KeyValue>> fixedValues = new HashMap<>();
		Map<Integer, List<AttributeRule>> attributeRules = new HashMap<>();
		String colourAttribute = null;
		Map<Integer[], String[]> cellIndexes = new HashMap<>(); //OLD worksheet indexes

		Map<Integer, Map<String, String>> colourCellMap = new HashMap<>(); //Hex to Id
		Map<Integer, IURNSingle<? extends IDSDRelatedBean>> sRefMap = new HashMap<>();
		Map<Integer, String> globalVariables = new HashMap<>();


		if(LOG.isDebugEnabled()) {
			LOG.debug("Read custom Metadata Properties");
		}
		Map<Integer, WorksheetIndex> worksheetIndexMap = new HashMap<>();
		CTProperty[] properties = props.getUnderlyingProperties().getPropertyArray();
		for(int pIdx=0; pIdx < properties.length; pIdx++) {
			CTProperty currentProp = properties[pIdx];
			String propName = currentProp.getName();
			String propValue =  currentProp.getLpwstr();
			if(LOG.isDebugEnabled()) {
				LOG.debug("Metadata Property '"+propName+"' with value '"+propValue+"'");
			}
			if(propName.startsWith("WS,")) {
				String worksheetIdx = propName.substring(3);
				Integer index = Integer.parseInt(worksheetIdx);
				getWorksheetIndex(worksheetIndexMap, index);

				sheetMap.put(index, propValue);

			} else if(COL_PATTERN.matcher(propName).matches()) {
				String[] split = propName.split(",");
				WorksheetIndex idx = getWorksheetIndex(worksheetIndexMap, Integer.parseInt(split[0]));
				Integer row = Integer.parseInt(split[1].substring(1));
				idx.addColumnKey(row, SeriesUtil.splitKey(propValue));
			} else if(ROW_PATTERN.matcher(propName).matches()) {
				String[] split = propName.split(",");
				WorksheetIndex idx = getWorksheetIndex(worksheetIndexMap, Integer.parseInt(split[0]));
				Integer row = Integer.parseInt(split[1].substring(1));
				idx.addRowKey(row, SeriesUtil.splitKey(propValue));
			} else if(NO_HEAD_OBS_ATT_PATTERN.matcher(propName).matches()) {
				WorksheetIndex idx = getWorksheetIndex(worksheetIndexMap, propName);
				String[] keyValue = propName.split(",");
				idx.addNoHeaderColMapObsAttTable(propValue, Integer.parseInt(keyValue[2]));

			}  else if(NO_HEAD_SERIES_ATT_PATTERN.matcher(propName).matches()) {
				WorksheetIndex idx = getWorksheetIndex(worksheetIndexMap, propName);
				String[] keyValue = propName.split(",");
				idx.addNoHeaderColMapSeriesAttTable(propValue, Integer.parseInt(keyValue[2]));

			} else if(NO_HEAD_OBS_PATTERN.matcher(propName).matches()) {
				WorksheetIndex idx = getWorksheetIndex(worksheetIndexMap, propName);
				String[] keyValue = propName.split(",");
				idx.addNoHeaderColMapObsTable(propValue, Integer.parseInt(keyValue[2]));

			} else if(OBS_ATT_START_PATTERN.matcher(propName).matches()) {
				WorksheetIndex idx = getWorksheetIndex(worksheetIndexMap, propName);
				idx.setObsAttributeTableStart(Integer.parseInt(propValue));
			} else if(SERIES_ATT_START_PATTERN.matcher(propName).matches()) {
				WorksheetIndex idx = getWorksheetIndex(worksheetIndexMap, propName);
				idx.setSeriesAttributeTableStart(Integer.parseInt(propValue));
			}  else if(DECIMAL_PATTERN.matcher(propName).matches()) {
				WorksheetIndex idx = getWorksheetIndex(worksheetIndexMap, propName);
				idx.setRoundDecimals(Integer.parseInt(propValue));
			}  else if(VARIABLE_DIMENSION_PATTERN.matcher(propName).matches()) {
				WorksheetIndex idx = getWorksheetIndex(worksheetIndexMap, propName);
				String[] split = propName.split(",");
				idx.addVariableDimension(Integer.parseInt(split[2]), propValue);
			}  else if(propName.startsWith("FIX_")) {
				String[] split = propName.split("_", 3);

				Integer wsIndex = Integer.parseInt(split[1]);
				Set<KeyValue> valuesSet = fixedValues.get(wsIndex);
				if(valuesSet == null) {
					valuesSet = new HashSet<>();
					fixedValues.put(wsIndex, valuesSet);
				}
				valuesSet.add(KeyValueImpl.getInstance(split[2], propValue));
			} else if(propName.startsWith("STRUCTURE")) {
				Integer wsIdx = Integer.parseInt(propName.split(",")[1]);
				sRefMap.put(wsIdx, URN.builder(propValue).buildSingle(IDSDRelatedBean.class));
			}else if(propName.startsWith("COLOUR")) {
				Integer wsIdx = Integer.parseInt(propName.split(",")[1]);
				String[] colourSplit =propValue.split(",");
				colourAttribute = colourSplit[0];
				for(int i = 1; i < colourSplit.length; i++) {
					String[] colourVal = colourSplit[i].split(":");
					Map<String, String> ccm = colourCellMap.get(wsIdx);
					if(ccm == null) {
						ccm = new HashMap<>();
						colourCellMap.put(wsIdx, ccm);
					}
					ccm.put(colourVal[0].toUpperCase(), colourVal[1]);
				}
			} else if(propName.startsWith("COND")) {
				//Conditional Attribute
				Integer wsIdx = Integer.parseInt(propName.split(",")[2]);
				String[] conditionValues = null;

				try (CSVReader csv = new CSVReader(new StringReader(propValue))){
					conditionValues = csv.readNext();
				} catch (IOException | CsvValidationException e) {
					LOG.error("Error while trying to read CSV value '"+propValue+"' for metadata property conditional attribute.", e);
					e.printStackTrace();
				}

				if(conditionValues != null) {
					String attributeId = conditionValues[0];
					String attributeVal = conditionValues[1];
					String rule = conditionValues[2];
					String ruleDetail = conditionValues[3];

					List<AttributeRule> wsAttRules = attributeRules.get(wsIdx);
					if(wsAttRules == null) {
						wsAttRules = new ArrayList<>();
						attributeRules.put(wsIdx, wsAttRules);
					}
					wsAttRules.add(new AttributeRule(attributeId, attributeVal, CONDITION.parseString(rule), ruleDetail));
				}
			} else if(PATTERN.matcher(propName).matches()) {
				String[] split = propName.split(",");
				Integer[] indexes = new Integer[] {Integer.parseInt(split[0]), Integer.parseInt(split[1]), Integer.parseInt(split[2])};
				cellIndexes.put(indexes, propValue.split(":"));
			} else if(propName.startsWith(GLOBAL_VARIABLE_DIMENSION_PATTERN)) {
				String[] split = propName.split(",");
				CellAddress cellAddress = new CellAddress(propValue);
				String dimValue = getCellValue(cellAddress.getRow(), cellAddress.getColumn());
				globalVariables.put(Integer.parseInt(split[1]), dimValue.split(":")[0]);
			}
		}

		Map<String, List<CellIndex>> workSheetCellIndexMap = new HashMap<>();

		Map<Integer, Map<Integer, String>> worksheetVariableDimsMap = new HashMap<>();
		Map<IURNSingle<? extends IDSDRelatedBean>, Integer> obsSheetVariables = new HashMap<>();
		for(int i=0; i < workbook.getNumberOfSheets(); i++) {
			currentWorksheet = workbook.getSheetAt(i);
			String ws = getCellValue(0,1);
			if(!ObjectUtil.equivalent(ws, "Worksheet")) {
				continue;
			}
			String sheetName = getCellValue(0,2);

			Integer sheetIdx = -1;
			for(Integer idx : sheetMap.keySet()) {
				if(sheetMap.get(idx).equals(sheetName)) {
					sheetIdx  = idx;
				}
			}

			if(sheetIdx >= 0) {
				WorksheetIndex idx = worksheetIndexMap.get(sheetIdx);
				IURNSingle<? extends IDSDRelatedBean> sRef = sRefMap.get(sheetIdx);
				idx.setsRef(sRef);

				idx.setXlsxWorksheet(currentWorksheet);
				Map<Integer, String> reportedVariableValues = new HashMap<>(globalVariables);
				if(idx.getVariableDimensions().keySet().size() > 0) {
					Map<Integer, String> variableDims = idx.getVariableDimensions();

					for(Integer dimIdx : variableDims.keySet()) {
						String cellRef = variableDims.get(dimIdx);
						CellAddress cellAddress = new CellAddress(cellRef);
						String dimValue = getCellValue(cellAddress.getRow(), cellAddress.getColumn());
						if (dimValue != null) {
							reportedVariableValues.put(dimIdx, dimValue.split(":")[0]);
						}
						obsSheetVariables.put(sRef, sheetIdx);
					}
				}
				worksheetVariableDimsMap.put(sheetIdx, reportedVariableValues);
			}
		}
		for(Integer index : worksheetIndexMap.keySet()) {
			WorksheetIndex idx = worksheetIndexMap.get(index);
			currentWorksheet =  idx.getXlsxWorksheet();

			Set<Integer> rowIndexes = new TreeSet<>(idx.getRowKeys().keySet());
			Set<Integer> columnIndexes = idx.getColumnKeys().keySet();


			List<CellIndex> worksheetCells = new ArrayList<>();
			String worksheetName = sheetMap.get(index);
			workSheetCellIndexMap.put(worksheetName, worksheetCells);
			Map<Integer, String> reportedVaraibleValues = worksheetVariableDimsMap.get(index);
			if(reportedVaraibleValues == null) {
				reportedVaraibleValues = new HashMap<>();
			}
			Integer obsSheetVar = obsSheetVariables.get(idx.getsRef());
			if(obsSheetVar != null) {
				reportedVaraibleValues.putAll(worksheetVariableDimsMap.get(obsSheetVar));
			}
			if(columnIndexes.size() == 0) {
				Map<String, Integer> obsTable = idx.getNoHeaderColMapObsTable();
				Map<String, Integer> obsAttTable = idx.getNoHeaderColMapObsAttTable();
				Map<String, Integer> serAttTable = idx.getNoHeaderColMapSeriesAttTable();

				Integer obsAttributeTableStartRow = idx.getObsAttributeTableStart();
				Integer seriesAttributeTableStartRow = idx.getSeriesAttributeTableStart();
				if (obsAttributeTableStartRow == null) {
					obsAttributeTableStartRow = Integer.MAX_VALUE;
				}
				if (seriesAttributeTableStartRow == null) {
					seriesAttributeTableStartRow = Integer.MAX_VALUE;
				}
				for(Integer rowIdx : rowIndexes) {
					Map<String, Integer> toUse;
					if(rowIdx > seriesAttributeTableStartRow) {
						toUse = serAttTable;
					} else if(rowIdx > obsAttributeTableStartRow) {
						toUse = obsAttTable;
					} else {
						toUse = obsTable;
					}
					for(String attId : toUse.keySet()) {
						Integer colIdx = toUse.get(attId);
						String[] rowKey = idx.getRowKeys().get(rowIdx);
						for(Integer dimIdx : reportedVaraibleValues.keySet()) {
							rowKey[dimIdx] = reportedVaraibleValues.get(dimIdx);
						}
						if(!attId.equals(PrimaryMeasureBean.FIXED_ID)) {
							rowKey = Arrays.copyOf(rowKey, rowKey.length +1);
							rowKey[rowKey.length-1] = attId; //multiple attributes
						}
						worksheetCells.add(new CellIndex(rowIdx, colIdx, rowKey));
					}
				}
			} else {
				//New way is to use row indexes [A,B,,E] and col indexes [,,Z,] and merge them into a single cell index [A,B,Z,E]
				for(Integer rowIdx : rowIndexes) {
					String[] rowKey = idx.getRowKeys().get(rowIdx);
					for(Integer dimIdx : reportedVaraibleValues.keySet()) {
						rowKey[dimIdx] = reportedVaraibleValues.get(dimIdx);
					}
					for(Integer colIdx : columnIndexes) {
						String[] colKey = idx.getColumnKeys().get(colIdx);

						String[] cellKey = ObjectUtil.mergeStringArrays(rowKey, colKey);
						worksheetCells.add(new CellIndex(rowIdx, colIdx, cellKey));
					}
				}
			}
		}
		//Preserve the old way to read the data index (pre v9.3.5)
		//Prior to FR-2867 Reduce file size of Excel Templates to improve performance for opening the generated Excel file
		for(Integer[] index : cellIndexes.keySet()) {
			String[] key = cellIndexes.get(index);
			String worksheetName = sheetMap.get(index[0]);
			int col = index[1];
			int row = index[2];
			workSheetCellIndexMap.get(worksheetName).add(new CellIndex(row, col, key));
		}

		for(Integer sheetIndex : sheetMap.keySet()) {
			WorksheetIndex idx = worksheetIndexMap.get(sheetIndex);
			String sheetValue = sheetMap.get(sheetIndex);
			IURNSingle<? extends IDSDRelatedBean> sRef = idx.getsRef();
			worksheetMetadata.put(sheetValue, new WorksheetMetadata(idx, sRef,
					workSheetCellIndexMap.get(sheetValue),
					fixedValues.get(sheetIndex),
					colourAttribute,
					colourCellMap.get(sheetIndex)));

			List<AttributeRule> rules = attributeRules.get(sheetIndex);
			if(ObjectUtil.validCollection(rules)) {
				provMetadataMap.put(sRef, new ProvisionMetadata(rules));
			}
		}
	}

	/**
	 * Checks each worksheet, to work out the link between provision agreement and worksheet index(es)
	 */
	private void processWorksheetPlacement() {
		for(int i=0; i < workbook.getNumberOfSheets(); i++) {
			currentWorksheet = workbook.getSheetAt(i);
			String ws = getCellValue(0,1);
			if(!ObjectUtil.equivalent(ws, "Worksheet")) {
				continue;
			}
			String sheetName = getCellValue(0,2);
			currentSheetMetadata = worksheetMetadata.get(sheetName);

			String provisionRef = currentSheetMetadata.sRef.getURN();
			List<Integer> worksheetIndexes = provisionToWorksheets.get(provisionRef);
			if(worksheetIndexes == null) {
				worksheetIndexes = new ArrayList<>();
				provisionToWorksheets.put(provisionRef, worksheetIndexes);
				provisionList.add(provisionRef);
			}
			worksheetIndexes.add(i);
		}
	}

	private class ProvisionMetadata {

		//Conditional Attributes
		private List<AttributeRule> defaultConditions = new ArrayList<>();
		private List<AttributeRule> obsValConditions = new ArrayList<>();
		private Map<String, List<AttributeRule>> attValConditions = new HashMap<>();
		private boolean hasConditionalRules = false;

		public ProvisionMetadata(List<AttributeRule> attributeRules) {
			if(attributeRules != null) {
				for(AttributeRule rule : attributeRules) {
					hasConditionalRules = true;
					addAttributeRule(rule);
				}
			}
		}

		private void addAttributeRule(AttributeRule rule) {
			switch(rule.getCondition()) {
				case DEAFULT_VALUE :
					defaultConditions.add(rule);
					break;
				case ATTRIBUTE_NOTPRESENT :
				case ATTRIBUTE_PRESENT :
				case ATTRIBUTE_VALUE :
					String attId = rule.getRuleDetail().split("\\.")[0];
					List<AttributeRule> conditions = attValConditions.get(rule.getAttributeId());
					if(conditions == null) {
						conditions = new ArrayList<>();
						attValConditions.put(attId, conditions);
					}
					conditions.add(rule);
					break;
				default:
					obsValConditions.add(rule);
			}
		}
	}

	private class WorksheetMetadata {
		private IURNSingle<? extends IDSDRelatedBean> sRef;
		private List<CellIndex> cellIndexes;
		private Map<String, KeyValue> fixedValuesMap = new HashMap<>();

		//Fixed Values
		private List<KeyValue> fixedDatasetAttributes = new ArrayList<>();
		private List<KeyValue> fixedSeriesAttributes = new ArrayList<>();
		private List<KeyValue> fixedObsAttributes = new ArrayList<>();
		private String colourAttribute;
		private Map<String, String> colourCellMap;

		//Attribute Id to position in the Series String[]

		//		private Set<String> seriesAttributeIds = new HashSet<>();

		private Map<String, DecimalFormat> numberFormatMap = new HashMap<>();
		private Integer roundDecimals;
		private int seriesTableStart;


		public WorksheetMetadata(WorksheetIndex idx,
								 IURNSingle<? extends IDSDRelatedBean>  sRef,
								 List<CellIndex> cellIndexes,
								 Set<KeyValue> fixedValues,
								 String colourAttribute,
								 Map<String, String> colourCellMap) {
			this.sRef = sRef;
			this.roundDecimals = idx.getRoundDecimals();
			if(idx.getSeriesAttributeTableStart() == null) {
				seriesTableStart = Integer.MAX_VALUE;
			} else {
				seriesTableStart = idx.getSeriesAttributeTableStart();
			}
			if(this.roundDecimals != null) {
				DecimalFormat df = NumberUtils.getDecimalFormat(roundDecimals);
				numberFormatMap.put(SDMX_EDI_ATTRIBUTES.OBS_PRE_BREAK_V1.getId(), df);
				numberFormatMap.put(SDMX_EDI_ATTRIBUTES.OBS_PRE_BREAK_V2.getId(), df);
				numberFormatMap.put("PRE_BREAK", df);
				numberFormatMap.put(PrimaryMeasureBean.FIXED_ID, df);
			}
			this.cellIndexes = cellIndexes;
			this.colourAttribute = colourAttribute;
			this.colourCellMap = colourCellMap;
			Collections.sort(cellIndexes);
			if(fixedValues != null) {
				for(KeyValue kv : fixedValues) {
					fixedValuesMap.put(kv.getConcept(), kv);
				}
			}
		}

		private DataModel createDataModel(DataStructureBean dsd) {
			Map<String, Integer> seriesAttrPos = SdmxCollectionUtil.identifiableIdToPosition(dsd.getSeriesAttributes(DimensionBean.TIME_DIMENSION_FIXED_ID));
			Map<String, Integer> obsAttrPos = SdmxCollectionUtil.identifiableIdToPosition(dsd.getObservationAttributes());
			DataModel dataModel = new DataModel(seriesAttrPos, obsAttrPos);
			createDataModel(dsd, dataModel);
			return dataModel;
		}


		/**
		 * Takes the CellIndex which is a pointer to a cell in the excel workbook linked to a series key and optional attribute keys
		 * and groups this with other cell indexes that point to the same series key, storing the observation value and attributes
		 * in a map therefore consolidating the dataset into a single object
		 */
		private void createDataModel(DataStructureBean dsd, DataModel dataModel) {
			List<AttributeBean> sAtt = dsd.getSeriesAttributes(DimensionBean.TIME_DIMENSION_FIXED_ID);
			populateFixedValues(fixedDatasetAttributes, dsd.getDatasetAttributes());
			populateFixedValues(fixedSeriesAttributes, dsd.getSeriesAttributes(DimensionBean.TIME_DIMENSION_FIXED_ID));
			populateFixedValues(fixedObsAttributes, dsd.getObservationAttributes());


			//			this.seriesAttributeIds = CollectionUtil.identifiablesIds(dsd.getSeriesAttributes(DimensionBean.TIME_DIMENSION_FIXED_ID));

			fixedDatasetAttributes = Collections.unmodifiableList(fixedDatasetAttributes);
			fixedSeriesAttributes = Collections.unmodifiableList(fixedSeriesAttributes);
			fixedObsAttributes = Collections.unmodifiableList(fixedObsAttributes);
			currentDimensions = Collections.unmodifiableList(currentDsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION));

			if(roundDecimals == null) {
				storeComponentFormat(dsd.getPrimaryMeasure());
			}
			for(ComponentBean comp : dsd.getComponents()) {
				storeComponentFormat(comp);
			}

			Map<String, Integer> seriesAttrPos = SdmxCollectionUtil.identifiableIdToPosition(sAtt);
			Map<String, Integer> obsAttrPos = SdmxCollectionUtil.identifiableIdToPosition(dsd.getObservationAttributes());


			int seriesAttributeSize = seriesAttrPos.size();
			int obsAttributeSize = obsAttrPos.size()+1; //+1 for the observation value

			Map<String, Series> seriesMap = dataModel.series;  //series key to a series object
			Map<String, String>  attributeOnlyMap = null; //a map of observations with no value, to check if there is an additional colour to apply

			Integer colourAttributePos = colourAttribute == null ? null : obsAttrPos.get(colourAttribute);
			for(CellIndex index : this.cellIndexes) {
				int expectedKeyLength = multipleReportingPeriods && index.row < seriesTableStart ? currentDimensions.size()+1 : currentDimensions.size();
				boolean isAttribute = index.key.length > expectedKeyLength;
				String cellValue = getCellValue(index.row, index.col);
				if(!ObjectUtil.validString(cellValue)) {
					if(isAttribute == false && colourAttributePos != null) {
						//Store the colour just in case it is needed for an attribute only obs
						String colourAttribute = getColourAttributeValue(index, colourAttributePos);
						if(colourAttribute != null) {
							if(attributeOnlyMap == null) {
								attributeOnlyMap = new HashMap<>();
							}
							attributeOnlyMap.put(SeriesUtil.toSeriesKey(index.key, currentDimensions.size()), colourAttribute);
						}
					}
					continue;
				}
				String obsDate = multipleReportingPeriods ? null : reportingPeriod == null ? null : reportingPeriod.getDateInSdmxFormat();
				if(multipleReportingPeriods) {
					if(index.key.length < expectedKeyLength) {
						//The Observation time was expected to be part of the cell key, but it is not.  This implies that the worksheet is not
						//for a specific time period, but the period specified on the Main worksheet.
						//The only way to get here is either if the main worksheet is missing, or the time period was not filled in on the main worksheet
						if(workbook.getSheet("Main") == null) {
							throw new SdmxSemmanticException("Expected Worksheet with name 'Main' is not present in Excel Workbook");
						} else {
							throw new SdmxSemmanticException("Missing Reporting Period (Cell D12 on the Main worksheet)");
						}
					}
					obsDate = index.key[currentDimensions.size()];
				}
				String seriesKey = SeriesUtil.toSeriesKey(index.key, currentDimensions.size());
				Series series = seriesMap.get(seriesKey);
				if(series == null) {
					series = new Series(seriesAttributeSize);
					seriesMap.put(seriesKey, series);
				}

				if(isAttribute) {
					//This is an Attribute
					String attributeId = index.key[expectedKeyLength];
					Integer attrPos = seriesAttrPos.get(attributeId);
					boolean isSeries = attrPos != null;
					if(!isSeries) {
						attrPos = obsAttrPos.get(attributeId);
					}
					if(attrPos == null) {
						//unknown attribute
						continue;
					}
					cellValue = currentSheetMetadata.formatValue(attributeId, cellValue);

					if(isSeries) {
						if(series.obs.size() > 0) {
							series.seriesAttributes[attrPos] = cellValue;
						}
					} else {
						String[] obs = series.obs.get(obsDate);
						if(obs != null) {
							obs[attrPos] = cellValue;
						} else if(!attributeId.equals(colourAttribute)){
							//An attribute with no observation value
							obs =  new String[obsAttributeSize];
							obs[attrPos] = cellValue;
							if(attributeOnlyMap != null) {
								obs[colourAttributePos] = attributeOnlyMap.get(seriesKey);
							}
							series.obs.put(obsDate, obs);
						}
					}
				} else {
					//This is an observation
					String[] obs =  new String[obsAttributeSize];
					if(colourAttributePos != null) {
						obs[colourAttributePos] = getColourAttributeValue(index, colourAttributePos);
					}
					cellValue = currentSheetMetadata.formatValue(PrimaryMeasureBean.FIXED_ID, cellValue);
					obs[obs.length-1] = cellValue;
					series.obs.put(obsDate, obs);
				}
			}
		}

		private String getColourAttributeValue(CellIndex index, Integer attPos) {
			if(currentSheetMetadata.isUsingColour()) {
				//use default reported colour if it exists, and overwrite later if necessary
				String hex = getCellColourHex(index.row, index.col);
				if(hex != null && !hex.equals("#FFFFFF") && currentSheetMetadata.colourCellMap != null) { //White is deemed as missing
					return currentSheetMetadata.colourCellMap.get(hex);
				}
			}
			return null;
		}

		private void storeComponentFormat(ComponentBean component) {
			RepresentationBean pmRep = component.getRepresentation();
			if(pmRep != null && pmRep.getTextFormat() != null) {
				BigInteger decimals = pmRep.getTextFormat().getDecimals();
				if(decimals != null) {
					DecimalFormat df = NumberUtils.getDecimalFormat(decimals.intValue());
					numberFormatMap.put(component.getId(), df);
				}
			}
		}

		private void populateFixedValues(List<KeyValue> fixed, List<? extends ComponentBean> components) {
			for(ComponentBean att : components) {
				KeyValue kv = fixedValuesMap.get(att.getId());
				if(kv != null) {
					fixed.add(kv);
				}
			}
		}

		private boolean isUsingColour() {
			return colourAttribute != null;
		}

		/**
		 * Formats numerical values based on the DSD (for example rounds to n decimal places)
		 * @param componentId - includeing OBS_VALUE for primary measure
		 * @param value
		 * @return
		 */
		private String formatValue(String componentId, String value) {
			if(value == null) {
				return value;
			}
			if(!value.contains(".")) {
				return value;
			}
			DecimalFormat df = numberFormatMap.get(componentId);
			if(df != null) {
				return NumberUtils.round(df, value);
			}
			return value;
		}
	}

	private class DataModel {
		private String[] seriesAttrPos;
		private String[] obsAttrPos;
		private Map<String, Series> series = new TreeMap<>();
		private Iterator<String> seriesIterator;
		private Iterator<String> obsIterator;

		private Series currentSeries;
		private Keyable currentKey;
		private Observation currentObs;


		public DataModel(Map<String, Integer> seriesAttrPos, Map<String, Integer> obsAttrPos) {
			this.seriesAttrPos = CollectionUtil.positionMapToArray(seriesAttrPos);
			this.obsAttrPos = CollectionUtil.positionMapToArray(obsAttrPos);
		}

		/**
		 * Moves to the next series returning the series key or null (no series left for dataset)
		 * @return
		 */
		public boolean moveNextSeries() {
			obsIterator = null;
			currentObs = null;
			currentKey = null;
			currentSeries = null;
			if(seriesIterator == null) {
				seriesIterator = series.keySet().iterator();
			}
			while(seriesIterator.hasNext()) {
				String seriesKey = seriesIterator.next();
				currentSeries = series.get(seriesKey);
				if(currentSeries.obs.size() == 0) {
					continue;
				}
				List<KeyValue> key = new ArrayList<>();
				int i=0;
				String[] seriesKeyArray = seriesKey.split(":");
				for(DimensionBean dim : currentDimensions) {
					key.add(KeyValueImpl.getInstance(dim.getId(), seriesKeyArray[i]));
					i++;
				}
				List<KeyValue> keyAttributes = new ArrayList<>(currentSheetMetadata.fixedSeriesAttributes);
				addAttributeValues(currentSeries.seriesAttributes, seriesAttrPos, keyAttributes);
				currentKey = KeyableImpl.seriesKey(currentDataflow, currentDsd, key, keyAttributes);
				return true;
			}
			return false;
		}

		/**
		 * Moves to the next observation in the series returning the obs or null (no obs left for series)
		 * @return
		 */
		public boolean moveNextObs() {
			if(obsIterator == null) {
				if(currentSeries == null) {
					return false;
				}
				obsIterator = currentSeries.obs.keySet().iterator();
			}
			if(!obsIterator.hasNext()) {
				return false;
			}
			String obsDate = obsIterator.next();
			String[] obsAttrAndVal = currentSeries.obs.get(obsDate);

			String obsValue = obsAttrAndVal[obsAttrAndVal.length-1];
			List<KeyValue> obsAttributes = new ArrayList<>(currentSheetMetadata.fixedObsAttributes);
			addAttributeValues(obsAttrAndVal, obsAttrPos, obsAttributes);
			obsValue = currentSheetMetadata.formatValue(PrimaryMeasureBean.FIXED_ID, obsValue);
			currentObs = ObservationImpl.timeSeries(currentKey, obsDate, obsValue, obsAttributes);
			return true;
		}

		private void addAttributeValues(String[] reportedValues, String[] attrIds, List<KeyValue> keyAttributes) {
			if(reportedValues != null) {
				for(int i=0; i < reportedValues.length; i++) {
					String attrVal = reportedValues[i];
					if(ObjectUtil.validString(attrVal) && attrIds.length > i) {
						String attrId = attrIds[i];
						keyAttributes.add(KeyValueImpl.getInstance(attrId, attrVal));
					}
				}
			}
		}

		/**
		 * Called after the data model is fully build from all the worksheets for a Provision Agreement.
		 *
		 * This method calculates all the conditional attribute values in the data model
		 */
		private void calculateConditionalAttributes() {
			ProvisionMetadata provisionMetadata = provMetadataMap.get(currentSheetMetadata.sRef);
			if (provisionMetadata == null || !provisionMetadata.hasConditionalRules) {
				return;
			}

			List<AttributeRule> defaultConditions = null;
			List<AttributeRule> obsValConditions = null;
			Map<Integer, List<AttributeRule>> attValConditions = null; //att idx to rules
			if (provisionMetadata != null) {
				if(ObjectUtil.validCollection(provisionMetadata.defaultConditions)) {
					defaultConditions = provisionMetadata.defaultConditions;
				}
				if(ObjectUtil.validCollection(provisionMetadata.obsValConditions)) {
					obsValConditions = provisionMetadata.obsValConditions;
				}
				if(ObjectUtil.validMap(provisionMetadata.attValConditions)) {
					attValConditions = new HashMap<>();
					for(String attId : provisionMetadata.attValConditions.keySet()) {
						int attPos = CollectionUtil.indexInArray(obsAttrPos, attId);
						if(attPos >=0 ) {
							attValConditions.put(attPos, provisionMetadata.attValConditions.get(attId));
						}
					}
				}
			}
			for(String sk : series.keySet()) {
				Series currentSeries = series.get(sk);
				for(String obsTime : currentSeries.obs.keySet()) {
					String[] reportedVales = currentSeries.obs.get(obsTime);
					Set<String> processedAttributes = new HashSet<>();
					if(attValConditions != null) {
						for(Integer attPos : attValConditions.keySet()) {
							String reportedVal = reportedVales[attPos];
							for(AttributeRule ar : attValConditions.get(attPos)) {
								boolean addRule = false;
								switch(ar.getCondition()) {
									case ATTRIBUTE_VALUE :
										addRule = ObjectUtil.equivalent(reportedVal, ar.getRuleDetail().split("\\.")[1]);
										break;
									case ATTRIBUTE_NOTPRESENT :
										addRule = !ObjectUtil.validString(reportedVal);
										break;
									case ATTRIBUTE_PRESENT :
										addRule = ObjectUtil.validString(reportedVal);
										break;
								}
								if(addRule && !processedAttributes.contains(ar.getAttributeId())) {
									processedAttributes.add(ar.getAttributeId());
									addDerivedAttributeValue(currentSeries, reportedVales, ar.getAttributeId(), ar.getAttributeValue());
								}
							}
						}
					}
					if(obsValConditions != null) {
						String reportedVal = reportedVales[reportedVales.length-1];
						for(AttributeRule ar : obsValConditions) {
							boolean addRule = false;
							switch(ar.getCondition()) {
								case OBSERAVTION_NAN :
									addRule = ObjectUtil.equivalent(reportedVal, "NaN");
									break;
								case OBSERAVTION_VALUE :
									if(ObjectUtil.validString(reportedVal)) {
										if(ar.getEquality() == EQUALITY.EQUAL) {
											addRule = ObjectUtil.equivalent(reportedVal, ar.getRuleDetail());
										} else {
											try {
												Double d = Double.parseDouble(reportedVal);
												Double r = Double.parseDouble(ar.getRuleDetail());
												switch(ar.getEquality()) {
													case GT :
														addRule = d > r;
														break;
													case LT :
														addRule = d < r;
														break;
													case GT_EQUAL :
														addRule = d >= r;
														break;
													case LT_EQUAL :
														addRule = d <= r;
														break;
												}
											} catch(Throwable th) {}
										}
									}
									break;
								case OBSERVATION_MISSING :
									addRule = !ObjectUtil.validString(reportedVal);
									break;

								case OBSERVATION_PRESENT :
									addRule = ObjectUtil.validString(reportedVal);
									break;

							}
							if(addRule && !processedAttributes.contains(ar.getAttributeId())) {
								processedAttributes.add(ar.getAttributeId());
								addDerivedAttributeValue(currentSeries, reportedVales, ar.getAttributeId(), ar.getAttributeValue());
							}
						}
					}
					if(defaultConditions != null) {
						String reportedVal = reportedVales[reportedVales.length-1];
						for(AttributeRule ar : defaultConditions) {
							if(ObjectUtil.validString(reportedVal) && !processedAttributes.contains(ar.getAttributeId())) {
								processedAttributes.add(ar.getAttributeId());
								addDerivedAttributeValue(currentSeries, reportedVales, ar.getAttributeId(), ar.getAttributeValue());
							}
						}
					}
				}
			}
		}

		private void addDerivedAttributeValue(Series series, String[] obsAttr, String attributeId, String attributeValue) {
			if(series.seriesAttributes != null) {
				int idx = CollectionUtil.indexInArray(seriesAttrPos, attributeId);
				if(idx >=0 ) {
					series.seriesAttributes[idx] = attributeValue;
					return;
				}
			}
			int idx = CollectionUtil.indexInArray(obsAttrPos, attributeId);
			if(idx >=0 ) {
				obsAttr[idx] = attributeValue;
			}
		}
	}

	private class Series {
		private String[] seriesAttributes;  //series key
		private Map<String, String[]> obs;  //each array is obs value, obs

		public Series(int seriesAttributeSize) {
			if(seriesAttributeSize > 0) {
				seriesAttributes = new String[seriesAttributeSize];
			}
			obs = new TreeMap<>();
		}
	}


	/**
	 * Contains a link to a cell, along with the related series key
	 *
	 * The key is either a full series key, or if the cell is a pointer to a series
	 * attribute, the last part of the key will be the attribute Id
	 *
	 * Example:
	 * [A, S, 5A, 4B, F, B, A, A, LC1, A, 1C, OBS_CONF]
	 */
	private class CellIndex implements Comparable<CellIndex> {
		private int row;
		private int col;
		private String[] key;

		public CellIndex(int row, int col, String[] key) {
			this.row = row;
			this.col = col;
			this.key = key;
		}

		@Override
		public int compareTo(CellIndex that) {
			int i = Integer.compare(this.row, that.row);
			if(i == 0) {
				i = Integer.compare(this.col, that.col);
			}
			return i;
		}

		@Override
		public String toString() {
			return "r="+row+",c="+col;
		}

	}



	private String getCellValue(int rowIdx, int cellIdx) {
		XSSFRow row = currentWorksheet.getRow(rowIdx);
		if(row == null) {
			return null;
		}
		XSSFCell cell = row.getCell(cellIdx);
		return POIUtils.getCellValue(cell, false);
	}

	/**
	 * Returns the cells colour as a hex string, or null if not defined
	 * @param rowIdx
	 * @param cellIdx
	 * @return
	 */
	private String getCellColourHex(int rowIdx, int cellIdx) {
		XSSFCell cell = currentWorksheet.getRow(rowIdx).getCell(cellIdx);

		String cellColour = null;
		XSSFCellStyle style = cell.getCellStyle();
		if(style != null && style.getFillForegroundColorColor() != null) {
			cellColour = cell.getCellStyle().getFillForegroundColorColor().getARGBHex();
			cellColour = cellColour.replaceFirst("FF", "#").toUpperCase();
		}
		return cellColour;
	}

	private WorksheetIndex getWorksheetIndex(Map<Integer, WorksheetIndex> worksheetIndexMap, String cProp) {
		String[] split = cProp.split(",");
		return getWorksheetIndex(worksheetIndexMap, Integer.parseInt(split[0]));
	}

	private WorksheetIndex getWorksheetIndex(Map<Integer, WorksheetIndex> worksheetIndexMap, Integer idx) {
		WorksheetIndex returnIdx = worksheetIndexMap.get(idx);
		if(returnIdx == null) {
			returnIdx = new WorksheetIndex(idx);
			worksheetIndexMap.put(idx, returnIdx);
		}
		return returnIdx;
	}
}
