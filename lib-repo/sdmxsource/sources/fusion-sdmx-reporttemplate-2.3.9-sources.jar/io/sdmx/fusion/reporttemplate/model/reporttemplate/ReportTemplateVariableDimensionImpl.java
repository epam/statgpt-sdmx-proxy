package io.sdmx.fusion.reporttemplate.model.reporttemplate;

import java.util.List;

import io.sdmx.fusion.reporttemplate.api.model.template.ReportTemplateVariableDimension;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateComponent;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;

public class ReportTemplateVariableDimensionImpl implements ReportTemplateVariableDimension {
	private ReportingTemplateComponent reportingTemplateComponent;
	private List<EnumeratedItemBean> codes;	
	
	public ReportTemplateVariableDimensionImpl(ReportingTemplateComponent reportingTemplateComponent, List<EnumeratedItemBean> codes) {
		this.reportingTemplateComponent = reportingTemplateComponent;
		this.codes = codes;
	}

	@Override
	public ReportingTemplateComponent getReportingTemplateComponent() {
		return reportingTemplateComponent;
	}

	@Override
	public List<EnumeratedItemBean> getValidCodes() {
		return codes;
	}

}
