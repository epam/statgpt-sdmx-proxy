package io.sdmx.fusion.reporttemplate.builder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.buider.Builder;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.ICheckingTableModel;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.PivotTableCollection;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.PivotTableModel;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.PivotTableModel.TABLE_TYPE;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.TableRow;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateComponent;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateDimension;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateDimensionCode;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateSeries;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateWorksheet;
import io.sdmx.fusion.reporttemplate.model.table.PivotTableCollectionImpl;
import io.sdmx.fusion.reporttemplate.model.table.PivotTableModelImpl;
import io.sdmx.fusion.reporttemplate.model.worksheet.CheckingTableModel;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.utils.core.object.ObjectUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PivotTableBuilder implements Builder<PivotTableCollection, ReportingTemplateWorksheet> {
	private static final Logger LOG = LoggerFactory.getLogger(PivotTableBuilder.class);
	public static final PivotTableBuilder INSTANCE = new PivotTableBuilder();

	@Override
	/**
	 * Builds multiple pivot tables for the worksheet:
	 * 
	 * The first table is always the observation table with (possibly) integrated attributes
	 * The second table is always for observation attributes table within the same
	 * the subsequent table are for the attributes to be used as a separate table
	 */
	public PivotTableCollection build(ReportingTemplateWorksheet ws) throws SdmxException {
		LOG.info("Build Table Model for worksheet '"+ws.getName()+"'");
		int attrIdCount = ws.getAttributesInReport().size();
		String[] attrIds = new String[attrIdCount];
		int i =0;
		for(ReportingTemplateComponent attr : ws.getAttributesInReport()) {
			attrIds[i] = attr.getComponent().getId();
			i++;
		}
		PivotTableModelImpl obsTable = new PivotTableModelImpl(ws, PivotTableModel.TABLE_TYPE.OBS, attrIds);
		PivotTableModel obsAttrTable = null;
		PivotTableModel serAttrTable = null;
		Map<String, PivotTableModel> obsAttrWsTables = null;

		int seriesCols = buildTableHeader(obsTable, false, ws, PivotTableModel.TABLE_TYPE.OBS, null);
		boolean addColSpan = addColspanToObsTable(ws);
		buildTableRows(obsTable, ws, seriesCols, PivotTableModel.TABLE_TYPE.OBS, addColSpan, null);

		if(ws.getObsAttributesInSeparateTable().size() > 0) {
			attrIdCount = ws.getObsAttributesInSeparateTable().size();
			attrIds = new String[attrIdCount];
			i =0;
			for(ReportingTemplateComponent attr : ws.getObsAttributesInSeparateTable()) {
				attrIds[i] = attr.getComponent().getId();
				i++;
			}
			obsAttrTable = new PivotTableModelImpl(ws, PivotTableModel.TABLE_TYPE.OBS_ATTRIBUTE, attrIds);
			seriesCols = buildTableHeader(obsAttrTable, false, ws, PivotTableModel.TABLE_TYPE.OBS_ATTRIBUTE, null);
			buildTableRows(obsAttrTable, ws, seriesCols, PivotTableModel.TABLE_TYPE.OBS_ATTRIBUTE, false, null);
		}
		if(ws.getSeriesAttributesInSeparateTable().size() > 0) {
			attrIdCount = ws.getSeriesAttributesInSeparateTable().size();
			attrIds = new String[attrIdCount];
			i =0;
			for(ReportingTemplateComponent attr : ws.getSeriesAttributesInSeparateTable()) {
				attrIds[i] = attr.getComponent().getId();
				i++;
			}
			serAttrTable = new PivotTableModelImpl(ws, PivotTableModel.TABLE_TYPE.SERIES_ATTRIBUTE, attrIds);
			seriesCols = buildTableHeader(serAttrTable, false, ws, PivotTableModel.TABLE_TYPE.SERIES_ATTRIBUTE, null);
			buildTableRows(serAttrTable, ws, seriesCols, PivotTableModel.TABLE_TYPE.SERIES_ATTRIBUTE, false, null);
		}
		if(ws.getObsAttributesInSeparateWorksheet().size() > 0) {
			obsAttrWsTables = new HashMap<>();
			for(ReportingTemplateComponent att : ws.getObsAttributesInSeparateWorksheet()) {
				attrIds = new String[] {att.getComponent().getId()};
				PivotTableModel pv  = new PivotTableModelImpl(ws, PivotTableModel.TABLE_TYPE.OBS_ATTRIBUTE, attrIds);
				//A bit odd that the table type is OBS, this acts like a obs table, 
				seriesCols = buildTableHeader(pv, true, ws, PivotTableModel.TABLE_TYPE.OBS, att);
				buildTableRows(pv, ws, seriesCols, PivotTableModel.TABLE_TYPE.OBS, false, att);
				obsAttrWsTables.put(att.getComponent().getId(), pv);
			}
		}

		obsTable.createValidaitonCells(ws);  //Update Obs Pivot Table Model to include validation cells 

		ICheckingTableModel checkingModel = null;
		if(ws.includeFormulaCheckingTable() && ObjectUtil.validCollection(obsTable.getValidationRules())) {
			PivotTableModel obsTableModel = obsTable;
			//THIS IS LEFT HERE JUST IN CASE THE CHECK TABLE SHOULD HAVE THE INLINE ATTRIBUTES REMOVED
			//			PivotTableModel obsTableNoAttributes = null;
			//			if(ws.getAttributesInReport().size() > 0) {
			//				//more complex as the observation table has attributes in it alongside the observations, in the checking
			//				//table we do not want attribute ids, so we will rebuild the observation table model without the attribute ids
			//				obsTableNoAttributes = new PivotTableModelImpl(ws, true, new String[]{});
			//				seriesCols = buildTableHeader(obsTableNoAttributes, ws, PivotTableModel.TABLE_TYPE.CHECKING, null);
			//				
			//				buildTableRows(obsTableNoAttributes, ws, seriesCols, PivotTableModel.TABLE_TYPE.CHECKING, addColSpan, null);
			//			}
			checkingModel = new CheckingTableModel(obsTableModel);
		}

		return new PivotTableCollectionImpl(obsTable, obsAttrTable,  obsAttrWsTables, serAttrTable, checkingModel);
	}

	/**
	 * A Colspan is added to the Observation Table when it has to align the header with the Attribute table. As the attribute
	 * table contains an extra left hand column (the attribute Id) it sometimes requires the observation table to add an extra colspan
	 * to its last column. This is not always the case, for example if the attribute table has the attribute ids in the header columns, or if 
	 * the table is for series attributes (no time element) and the observation table has multiple time periods (as it alredy has an extra time column).
	 * If the observation table contains attributes in the obs table it will already have an extra column, and is another example of when an additional colspan
	 * would not be required.
	 * 
	 * A colspan is added to the observation table when the following conditions are met:
	 * 1. Obs table contains header values AND
	 * 2. Obs table does not contain any observation attributes AND
	 * 
	 * 3. There is a separate table containing observation attributes OR
	 * 4. There is a separate table containing series attributes AND not multiple time periods
	 * 
	 * Under these conditions, the obs table requires an extra column being used so that the table header from the obs table match up with the table headers of the observation table
	 * @return
	 */
	private boolean addColspanToObsTable(ReportingTemplateWorksheet ws) {
		//There are already table columns, so we know the attribute ids will be in the rows not header
		//There are no attributes in the observation table
		if(ObjectUtil.validCollection(ws.getTableColumns(true)) && !ObjectUtil.validCollection(ws.getAttributesInReport())) {
			//observation attributes are in a separate table, we need to add a colspan
			if(ObjectUtil.validCollection(ws.getObsAttributesInSeparateTable())) {
				return true;
			}
			//only 1 time period and there are series attributes, we need to add a colspan
			if(!ws.hasTimePeriods() && ObjectUtil.validCollection(ws.getSeriesAttributesInSeparateTable())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Builds the model for the table headers
	 * 
	 * @param pvModel
	 * @param ws
	 * @param tableType
	 * @param att when building an attribute in a seperate worksheet
	 * @return a count of the number of series which are shown in the columns - if there are no columns, then 0 is returned, this indicates that the Observation becomes a column along with Observation Attributes
	 */
	private int buildTableHeader(PivotTableModel pvModel, 
			boolean isAttributesInSeperateWorksheet,
			ReportingTemplateWorksheet ws, 
			PivotTableModel.TABLE_TYPE tableType, 
			ReportingTemplateComponent att) {
		//build header section
		boolean includeTime = tableType != TABLE_TYPE.SERIES_ATTRIBUTE;
		int[] aggregateDims = getAggregatedDimensions(ws, tableType, false);
		boolean hasColumns = aggregateDims.length > 0;
		int colspan = ws.getTableRows(includeTime).size();
		if(tableType == TABLE_TYPE.SERIES_ATTRIBUTE) {
			if(ws.hasTimePeriods() && ws.isInTableRow(ws.getDataStructureBean().getTimeDimension())) {
				//the obs table has an additional time period column, so the series attribute table needs to 
				//add a colspan to the header to take account of this
				colspan++;  
			}
		} else if(att == null && hasColumns && ObjectUtil.validCollection(ws.getAttributesInReport())) {
			colspan++;
		}

		//If this is not an attribute only worksheet, and there are attributes as a separate table, 
		//and no attributes in this table, increase the colspan by 1 of the header and first 
		if(!isAttributesInSeperateWorksheet && addColspanToObsTable(ws)) {
			colspan++;
		}
		if(colspan == 0) {
			colspan = 1;//The header titles must have a colspan of something
		}

		ReportingTemplateSeries allSeries = ws.getSeries();

		//No Header Dimensions
		if(hasColumns == false) {
			TableRow header = pvModel.addTableRow(true);
			for(ReportingTemplateDimension dim : ws.getTableRows(includeTime)) {
				header.addHeaderTitle(dim.getDimensionLabel(), 1, 1);
			}
			switch(tableType) {
			case OBS :
				header.addHeaderTitle(att == null ? "Obs Value" : att.getLabel() + " Value", 1, 1);
				if(att == null && ws.getAttributesInReport() != null) {
					for(ReportingTemplateComponent attr: ws.getAttributesInReport()) {
						header.addHeaderTitle(attr.getLabel(), 1, 1);
					}
				}
				break;
			case OBS_ATTRIBUTE :
				for(ReportingTemplateComponent attr: ws.getObsAttributesInSeparateTable()) {
					header.addHeaderTitle(attr.getLabel(), 1, 1);
				}
				break;
			case SERIES_ATTRIBUTE :
				for(ReportingTemplateComponent attr: ws.getSeriesAttributesInSeparateTable()) {
					header.addHeaderTitle(attr.getLabel(), 1, 1);
				}
				break;
			case CHECKING :
				header.addHeaderTitle("Check Value", 1, 1);
				break;
			}
			return 0;
		}

		List<String[]> aggregatedSeriesCols = allSeries.aggregate(aggregateDims);

		String[] headerPartialKey = new String[aggregateDims.length];

		int dimIdx = 0;
		List<TableRow>[] rowsPerDimension = new List[aggregateDims.length];
		for(ReportingTemplateDimension dim : ws.getTableColumns(includeTime)) {
			List<TableRow> tableRows = new ArrayList<>();
			tableRows.add(pvModel.addTableRow(true));

			//Build the Header Title for example 'Balance Sheet Position Hierarchy'
			int rowspan = getHierarchyDepth(dim.getCodes(), 0);
			//Add additional rows for other members of the dimension's hierarchy
			for(int row=1; row < rowspan; row++) {
				tableRows.add(pvModel.addTableRow(true));
			}
			rowsPerDimension[dimIdx] = tableRows;
			dimIdx++;
		}
		dimIdx = 0;
		for(ReportingTemplateDimension dim : ws.getTableColumns(includeTime)) {
			//Build the Header Title for example 'Balance Sheet Position Hierarchy'
			int rowspan = getHierarchyDepth(dim.getCodes(), 0);
			rowsPerDimension[dimIdx].get(0).addHeaderTitle(dim.getDimensionLabel(), colspan, rowspan);
			dimIdx++;
		}
		//All the header rows are built, now build the Header Values (light blue, for example 'Total Claims')
		buildTableHeaderValues(headerPartialKey, ws.getTableColumns(includeTime), rowsPerDimension, 0, aggregateDims, 0, aggregatedSeriesCols, null, 0, 0, 0);
		return aggregatedSeriesCols.size();
	}


	/**
	 * Builds the Header values for the given Dimension
	 * @param tHead - a list of existing table rows
	 * @param dimIdx - the index of the dimension that is being rendered
	 * @param cellIndex - this is the cell index that the cell will be placed on
	 * @param allSeries - these are all the series that exist along the horizontal axis - an aggregate of the full dataset based on the header dimensions
	 * @param codes - the codes for this Dimension, this may contain a hierarchy
	 * @param hDepth - the current depth in the Hierarchy for the Dimension - 0 indexed
	 */
	private void buildTableHeaderValues(
			String[] partialKey,
			List<ReportingTemplateDimension> tableColumns,
			List<TableRow>[] rowsPerDimension,
			int idx, 
			int[] aggregateDims,
			int cellIndex,
			List<String[]> allSeries, 
			List<ReportingTemplateDimensionCode> codes,
			int hDepth,
			int skipLines,
			int parentRowSpan) {

		if(codes == null) {
			codes = tableColumns.get(idx).getCodes();
		}
		int maxLength = allSeries.size() - cellIndex;

		TableRow thisRow = rowsPerDimension[idx].get(hDepth);

		int nextIdx = idx + 1;
		boolean hasNextDimension = aggregateDims.length > nextIdx ? true : false;

		int rpds = rowsPerDimension[idx].size();
		for(ReportingTemplateDimensionCode currentCode : codes) {
			int newHDepth = hDepth;
			List<String[]> filterSeries;
			int colspan=0;
			String label = "";
			//			for(int skip=0; skip < skipLines; skip++) {
			//				label += "\r\n";
			//			}
			label += currentCode.getCodeLabel();
			int rowspan;
			if(!currentCode.hasData()) {
				filterSeries = new ArrayList<>();
				for(ReportingTemplateDimensionCode child : currentCode.getChildren(true)) {
					List<String[]> series  = filterSeries(child.getId(), idx, allSeries);
					filterSeries.addAll(series);
				}
				skipLines++;
				colspan = filterSeries.size(); 
				rowspan = 1; //currentCode.getDepth()+1;
				if(colspan > 0) {
					thisRow.addHeaderColValue(label, colspan, rowspan, partialKey);  
					newHDepth+=rowspan;
				}
			} else {
				String codeId = currentCode.getId();
				partialKey[idx] = codeId;
				filterSeries = filterSeries(codeId, idx, allSeries);

				if(filterSeries.size() == 0) {
					if(currentCode.hasChildren()) {
						int newSkipLines = currentCode.hasData() ? skipLines+1 : 0;
						buildTableHeaderValues(partialKey, tableColumns, rowsPerDimension, idx, aggregateDims, cellIndex, allSeries, currentCode.getChildren(), newHDepth, newSkipLines, 1);
					} 
					continue;
				}
				//colspan is the number of Series under this Dimension label
				colspan =  filterSeries.size();

				if(colspan > 0) {
					rowspan = rpds - (hDepth);
					if(parentRowSpan > 1 && rowspan < parentRowSpan && currentCode.hasChildren() == false) {
						rowspan = parentRowSpan;
					}
					thisRow.addHeaderColValue(label, colspan, rowspan, partialKey);
					maxLength = maxLength - colspan;
				} else {
					rowspan = parentRowSpan;
				}
			}
			if(hasNextDimension && currentCode.hasData()) {
				//move to the next dimension
				buildTableHeaderValues(partialKey, tableColumns, rowsPerDimension, nextIdx, aggregateDims, cellIndex, filterSeries, null, 0, skipLines, 1);
			}
			if(currentCode.hasChildren()) {
				int newSkipLines = currentCode.hasData() ? skipLines+1 : 0;
				buildTableHeaderValues(partialKey, tableColumns, rowsPerDimension, idx, aggregateDims, cellIndex, allSeries, currentCode.getChildren(), newHDepth, newSkipLines, rowspan);
			} 
		}
		partialKey[idx] = null;
	}

	
	/**
	 * 
	 * @param pvModel
	 * @param ws
	 * @param seriesCols
	 * @param tableType
	 * @param addColspan - this is relevent to the observation table, based on the outcome of the addColspanToObsTable method
	 * @param att
	 */
	private void buildTableRows(PivotTableModel pvModel, 
			ReportingTemplateWorksheet ws, 
			int seriesCols, 
			PivotTableModel.TABLE_TYPE tableType, 
			boolean addColspan, 
			ReportingTemplateComponent att) {
		boolean includeTime = tableType != TABLE_TYPE.SERIES_ATTRIBUTE;

		int[] aggregateDims = getAggregatedDimensions(ws, tableType, true);
		List<TableRow> rows = new ArrayList<>();
		//BUILD EMPTY ROWS
		int attributesInReport = 0;
		boolean obsInRows = seriesCols > 0;
		if(tableType == PivotTableModel.TABLE_TYPE.OBS &&  att == null && obsInRows == true && ObjectUtil.validCollection(ws.getAttributesInReport())) {
			attributesInReport = ws.getAttributesInReport().size();
		}

		int offset = pvModel.getTableRows().size();
		if(aggregateDims.length == 0) { 
			//No Row Dimensions - each row is 
			if(tableType == PivotTableModel.TABLE_TYPE.OBS) {
				int numRows = 1 + attributesInReport;
				for(int i = 0; i < numRows; i++) {
					rows.add(pvModel.addTableRow(false));
				}
				if(attributesInReport == 0) {
					rows.get(0).addHeaderRowValue(att == null ? "Obs Value" : att.getLabel() +" Value", 1, 1, null);
				}
			} else if(tableType == PivotTableModel.TABLE_TYPE.OBS_ATTRIBUTE) {
				int numRows = ws.getObsAttributesInSeparateTable().size();
				for(int i = 0; i < numRows; i++) {
					rows.add(pvModel.addTableRow(false));
				}
			} else if(tableType == PivotTableModel.TABLE_TYPE.SERIES_ATTRIBUTE) {
				int numRows = ws.getSeriesAttributesInSeparateTable().size();
				for(int i = 0; i < numRows; i++) {
					rows.add(pvModel.addTableRow(false));
				}
			}
		} else {
			List<String[]> aggregatedSeriesCols = ws.getSeries().aggregate(aggregateDims);
			int numRows = aggregatedSeriesCols.size();

			int attributeMultiplier = 1; 
			if(att == null && attributesInReport > 0) {
				attributeMultiplier = ws.getAttributesInReport().size() + 1;
				numRows *= attributeMultiplier;
			} else if(att == null && tableType == PivotTableModel.TABLE_TYPE.OBS_ATTRIBUTE && obsInRows) {
				attributeMultiplier = ws.getObsAttributesInSeparateTable().size();
				numRows *= attributeMultiplier;
			} else if(att == null && tableType == PivotTableModel.TABLE_TYPE.SERIES_ATTRIBUTE && obsInRows) {
				attributeMultiplier = ws.getSeriesAttributesInSeparateTable().size();
				numRows *= attributeMultiplier;
			}

			//BUILD HEADER
			if(obsInRows) {
				TableRow headerRow = pvModel.addTableRow(true); //A row for the header
				int i = 0;
				for(ReportingTemplateDimension dim : ws.getTableRows(includeTime)) {
					int colspan = 1;
					if(addColspan && (i+1) == ws.getTableRows(includeTime).size()) {
						colspan = 2;
					}
					headerRow.addHeaderTitle(dim.getDimensionLabel(), colspan, 1);
					i++;
				}
				if(tableType == PivotTableModel.TABLE_TYPE.OBS && attributeMultiplier > 1) {
					headerRow.addHeaderTitle("Observation", 1, 1);
				} else if(tableType == PivotTableModel.TABLE_TYPE.OBS_ATTRIBUTE) {
					//IF this is the Attribute table, then output Attributes Header Column
					headerRow.addHeaderTitle("Obs Attribute", 1, 1);
				} else if(tableType == PivotTableModel.TABLE_TYPE.SERIES_ATTRIBUTE) {
					//IF this is the Attribute table, then output Attributes Header Column
					headerRow.addHeaderTitle("Series Attribute", 1, 1);
				} else if(tableType == PivotTableModel.TABLE_TYPE.CHECKING && ws.getAttributesInReport().size() > 0) {
					headerRow.addHeaderTitle("Checking", 1, 1);  //To keep it aligned with the observation table
				}
				//Add Observation cells
				for(i = 0; i < seriesCols; i++) {
					headerRow.addHeaderRowValue(null, 1, 1, null);
				}
			}

			//BUILD BODY
			String[] partialKey = new String[aggregateDims.length];
			offset = pvModel.getTableRows().size();
			int rowIdx = buildTableRowValues(pvModel, addColspan, partialKey, aggregatedSeriesCols, ws.getTableRows(includeTime), 0, attributeMultiplier, offset, null, 0);
			
			getRow(pvModel, rowIdx-1); //Ensure all rows are built
			rows = pvModel.getTableRows().subList(offset, pvModel.getTableRows().size());
		}

		//Add Attribute Values
		if(tableType == PivotTableModel.TABLE_TYPE.CHECKING) {
			//do nothing
			if(ws.getAttributesInReport().size() > 0) {
				for(int i=0; i < rows.size(); i++) {
					rows.get(i).addHeaderRowValue("Check Value", 1, 1, null);  //To keep it aligned with the observation tabl
				}
			}
		} else if(tableType == PivotTableModel.TABLE_TYPE.OBS) {
			if(attributesInReport > 0) {
				int max = rows.size();
				for(int i=0; i < max; i++) {
					TableRow row = getRow(pvModel, i+offset);
					if(row.isPresentational()) {
						continue;
					}
					row.addHeaderRowValue("Obs Value", 1, 1, null);
					for(ReportingTemplateComponent attribute : ws.getAttributesInReport()) {
						i++;
						getRow(pvModel, i+offset).addHeaderRowValue(attribute.getLabel(), 1, 1, null);
					}
				}
				rows = pvModel.getTableRows().subList(offset, pvModel.getTableRows().size());
			}
		} else if(obsInRows) {
			//Adds in the empty cells for the user to enter data
			int rowIdx = 0;
			while(rowIdx < rows.size()) {
				int colspan = 1;
				Set<ReportingTemplateComponent> attributes;
				if(tableType == PivotTableModel.TABLE_TYPE.SERIES_ATTRIBUTE) {
					attributes = ws.getSeriesAttributesInSeparateTable();
					//IF the table is series attribute, and there are multiple time periods in the rows, then an extra colspan is required
					//but only if there are observation attributes in the same worksheet
					boolean hasObsAttributes = ObjectUtil.validCollection(ws.getObsAttributesInSeparateTable());
					if(hasObsAttributes) {
						for(ReportingTemplateDimension currentDim : ws.getTableRows(true)) {
							if(currentDim.getDimension().getComponent().getId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
								colspan = 2;
								break;
							}
						}
					}
				} else {
					attributes = ws.getObsAttributesInSeparateTable();
				}
				for(ReportingTemplateComponent attribute : attributes) {
					TableRow row = rows.get(rowIdx);
					rowIdx++;
					if(row.isPresentational()) {
						continue;
					}
					row.addHeaderRowValue(attribute.getLabel(), colspan, 1, null);
				}
			}
		}
		ReportingTemplateSeries series = ws.getSeries();
		List<String> attIds = new ArrayList<>();
		if(tableType == PivotTableModel.TABLE_TYPE.OBS) {
			for(ReportingTemplateComponent attr : ws.getAttributesInReport()) {
				attIds.add(attr.getComponent().getId());
			}
		} else {
			Set<ReportingTemplateComponent> attributes = tableType == PivotTableModel.TABLE_TYPE.SERIES_ATTRIBUTE ? ws.getSeriesAttributesInSeparateTable() : ws.getObsAttributesInSeparateTable();
			for(ReportingTemplateComponent attr : attributes) {
				attIds.add(attr.getComponent().getId());
			}
		}
		if(seriesCols == 0) {
			//Add Observation cells - attributes in columns
			for(TableRow tr : rows) {
				if(tableType == PivotTableModel.TABLE_TYPE.OBS) {
					tr.addObsCell(ws);
					for(String attId : attIds) {
						tr.addObsAttribute(ws, series, attId, 1);
					}
				} else {
					Set<ReportingTemplateComponent> attributes;
					if(tableType == PivotTableModel.TABLE_TYPE.SERIES_ATTRIBUTE) {
						attributes = ws.getSeriesAttributesInSeparateTable();
					} else {
						attributes = ws.getObsAttributesInSeparateTable();
					}
					for(ReportingTemplateComponent attSep : attributes) {
						tr.addObsAttribute(ws, series, attSep.getComponent().getId(), 1);
					}
				}
			}
		} else if(tableType == PivotTableModel.TABLE_TYPE.OBS || tableType == PivotTableModel.TABLE_TYPE.CHECKING) {
			//Add Observation cells - attributes in rows
			//Add Observation cells
			int rowIdx = 0;
			int maxIdx = attIds.size();

			for(TableRow tr : rows) {
				if(rowIdx > maxIdx) {
					rowIdx = 0;
				}
				if(rowIdx == 0) {
					for(int i = 0; i < seriesCols; i++) {
						if(att == null) {
							tr.addObsCell(ws);
						} else {
							tr.addObsAttribute(ws, series, att.getComponent().getId(), 1);
						}
					}
				} else {
					String attId = attIds.get(rowIdx-1);
					for(int i = 0; i < seriesCols; i++) {
						tr.addObsAttribute(ws, series, attId, 1);
					}
				}
				rowIdx++;
			}
		} else {
			//Adds in the empty cells for the user to enter data
			int rowIdx = 0;
			int maxIdx = attIds.size() - 1;
			for(TableRow tr : rows) {
				if(rowIdx > maxIdx) {
					rowIdx = 0;
				}
				String attId = attIds.get(rowIdx);
				for(int i = 0; i < seriesCols; i++) {
					tr.addObsAttribute(ws, series, attId, 1);
				}
				rowIdx++;
			}
		}
	}

	/**
	 * Gets the row from the list, if it does not exist, rows will be created up to the given row index
	 * @param pvModel
	 * @param rows
	 * @param idx
	 */
	private TableRow getRow(PivotTableModel pvModel,int idx) {
		List<TableRow> rows = pvModel.getTableRows();

		if(rows.size() <= idx) {
			for(int i=rows.size(); i <= idx; i++) {
				pvModel.addTableRow(false);
			}
		}
		return rows.get(idx);
	}

	private int buildTableRowValues(
			PivotTableModel pvModel,
			boolean addColspan,
			String[] partialKey, 
			List<String[]>  allSeries, 
			List<ReportingTemplateDimension> dims, 
			int currentDimIdx, 
			int multiplier, 
			int rowIdx, 
			List<ReportingTemplateDimensionCode> codes,
			int depth) {
		
		List<HeaderRow> builtRows = new ArrayList<>();
		
		//Build a temporary model as we do not know what the rowspan is until after the rows are built
		int returnVal = populateHeaderRows(builtRows, pvModel, addColspan, partialKey, allSeries, dims, currentDimIdx, multiplier, 0, codes, depth);
		
		Map<HeaderRow, TableRow> rowMap = new HashMap<>();
		for(HeaderRow row : builtRows) {
			TableRow tRow = pvModel.addTableRow(false);
			tRow.setPresentational(row.presentational);
			rowMap.put(row, tRow);
			//Don't add the cells yet as they can result in another row being created
			//due to the rowspan
		}
		for(HeaderRow row : builtRows) {
			TableRow tRow = rowMap.get(row);
			for(HeaderCell cell : row.cells) {
				tRow.addHeaderRowValue(cell.label, cell.colspan, cell.rowspan, cell.partialKey);
			}
		}
		return returnVal+rowIdx;
	}
	
	/**
	 * Walks through the Dimensions in the rows to populate the list of HeaderRows which are ultimately
	 * used to build the PivotTableModel
	 */
	private int populateHeaderRows (
			List<HeaderRow> builtRows,
			PivotTableModel pvModel,
			boolean addColspan,
			String[] partialKey, 
			List<String[]>  allSeries, 
			List<ReportingTemplateDimension> dims, 
			int currentDimIdx, 
			int multiplier, 
			int rowIdx, 
			List<ReportingTemplateDimensionCode> codes,
			int depth) {
		boolean lastDimension = currentDimIdx+1 == dims.size();
		if(codes == null) {
			ReportingTemplateDimension dim = dims.get(currentDimIdx);
			codes = dim.getCodes();
		}

		int newRowIndex = rowIdx;
		for(ReportingTemplateDimensionCode code : codes) {
			int newDepth = depth;
			StringBuilder lableSb = new StringBuilder();
			for(int i=0; i < newDepth; i++) {
				lableSb.append("  ");
			}
			lableSb.append(code.getCodeLabel());

			String label =lableSb.toString();
			int rowSpan = 0;
			String codeId = code.getId();
			partialKey[currentDimIdx] = codeId;
			List<String[]>  filteredSeries = filterSeries(codeId, currentDimIdx, allSeries);
			if(ObjectUtil.validCollection(filteredSeries)) {
				HeaderRow row;
				while(builtRows.size() <= newRowIndex) {
					builtRows.add(new HeaderRow());
				} 
				row = builtRows.get(newRowIndex);

				rowSpan = filteredSeries.size() * multiplier;
				int colspan = 1;
				if(addColspan && lastDimension) {
					colspan = 2;
				}
				HeaderCell cell = row.addCell(label, colspan, rowSpan, partialKey);
				int oldIndex = newRowIndex;
				int newRows = newRowIndex;
				if(!lastDimension) {
					newRows = populateHeaderRows(builtRows, pvModel, addColspan, partialKey, filteredSeries, dims, currentDimIdx+1, multiplier, newRowIndex, null, 0);
				} 
				int rowSpanDiff = newRows - oldIndex;
				if(rowSpanDiff > 0) {
					cell.rowspan = rowSpanDiff;
					rowSpan  =rowSpanDiff;
				}
				
				newDepth = depth + 1;
			} else if(!code.hasData() && code.hasChildren()){
				//No data for code, but child codes, presentational only row
				HeaderRow row;
				while(builtRows.size() <= newRowIndex) {
					builtRows.add(new HeaderRow());
				} 
				row = builtRows.get(newRowIndex);
				row.presentational = true;
				
				rowSpan = 1;
				int colspan = addColspan ? 2 : 1;
				for(String currentPk : partialKey) {
					if(currentPk == null) {
						colspan++;
					}
				}
				if(pvModel.getTableType() == TABLE_TYPE.OBS_ATTRIBUTE && pvModel.hasHeaderDimensions()) {
					colspan++;
				}
				row.addCell(label, colspan, rowSpan, partialKey);
				newDepth = depth + 1;
			}
			newRowIndex += rowSpan;
			if(code.hasChildren()){
				newRowIndex = populateHeaderRows(builtRows, pvModel, addColspan, partialKey, allSeries, dims, currentDimIdx, multiplier, newRowIndex, code.getChildren(), newDepth);
			}
		}
		partialKey[currentDimIdx] = null;
		return newRowIndex;
	}

	/**
	 * Lightweight model of rows and cells which is used to build the more complex PivotTableModel
	 * once the rowspans are known
	 */
	private class HeaderRow {
		private boolean presentational;
		private List<HeaderCell> cells = new ArrayList<>();
		
		public HeaderCell addCell(String label, int colspan, int rowspan, String[] partialKey) {
			HeaderCell cell = new HeaderCell(partialKey, label, colspan, rowspan);
			cells.add(cell);
			return cell;
		}
	}

	private class HeaderCell {
		private String[] partialKey;
		private String label;
		private int colspan;
		private int rowspan;

		public HeaderCell(String[] partialKey, String label, int colspan, int rowspan) {
			this.partialKey = partialKey.clone();
			this.label = label;
			this.colspan = colspan;
			this.rowspan = rowspan;
		}
	}

	/**
	 * Returns an integer array of dimension indexes that appear in the rows/columns
	 * @param ws
	 * @param isRows
	 * @return
	 */
	private int[] getAggregatedDimensions(ReportingTemplateWorksheet ws, PivotTableModel.TABLE_TYPE tableType, boolean isRows) {
		boolean includeTime = tableType != TABLE_TYPE.SERIES_ATTRIBUTE;
		int aggSize = isRows ? ws.getTableRows(includeTime).size() : ws.getTableColumns(includeTime).size();
		int[] aggregateDims = new int[aggSize];
		if(aggSize > 0) {
			aggregateDims[aggregateDims.length-1] = -1;
			int i = 0;
			if(isRows) {
				for(ReportingTemplateDimension tr : ws.getTableRows(includeTime)) {
					if(tableType == TABLE_TYPE.SERIES_ATTRIBUTE && tr.getDimension().getComponent().getId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
						continue;
					}
					aggregateDims[i] = ((DimensionBean)tr.getDimension().getComponent()).getPosition()-1;
					i++;
				}
			} else {
				for(ReportingTemplateDimension tr : ws.getTableColumns(includeTime)) {
					if(tableType == TABLE_TYPE.SERIES_ATTRIBUTE && tr.getDimension().getComponent().getId().equals(DimensionBean.TIME_DIMENSION_FIXED_ID)) {
						continue;
					}
					aggregateDims[i] = ((DimensionBean)tr.getDimension().getComponent()).getPosition()-1;
					i++;
				}
			}
		}
		return aggregateDims;
	}

	/**
	 * Returns a subset of series based on the mask, for example
	 * 
	 * Four Series:
	 * ["A","UK","M"]
	 * ["A","UK","F"]
	 * ["A","DE","M"]
	 * ["A","DE","F"]
	 * 
	 * Using Filter
	 * Code Id: UK
	 * Dim Index : 1
	 * 
	 * Will Return Two Series
	 * ["A","UK","M"]
	 * ["A","UK","F"]
	 * 
	 * @param id - the code id
	 * @param dimIndex - the dimension index
	 * @param series
	 * @return
	 */
	private List<String[]> filterSeries(String id, int dimIndex, List<String[]> series) {
		List<String[]> returnList = new ArrayList<>();

		for(String[] currentSeries : series) {
			if(currentSeries[dimIndex].equals(id)) {
				returnList.add(currentSeries);
			}
		}
		return returnList;
	}


	private int getHierarchyDepth(List<ReportingTemplateDimensionCode> codes, int d) {
		if(ObjectUtil.validCollection(codes)) {
			d++;
			for(ReportingTemplateDimensionCode currentCode : codes) {
				int d2 = currentCode.getDepth()+1;
				if(d2 > d) {
					d = d2;
				}
			}
		}
		return d;
	}
}
