package io.sdmx.fusion.reporttemplate.engine;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.base.ConditionalAttributeMappingBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateConditionalAttributeBean;
import io.sdmx.core.data.model.calcuation.CustomValidationExpression;
import io.sdmx.fusion.reporttemplate.api.engine.ReportTemplateWriterEngine;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.CELL_TYPE;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.ICellFormula;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.ICheckingTableModel;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.PivotTableCollection;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.PivotTableModel;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.TableCell;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.TableRow;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportTemplateVariableDimension;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplate;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateColouredAttribute;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateComponent;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateWorksheet;
import io.sdmx.fusion.reporttemplate.builder.PivotTableBuilder;
import io.sdmx.fusion.reporttemplate.model.worksheet.WorksheetIndex;
import io.sdmx.utils.core.colour.ColourUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;
import io.sdmx.utils.core.xlsx.ExcelUtil;
import io.sdmx.utils.xlsx.api.model.FusionCell;
import io.sdmx.utils.xlsx.api.model.ICellStyle;
import io.sdmx.utils.xlsx.api.model.IFontStyle.FONT_COLOUR;
import io.sdmx.utils.xlsx.api.model.IFusionExcelStyles;
import io.sdmx.utils.xlsx.api.model.SheetProperties;
import io.sdmx.utils.xlsx.api.model.SimpleExcelWriter;
import io.sdmx.utils.xlsx.constant.BORDER_STYLE;
import io.sdmx.utils.xlsx.constant.CELL_FORMAT;
import io.sdmx.utils.xlsx.model.CellImpl;
import io.sdmx.utils.xlsx.model.FontStyle;
import io.sdmx.utils.xlsx.model.FusionCellStyle;
import io.sdmx.utils.xlsx.model.FusionExcelStyles;
import io.sdmx.utils.xlsx.model.SheetPropertiesImpl;
import io.sdmx.utils.xlsx.model.SimpleExcelWriterImpl;
import io.sdmx.utils.xlsx.util.FusionCellUtil;

/**
 * Stateless Writer for writing Excel Templates
 */
public class ExcelReportingTemplateWriter implements ReportTemplateWriterEngine {
	private static final Logger LOG = LoggerFactory.getLogger(ExcelReportingTemplateWriter.class);
	public static final ExcelReportingTemplateWriter INSTANCE = new ExcelReportingTemplateWriter();
	private ExcelReportingTemplateWriter() {}
	
	private static final int MIN_WHITE_COLS = 26;

	private static final String DEFAULT_OBS = "DEFAULT_OBS";
	private static final String WHITE = "#FFFFFF";
	private static final String YELLOW = "#ffffcc";
	private static final String LIGHT_BLUE = "#c5d9f1";  //Excel light blue, rgb 197,217,241
	private static final String DARK_BLUE = "#8db4f6";  //Excel light blue, rgb 141,180,226

	private static final String DISABLED = "disabled";
	private static final String WHITE_CELL = "white";
	private static final String TEXT_WRAP = "text_wrap";     //Standard text, word wrap, which background
	private static final String CHECKING_CELL = "checking";
	private static final String WHITE_FONT_WHITE_CELL = "white_all";

	private static final String WHITE_BORDER_TOP = "white_mb_t";

	private static final String WHITE_BOLD = "bold";
	private static final String TIME_PERIOD_EDITABLE = "white_ball";
	private static final String VARIABLE_DIM = "var_dim";

	private static final String WHITE_BOLD_MD_BORDER_BOTTOM = "bold_md_b";

	private static final String MAIN_YELLOW = "main";
	private static final String MAIN_YELLOW_H1 = "main_h1";   //Agency Name
	private static final String MAIN_YELLOW_H2 = "main_h2";   //Report Name
	private static final String MAIN_YELLOW_H3 = "main_h3";   //The Labels for reporting organisation id, name, etc
	private static final String MAIN_YELLOW_H4 = "main_h4";   //Little heading for Template Version
	private static final String MAIN_YELLOW_V1 = "main_v1";   //Large value text
	private static final String MAIN_YELLOW_V2 = "main_v2";   //Small value text
	private static final String MAIN_YELLOW_TOP_LEFT = "main_tl";
	private static final String MAIN_YELLOW_TOP = "main_t";
	private static final String MAIN_YELLOW_TOP_RIGHT = "main_tr";
	private static final String MAIN_YELLOW_RIGHT = "main_r";
	private static final String MAIN_YELLOW_BOTTOM_RIGHT = "main_br";
	private static final String MAIN_YELLOW_BOTTOM = "main_b";
	private static final String MAIN_YELLOW_BOTTOM_LEFT = "main_bl";
	private static final String MAIN_YELLOW_LEFT = "main_l";

	private static final String HEAD = "thead";
	private static final String HEAD_MD_BORDER_TOP_LEFT = "thead_mb_tl";
	private static final String HEAD_MD_BORDER_TOP = "thead_mb_t";
	private static final String HEAD_MD_BORDER_LEFT = "thead_mb_l";
	private static final String HEAD_MD_BORDER_TOP_RIGHT = "thead_mb_tr";
	private static final String HEAD_MD_BORDER_BOTTOM = "thead_mb_b";

	private static final String HEAD_VAL = "theadv";
	private static final String HEADVAL_MD_BORDER_TOP_LEFT = "theadv_mb_tl";
	private static final String HEADVAL_MD_BORDER_TOP = "theadv_mb_t";
	private static final String HEADVAL_MD_BORDER_TOP_RIGHT = "theadv_mb_tr";
	private static final String HEADVAL_MD_BORDER_RIGHT = "theadv_mb_r";
	private static final String HEADVAL_MD_BORDER_LEFT = "theadv_mb_l";
	private static final String HEADVAL_MD_BORDER_BOTTOM = "theadv_mb_b";

	//white cell, border on left, to overcome issue with borders on merged cells
	private static final String BORDER_LEFT = "bd_l";
	
	private static final String HEAD_L_BORDER_TOP_LEFT = "theadv_l_tl";
	private static final String HEAD_L_BORDER_TOP_LEFT_BOTTOM = "theadv_l_tlb";
	private static final String HEAD_L_BORDER_TOP = "theadv_l_t";
	private static final String HEAD_L_BORDER_TOP_BOTTOM = "theadv_l_tb";
	private static final String HEAD_L_BORDER_LEFT = "theadv_l_l";
	private static final String HEAD_L_BORDER_BOTTOM = "theadv_l_b";
	private static final String HEAD_L_BORDER_BOTTOM_LEFT = "theadv_l_bl";

	//All Borders
	private static final String HEADVAL_ALL_BORDERS = "theadv_all";
	private static final String HEADVAL_BOLD_ALL_BORDERS = "theadvb_all";
	
	
	private static final String HEAD_ALL_BORDERS = "thead_all";

	private static final BorderStyle bsMed = BorderStyle.THIN;
	private static final BorderStyle bsThin = BorderStyle.THIN;

	
	private IFusionExcelStyles getStyles() {
		IFusionExcelStyles styles = new FusionExcelStyles();
		ICellStyle backgroundStyle = new FusionCellStyle("background");
		backgroundStyle.setHexColour("#FFFFFF");
		
		styles.setBackgroundColourStyle(backgroundStyle);
		
		ICellStyle h1 = new FusionCellStyle("h1");
		h1.setHexColour("#FFFFFF");
		h1.setFontStyle(new FontStyle(FONT_COLOUR.BLACK, 16, true));
		
		styles.setHeading(1, h1);
		
		return styles;
	}

	/**
	 * Turns off custom metadata properties, required to keep workbook size small when the user does not want
	 * to re-load the workbook in for reading
	 */
	private class NoMetadataExcelWriter extends SimpleExcelWriterImpl {

		@Override
		public void addCustomMetadataProperty(String name, String value) {
			//Dont
		}
	}
	
	@Override
	public void writeReportForm(ReportingTemplate reportingTemplate, boolean includeMetadataForReading, String password, OutputStream out) {
		SimpleExcelWriter writer = includeMetadataForReading ? new SimpleExcelWriterImpl() : new NoMetadataExcelWriter();
		
		if(includeMetadataForReading) {
			writer.addCustomMetadataProperty("ExcelTemplateRef", reportingTemplate.getAgency().getId()+","+reportingTemplate.getId()+","+reportingTemplate.getVersion());
			writer.addCustomMetadataProperty("ExcelTemplateCreation", Long.toString(System.currentTimeMillis()));
		}
		createStyles(reportingTemplate, writer);
		if(reportingTemplate.getDataProvider() != null) {
			writeMainPage(reportingTemplate, password, writer);
		}
		if(reportingTemplate.getInstructionSheet() != null) {
			ExcelInstructionSheetWriter.writeInstructionSheet(reportingTemplate.getInstructionSheet(), writer, getStyles(), password);
		}
		int i=0;
		int cond = 0;
		for(ReportingTemplateWorksheet ws : reportingTemplate.getDataSheets()) {
			writer.addCustomMetadataProperty("WS,"+i, ws.getName());

			for(ReportingTemplateConditionalAttributeBean condAttr : ws.getConditionalAttributes()) {
				String attributeId = condAttr.getAttributeId();
				for(ConditionalAttributeMappingBean condition : condAttr.getConditions()) {
					//AttributeId, AttributeValue, Rule, Rule Detail (escaped)
					String metaVal = attributeId+","+condition.getAttributeValue()+","+condition.getCondition().toString()+",\""+condition.getConditionDetail()+"\"";
					cond++;
					writer.addCustomMetadataProperty("COND,"+cond+","+i, metaVal);
				}
			}
			i++;
			for(ReportingTemplateComponent rtc : ws.getObsAttributesInSeparateWorksheet()) {
				writer.addCustomMetadataProperty("WS,"+i, getAttributeWorksheetName(ws, rtc));
				i++;
			}
		}
		i=0;
		List<RTObsWorksheetTables> wbTables = new ArrayList<>();
		for(ReportingTemplateWorksheet ws : reportingTemplate.getDataSheets()) {
			LOG.info("Write Worksheet '"+ws.getName()+"'");
			RTObsWorksheetTables wsTables =  writeWorksheet(ws, password, i, writer);
			i += wsTables.worksheetCount;
			wbTables.add(wsTables);
		}
		//optionally output formula checking summary table

		boolean hasCheckingTables = false;
		for(RTObsWorksheetTables wsTables : wbTables) {
			if(ObjectUtil.validCollection(wsTables.checkingTable)) {
				hasCheckingTables = true;
				break;
			}
		}
		if(hasCheckingTables) {
			writeCheckingTableSummary(wbTables, password, writer);
		}

		writer.save(out);
	}

	private String getAttributeWorksheetName(ReportingTemplateWorksheet ws, ReportingTemplateComponent rtc) {
		return rtc.getComponent().getId();
	}

	private void writeMainPage(ReportingTemplate reportingTemplate, String password, SimpleExcelWriter writer) {
		SheetProperties properties = new SheetPropertiesImpl("Main");
		if(ObjectUtil.validString(password)) {
			properties.setSheetPassword(password);
		}
		properties.addColumnWidth(2, 11520);  //36 = 1px, 320px = 36 * 320
		properties.addColumnWidth(3, 11520);
		properties.addColumnWidth(4, 11520);

		writer.createWorkSheet(properties);

		//White out the cells
		int whiteRowMax = 40;
		int whiteColMax = MIN_WHITE_COLS;

		for(int colIdx=0; colIdx < whiteColMax; colIdx++) {
			for(int rowIdx=0; rowIdx < whiteRowMax; rowIdx++) {
				writeCell(writer, null, colIdx, rowIdx, WHITE_CELL);
			}
		}

		Set<ReportTemplateVariableDimension> globalDims = reportingTemplate.getGlobalVariableDimensions();
		int maxBottom = 15 + globalDims.size();
		//Yellow out the cells
		for(int colIdx=2; colIdx <= 4; colIdx++) {
			for(int rowIdx=2; rowIdx <= maxBottom; rowIdx++) {
				writeCell(writer, null, colIdx, rowIdx, MAIN_YELLOW);
			}
		}

		//Top Border
		writeCell(writer, null, 1, 1, MAIN_YELLOW_TOP_LEFT);
		for(int colIdx=2; colIdx <= 4; colIdx++) {
			writeCell(writer, null, colIdx, 1, MAIN_YELLOW_TOP);
		}
		writeCell(writer, null, 5, 1, MAIN_YELLOW_TOP_RIGHT);

		//Left Border
		for(int rowIdx=2; rowIdx <= maxBottom; rowIdx++) {
			writeCell(writer, null, 1, rowIdx, MAIN_YELLOW_LEFT);
		}
		//Right Border
		for(int rowIdx=2; rowIdx <= maxBottom; rowIdx++) {
			writeCell(writer, null, 5, rowIdx, MAIN_YELLOW_RIGHT);
		}

		//Bottom Border
		writeCell(writer, null, 1, maxBottom+1, MAIN_YELLOW_BOTTOM_LEFT);
		for(int colIdx=2; colIdx <= 4; colIdx++) {
			writeCell(writer, null, colIdx, maxBottom+1, MAIN_YELLOW_BOTTOM);
		}

		writeCell(writer, null, 5, maxBottom+1, MAIN_YELLOW_BOTTOM_RIGHT);

		writeCell(writer, reportingTemplate.getName(), 2, 2, MAIN_YELLOW_H1);

		if(reportingTemplate.getDataProvider() != null) {
			writeCell(writer, "Reporting Organisation Id", 2, 7, MAIN_YELLOW_H3);
			writeCell(writer, reportingTemplate.getDataProvider().getId(), 3, 7, MAIN_YELLOW_V1);
			writeCell(writer, "Reporting Organisation Name", 2, 9, MAIN_YELLOW_H3);
			writeCell(writer, reportingTemplate.getDataProvider().getName(), 3, 9, MAIN_YELLOW_V1);
		}

		if(reportingTemplate.getReportingPeriod() != null) {
			writeCell(writer, "Reporting Period", 2, 11, MAIN_YELLOW_H3);
			FusionCell cell = getCell(reportingTemplate.getReportingPeriod().getDateInSdmxFormat(), 3, 11, TIME_PERIOD_EDITABLE);
			cell.setFormat(CELL_FORMAT.INTEGER);
			writer.writeCell(cell);
		}


		//Globally relevant dimensions
		int startRow = 13;
		for(ReportTemplateVariableDimension vDim : globalDims) {
			writeCell(writer, vDim.getReportingTemplateComponent().getConcept().getName(), 2, startRow, MAIN_YELLOW_H3);
			FusionCell cell = getCell("", 3, startRow, TIME_PERIOD_EDITABLE);
			List<String> variables = ObjectUtil.collectToList(vDim.getValidCodes().stream().map(c -> c.getId() +": "+c.getName()));
			if(ObjectUtil.validCollection(variables)) {
				Collections.sort(variables);
				cell.setCellValues(variables);
			}
			String cellRef = writer.writeCell(cell);

			ComponentBean comp = vDim.getReportingTemplateComponent().getComponent();

			int dimIdx = ((DimensionBean)comp).getPosition() - 1;
			writer.addCustomMetadataProperty("gv,"+dimIdx, cellRef);
			startRow = startRow+1;
		}
	}


	private void writeCheckingTableSummary(List<RTObsWorksheetTables> writtenWbTables, String password, SimpleExcelWriter writer) {
		SheetProperties properties = new SheetPropertiesImpl("Check");
		if(ObjectUtil.validString(password)) {
			properties.setSheetPassword(password);
		}
		properties.addColumnWidth(0, 800);  //800=22pixels 14chars=100px   7.1px per char=258

		properties.setDefaultRowHeight(19);
		properties.setAutoScaleWidth(true);
		writer.createWorkSheet(properties);

		//Create a white background
		int whiteColMax = 40;
		int whiteRowMax = 50;
		for(int colIdx=0; colIdx < whiteColMax; colIdx++) {
			for(int rowIdx=0; rowIdx < whiteRowMax; rowIdx++) {
				writeCell(writer, null, colIdx, rowIdx, WHITE_CELL);
			}
		}
		List<RTObsWorksheetTables> rulesCheckWorksheets = new ArrayList<>();
		List<RTObsWorksheetTables> checkSumWorksheets = new ArrayList<>();  //A list of worksheets the require checksum tests
		for(RTObsWorksheetTables wb : writtenWbTables) {
			if(ObjectUtil.validCollection(wb.checkingTable)) {
				ICheckingTableModel checkingTableModel = wb.ptCollection.getFormulaCheckingTable();
				for(ValidationRuleBean validationRule : checkingTableModel.getValidationRules()) {
					//Put into Check Sum Summary
					if(validationRule.getValidationHierarchy() != null || validationRule.getEqualityOperator() == EQUALITY.EQUAL) {
						//Equations which rely on the equals operator do not output error codes, and therefore do not require an error count
						//They do however require a single error count entry (summation of totals in check table)
						if(!checkSumWorksheets.contains(wb)) {
							checkSumWorksheets.add(wb);
						}
					} else {
						rulesCheckWorksheets.add(wb);
					}
				}
			}
		}
		int rownum = 1;
		if(ObjectUtil.validCollection(rulesCheckWorksheets)) {
			writeCell(writer, "Relationship Validation Rules Summary", 1, rownum, WHITE_BOLD);
			String rulesCheckText = "These checks use formula which allow a range of possible reported values.  " +
					"Failures will display error codes in the Check Table of the respective worksheet.  "+
					"This summary shows the number of errors detected for each rule, per worksheet that has relationship rules.";
			FusionCell cell = getCell(rulesCheckText, 1, rownum+1, TEXT_WRAP);
			cell.setColspan(5);
			cell.setRowspan(6);
			cell.disableAutosizeColumn();
			writer.writeCell(cell);
			rownum= 8;
			writeCell(writer, "Worksheet", 1, rownum, HEAD_MD_BORDER_TOP_LEFT);
			writeCell(writer, "Rule Id", 2, rownum, HEAD_MD_BORDER_TOP);
			writeCell(writer, "Dimension", 3, rownum, HEAD_MD_BORDER_TOP);
			writeCell(writer, "Formula", 4, rownum, HEAD_MD_BORDER_TOP);
			writeCell(writer, "Error Count", 5, rownum, HEAD_MD_BORDER_TOP_RIGHT);
			rownum++;
			for(RTObsWorksheetTables wb : writtenWbTables) {
				ICheckingTableModel checkingTableModel = wb.ptCollection.getFormulaCheckingTable();
				if(checkingTableModel == null) {
					continue;
				}
				for(ValidationRuleBean validationRule : checkingTableModel.getValidationRules()) {
					//Put into Check Sum Summary
					if(validationRule.getValidationHierarchy() != null || validationRule.getEqualityOperator() == EQUALITY.EQUAL) {
						continue;
					}



					CustomValidationExpression validationExpression = new CustomValidationExpression(validationRule);
					int dimIdx = validationExpression.getDimensionIndex();

					DimensionBean dim = wb.dsd.getDimensionList().getDimensions().get(dimIdx);
					writeCell(writer, wb.worksheetName, 1, rownum, HEADVAL_MD_BORDER_LEFT);
					writeCell(writer, validationRule.getId(), 2, rownum, HEAD_VAL);
					writeCell(writer, dim.getId(), 3, rownum, HEAD_VAL);

					String expAsString = validationExpression.toString();
					expAsString = expAsString.replaceAll("\\[", "");
					expAsString = expAsString.replaceAll("\\]", "");
					writeCell(writer, expAsString, 4, rownum, HEAD_VAL);

					//B[row] = Worksheet Name
					//C[row] = Rule Id

					//Checking Table Range
					FusionCell chkTableStartCell = wb.checkingTable.get(0);
					FusionCell chkTableEndCell = wb.checkingTable.get(wb.checkingTable.size()-1);
					String range = FusionCellUtil.toCellRange(chkTableStartCell, chkTableEndCell);
					String checkSumFormula = "SUMPRODUCT(COUNTIF(INDIRECT(\"'\"&B"+(rownum+1)+"&\"'!"+range+"\"),C"+(rownum+1)+"))";

					cell = new CellImpl(5, rownum, "");
					cell.setCellFormula(checkSumFormula);
					cell.setStyleName(HEADVAL_MD_BORDER_RIGHT);
					writer.writeCell(cell);
					rownum++;
				}
			}
			//Write borders to the top of the worksheet
			writeCell(writer, null, 1, rownum, WHITE_BORDER_TOP);
			writeCell(writer, null, 2, rownum, WHITE_BORDER_TOP);
			writeCell(writer, null, 3, rownum, WHITE_BORDER_TOP);
			writeCell(writer, null, 4, rownum, WHITE_BORDER_TOP);
			writeCell(writer, null, 5, rownum, WHITE_BORDER_TOP);
			rownum++; rownum++;//Two spaces at the end
		}


		//Check Sum Summary
		if(checkSumWorksheets.size() > 0) {
			writeCell(writer, "Equlaity Check Summary", 1, rownum, WHITE_BOLD);
			rownum++;
			String checkSumText =
					"Equality check failures result in the difference between the reported value and the expected value being displayed in the Check Table.  "
							+ "Zero values indicate there is no difference between the reported value and the expected value. "
							+ "This summary shows the maximum difference, for each worksheet that define equality checks.";
			FusionCell cell = getCell(checkSumText, 1, rownum, TEXT_WRAP);
			cell.setColspan(5);
			cell.setRowspan(6);
			cell.disableAutosizeColumn();
			writer.writeCell(cell);
			rownum = rownum+6;

			writeCell(writer, "Worksheet", 1, rownum, HEAD_MD_BORDER_TOP_LEFT);
			writeCell(writer, "Max Difference", 2, rownum, HEAD_MD_BORDER_TOP_RIGHT);
			rownum++;
			for(RTObsWorksheetTables wb : checkSumWorksheets) {
				FusionCell chkTableStartCell = wb.checkingTable.get(0);
				FusionCell chkTableEndCell = wb.checkingTable.get(wb.checkingTable.size()-1);
				String range = FusionCellUtil.toCellRange(chkTableStartCell, chkTableEndCell);

				//Results in something like this:
				//INDIRECT("'"&B21&"'!B30:D44"),B21
				//Where B21 is the reference to the worksheet, and B30:D44 is the cell range of the checking table
				String indirectFormulaPart = "INDIRECT(\"'\"&B"+(rownum+1)+"&\"'!"+range+"\")";
				//Final Formula, get the absolute value for the maximum and minimum error difference, and then take the maximum
				//difference from that
				/*
				 * =MAX(
					    ABS(
					       MAX(INDIRECT("'"&B21&"'!B30:D44"))),
					    ABS(
					       MIN(INDIRECT("'"&B21&"'!B30:D44"))
					       )
					)
				 */
				writeCell(writer, wb.worksheetName, 1, rownum, HEADVAL_MD_BORDER_LEFT);

				cell = new CellImpl(2, rownum, "");
				cell.setCellFormula("MAX(ABS(MAX("+indirectFormulaPart+")),ABS(MIN("+indirectFormulaPart+")))");
				cell.setStyleName(HEADVAL_MD_BORDER_RIGHT);
				writer.writeCell(cell);
				rownum++;
			}
			writeCell(writer, null, 1, rownum, WHITE_BORDER_TOP);
			writeCell(writer, null, 2, rownum, WHITE_BORDER_TOP);
		}
	}

	/**
	 * Wrutes a worksheet for the
	 * @param ws
	 * @param password
	 * @param wsNum
	 * @param writer
	 * @return
	 */
	private RTObsWorksheetTables writeWorksheet(ReportingTemplateWorksheet ws, String password, int wsNum, SimpleExcelWriter writer) {
		RTObsWorksheetTables tables = new RTObsWorksheetTables(ws.getDataStructureBean());
		PivotTableCollection pvModels = PivotTableBuilder.INSTANCE.build(ws);

		tables.ptCollection = pvModels;
		WorksheetIndex wsIdx = new WorksheetIndex(wsNum);
		wsIdx.setRoundDecimals(ws.getRoundDecimals());

		int totalTables = 1;
		int totalRows = 0;
		if(pvModels.getObsTable() != null) {
			totalRows += pvModels.getObsTable().getTableRows().size();
		}
		if(pvModels.getObsAttributesTableSameWorksheet() != null) {
			totalRows += pvModels.getObsAttributesTableSameWorksheet().getTableRows().size();
			totalTables++;
		}
		if(pvModels.getSeriesAttributesTableSameWorksheet() != null) {
			totalRows += pvModels.getSeriesAttributesTableSameWorksheet().getTableRows().size();
			totalTables++;
		}
		if(pvModels.getFormulaCheckingTable() != null) {
			totalRows += pvModels.getFormulaCheckingTable().getTableRows().size();
			totalTables++;
		}
		Map<TableCell, String> cellRefMap = new HashMap<>();
		RTWorksheet worksheet = writeObsTable(cellRefMap, pvModels.getObsTable(), password, ws, wsIdx, writer, totalTables, totalRows);
		tables.observationTable = worksheet.observationTable;
		tables.worksheetName = worksheet.properties.getSheetName();
		if(pvModels.getObsAttributesTableSameWorksheet() != null) {
			int rowIdx = tables.getCurrentRowNum()+2;
			writeCell(writer, "Observation Attributes", 1, rowIdx, WHITE_BOLD);
			ReportingTemplateColouredAttribute coloutAttribute = ws.getColourAttribute();

			tables.obsAttTable = writeAttributesTable(coloutAttribute, cellRefMap, pvModels.getObsAttributesTableSameWorksheet(), ws, wsIdx, rowIdx, writer);
		}
		if(pvModels.getSeriesAttributesTableSameWorksheet() != null) {
			int rowIdx = tables.getCurrentRowNum()+2;
			writeCell(writer, "Series Attributes", 1, rowIdx, WHITE_BOLD);
			tables.seriesAttTable = writeAttributesTable(null, cellRefMap, pvModels.getSeriesAttributesTableSameWorksheet(), ws, wsIdx, rowIdx, writer);
		}
		if(pvModels.getFormulaCheckingTable() != null) {
			int rowIdx = tables.getCurrentRowNum()+2;
			writeCell(writer, "Check Table", 1, rowIdx, WHITE_BOLD);
			tables.checkingTable = writeAttributesTable(null, cellRefMap, pvModels.getFormulaCheckingTable(), ws, wsIdx, rowIdx, writer);
		}
		writeWorksheetIndex(writer, wsIdx);
		//Separate Worksheets for Attributes
		for(ReportingTemplateComponent rtc : ws.getObsAttributesInSeparateWorksheet()) {
			tables.worksheetCount++;
			wsIdx = new WorksheetIndex(tables.worksheetCount+wsNum);
			wsIdx.setRoundDecimals(ws.getRoundDecimals());
			PivotTableModel pv = pvModels.getAttributeTablesSeperateWorksheets().get(rtc.getComponent().getId());
			writeObsAttributeTable(cellRefMap, pv, password, ws, wsIdx, rtc, writer, 1, pv.getTableRows().size());
			writeWorksheetIndex(writer, wsIdx);
		}
		return tables;
	}

	/**
	 * Writes the Index information as CustomMetadataProperties in Excel
	 * @param writer
	 * @param wsIdx
	 */
	private void writeWorksheetIndex(SimpleExcelWriter writer, WorksheetIndex wsIdx) {
		writer.addCustomMetadataProperty("STRUCTURE,"+wsIdx.getWorksheet(), wsIdx.getsRef().getURN());
		for(String componentId : wsIdx.getFixedValues().keySet()) {
			writer.addCustomMetadataProperty("FIX_"+wsIdx.getWorksheet()+"_"+componentId, wsIdx.getFixedValues().get(componentId));
		}
		for(Integer rowIdx : wsIdx.getRowKeys().keySet()) {
			String key = wsIdx.getWorksheet()+",r"+rowIdx;
			writer.addCustomMetadataProperty(key, SeriesUtil.toSeriesKey(wsIdx.getRowKeys().get(rowIdx)));
		}
		for(Integer ColIdx : wsIdx.getColumnKeys().keySet()) {
			String key = wsIdx.getWorksheet()+",c"+ColIdx;
			writer.addCustomMetadataProperty(key, SeriesUtil.toSeriesKey(wsIdx.getColumnKeys().get(ColIdx)));
		}
		for(String attId : wsIdx.getNoHeaderColMapObsTable().keySet()) {
			String key = wsIdx.getWorksheet()+",nh_obs,"+wsIdx.getNoHeaderColMapObsTable().get(attId);
			writer.addCustomMetadataProperty(key, attId);
		}
		for(String attId : wsIdx.getNoHeaderColMapObsAttTable().keySet()) {
			String key = wsIdx.getWorksheet()+",nh_att,"+wsIdx.getNoHeaderColMapObsAttTable().get(attId);
			writer.addCustomMetadataProperty(key, attId);
		}
		for(String attId : wsIdx.getNoHeaderColMapSeriesAttTable().keySet()) {
			String key = wsIdx.getWorksheet()+",nh_satt,"+wsIdx.getNoHeaderColMapSeriesAttTable().get(attId);
			writer.addCustomMetadataProperty(key, attId);
		}
		if(wsIdx.getRoundDecimals() != null) {
			String key = wsIdx.getWorksheet()+",DP";
			writer.addCustomMetadataProperty(key, wsIdx.getRoundDecimals().toString());
		}
		for(Integer dimIdx : wsIdx.getVariableDimensions().keySet()) {
			String key = wsIdx.getWorksheet()+",v,"+dimIdx;
			writer.addCustomMetadataProperty(key, wsIdx.getVariableDimensions().get(dimIdx));
		}
		Integer attStartIdx = wsIdx.getObsAttributeTableStart();
		if(attStartIdx != null) {
			String key = wsIdx.getWorksheet()+",attstart";
			writer.addCustomMetadataProperty(key, attStartIdx.toString());
		}
		attStartIdx = wsIdx.getSeriesAttributeTableStart();
		if(attStartIdx != null) {
			String key = wsIdx.getWorksheet()+",sattstart";
			writer.addCustomMetadataProperty(key, attStartIdx.toString());
		}
	}

	/**
	 * Writes the Observation Table
	 * @param pvModel
	 * @param ws
	 * @param wsIdx
	 * @param writer
	 */
	private RTWorksheet writeObsAttributeTable(Map<TableCell, String> cellRefMap, PivotTableModel pvModel, String password, ReportingTemplateWorksheet ws, WorksheetIndex wsIdx, ReportingTemplateComponent att, SimpleExcelWriter writer, int totalTables, int totalRows) {
		return writeObsTable(cellRefMap, pvModel, password, ws, wsIdx, att, writer, totalTables, totalRows);
	}

	private RTWorksheet writeObsTable(Map<TableCell, String> cellRefMap, PivotTableModel pvModel, String password, ReportingTemplateWorksheet ws, WorksheetIndex wsIdx, SimpleExcelWriter writer, int totalTables, int totalRows) {
		return writeObsTable(cellRefMap, pvModel, password,  ws, wsIdx, null, writer, totalTables, totalRows);
	}

	/**
	 * Writes the Observation Table
	 * @param pvModel
	 * @param ws
	 * @param wsIdx
	 * @param att if this is writing a table just for a specific attribute, then this is the attribute, if not then this should be null
	 * @param writer
	 */
	private RTWorksheet writeObsTable(Map<TableCell, String> cellRefMap, PivotTableModel pvModel, String password, ReportingTemplateWorksheet ws, WorksheetIndex wsIdx, ReportingTemplateComponent att, SimpleExcelWriter writer, int totalTables, int totalRows) {
		int columnCount = pvModel.getColumnCount();

		boolean isAttributeWorksheet = att != null; //If the worksheet is for attributes only

		String wsName = att == null ? ws.getName() : getAttributeWorksheetName(ws, att);
		SheetProperties properties = new SheetPropertiesImpl(wsName);
		properties.setSheetPassword(password);
		properties.addColumnWidth(0, 800);  //800=22pixels 14chars=100px   7.1px per char=258
		properties.setAutoScaleWidth(true);
		
		if(ws.getColMaxWidth() != null) {
			properties.setAutoScaleMaxWidth(ws.getColMaxWidth());
		} else {
			properties.setDefaultRowHeight(19);
		}

		int plus = 1;
		int wsHeadSize = getHeadSize(ws);
		if(!isAttributeWorksheet) {
			int tHeadSize = pvModel.getTHeadRowCount();
			properties.setFreezePaneRowSplit(tHeadSize + wsHeadSize + plus);
		} else {
			int tHeadSize = pvModel.getTHeadRowCount();
			properties.setFreezePaneRowSplit(3 + tHeadSize +plus);
		}


		writer.createWorkSheet(properties);

		//White out the cells
		int whiteRowMax = (totalRows) + (totalTables * 2) + wsHeadSize + 10;
		whiteRowMax = whiteRowMax < 50 ? 50 : whiteRowMax;

		int whiteColMax = columnCount + 10 < MIN_WHITE_COLS ? MIN_WHITE_COLS : columnCount + 10;

		
		for(int colIdx=0; colIdx < whiteColMax; colIdx++) {
			for(int rowIdx=0; rowIdx < whiteRowMax; rowIdx++) {
				writeCell(writer, null, colIdx, rowIdx, WHITE_CELL);
			}
		}

		int rowIdx = 1;
		ProvisionAgreementBean prov = ws.getProvisionAgreementBean();
		wsIdx.setsRef(prov != null ? prov.getURN() : ws.getDataflowBean().getURN());

		int originalRowIndex = rowIdx;
		String headerStyle = WHITE_FONT_WHITE_CELL;
		if(isAttributeWorksheet == false) {
			rowIdx = writeFixedValues(writer, ws, wsIdx, ws.getFixedDimensions(), rowIdx, false);
			rowIdx = writeFixedValues(writer, ws, wsIdx, ws.getFixedAttributes(), rowIdx, true);

			if(originalRowIndex != rowIdx) {
				headerStyle = WHITE_BOLD_MD_BORDER_BOTTOM;
				for(int i =1; i <=7; i ++) {
					writeCell(writer, null, i, rowIdx, WHITE_BORDER_TOP);
				}
			}

			rowIdx = writeVariableDimensions(writer, ws, wsIdx, ws.getVariableDimensions(), rowIdx);
		}
		//Write the worksheet name in white at the top
		writeCell(writer, "Worksheet", 1, 0, headerStyle);
		writeCell(writer, wsName, 2, 0, headerStyle);
		for(int i =3; i <=7; i ++) {
			writeCell(writer, null, i, 0, headerStyle);
		}

		if(!isAttributeWorksheet) {
			int colorRow = writeColouredAttributeValues(writer, wsIdx, ws.getColourAttribute());
			rowIdx = colorRow > rowIdx ? colorRow : rowIdx;
		} else {
			writeCell(writer, ws.getDataflowBean().getName(), 1, rowIdx, WHITE_BOLD);
			rowIdx++;
			writeCell(writer, att.getConcept().getName(), 1, rowIdx, WHITE_BOLD);
			rowIdx++;
		}
		//Create Pivot Table
		return new RTWorksheet(properties, writeTable(writer, null, cellRefMap, pvModel, wsIdx, rowIdx));
	}

	/**
	 * Writes the separate Attributes Table
	 * @param pvModel
	 * @param ws
	 * @param wsIdx
	 * @param writer
	 */
	private List<FusionCell> writeAttributesTable(ReportingTemplateColouredAttribute coloutAttribute , Map<TableCell, String> cellRefMap, PivotTableModel pvModel, ReportingTemplateWorksheet ws, WorksheetIndex wsIdx, int rowIdx, SimpleExcelWriter writer) {
		return writeTable(writer, coloutAttribute, cellRefMap, pvModel,  wsIdx, rowIdx);
	}


	/**
	 * Returns the size of the header which is either the size of the fixed keys, or the colour keys, whichever is greater
	 * @return
	 */
	private int getHeadSize(ReportingTemplateWorksheet ws) {
		int colourKeyRowSize = 0;
		if(ws.getColourAttribute() != null) {
			colourKeyRowSize = ws.getColourAttribute().getAttributeColorKey().size();
		}

		int fixedKeyRowSize = 0;
		for(ReportingTemplateComponent fixedComp : ws.getFixedAttributes().keySet()) {
			if(!ws.isExcludeDimension(fixedComp.getComponent().getId())) {
				fixedKeyRowSize++;
			}
		}
		for(ReportingTemplateComponent fixedComp : ws.getFixedDimensions().keySet()) {
			if(!ws.isExcludeDimension(fixedComp.getComponent().getId())) {
				fixedKeyRowSize++;
			}
		}
		int variableDims = 0;
		for(String dimId : ws.getVariableDimensions().keySet()) {
			if(!ws.getReportingTemplate().isGlobalVariableDimension(dimId)) {
				variableDims++;
			}
		}
		fixedKeyRowSize+=variableDims;
		if(variableDims > 0) {
			fixedKeyRowSize++; //An extra blank row between the header and variable
		}
		return (colourKeyRowSize > fixedKeyRowSize ? colourKeyRowSize : fixedKeyRowSize)+1;  //1 for the first row which is whitespace
	}

	/**
	 * Builds the table Head
	 * @param pvModel
	 */

	/**
	 * Writes the PivotTable, returns the written FusionCells which contain reference to the cell and row indexes
	 * @param writer - to write the Excel file
	 * @param pvModel - the model to write to Excel
	 * @param wsIdx - worksheet index for storing metadata
	 * @param rowIdx - starting from row index
	 * @return
	 */
	private List<FusionCell> writeTable(SimpleExcelWriter writer, ReportingTemplateColouredAttribute coloutAttribute, Map<TableCell, String> cellRefMap, PivotTableModel pvModel, WorksheetIndex wsIdx, int rowIdx) {
		List<FusionCell> returnList = new ArrayList<>();
		int tableOffset = rowIdx + 1; //one is for the extra row added

		boolean hasHeaderDimensions = pvModel.hasHeaderDimensions();
		boolean hasRowDimensions = pvModel.hasRowDimensions();


		Map<String, String> shortCodeToObsCell = null;
		if(pvModel.getTableType() == PivotTableModel.TABLE_TYPE.OBS_ATTRIBUTE) {
			wsIdx.setObsAttributeTableStart(rowIdx+1);
			shortCodeToObsCell= new HashMap<>();
			for(TableCell cell : cellRefMap.keySet()) {
				if(cell.getCellType() == CELL_TYPE.OBSERVATION) {
					shortCodeToObsCell.put(SeriesUtil.toSeriesKey(cell.getCellSeriesKey()), cellRefMap.get(cell));
				}
			}
		}
		if(pvModel.getTableType() == PivotTableModel.TABLE_TYPE.SERIES_ATTRIBUTE) {
			wsIdx.setSeriesAttributeTableStart(rowIdx+1);
		}

		if(!hasHeaderDimensions) {
			int colCount = pvModel.getColumnCount();
			String[] attributeIds = pvModel.getAttributeIds();

			List<TableCell> headerCells = pvModel.getTableRows().get(0).getTableCells();
			Map<String, Integer> attributeIdToColIdx = new HashMap<>();
			if(pvModel.getTableType() ==  PivotTableModel.TABLE_TYPE.OBS) {
				//Obs Value is the first non-attribute column
				int nonAttributeCols = colCount - attributeIds.length;
				int obsValueCol = headerCells.get(nonAttributeCols-1).getCellIndex()+1;
				int attrIdx = obsValueCol;

				attributeIdToColIdx.put(PrimaryMeasureBean.FIXED_ID, obsValueCol);
				for(String attId : attributeIds) {
					attrIdx += 1;
					attributeIdToColIdx.put(attId, attrIdx);
				}
				wsIdx.setNoHeaderColMapObsTable(attributeIdToColIdx);
			} else if(pvModel.getTableType() ==  PivotTableModel.TABLE_TYPE.OBS_ATTRIBUTE || pvModel.getTableType() ==  PivotTableModel.TABLE_TYPE.SERIES_ATTRIBUTE) {
				int attributeStartCols = colCount - attributeIds.length;
				int attrIdx = headerCells.get(attributeStartCols).getCellIndex()+1;
				for(String attId : attributeIds) {
					attributeIdToColIdx.put(attId, attrIdx);
					attrIdx += 1;
				}
				if(pvModel.getTableType() ==  PivotTableModel.TABLE_TYPE.OBS_ATTRIBUTE) {
					wsIdx.setNoHeaderColMapObsAttTable(attributeIdToColIdx);
				} else {
					wsIdx.setNoHeaderColMapSeriesAttTable(attributeIdToColIdx);
				}
			}
		}

		boolean isCheckingTable = pvModel.getTableType() == PivotTableModel.TABLE_TYPE.CHECKING;

		for (TableRow hRow : pvModel.getTableRows()) {
			boolean attributeRow = false;
			rowIdx++;
			String[] rowKey = null;

			for (TableCell tCell : hRow.getTableCells()) {
				List<String> values = null;
				String cellRef = toCellReference(cellRefMap, tCell, tableOffset);

				CELL_FORMAT format = CELL_FORMAT.STRING;
				Integer colIndex = tCell.getCellIndex()+1;
				String styleName = null;
				String cellValue = tCell.getCellValue();

				switch(tCell.getCellType()) {
				case HEADER_TITLE :
					styleName = HEAD_ALL_BORDERS;
					break;
				case HEADER_VALUE :
					styleName = HEADVAL_ALL_BORDERS;
					rowKey = tCell.getCellSeriesKey();
					if(hRow.isPresentational()) {
						styleName = HEADVAL_BOLD_ALL_BORDERS;
					} else if(hRow.isTableHead() && !hasRowDimensions) {
						//There are only Dimensions iterating accross the header, so for each header column
						//store the cell key
						wsIdx.addColumnKey(colIndex, tCell.getCellSeriesKey());
					} else {
						if(!ObjectUtil.validString(cellValue)) {
							//THIS IS THE LAST HEADER ITEM, WHICH IS THE PARTIAL KEY FOR THE COLUMN
							cellValue = SeriesUtil.toSeriesKey(tCell.getCellSeriesKey());
							wsIdx.addColumnKey(colIndex, tCell.getCellSeriesKey());
						}
					}
//					if(cellValue.length() > 20) {
//						int length = cellValue.length();
//						for(int i=0; i < length; i++) {
//							int subStr
//						}
//					}
					break;
				case OBSERVATION :
					format = CELL_FORMAT.DOUBLE;
				case OBSERVATION_ATTRIBUTE :
					if(isCheckingTable) {
						if(tCell.getCellType() == CELL_TYPE.OBSERVATION) {
							styleName = CHECKING_CELL;
						} else {
							styleName = DISABLED;
						}
					} else {
						
						String cellColour = tCell.getCellColour();
						if(cellColour == null) {
							styleName = DEFAULT_OBS;
						} else {
							styleName = cellColour;
						}
						if(coloutAttribute != null && tCell.getAttributeId().equals(coloutAttribute.getAttribute().getComponent().getId())) {
							String seriesKey = SeriesUtil.toSeriesKey(tCell.getCellSeriesKey());
							String obsCellRef = shortCodeToObsCell.get(seriesKey);
							
							//TODO Add values back in once the POI performance issues are resolveds
							//values = new ArrayList<>();
							for(EnumeratedItemBean item : coloutAttribute.getAttributeColorKey().keySet()) {
								//values.add(item.getId());
								writer.addConditionalFormatting(obsCellRef, cellRef, item.getId(), coloutAttribute.getAttributeColorKey().get(item));
							}
						}
						//First time data is hit store the row key
						if(rowKey != null) {
							if(tCell.getCellType() == CELL_TYPE.OBSERVATION_ATTRIBUTE) {
								attributeRow = true;
								if(!hasHeaderDimensions) {
									//The attribute is part of the column
									//								rowKey = Arrays.copyOf(rowKey, rowKey.length +1);
									//								rowKey[rowKey.length-1] = "*"; //multiple attributes
								} else {
									rowKey = Arrays.copyOf(rowKey, rowKey.length +1);
									rowKey[rowKey.length-1] = tCell.getAttributeId();
								}
							}
							wsIdx.addRowKey(rowIdx, rowKey);
							rowKey = null;
						}
					}
					break;
				case OBSERVATION_NO_DATA :
					styleName = DISABLED;
					break;
				default:
				}

				String cellFormula = null;
				if(tCell.hasExpression()) {
					ICellFormula formula = tCell.getCellFormula();
					String expression = formula.getExpression();
					List<TableCell> expInputs = formula.getExpressionInputs();
					for(int i = expInputs.size()-1; i >= 0; i--) {
						TableCell calcInputCell = expInputs.get(i);
						String substitute = calcInputCell != null ? toCellReference(cellRefMap, calcInputCell, tableOffset) : "0";
						expression = expression.replaceAll("a"+i, substitute);
					}
					cellFormula = expression;
				}
				FusionCell cell = getCell(cellValue, colIndex, rowIdx, styleName);
				cell.setFormat(format);
				cell.setCellValues(values);
				cell.setColspan(tCell.getColspan());
				cell.setRowspan(tCell.getRowspan());
				cell.setWrapText(true);
				cell.setBorderStyle(BORDER_STYLE.THIN);
				cell.setCellFormula(cellFormula);
				returnList.add(cell);
				writer.writeCell(cell);
			}
			if(pvModel.getTableType() == PivotTableModel.TABLE_TYPE.OBS && attributeRow) {
				//FR-4620 Excel Reporting Template: Toggle (to hide/show observation attributes section) keeping the worksheets protected
				//This can not be achieved on a protected workbook so has not been included, code left in position
				//writer.groupRows(rowIdx, rowIdx);
			}
		}
		
		

		return returnList;
	}

	public String toCellReference(Map<TableCell, String> cellRefMap, TableCell cell, int offsetRow) {
		String cellRef = cellRefMap.get(cell);
		if(cellRef != null) {
			return cellRef;
		}
		int colIdx = cell.getCellIndex()+1;  //Offset 2, 1 is because it's zero indexed, 1 because the pivot table starts on second column
		int rowIdx = cell.getRowIndex() + offsetRow;
		cellRef = ExcelUtil.toCellReference(colIdx, rowIdx);
		cellRefMap.put(cell, cellRef);
		return cellRef;
	}

	/**
	 * Writes fixed values for the Dimensions/Attributes in the header section of the Excel template
	 * @param fixedComponent
	 */
	private int writeFixedValues(SimpleExcelWriter writer,
			ReportingTemplateWorksheet ws,
			WorksheetIndex wsIdx,
			Map<ReportingTemplateComponent, EnumeratedItemBean> fixedComponent, int rownum, boolean isAttribute) {
		Map<String, ReportingTemplateComponent> compMap = new HashMap<>();
		for(ReportingTemplateComponent fixedDim : fixedComponent.keySet()) {
			compMap.put(fixedDim.getComponent().getId(), fixedDim);
		}
		for(ComponentBean currentComp : ws.getDataStructureBean().getComponents()) {
			ReportingTemplateComponent fixedComp = compMap.get(currentComp.getId());
			if(fixedComp == null || ws.isExcludeDimension(currentComp.getId())) {
				continue;
			}

			EnumeratedItemBean fixedCode = fixedComponent.get(fixedComp);

			String componentId = fixedComp.getComponent().getId();
			String componentValue = fixedCode.getId();

			writeCell(writer, componentId, 1, rownum, HEAD_MD_BORDER_LEFT);
			FusionCell cell = getCell(fixedComp.getConcept().getName(), 2, rownum, HEAD);
			cell.setColspan(2);
			writer.writeCell(cell);
//			writeCell(writer, fixedComp.getConcept().getName(), 2, rownum, HEAD);
			writeCell(writer, componentValue, 4, rownum, HEAD_VAL);
			
			cell = getCell(fixedCode.getName(), 5, rownum, HEADVAL_MD_BORDER_RIGHT);
			cell.setColspan(3);
			writer.writeCell(cell);
			
			
			writeCell(writer, null, 7, rownum, BORDER_LEFT);

			if(isAttribute) {
				wsIdx.addFixedValue(componentId, componentValue);
			}
			rownum++;
		}
		return rownum;
	}

	/**
	 * Writes fixed values for the Dimensions/Attributes in the header section of the Excel template
	 * @param fixedComponent
	 */
	private int writeVariableDimensions(SimpleExcelWriter writer, ReportingTemplateWorksheet ws, WorksheetIndex wsIdx, Map<String, ReportTemplateVariableDimension> variableDimensions, int rownum) {
		int loopIdx = 1;

		for(DimensionBean dim : ws.getDataStructureBean().getDimensionList().getDimensions()) {
			ReportTemplateVariableDimension variableDim = variableDimensions.get(dim.getId());
			if(variableDim == null) {
				continue;
			}
			ReportingTemplateComponent component = variableDim.getReportingTemplateComponent();
			String componentId = component.getComponent().getId();
			if(ws.getReportingTemplate().isGlobalVariableDimension(componentId)) {
				continue;
			}
			rownum++;

			String compIdStyle;    //Top left, Left, Bottom Left, top-left-bottom
			String compNameStyle;  //Top, Top-bottom, None

			if(loopIdx == 1 && loopIdx == variableDimensions.size()) {
				compIdStyle = HEAD_L_BORDER_TOP_LEFT_BOTTOM;
				compNameStyle = HEAD_L_BORDER_TOP_BOTTOM;
			} else if(loopIdx == 1) {
				compIdStyle = HEAD_L_BORDER_TOP_LEFT;
				compNameStyle = HEAD_L_BORDER_TOP;
			} else if (loopIdx == variableDimensions.size()) {
				compIdStyle = HEAD_L_BORDER_BOTTOM_LEFT;
				compNameStyle = HEAD_L_BORDER_BOTTOM;
			} else {
				compNameStyle = HEAD;
				compIdStyle = HEAD_L_BORDER_LEFT;
			}

			writeCell(writer, componentId, 1, rownum, compIdStyle);
			writeCell(writer, component.getConcept().getName(), 2, rownum, compNameStyle);

			FusionCell cell = getCell("", 3, rownum, VARIABLE_DIM);
			cell.setColspan(2);

			List<String> dropDownValues = ObjectUtil.collectToList(variableDim.getValidCodes().stream().map(code -> code.getId() +": "+code.getName()));
			Collections.sort(dropDownValues);
			cell.setCellValues(dropDownValues);
			String cellAddress = writer.writeCell(cell);

			int dimIdx = dim.getPosition() - 1;
			wsIdx.addVariableDimension(dimIdx, cellAddress);
			loopIdx++;
		}
		if(loopIdx > 1) {
			rownum++;
		}
		return rownum;
	}

	/**
	 * Writes the key in the header section of the template, the key is represented by colour and labels
	 * @param colouredAttribute
	 * @return rownum
	 */
	private int writeColouredAttributeValues(SimpleExcelWriter writer, WorksheetIndex wsIdx, ReportingTemplateColouredAttribute colouredAttribute) {
		if(colouredAttribute == null) {
			return 0;
		}
		int colourKeyStartColumn = 9;
		FusionCell cell = getCell(colouredAttribute.getAttribute().getConcept().getName(), colourKeyStartColumn, 0, WHITE_BOLD);
		cell.setColspan(3);
		writer.writeCell(cell);


		Map<EnumeratedItemBean, String> colourMap = colouredAttribute.getAttributeColorKey();
		int rownum = 1;
		Font sFont = writer.getWorkbook().createFont();
		sFont.setFontHeightInPoints((short)9);
		sFont.setBold(false);

		StringBuilder colourMetadata = new StringBuilder();
		colourMetadata.append(colouredAttribute.getAttribute().getComponent().getId());

		for(EnumeratedItemBean currentCode : colourMap.keySet()) {
			String colour = colourMap.get(currentCode);

			colourMetadata.append(","+colour+":"+currentCode.getId());

			CellStyle style = createStyle(sFont, colour, writer, colour);
			style.setLocked(false);
			style.setWrapText(true);
			setBorders(style, bsThin, bsThin, bsThin, bsThin);

			writeCell(writer, currentCode.getId(), colourKeyStartColumn, rownum, colour);

			cell = getCell(currentCode.getName(), (colourKeyStartColumn+1), rownum, null);
			cell.setColspan(3);
			writer.writeCell(cell);

			rownum++;
		}
		writer.addCustomMetadataProperty("COLOUR,"+wsIdx.getWorksheet(), colourMetadata.toString());
		return rownum;
	}


	/**
	 * @param writer
	 * @param val
	 * @param colIdx
	 * @param rowIdx
	 * @param styleName
	 * @return cell address
	 */
	private String writeCell(SimpleExcelWriter writer, String val, int colIdx, int rowIdx, String styleName) {
		return writer.writeCell(val, colIdx, rowIdx, styleName);
	}

	private FusionCell getCell(String val, int colIdx, int rowIdx, String styleName) {
		FusionCell cell = new CellImpl(colIdx, rowIdx, val);
		cell.setStyleName(styleName);
		return cell;
	}

	private void createStyles(ReportingTemplate reportingTemplate, SimpleExcelWriter writer) {
		Workbook workbook = writer.getWorkbook();
		Font bFont = createFont(workbook, 9, true);
		Font whiteFont = createFont(workbook, 9, true);
		whiteFont.setColor(HSSFColorPredefined.WHITE.getIndex());
		Font sFont = createFont(workbook, 9, false);

		//MAIN PAGE
		Font h1 = createFont(workbook, 24, true);
		Font h2 = createFont(workbook, 22, true);
		Font h3 = createFont(workbook, 14, true);
		Font h4 = createFont(workbook, 11, true);
		Font v1 = createFont(workbook, 14, false);
		Font v2 = createFont(workbook, 11, false);

		CellStyle style = createStyle(sFont, WHITE, writer, WHITE_CELL);
		style = createStyle(sFont, WHITE, writer, DEFAULT_OBS);
		style.setWrapText(true);
		setBorders(style, bsThin, bsThin, bsThin, bsThin);
		style.setLocked(false);

		style = createStyle(sFont, WHITE, writer, BORDER_LEFT);
		
		
		//Only add this style if we need to
		boolean hasCheckingTable = false;
		for(ReportingTemplateWorksheet ws : reportingTemplate.getDataSheets()) {
			if(ws.includeFormulaCheckingTable()) {
				hasCheckingTable = true;
				break;
			}
		}

		if(hasCheckingTable) {
			style = createStyle(sFont, WHITE, writer, CHECKING_CELL);
			setBorders(style, bsThin, bsThin, bsThin, bsThin);
		}


		style = createStyle(sFont, WHITE, writer, TEXT_WRAP);
		style.setWrapText(true);
		style = createStyle(whiteFont, WHITE, writer, WHITE_FONT_WHITE_CELL);
		style = createStyle(bFont, WHITE, writer, WHITE_BOLD);
		style = createStyle(bFont, WHITE, writer, WHITE_BORDER_TOP);
		setBorders(style, bsMed, null, null, null);
		style = createStyle(whiteFont, WHITE, writer, WHITE_BOLD_MD_BORDER_BOTTOM);
		setBorders(style, null, null, bsMed, null);
		style = createStyle(v1, WHITE, writer, TIME_PERIOD_EDITABLE);
		style.setLocked(false);
		setBorders(style, bsMed, bsMed, bsMed, bsMed);

		style = createStyle(sFont, YELLOW, writer, VARIABLE_DIM);
		setBorders(style, null, null, null, bsThin);
		style.setLocked(false);

		style = createStyle(null, YELLOW, writer, MAIN_YELLOW);
		style = createStyle(null, YELLOW, writer, MAIN_YELLOW_BOTTOM);
		setBorders(style, null, null, bsMed, null);
		style = createStyle(null, YELLOW, writer, MAIN_YELLOW_BOTTOM_LEFT);
		setBorders(style, null, null, bsMed, bsMed);
		style = createStyle(null, YELLOW, writer, MAIN_YELLOW_BOTTOM_RIGHT);
		setBorders(style, null, bsMed, bsMed, null);
		style = createStyle(null, YELLOW, writer, MAIN_YELLOW_LEFT);
		setBorders(style, null, null, null, bsMed);
		style = createStyle(null, YELLOW, writer, MAIN_YELLOW_RIGHT);
		setBorders(style, null, bsMed, null, null);
		style = createStyle(null, YELLOW, writer, MAIN_YELLOW_TOP);
		setBorders(style, bsMed, null, null, null);
		style = createStyle(null, YELLOW, writer, MAIN_YELLOW_TOP_LEFT);
		setBorders(style, bsMed, null, null, bsMed);
		style = createStyle(null, YELLOW, writer, MAIN_YELLOW_TOP_RIGHT);
		setBorders(style, bsMed, bsMed, null, null);

		style = createStyle(h1, YELLOW, writer, MAIN_YELLOW_H1);
		style = createStyle(h2, YELLOW, writer, MAIN_YELLOW_H2);
		style = createStyle(h3, YELLOW, writer, MAIN_YELLOW_H3);
		style = createStyle(h4, YELLOW, writer, MAIN_YELLOW_H4);
		style = createStyle(v1, YELLOW, writer, MAIN_YELLOW_V1);
		style = createStyle(v2, YELLOW, writer, MAIN_YELLOW_V2);

		//DISABLED
		style = createStyle(bFont, "#a6a6a6", writer, DISABLED);
		style.setFillPattern(FillPatternType.FINE_DOTS);

		style = createTableHeadStyle(bFont, writer, HEAD);
		style.setWrapText(true);
		
		style = createTableHeadStyle(bFont, writer, HEAD_MD_BORDER_TOP_LEFT);
		setBorders(style, bsMed, null, null, bsMed);

		style = createTableHeadStyle(bFont, writer, HEAD_MD_BORDER_TOP);
		setBorders(style, bsMed, null, null, null);

		style = createTableHeadStyle(bFont, writer, HEAD_MD_BORDER_TOP_RIGHT);
		setBorders(style, bsMed, bsMed, null, null);

		style = createTableHeadStyle(bFont, writer, HEAD_MD_BORDER_LEFT);
		setBorders(style, null, null, null, bsMed);

		style = createTableHeadStyle(bFont, writer, HEAD_MD_BORDER_BOTTOM);
		setBorders(style, null, null, bsMed, null);

		style = createTableHeadValueStyle(sFont, writer, HEAD_VAL);
		style.setWrapText(true);


		//Borders for Fixed Dimensions and Attributes
		style = createTableHeadValueStyle(sFont, writer, HEADVAL_MD_BORDER_TOP_LEFT);
		setBorders(style, bsMed, null, null, bsMed);

		style = createTableHeadValueStyle(sFont, writer, HEADVAL_MD_BORDER_TOP);
		setBorders(style, bsMed, null, null, null);

		style = createTableHeadValueStyle(sFont, writer, HEADVAL_MD_BORDER_RIGHT);
		setBorders(style, null, bsMed, null, null);

		style = createTableHeadValueStyle(sFont, writer, HEADVAL_MD_BORDER_LEFT);
		setBorders(style, null, null, null, bsMed);

		style = createTableHeadValueStyle(sFont, writer, HEADVAL_MD_BORDER_BOTTOM);
		setBorders(style, null, null, bsMed, null);

		style = createTableHeadValueStyle(sFont, writer, HEADVAL_MD_BORDER_TOP_RIGHT);
		setBorders(style, bsMed, bsMed, null, null);

		//Borders for Variable Dimensions
		style = createTableHeadStyle(sFont, writer, HEAD_L_BORDER_TOP_LEFT);
		setBorders(style, bsThin, null, null, bsThin);

		style = createTableHeadStyle(sFont, writer, HEAD_L_BORDER_TOP_LEFT_BOTTOM);
		setBorders(style, bsThin, null, bsThin, bsThin);

		style = createTableHeadStyle(sFont, writer, HEAD_L_BORDER_TOP);
		setBorders(style, bsThin, null, null, null);

		style = createTableHeadStyle(sFont, writer, HEAD_L_BORDER_TOP_BOTTOM);
		setBorders(style, bsThin, null, bsThin, null);

		style = createTableHeadStyle(sFont, writer, HEAD_L_BORDER_BOTTOM_LEFT);
		setBorders(style, null, null, bsThin, bsThin);

		style = createTableHeadStyle(sFont, writer, HEAD_L_BORDER_LEFT);
		setBorders(style, null, null, null, bsThin);

		style = createTableHeadStyle(sFont, writer, HEAD_L_BORDER_BOTTOM);
		setBorders(style, null, null, bsThin, null);

		//Data Table Borders
		style = createTableHeadStyle(bFont, writer, HEAD_ALL_BORDERS);
		style.setWrapText(true);
		setBorders(style, bsThin, bsThin, bsThin, bsThin);

		style = createTableHeadValueStyle(sFont, writer, HEADVAL_ALL_BORDERS);
		style.setWrapText(true);
		setBorders(style, bsThin, bsThin, bsThin, bsThin);
		
		style = createTableHeadValueStyle(bFont, writer, HEADVAL_BOLD_ALL_BORDERS);
		style.setWrapText(true);
		
		setBorders(style, bsThin, bsThin, bsThin, bsThin);
		
		
	}

	private Font createFont(Workbook workbook, int height, boolean isBold) {
		Font font = workbook.createFont();
		font.setFontHeightInPoints((short)height);
		font.setBold(isBold);
		return font;
	}

	private CellStyle createTableHeadStyle(Font font, SimpleExcelWriter writer, String styleName) {
		CellStyle style = createStyle(font, DARK_BLUE, writer, styleName);
		style.setVerticalAlignment(VerticalAlignment.BOTTOM);
		return style;
	}

	private CellStyle createTableHeadValueStyle(Font font, SimpleExcelWriter writer, String styleName) {
		return createStyle(font, LIGHT_BLUE, writer, styleName);
	}

	private CellStyle createStyle(Font font, String colour, SimpleExcelWriter writer, String styleName) {
		CellStyle tableHeader = writer.getWorkbook().createCellStyle();

		if(font != null) {
			tableHeader.setFont(font);
		}

		XSSFCellStyle style = (XSSFCellStyle)tableHeader;
		
		if(colour != null) {
			XSSFColor myColor = new XSSFColor(ColourUtil.hex2Rgb(colour), null);
			style.setFillForegroundColor(myColor);
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		}

		style.setVerticalAlignment(VerticalAlignment.TOP);

		tableHeader.setLocked(true);

		writer.registerStyle(styleName, style);
		return tableHeader;
	}

	private void setBorders(CellStyle style, BorderStyle top, BorderStyle right, BorderStyle bottom, BorderStyle left) {
		if(left != null) {
			style.setBorderLeft(left);

		}
		if(right != null) {
			style.setBorderRight(right);
		}
		if(top != null) {
			style.setBorderTop(top);
		}
		if(bottom != null) {
			style.setBorderBottom(bottom);
		}
	}

	private class RTObsWorksheetTables {
		private DataStructureBean dsd;
		private String worksheetName;
		private PivotTableCollection ptCollection;
		private List<FusionCell> observationTable;
		private List<FusionCell> obsAttTable;
		private List<FusionCell> seriesAttTable;
		private List<FusionCell> checkingTable;
		private int worksheetCount =1;  //for the obs table

		public RTObsWorksheetTables(DataStructureBean dsd) {
			this.dsd = dsd;
		}

		private int getCurrentRowNum() {
			if(checkingTable != null) {
				return getRowNum(checkingTable);
			} else if(seriesAttTable != null) {
				return getRowNum(seriesAttTable);
			}  else if(obsAttTable != null) {
				return getRowNum(obsAttTable);
			} else if(observationTable != null) {
				return getRowNum(observationTable);
			}
			return -1;
		}

		/**
		 * @param cells
		 * @return the last rown number in the list of cells
		 */
		private int getRowNum(List<FusionCell> cells) {
			return cells.get(cells.size()-1).getRowIdx();
		}
	}

	private class RTWorksheet {
		private List<FusionCell> observationTable;
		private SheetProperties properties;

		public RTWorksheet(SheetProperties properties, List<FusionCell> observationTable) {
			this.observationTable = observationTable;
			this.properties = properties;
		}
	}

}
