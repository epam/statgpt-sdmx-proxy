package io.sdmx.fusion.reporttemplate.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.utils.core.file.ZipUtil;
import io.sdmx.utils.core.io.ReadableDataLocationTmp;
import io.sdmx.utils.core.xlsx.XLSXUtil;
import io.sdmx.utils.core.xml.StaxReader;

public class ReportTemplateUtil {

	/**
	 * @param rdl
	 * @return true if the stream of information contains a reporting template
	 */
	public static boolean isReportingTemplate(ReadableDataLocation sourceData) {
		if(XLSXUtil.isXlsx(sourceData)) {
			try {
				StaxReader reader = null;
				ReadableDataLocationTmp  rdl = null;
				try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
					if(ZipUtil.getFileFromZip(sourceData.getInputStream(), "docProps/custom.xml", bos)) {
					    rdl = new ReadableDataLocationTmp(new ByteArrayInputStream(bos.toByteArray()));
					    reader = new StaxReader(rdl);
						bos.close();
						while(reader.moveNextStartNode()) {
							if(reader.getElementName().equals("property")) {
								if("ExcelTemplateRef".equals(reader.getAttributeValue(null, "name"))) {
									return true;
								}
							}
						}
					}
				} finally {
					if(reader != null) {
						reader.close();
					}
					if (rdl != null) {
					    rdl.close();
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

}
