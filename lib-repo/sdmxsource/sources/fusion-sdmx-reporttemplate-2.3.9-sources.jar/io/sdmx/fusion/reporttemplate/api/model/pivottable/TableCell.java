package io.sdmx.fusion.reporttemplate.api.model.pivottable;

import java.util.List;

public interface TableCell {

	/**
	 * Returns the index of the column in relation to the left hand column of the table - zero indexed
	 * @return
	 */
	int getCellIndex();
	

	/**
	 * Returns the index of the row in relation to the left hand column of the table - zero indexed
	 * @return
	 */
	int getRowIndex();
	
	/**
	 * Returns the number of columns this cell spans
	 * @return
	 */
	int getColspan();
	
	/**
	 * Returns the number of rows this cell spans
	 * @return
	 */
	int getRowspan();
	
	/**
	 * Returns the cell type
	 * @return
	 */
	CELL_TYPE getCellType();
	
	/**
	 * Returns the colour for this cell as a Hexadecimal e.g #CCCCCC, note this in only relevent for CELL_TYPE=OBSERVATION and is not mandatory (may be null)
	 * @return hex colour or null if not specified
	 */
	String getCellColour();
	
	/**
	 * Returns true if this cell is not part of the table body
	 * @return
	 */
	boolean isHeaderCell();
	
	/**
	 * Returns the Id of the underlying component, for example the Dimension Id, the Dimension Value Id, or the Observation Short Code
	 * @return
	 */
	String getCellId();
	
	/**
	 * Returns the cell text value to display
	 * @return
	 */
	String getCellValue();
	
	/**
	 * If this cell is of CELL_TYPE.OBSERVATION_ATTRIBUTE then this returns the id of the dsd attribute component 
	 * @return
	 */
	String getAttributeId();
	
	/**
	 * Returns the partial series key (if a leaf header cell) or full series key (if an obs cell)
	 * Includes the time dimension. Example: [A, S, 5A, 4B, F, B, A, A, LC1, A, 5J, 2008]
	 * @return
	 */
	String[] getCellSeriesKey();
	
	/**
	 * Returns the partial series key of the column for the cell
	 * @return
	 */
	String[] getCellColKey();

	/**
	 * Returns the partial series key for the row of the cell
	 * @return
	 */
	String[] getCellRowKey();
	
	/**
	 * Returns true if this cell has an expression and corresponding expression inputs
	 * @param obsTableExp if true this will check ONLY for expressions which have an EQUALITY of EQUAL and can therefore be put into the observation table
	 * if false, then it will check for all expression types
	 * @return
	 * 
	 */
	default boolean hasExpression() {
		return getCellFormula() != null;
	}

	/**
	 * Returns any checking formula which are used for a checking table
	 * @return
	 */
	List<ITableCellChecking> getCheckingTableInputs();
	
	/**
	 * @return formula at the cell level
	 */
	ICellFormula getCellFormula();
	
}
