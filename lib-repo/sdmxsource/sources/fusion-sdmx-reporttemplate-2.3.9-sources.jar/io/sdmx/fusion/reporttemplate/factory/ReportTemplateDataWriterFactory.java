package io.sdmx.fusion.reporttemplate.factory;

import java.io.OutputStream;

import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.manager.structure.ConstraintRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.core.sdmx.api.factory.data.ISeriesDataWriterFactory;
import io.sdmx.fusion.reporttemplate.engine.ReportTemplateDynamicDataWriterEngine;
import io.sdmx.fusion.reporttemplate.engine.ReportTemplateFullDataWriterEngine;
import io.sdmx.fusion.reporttemplate.model.format.ReportTemplateDataFormat;
import io.sdmx.utils.sdmx.structure.UrnUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class ReportTemplateDataWriterFactory implements ISeriesDataWriterFactory {

	private SdmxSuperBeanRetrievalManager superBeanRetrievalManager;
	private SdmxBeanRetrievalManager beanRetrievalManager;
	private ConstraintRetrievalManager constraintRetrievalManager;
	
	public ReportTemplateDataWriterFactory(SdmxBeanRetrievalManager beanRetrievalManager, ConstraintRetrievalManager constraintRetrievalManager, SdmxSuperBeanRetrievalManager superBeanRetrievalManager) {
		this.superBeanRetrievalManager = superBeanRetrievalManager;
		this.constraintRetrievalManager = constraintRetrievalManager;
		this.beanRetrievalManager = beanRetrievalManager;
	}

	@Override
	public ISeriesObsDataWriterEngine getDataWriterEngine(DataFormat dataFormat, OutputStream out, DataQuery dataQuery) {
		if(dataFormat == null || out == null) {
			return null;
		}
		
		if(dataFormat == ReportTemplateDataFormat.getInstance(false) || dataFormat == ReportTemplateDataFormat.getInstance(true)) {
			ReportingTemplateBean rt = dataQuery == null ? null : lookupReportingTemplateBean(dataQuery);
			if(dataFormat == ReportTemplateDataFormat.getInstance(false)) {
				//Report Template - data only
				return new ReportTemplateDynamicDataWriterEngine(rt, true, beanRetrievalManager, superBeanRetrievalManager, out);
			}
			if(dataQuery == null) {
				throw new SdmxNotAcceptableException("Can not create create output format, unable to determine which Report Template to use");
			}
			if(dataFormat == ReportTemplateDataFormat.getInstance(true)) {
				IURNSingle<DataProviderBean> providerRef = getProviderReferenceFromDataQuery(dataQuery);
				return new ReportTemplateFullDataWriterEngine(rt, beanRetrievalManager, constraintRetrievalManager, superBeanRetrievalManager, providerRef, out);
			}
		} else if(dataFormat instanceof ReportTemplateDataFormat) {
			ReportTemplateDataFormat templateSpecificDataFormat = (ReportTemplateDataFormat)dataFormat;
			IURNSingle<ReportingTemplateBean> mRef = templateSpecificDataFormat.getReportTemplateRef();
			ReportingTemplateBean rt = null;
			if(mRef != null) {
				 rt = beanRetrievalManager.getBean(mRef);
			} else if (dataQuery != null) {
				rt = lookupReportingTemplateBean(dataQuery);
			} else {
				throw new SdmxNotAcceptableException("Can not create create output format, unable to determine which Report Template to use");
			}
			
			if(rt == null) {
				String postFix = UrnUtil.getUrnPostfix(mRef.getAgencyId(), mRef.getMaintainableId(), mRef.getVersion());
				throw new SdmxNotAcceptableException("No reporting template found with identifiers '"+postFix+"' for requested output");
			}
			if(templateSpecificDataFormat.isIncludeFullWorkbook()) {
				return new ReportTemplateFullDataWriterEngine(rt, beanRetrievalManager, constraintRetrievalManager ,superBeanRetrievalManager, templateSpecificDataFormat.getProviderRef(), out);
			} else {
				return new ReportTemplateDynamicDataWriterEngine(rt, true, beanRetrievalManager, superBeanRetrievalManager, out);
			}
		}
		
		return null;
	}
	
	private IURNSingle<DataProviderBean> getProviderReferenceFromDataQuery(DataQuery dataQuery) {
		if(dataQuery == null) {
			return null;
		}
		if(dataQuery != null) {
			for(ProvisionAgreementBean prov : dataQuery.getProvisionAgreements()) {
				return prov.getDataproviderRef().getReference();
			}
			for(DataProviderBean provider : dataQuery.getDataProvider()) {
				return provider.getURN();
			}
		}
		return null;
	}
	
	/**
	 * Returns the ReportingTemplateBean derived from the Dataflow for the DataQuer
	 * @param dq
	 * @return
	 * @throws SdmxNotAcceptableException if no reporting template can be found (user error in requesting this data in an unsupported format)
	 */
	private ReportingTemplateBean lookupReportingTemplateBean(DataQuery dq) throws SdmxNotAcceptableException {
		for(ReportingTemplateBean rt : 	beanRetrievalManager.getMaintainableBeans(URN.build(ReportingTemplateBean.class))) {
			for(ReportingTemplateWorksheetBean rtWorksheet : rt.getWorksheets()) {
				if(rtWorksheet.getDataflow().isMatch(dq.getDataflow())) {
					return rt;
				}
			}
		}
		throw new SdmxNotAcceptableException("No Report Template for Dataflow: "+dq.getDataflow().getShortURN());
	}


}
