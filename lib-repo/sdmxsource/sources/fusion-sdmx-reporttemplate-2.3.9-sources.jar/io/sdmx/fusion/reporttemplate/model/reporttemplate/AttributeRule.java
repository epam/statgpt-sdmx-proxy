package io.sdmx.fusion.reporttemplate.model.reporttemplate;

import io.sdmx.api.sdmx.constants.CONDITION;
import io.sdmx.api.sdmx.constants.EQUALITY;

public class AttributeRule {
	private String attributeValue;
	private String attributeId;
	private CONDITION condition;
	private String ruleDetail;
	private EQUALITY equality;
	
	public AttributeRule(String attributeId, String attributeValue, CONDITION condition, String ruleDetail) {
		this.attributeId = attributeId;
		this.attributeValue = attributeValue;
		this.condition = condition;
		this.ruleDetail = ruleDetail;
		if(condition == CONDITION.OBSERAVTION_VALUE) {
			String[] split = ruleDetail.split("\\.");
			String eq = split[0];
			this.equality = EQUALITY.fromString(eq);
			this.ruleDetail = ruleDetail.substring(ruleDetail.indexOf(".")+1);
		}
	}

	public String getAttributeId() {
		return attributeId;
	}

	public String getAttributeValue() {
		return attributeValue;
	}

	public CONDITION getCondition() {
		return condition;
	}

	public String getRuleDetail() {
		return ruleDetail;
	}

	public EQUALITY getEquality() {
		return equality;
	}
}
