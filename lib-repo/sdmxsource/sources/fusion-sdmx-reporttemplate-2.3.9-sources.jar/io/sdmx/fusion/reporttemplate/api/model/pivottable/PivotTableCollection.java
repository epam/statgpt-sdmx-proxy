package io.sdmx.fusion.reporttemplate.api.model.pivottable;

import java.util.Map;

/**
 * Returns a grouping of tables, representing tables that exist on the same worksheet (obs and obs attr) and includes tables which should be 
 * placed in their own worksheet (obs attr)
 */
public interface PivotTableCollection {

	/**
	 * Returns the model for the observation table
	 * @return the observation table, will not ever be null
	 */
	PivotTableModel getObsTable();

	/**
	 * Returns the model for the formula checking table
	 * @return the table model, or null if not required
	 */
	ICheckingTableModel getFormulaCheckingTable();
	
	/**
	 * Returns the model for the observation attributes table which should appear in the same worksheet as the obs table
	 * 
	 * @return model, or null if there are no attributes in the same worksheet
	 */
	PivotTableModel getObsAttributesTableSameWorksheet();
	
	/**
	 * Returns the model for the series attributes table which should appear in the same worksheet as the obs table
	 * 
	 * @return model, or null if there are no attributes in the same worksheet
	 */
	PivotTableModel getSeriesAttributesTableSameWorksheet();
	
	/**
	 * Returns a table per observation attribute which should be placed in its own worksheet, the map is attribute id to modal
	 * @return a map or null if there are no attributes in a separate worksheet
	 */
	Map<String, PivotTableModel> getAttributeTablesSeperateWorksheets();
}
