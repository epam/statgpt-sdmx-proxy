package io.sdmx.fusion.reporttemplate.model.reporttemplate;


import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateComponent;
import io.sdmx.api.sdmx.constants.TEXT_DISPLAY;
import io.sdmx.api.sdmx.model.beans.base.ComponentBean;
import io.sdmx.api.sdmx.model.beans.conceptscheme.ConceptBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;

public class ReportingTemplateComponentImpl implements ReportingTemplateComponent {
	private ComponentBean component;
	private ConceptBean concept;
	private TEXT_DISPLAY textDisplay;
	
	public ReportingTemplateComponentImpl(ReportingTemplateWorksheetBean ws, DataStructureSuperBean dsdSb, String compId) {
		ComponentSuperBean<ComponentBean> compSb = dsdSb.getComponentById(compId);
		this.concept = compSb.getConcept().getBuiltFrom();
		this.component = compSb.getBuiltFrom();
		this.textDisplay = ws.getTextDisplay(compId);
	}
	
	@Override
	public ComponentBean getComponent() {
		return component;

	}

	@Override
	public ConceptBean getConcept() {
		return concept;
	}

	@Override
	public String getLabel() {
		if(textDisplay == TEXT_DISPLAY.ID) {
			return component.getId();
		}
		if(textDisplay == TEXT_DISPLAY.NAME) {
			return concept.getName();
		}
		return component.getId()+"|"+concept.getName();
	}
	
	@Override
	public String toString() {
		return getLabel();
	}

	@Override
	public int compareTo(ReportingTemplateComponent o) {
		int returnVal = this.getComponent().getId().compareTo(o.getComponent().getId());
		if(returnVal == 0) {
			return this.getComponent().getUrn().compareTo(o.getComponent().getUrn());
		}
		return returnVal;
	}
}
