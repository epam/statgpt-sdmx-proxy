package io.sdmx.fusion.reporttemplate.model.format;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * Describes the data format used to obtain data in an excel template
 */
public class ReportTemplateDataFormat implements DataFormat {
	private static final long serialVersionUID = 1L;
	private FormatDetails formatDetails = new FormatDetailsImpl("Report Template", "xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", true, true, "application/vnd.reporttemplate");

	private static final ReportTemplateDataFormat FULL_INSTANCE = new ReportTemplateDataFormat(true);
	private static final ReportTemplateDataFormat DYNAMIC_INSTANCE = new ReportTemplateDataFormat(false);
	private boolean includeFullWorkbook;
	private IURNSingle<ReportingTemplateBean> rtRef;
	private IURNAbsolute<DataProviderBean> providerRef;
	
	private String asString;

	
	/**
	 * Returns a definition of the format
	 * @param isFullWorkbook , true if the output is to include the complete workbook as defined 
	 * @see isIncludeFullWorkbook
	 * @return
	 */
	public static ReportTemplateDataFormat getInstance(boolean isFullWorkbook) {
		return isFullWorkbook ? FULL_INSTANCE : DYNAMIC_INSTANCE;
	}
	
	public static ReportTemplateDataFormat getInstance(boolean isFullWorkbook, IURNSingle<ReportingTemplateBean> rtRef, IURNAbsolute<DataProviderBean> providerRef) {
		if(rtRef == null && providerRef == null) {
			return getInstance(isFullWorkbook);
		}
		if(rtRef != null && rtRef.getMaintainableId() == null) {
			throw new IllegalArgumentException("ReportTemplateDataFormat.getInstance() - MaintainableRefBean missing required ID");
		}
		return new ReportTemplateDataFormat(isFullWorkbook, rtRef, providerRef);
	}
	
	
	private ReportTemplateDataFormat(boolean includeFullWorkbook) {
		this.includeFullWorkbook = includeFullWorkbook;
	}
	

	private ReportTemplateDataFormat(boolean isFull, IURNSingle<ReportingTemplateBean> rtRef, IURNAbsolute<DataProviderBean> providerRef) {
		this.includeFullWorkbook = isFull;
		this.rtRef = rtRef;
		this.providerRef = providerRef;
	}
	
	/**
	 * @return a reference to the report template to use, or null if not provided (in which case a dynamic lookup is required based on some other information)
	 */
	public IURNSingle<ReportingTemplateBean> getReportTemplateRef() {
		return rtRef;
	}

	/**
	 * @return a reference to the data provider to output the template for, only required for full data report template (not a partial template)
	 */
	public IURNAbsolute<DataProviderBean> getProviderRef() {
		return providerRef;
	}

	/**
	 * If true, then the full workbook will be returned with all worksheets defined in the report template
	 * configuration, the data will be injected into the worksheet.  If false then the report template configuration
	 * will be used to know what the layout of the data is, but only the worksheet(s) for the dataset(s) written to the 
	 * output will be included, an in those worksheets, only cells which contain data will be included
	 * @return
	 */
	public boolean isIncludeFullWorkbook() {
		return includeFullWorkbook;
	}
	
	@Override
	public FormatDetails getFormatDetails() {
		return formatDetails;
	}
	
	
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof ReportTemplateDataFormat) {
			ReportTemplateDataFormat that = (ReportTemplateDataFormat)obj;
			return that.isIncludeFullWorkbook() == this.isIncludeFullWorkbook()
					&& ObjectUtil.equivalent(that.getProviderRef(), this.getProviderRef())
					&& ObjectUtil.equivalent(that.getReportTemplateRef(), this.getReportTemplateRef());
		}
		return false;
	}

	@Override
	public String toString() {
		if(asString == null) {
			StringBuilder sb = new StringBuilder();
			sb.append(includeFullWorkbook ? "full" : "partial");
			if(providerRef != null) {
				sb.append("providerRef"+providerRef.getAgencyId()+"."+providerRef.getMaintainableId()+"("+providerRef.getVersion()+")."+providerRef.getIdentifiableId());
			}
			if(rtRef != null) {
				sb.append("rtRef"+rtRef.getAgencyId()+"."+rtRef.getMaintainableId()+"("+rtRef.getVersion()+")");
			}
			asString = sb.toString();
		}
		
		return asString;
	}
}
