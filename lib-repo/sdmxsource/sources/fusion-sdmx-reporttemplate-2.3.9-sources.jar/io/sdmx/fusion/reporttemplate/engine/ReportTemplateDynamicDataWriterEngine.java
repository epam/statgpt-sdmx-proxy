package io.sdmx.fusion.reporttemplate.engine;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateWorksheetMutableBean;
import io.sdmx.fusion.reporttemplate.api.model.template.IReportingTemplateInstructionSheet;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportTemplateVariableDimension;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplate;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateWorksheet;
import io.sdmx.fusion.reporttemplate.model.reporttemplate.ReportingTemplateWorksheetImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.AgencyUtil;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * The output for this data writer is based on a Report Template, but only includes worksheets and series cells
 * for which there is data.
 */
public class ReportTemplateDynamicDataWriterEngine extends AbstractReportTemplateDataWriter {
	
	//Internal Implementation of ReportingTemplate Interface
	private DataWriterReportingTemplate reportTemplate;
	private ReportingTemplateBean reportingTemplateBean;
	
	/**
	 * @param reportTemplateBean this can be null, if it is the template will be discovered at the time the dataset is written
	 * @param beanRetrievalManager
	 * @param superBeanRetrievalManager
	 * @param out
	 */
	public ReportTemplateDynamicDataWriterEngine(ReportingTemplateBean reportTemplateBean, 
			boolean includeMetadataToReadWorkbook,
										  SdmxBeanRetrievalManager beanRetrievalManager,
										  SdmxSuperBeanRetrievalManager superBeanRetrievalManager, 
										  OutputStream out) {
		super(beanRetrievalManager, superBeanRetrievalManager, includeMetadataToReadWorkbook, out);
		setReportingTemplateBean(reportTemplateBean);
	}
	
	@Override
	protected ReportingTemplateBean getReportTemplateBean() {
		return this.reportingTemplateBean;
	}

	@Override
	protected DataWriterReportingTemplate getReportTemplate() {
		return reportTemplate;
	}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		if(this.getReportTemplateBean() == null) {
			DataflowBean flow = structures.getDataflow();
			if(flow == null) {
				throw new SdmxNotAcceptableException("Can not create create output format, unable to determine which report template for to use");
			}
			//lookup the reporting template
			ReportingTemplateBean reportTemplateBean = lookupReportingTemplateBean(flow);
			if(reportTemplateBean == null) {
				throw new SdmxNotAcceptableException("Can not create create output format, no report template for dataflow: "+flow.getShortURN());
			}
			setReportingTemplateBean(reportTemplateBean);
		}
		super.startDataset(structures, header, datasetAttributes, annotations);
	}
	
	protected void setReportingTemplateBean(ReportingTemplateBean reportTemplateBean) {
		if(reportTemplateBean != null) {
			//remove any variable dimensions
			boolean hasVariableDimension = false;
			for(ReportingTemplateWorksheetBean ws : reportTemplateBean.getWorksheets()) {
				if(ObjectUtil.validCollection(ws.getVariableDimensions())) {
					hasVariableDimension = true;
					break;
				}
			}
			if(hasVariableDimension || reportTemplateBean.includeFormulaCheckingSummary()) {
				//mutate it to remove the variable dimension, putting it into the row header as the first header
				ReportingTemplateMutableBean rtMutable = reportTemplateBean.getMutableInstance();
				if(hasVariableDimension) {
					for(ReportingTemplateWorksheetMutableBean wsMutable : rtMutable.getWorksheets()) {
						if(wsMutable.getVariableDimensions() != null) {
							List<String> tableRows = wsMutable.getTableRows() == null ? new ArrayList<>() : wsMutable.getTableRows();
							for(String varDim : wsMutable.getVariableDimensions()) {
								tableRows.add(0, varDim);
							}
							wsMutable.setTableRows(tableRows);
							wsMutable.setVariableDimensions(null);
						}
					}
				}
				rtMutable.setIncludeFormulaCheckingSummary(false);
				reportTemplateBean = rtMutable.getImmutableInstance();
			}
			this.reportingTemplateBean = reportTemplateBean;
			this.reportTemplate = new DataWriterReportingTemplate(reportTemplateBean);
		}
	}
	
	/**
	 * Returns the ReportingTemplateBean derived from the Dataflow for the DataQuer
	 * @param dq
	 * @return
	 * @throws SdmxNotAcceptableException if no reporting template can be found (user error in requesting this data in an unsupported format)
	 */
	private ReportingTemplateBean lookupReportingTemplateBean(DataflowBean flow) throws SdmxNotAcceptableException {
		for(ReportingTemplateBean rt : 	beanRetrievalManager.getMaintainableBeans(URN.build(ReportingTemplateBean.class))) {
			for(ReportingTemplateWorksheetBean rtWorksheet : rt.getWorksheets()) {
				if(rtWorksheet.getDataflow().isMatch(flow)) {
					return rt;
				}
			}
		}
		throw new SdmxNotAcceptableException("No Report Template for Dataflow: "+flow.getShortURN());
	}

	
	protected void flushWorksheet() {
		if(ObjectUtil.validCollection(obsList)) {
			
			ReportingTemplateWorksheet worksheet = new ReportingTemplateWorksheetImpl(reportTemplate, currentWorksheet, structures.getProvisionAgreement(), flow, dsd, obsList, beanRetrievalManager, superBeanRetrievalManager);
			reportTemplate.worksheets.add(worksheet);
		}
		obsList = new ArrayList<>();
	}

	@Override
	protected void closeInternal() {
		if(obsTimes.size() == 0) {
			terminateWriter();
			throw new SdmxNoResultsException("No Data for Report Template");
		}
		//Removed unless we want a main worksheet, in which case we need to determine the Data Provider
//		CrossReferenceBean dataProviderRef = null;
//		for(ReportingTemplateWorksheet ws : reportTemplate.worksheets) {
//			if(ws.getProvisionAgreementBean() == null) {
//				dataProviderRef = null;
//				break;
//			}
//			CrossReferenceBean paDataProviderRef = ws.getProvisionAgreementBean().getDataproviderRef();
//			if(dataProviderRef == null) {
//				dataProviderRef = paDataProviderRef;
//			} else if(!paDataProviderRef.equals(dataProviderRef)) {
//				dataProviderRef = null;
//				break;
//			}
//		}
//		if(dataProviderRef != null) {
//			reportTemplate.dataProviderBean = beanRetrievalManager.getIdentifiableBean(dataProviderRef, DataProviderBean.class);
//		}
	}

	/**
	 * The model used to pass to the excel writer
	 */
	protected class DataWriterReportingTemplate implements ReportingTemplate {
		private ReportingTemplateBean reportTemplateBean;
		private List<ReportingTemplateWorksheet> worksheets = new ArrayList<>();
		private AgencyBean agency;
		private SdmxDate reportingPeriod;
		
		public DataWriterReportingTemplate(ReportingTemplateBean reportTemplateBean) {
			this.reportTemplateBean = reportTemplateBean;
			this.agency = beanRetrievalManager.getBean(AgencyUtil.toRef(reportTemplateBean));
		}
		
		@Override
		public IReportingTemplateInstructionSheet getInstructionSheet() {
			//Only required if we want an instruction worksheet, for dynamic templates the decision was to not have this
			return null;
		}

		@Override
		public List<ReportingTemplateWorksheet> getDataSheets() {
			return worksheets;
		}

		@Override
		public ReportingTemplateBean getReportingTemplateBean() {
			return reportTemplateBean;
		}

		@Override
		public AgencyBean getAgency() {
			return agency;
		}

		@Override
		public DataProviderBean getDataProvider() {
			//Only required if we want a main worksheet, for dynamic templates the decision was to not have this
			return null;
		}

		@Override
		public SdmxDate getReportingPeriod() {
			return reportingPeriod;
		}

		@Override
		@SuppressWarnings("unchecked")
		public Set<ReportTemplateVariableDimension> getGlobalVariableDimensions() {
			return Collections.EMPTY_SET;
		}

		@Override
		public boolean isGlobalVariableDimension(String dimId) {
			return false;
		}
	}
	
}
