package io.sdmx.fusion.reporttemplate.model.table;

import java.util.Map;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.ICheckingTableModel;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.PivotTableCollection;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.PivotTableModel;

public class PivotTableCollectionImpl implements PivotTableCollection {
	private PivotTableModel obsTable;
	private PivotTableModel obsAttributesTableSameWorksheet;
	private PivotTableModel seriesAttributesTableSameWorksheet;
	private Map<String, PivotTableModel> attributeTablesSeperateWorksheets;
	private ICheckingTableModel checkingModel;
	
	public PivotTableCollectionImpl(PivotTableModel obsTable, 
									PivotTableModel obsAttributesTableSameWorksheet, 
									Map<String, PivotTableModel> attributeTablesSeperateWorksheets,
									PivotTableModel seriesAttributesTableSameWorksheet, 
									ICheckingTableModel checkingModel) {
		this.obsTable = obsTable;
		if(obsTable == null) {
			throw new SdmxException("Can not create PivotTableCollection, obsTable can not be null");
		}
		this.obsAttributesTableSameWorksheet = obsAttributesTableSameWorksheet;
		this.attributeTablesSeperateWorksheets = attributeTablesSeperateWorksheets;
		this.seriesAttributesTableSameWorksheet = seriesAttributesTableSameWorksheet;
		this.checkingModel = checkingModel;
	}

	@Override
	public PivotTableModel getObsTable() {
		return obsTable;
	}

	@Override
	public PivotTableModel getObsAttributesTableSameWorksheet() {
		return obsAttributesTableSameWorksheet;
	}
	
	@Override
	public PivotTableModel getSeriesAttributesTableSameWorksheet() {
		return seriesAttributesTableSameWorksheet;
	}

	@Override
	public ICheckingTableModel getFormulaCheckingTable() {
		return checkingModel;
	}

	@Override
	public Map<String, PivotTableModel> getAttributeTablesSeperateWorksheets() {
		return attributeTablesSeperateWorksheets;
	}
}
