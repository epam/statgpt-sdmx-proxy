package io.sdmx.fusion.reporttemplate.model.table;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.utils.json.JsonObjectUtil;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.CELL_TYPE;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.ITableCellChecking;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.PivotTableModel;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.TableCell;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.TableRow;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateComponent;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateSeries;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateWorksheet;
import io.sdmx.fusion.reporttemplate.model.worksheet.TableCellChecking;
import io.sdmx.utils.sdmx.comparator.IdentifiableComparator;
import io.sdmx.api.sdmx.constants.ATTRIBUTE_ATTACHMENT_LEVEL;
import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationSchemeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchicalCodeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.datastructure.AttributeBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.beans.datastructure.PrimaryMeasureBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.core.data.model.calcuation.CustomValidationExpression;
import io.sdmx.utils.core.object.NumberUtils;
import io.sdmx.utils.core.object.SeriesUtil;
import org.codehaus.jettison.json.JSONObject;

public class PivotTableModelImpl implements PivotTableModel {
	private List<TableRow> tableRows = new ArrayList<TableRow>();

	private int[] tRowDimIdx;
	private int[] tColDimIdx;
	private String[] seriesKeyTemplate;  //Use this to make copies for cell keys
	private String[] attributeIds;
	private TABLE_TYPE tableType = TABLE_TYPE.OBS;
	private SortedSet<ValidationRuleBean> validationRules = new TreeSet<>(IdentifiableComparator.INSTANCE);
	private DecimalFormat df;
	private Set<String> seriesAttributes = new HashSet<>();

	/**
	 * @param ws worksheet describing the layout of the model
	 * @param isObsTable - true if this is an observation table
	 * @param attributeIds - the attributes included in this table
	 */
	public PivotTableModelImpl(ReportingTemplateWorksheet ws, TABLE_TYPE tableType, String[] attributeIds) {
		boolean includeTime = tableType != TABLE_TYPE.SERIES_ATTRIBUTE;
		this.tableType = tableType;
		this.attributeIds = attributeIds;
		this.tRowDimIdx = ws.getTableRowDimensions(includeTime);
		this.tColDimIdx = ws.getTableColumnDimensions(includeTime);
		int dimSize = ws.getDataStructureBean().getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION, SDMX_STRUCTURE_TYPE.MEASURE_DIMENSION).size();
		if(tableType != TABLE_TYPE.SERIES_ATTRIBUTE && ws.hasTimePeriods()) {
			dimSize++;
		}
		this.seriesKeyTemplate = new String[dimSize];

		for(ReportingTemplateComponent comp : ws.getFixedDimensions().keySet()) {
			EnumeratedItemBean fixedVal = ws.getFixedDimensions().get(comp);
			int idx = ws.getDataStructureBean().getDimensionIndex(comp.getComponent().getId());
			seriesKeyTemplate[idx] = fixedVal.getId();
		}
		if(ws.getRoundDecimals() != null) {
			df = NumberUtils.getDecimalFormat(ws.getRoundDecimals());
		}
		for(AttributeBean attr : ws.getDataStructureBean().getAttributes()) {
			if(attr.getAttachmentLevel() == ATTRIBUTE_ATTACHMENT_LEVEL.DIMENSION_GROUP) {
				seriesAttributes.add(attr.getId());
			}
		}
	}



	public PivotTableModelImpl(JSONObject json) {
		buildCellFromJSON(json, "THead", true);
		buildCellFromJSON(json, "TBody", false);
	}
	
	@Override
	public SortedSet<ValidationRuleBean> getValidationRules() {
		return Collections.unmodifiableSortedSet(validationRules);
	}

	private void buildCellFromJSON(JSONObject json, String property, boolean isHeadRow) {
		List<TableRow> trList = new ArrayList<>();
		for(JSONObject tRow : JsonObjectUtil.getArrayOfObjects(json, property, false)) {
			TableRow tr = this.addTableRow(isHeadRow);
			trList.add(tr);
		}
		int idx = 0;
		for(JSONObject tRow : JsonObjectUtil.getArrayOfObjects(json, property, false)) {
			TableRow tr = trList.get(idx);
			idx++;
			for(JSONObject tCell : JsonObjectUtil.getArrayOfObjects(tRow, "Cells", false)) {
				int colSpan = JsonObjectUtil.getInteger(tCell, "ColSpan", false);
				int rowSpan = JsonObjectUtil.getInteger(tCell, "RowSpan", false);
				String cellValue = JsonObjectUtil.getString(tCell, "CellValue", true);
				String cellKey = JsonObjectUtil.getString(tCell, "CellKey", true);
				int cellType = JsonObjectUtil.getInteger(tCell, "CellType", false);

				//0=Dimension Id, 1=Dimension Code, 2=Observation,3=Aggregated Observation,4=Missing Value 
				switch(cellType) {
				case 0 :
					tr.addHeaderTitle(cellValue, colSpan, rowSpan);
					break;
				case 1 :
					tr.addHeaderColValue(cellValue, colSpan, rowSpan, null);
					break;
				case 2 :
				case 3 :
				case 4 :
					tr.addObsCell(cellValue);
					break;
				}
			}
		}

	}

	@Override
	public TABLE_TYPE getTableType() {
		return tableType;
	}

	@Override
	public boolean hasHeaderDimensions() {
		return tColDimIdx.length > 0;
	}

	@Override
	public String[] getAttributeIds() {
		return attributeIds;
	}

	@Override
	public boolean hasRowDimensions() {
		return tRowDimIdx.length > 0;
	}



	/**
	 * Sets the TableCell expression and expression inputs based on all ValidationSchemes in the ReportingTemplateWorksheet
	 * @param ws
	 */
	public void createValidaitonCells(ReportingTemplateWorksheet ws) {
		if(ws.getValidationSchemes() != null) {
			//Create a Map of SeriesKey to TableCell
			Map<String, TableCell> cellMap = new HashMap<>();
			for(TableRow currentRow : tableRows) {
				for(TableCell currentCell : currentRow.getTableCells()) {
					if(currentCell.getCellType() == CELL_TYPE.OBSERVATION) {
						String seriesKey = SeriesUtil.toSeriesKey(currentCell.getCellSeriesKey());
						cellMap.put(seriesKey, currentCell);
					}
				}
			}

			for(ValidationSchemeBean currentScheme : ws.getValidationSchemes()) {
				for(ValidationRuleBean currentRule : currentScheme.getItems()) {
					if(currentRule.hasExpression()) {
						createValidationCellsWithCustomExpression(cellMap, currentRule);
					} else if(currentRule.hasValidationHierarchy()){
						createValidationCellsWithHierarchyExpression(ws, cellMap, currentRule);
					}
				}
			}
		}
	}

	/**
	 * Sets the TableCell expression and expression inputs based on a Custom Validation Rule
	 * @param cellMap
	 * @param currentRule
	 */
	private void createValidationCellsWithCustomExpression(Map<String, TableCell> cellMap, ValidationRuleBean currentRule) {
		CustomValidationExpression expression = new CustomValidationExpression(currentRule);
		String output = expression.getOutputCode();
		int dimensionIdx = expression.getDimensionIndex(); 
		List<TableRowImpl.TableCellImpl> targetOutputCells = getTableCells(dimensionIdx, output);
		for(TableRowImpl.TableCellImpl outputCell : targetOutputCells) {
			String[] seriesKey = outputCell.getCellSeriesKey();
			boolean hasInputs = false;
			List<TableCell> expressionInputs = new ArrayList<>();
			for(String inputCode : expression.getInputCodes()) {
				String[] clonedSk = seriesKey.clone();
				clonedSk[dimensionIdx] = inputCode;
				String inputSeriesKey = SeriesUtil.toSeriesKey(clonedSk);
				TableCell input = cellMap.get(inputSeriesKey);
				expressionInputs.add(input);//Add it regardless of if it is null or not as we want to maintain the position of inputs to equation
				if(input != null) {
					hasInputs = true;
				}
			}
			if(hasInputs) {
				outputCell.setExpression(currentRule, expression.rewriteExpression(), currentRule.getEqualityOperator(), expressionInputs);
			}
		}
	}

	/**
	 * Sets the TableCell expression and expression inputs based on a Validation Hierarchy 
	 * @param ws
	 * @param cellMap
	 * @param currentRule
	 */
	private void createValidationCellsWithHierarchyExpression(ReportingTemplateWorksheet ws, Map<String, TableCell> cellMap, ValidationRuleBean currentRule) {
		ICrossReferenceBean<HierarchyBean> hRef = currentRule.getValidationHierarchy().getHierarchyReference();
		ICrossReferenceBean<DimensionBean> dimRef = currentRule.getValidationHierarchy().getDimensionReference();

		String dimId = dimRef.getReference().getIdentifiableId();

		DimensionBean dim = ws.getDataStructureBean().getDimension(dimId);

		int dimensionIdx = dim.getPosition() - 1;
		HierarchyBean hierarchy = ws.getHierarchy(hRef.getTargetUrn());
		if(hierarchy != null) {
			buildHierarchicalValidation(currentRule, hierarchy.getHierarchicalCodeBeans(), dimensionIdx, cellMap);
		}
	}

	/**
	 * Recursive function that walks through each code ref in the hierarchy and calls the buildHierarchicalValidation on it
	 * @param nodes
	 * @param dimensionIdx
	 * @param cellMap
	 */
	private void buildHierarchicalValidation(ValidationRuleBean currentRule, List<HierarchicalCodeBean> nodes, int dimensionIdx, Map<String, TableCell> cellMap) {
		for(HierarchicalCodeBean currentNode : nodes) {
			buildValidationHierarchyOnNode(currentRule, currentNode, dimensionIdx, cellMap);
			buildHierarchicalValidation(currentRule, currentNode.getCodeRefs(), dimensionIdx, cellMap);
		}
	}


	/**
	 * Sets the expression and input cells on the Table Cells that match this HierarchicalCodeBean.  
	 * If the HierarchicalCodeBean has no children or the HierarchicalCodeBean does not match any table cells, 
	 * or the descendants of this HierarchicalCodeBean do not match any cells, then no expression is added.
	 *  
	 * @param outputNode
	 * @param dimensionIdx
	 * @param cellMap
	 */
	public void buildValidationHierarchyOnNode(ValidationRuleBean currentRule, HierarchicalCodeBean outputNode, int dimensionIdx, Map<String, TableCell> cellMap) {
		if(!outputNode.hasChildren()) {
			return;
		}
		String output = outputNode.getCodeReference().getReference().getFullIdentifiableId();
		List<TableRowImpl.TableCellImpl>  outputCells = getTableCells(dimensionIdx, output);
		for(TableRowImpl.TableCellImpl outputCell : outputCells) {
			String[] seriesKey = outputCell.getCellSeriesKey();
			Map<String, TableCell> inputCodes = getInputCodes(outputNode, dimensionIdx, seriesKey, cellMap);
			if(inputCodes.size() > 0) {
				StringBuilder expDeRefSb = new StringBuilder();
				StringBuilder expFullSb = new StringBuilder();
				String concat = "";
				int i=0;
				for(String codeId : inputCodes.keySet()) {
					expFullSb.append(concat+codeId);
					expDeRefSb.append(concat+"a"+i);
					concat = "+";
					i++;
				}
				//Proxy the rule so we can pass a concrete expression to the excel template for display in the checking table
				ValidationRuleBean proxyRule = (ValidationRuleBean) Proxy.newProxyInstance(ValidationRuleBean.class.getClassLoader(),
		                  new Class[] { ValidationRuleBean.class },
		                  new ProxyRule(currentRule, expFullSb.toString()));
				
				List<TableCell> inputsAsList = new ArrayList<>(inputCodes.values());
				Collections.sort(inputsAsList, new Comparator<TableCell>() {
					public int compare(TableCell o1, TableCell o2) {
						int i = o1.getRowIndex() - o2.getRowIndex();
						if(i == 0) {
							i = o1.getCellIndex() - o2.getCellIndex();
						}
						return i;
					};
				});
				outputCell.setExpression(proxyRule, expDeRefSb.toString(), EQUALITY.EQUAL, inputsAsList);
			}
		}
	}
	
	/**
	 * Used because when a rule uses a Hierarchical Codelist it has no expression or equality operation.  These are both required when 
	 * writing out the Check Summary worksheet.  The solution is to tell the proxy what the expression is now that the actual codes used are resolved
	 * from the hierarhcy 
	 */
	private class ProxyRule implements InvocationHandler {
		private ValidationRuleBean proxy;
		private String expression;

		public ProxyRule(ValidationRuleBean proxy, String expression) {
			this.proxy = proxy;
			this.expression = expression;
		}

		@Override
		public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
			if(method.getName().equalsIgnoreCase("getExpression")) {
				return this.expression;
			}
			if(method.getName().equalsIgnoreCase("getEqualityOperator")) {
				return EQUALITY.EQUAL;
			}
			return  method.invoke(this.proxy, args);
		}
	}

	/**
	 * Returns a list of table cells that match the child cells of the outputNode based on the series key input, 
	 * if an immediate child does not have a corresponding TableCell, then it's children will be searched, this is a recusive search until at least
	 * one table cell is found, or there are no HierarchicalCodeBean left to check
	 * @param outputNode
	 * @param dimIdx
	 * @param seriesKey
	 * @param cellMap
	 * @return
	 */
	private Map<String, TableCell> getInputCodes(HierarchicalCodeBean outputNode, int dimIdx, String[] seriesKey, Map<String, TableCell> cellMap) {
		Map<String, TableCell> returnMap = new HashMap<>();
		seriesKey = seriesKey.clone();
		for(HierarchicalCodeBean hChild : outputNode.getCodeRefs()) {
			seriesKey[dimIdx] = hChild.getCodeReference().getReference().getIdentifiableId();
			TableCell input = cellMap.get(SeriesUtil.toSeriesKey(seriesKey));
			if(input != null) {
				returnMap.put(hChild.getCodeReference().getReference().getIdentifiableId(), input);
			} else if(hChild.hasChildren()) {
				returnMap.putAll(getInputCodes(hChild, dimIdx, seriesKey, cellMap));
			}
		}
		return returnMap;
	}


	/**
	 * Gets all table cells that match the dimension value for the given index
	 * @param dimIdx dimension index (zero indexed)
	 * @param dimValue the reported dimension value
	 * @return
	 */
	private List<TableRowImpl.TableCellImpl> getTableCells(int dimIdx, String dimValue) {
		List<TableRowImpl.TableCellImpl> returnList = new ArrayList<>();
		for(TableRow currentRow : tableRows) {
			for(TableCell currentCell : currentRow.getTableCells()) {
				if(currentCell.getCellType() == CELL_TYPE.OBSERVATION) {
					String[] cellKey = currentCell.getCellSeriesKey();
					if(cellKey[dimIdx].equals(dimValue)) {
						returnList.add((TableRowImpl.TableCellImpl)currentCell);
					}
				}
			}
		}
		return returnList;
	}


	@Override
	public List<TableRow> getTableRows() {
		return tableRows;
	}



	@Override
	public TableRow addTableRow(boolean isHeaderRow) {
		TableRow parentRow = null;
		if(tableRows.size() > 0) {
			parentRow = tableRows.get(tableRows.size()-1);
		}

		TableRow tRow = new TableRowImpl(parentRow, isHeaderRow);

		tableRows.add(tRow);
		return tRow;
	}

	@Override
	public int[] getColumnWidths() {
		int[] widths = null;
		if(tableRows.size() > 0) {
			int size = 0;
			TableRowImpl firstRow = (TableRowImpl)tableRows.get(0);
			for(TableCell cell : firstRow.rowCells) {
				size += cell.getColspan();
			}
			widths = new int[size];
			for(TableRow row : tableRows) {
				TableRowImpl rowImpl = (TableRowImpl) row;
				for(int idx=0; idx < size; idx++) {
					TableCell cell = rowImpl.cellMap.get(idx);
					if(cell == null) {
						continue;
					}
					int cs = cell.getColspan();
					String val = cell.getCellValue();
					int length = 0;
					if(val != null) {
						length = Math.round(val.length() / cs);
					}
					while(cs > 0) {
						if(length > widths[idx]) {
							widths[idx] = length;
						}
						cs--;
					}
				}
			}
		}
		return widths;
	}

	private class TableRowImpl implements TableRow {
		private List<TableCell> rowCells = new ArrayList<TableCell>();
		private Map<Integer, TableCell> cellMap = new HashMap<Integer, TableCell>();
		private String[] rowKey;
		private boolean isTableHead;
		private boolean isPresentational;
		private TableRow parentRow;
		private TableRow childRow;
		private int rowIdx;
		private int startCell = 0;
		private List<Integer> blockedCells = new ArrayList<>();

		public TableRowImpl(TableRow parentRow,boolean isTableHead) {
			this.isTableHead = isTableHead;
			this.parentRow = parentRow;
			this.rowIdx = tableRows.size();
			if(parentRow != null) {
				((TableRowImpl)parentRow).childRow = this;
			}
		}

		@Override
		public TableCell getCellAtIndex(int idx) {
			TableCell tc = cellMap.get(idx);
			if(tc == null && parentRow != null) {
				TableRowImpl currentParent = (TableRowImpl)parentRow;
				while(tc == null && currentParent != null) {
					tc = currentParent.cellMap.get(idx);
					if(tc == null) {
						currentParent = (TableRowImpl)currentParent.parentRow;
					}
				}
			}
			return tc;
		}

		@Override
		public void setPresentational(boolean presentational) {
			this.isPresentational = presentational;
		}

		@Override
		public boolean isPresentational() {
			return this.isPresentational;
		}

		@Override
		public boolean isTableHead() {
			return isTableHead;
		}

		@Override
		public String[] getRowKey() {
			return rowKey;
		}

		@Override
		public List<TableCell> getTableCells() {
			return rowCells;
		}

		@Override
		public TableCell addHeaderTitle(String value, int colspan, int rowspan) {
			return addTableCell(value, colspan, rowspan, CELL_TYPE.HEADER_TITLE, null, null);
		}

		@Override
		public TableCell addHeaderColValue(String value, int colspan, int rowspan, String[] partialKey) {
			return addTableCell(value, colspan, rowspan, CELL_TYPE.HEADER_VALUE, partialKey, null);
		}

		@Override
		public TableCell addHeaderRowValue(String value, int colspan, int rowspan, String[] partialKey) {
			return addTableCell(value, colspan, rowspan, CELL_TYPE.HEADER_VALUE, null, partialKey);
		}

		@Override
		public TableCell addObsCell(ReportingTemplateWorksheet ws) {
			TableCellImpl tCell = addTableCell(null, 1, 1, CELL_TYPE.OBSERVATION, null, null);
			
			if (!ws.getSeries().hasData(tCell.getCellSeriesKey())) {
				tCell.cellType = CELL_TYPE.OBSERVATION_NO_DATA;
			} else {
				tCell.cellColour = ws.getObsColour(tCell.getCellSeriesKey());
				if(tableType == TABLE_TYPE.OBS) {
					Observation obs = ws.getObservation(tCell.getCellSeriesKey());
					if(obs != null) {
						tCell.cellValue = NumberUtils.round(df, obs.getMeasureCode(PrimaryMeasureBean.FIXED_ID));
					}
				}
			}
			return tCell;
		}

		@Override
		public TableCell addObsCell(String value) {
			TableCellImpl tCell = addTableCell(value, 1, 1, CELL_TYPE.OBSERVATION, null, null);
			if (value == null) {
				tCell.cellType = CELL_TYPE.OBSERVATION_NO_DATA;
			} else {
				//				tCell.cellColour = ws.getObsColour(tCell.getCellSeriesKey());
			}
			return tCell;
		}

		@Override
		public TableCell addObsAttribute(ReportingTemplateWorksheet ws, ReportingTemplateSeries series, String attributeId, int colspan) {
			TableCellImpl tCell = addTableCell(null, colspan, 1, CELL_TYPE.OBSERVATION_ATTRIBUTE, null, null);
			if(!series.hasData(tCell.getCellSeriesKey())) {
				tCell.cellType = CELL_TYPE.OBSERVATION_NO_DATA;
			} else {
				if(ws.getColourAttribute() != null && ws.getColourAttribute().getAttribute().getComponent().getId().equals(attributeId)) {
//					String hex =  ws.getObsColour(tCell.getCellSeriesKey());
//					if(hex != null) {
//						EnumeratedItemBean item = ws.getColourAttribute().getColorCode(hex);
//						if(item != null) {
//							tCell.cellValue = item.getId();
//						}
//					}
				}
				if(tableType != TABLE_TYPE.CHECKING) {
					if(tableType == TABLE_TYPE.SERIES_ATTRIBUTE) {
						Keyable key = ws.getSeries(tCell.getCellSeriesKey());
						if(key != null && key.getAttribute(attributeId) != null) {
							tCell.cellValue = key.getAttribute(attributeId).getCode();
						}
					} else {
						Observation obs = ws.getObservation(tCell.getCellSeriesKey());
						if(obs != null && obs.getAttribute(attributeId) != null) {
							tCell.cellValue = obs.getAttribute(attributeId).getCode();
						}						
					}
				}
			}
			tCell.attributeId = attributeId;
			return tCell;
		}
		

		private TableCellImpl addTableCell(String cellValue, int colspan, int rowspan, CELL_TYPE cellType, String[] colKey, String[] rowKey) {
			TableCellImpl tCell = new TableCellImpl(rowIdx, blockedCells, colKey, rowKey, cellValue, colspan, rowspan, cellType);

			if(rowspan > 1) {
				try {
					if(this.childRow == null) {
						addTableRow(false);
					}
					((TableRowImpl)this.childRow).setChildRowspan(tCell.getCellIndex(), rowspan, tCell.getColspan());
				} catch(StackOverflowError e) {
					throw new SdmxException("Error writing workbook, stack overflow when trying to set rowspan of '"+rowspan+"' on cell.  Increase stact size, reconfigure table layout, or reduce universe of data for workbook.");
				}
			}

			this.rowCells.add(tCell);
			this.cellMap.put(tCell.getCellIndex(), tCell);
			return tCell;
		}

		private void setChildRowspan(int cellidx, int rowspan, int colspan) {
			for(int i=0; i < colspan; i++) {
				blockedCells.add(cellidx+i);
			}
			rowspan--;
			if(rowspan > 1) {
				if(this.childRow == null) {
					addTableRow(false);
				}
				((TableRowImpl)this.childRow).setChildRowspan(cellidx, rowspan, colspan);
			}
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			for(TableCell cell : rowCells) {
				sb.append(cell.toString()+";");
			}
			return sb.toString();
		}

		public class TableCellImpl implements TableCell {
			private int rowIndex;
			private int cellIndex;
			private int rowspan;
			private int colspan;
			private CELL_TYPE cellType;
			private String cellColour;
			private String cellId;
			private String cellValue;
			private String[] cellKey;
			private String[] colKey;
			private String[] rowKey;
			private String attributeId;
			//Mathmatical expressions

			private ITableCellChecking cellCheck = null;  //An optional equals check on the table cell
			private List<ITableCellChecking> checkingInputs = new ArrayList<>(); //any formual (equals, not equals, greater than, for the checking table of this cell)

			private TableCellImpl(int rowIndex, List<Integer> blockedCells, String[] colKey, String[] rowKey, String cellValue, int colspan, int rowspan, CELL_TYPE cellType) {
				TableCell proceedingCell = null;

				if(rowCells.size() > 0) {
					proceedingCell = rowCells.get(rowCells.size() -1);
				} 
				this.rowIndex = rowIndex;
				if(proceedingCell != null) {
					cellIndex = proceedingCell.getCellIndex()+proceedingCell.getColspan();
				} else {
					cellIndex = startCell;
				}
				while(blockedCells.contains(cellIndex)) {
					cellIndex++;
				}
				if(rowKey != null) {
					rowKey = rowKey.clone();
				} else if(proceedingCell != null) {
					rowKey = proceedingCell.getCellRowKey();
				}

				TableCell parentCell = null;
				if(parentRow != null) {
					parentCell = parentRow.getCellAtIndex(cellIndex);
				}
				if(colKey != null) {
					colKey = colKey.clone();
					//debug sanity check! the parent cell should have the same key as the child cell (except for one value) 
					//if there is an error building the table, in that the cells are misaligned or missing uncomment this and put a break point on the System.out
					//					if(parentCell != null) {
					//						for(int i=0; i < colKey.length; i++) {
					//							String[] parentColKey = parentCell.getCellColKey();
					//							if(parentColKey[i] == null) {
					//								break;
					//							} else if(!parentColKey[i].equals(colKey[i])){
					//								System.out.println(SeriesUtil.toSeriesKey(parentColKey));
					//							}
					//						}
					//					}
				} else if(parentCell != null) {
					colKey = parentCell.getCellColKey();
				}

				if(rowKey == null && parentCell != null) {
					rowKey = parentCell.getCellRowKey();
				}

				setCellKey(colKey, rowKey);

				this.colspan = colspan;
				this.rowspan = rowspan;
				this.cellType = cellType;
				this.cellValue = cellValue;
			}

			@Override
			public int getCellIndex() {
				return cellIndex;
			}

			@Override
			public int getRowIndex() {
				return rowIndex;
			}

			@Override
			public int getColspan() {
				return colspan;
			}

			@Override
			public int getRowspan() {
				return rowspan;
			}

			@Override
			public CELL_TYPE getCellType() {
				return cellType;
			}

			@Override
			public String getCellColour() {
				return cellColour;
			}

			@Override
			public boolean isHeaderCell() {
				return cellType == CELL_TYPE.HEADER_TITLE || cellType == CELL_TYPE.HEADER_VALUE;
			}

			@Override
			public String getAttributeId() {
				return attributeId;
			}

			@Override
			public String getCellId() {
				return cellId;
			}

			@Override
			public String getCellValue() {
				return cellValue;
			}

			@Override
			public String[] getCellSeriesKey() {
				return cellKey;
			}

			@Override
			public String[] getCellColKey() {
				return colKey;
			}

			@Override
			public String[] getCellRowKey() {
				return rowKey;
			}

			private void setCellKey(String[] colKey, String[] rowKey) {
				this.colKey = colKey;
				this.rowKey = rowKey;
				if(seriesKeyTemplate != null) {
					this.cellKey = seriesKeyTemplate.clone();
					if(this.rowKey != null && this.colKey != null) {
						this.cellKey = seriesKeyTemplate.clone();

						for(int i=0; i < tRowDimIdx.length; i++) {
							cellKey[tRowDimIdx[i]] = rowKey[i];
						}
						for(int i=0; i < tColDimIdx.length; i++) {
							cellKey[tColDimIdx[i]] = colKey[i];
						}
					} else if(this.rowKey != null) {
						for(int i=0; i < tRowDimIdx.length; i++) {
							int pos = tRowDimIdx[i];
							if(cellKey.length > pos) {
								cellKey[pos] = rowKey.length > i ? rowKey[i] : null;
							}
						}
					} else if(this.colKey != null) {
						for(int i=0; i < tColDimIdx.length; i++) {
							int pos = tColDimIdx[i];
							if(cellKey.length > pos) {
								cellKey[pos] = colKey.length > i ? colKey[i]: null;
							}
						}
					}
				}
			}


			public void setExpression(ValidationRuleBean underlyingRule, String expression, EQUALITY eq, List<TableCell> expressionInputs) {
				validationRules.add(underlyingRule);
				ITableCellChecking check = new TableCellChecking(underlyingRule, eq, expression, expressionInputs);
//				if(eq == EQUALITY.EQUAL) {
//					this.cellCheck = check;
//				}
				this.checkingInputs.add(check);
			}
			
			@Override
			public List<ITableCellChecking> getCheckingTableInputs() {
				return new ArrayList<>(checkingInputs);
			}

			@Override
			public ITableCellChecking getCellFormula() {
				return cellCheck;
			}

			@Override
			public String toString() {
				return cellValue+",rs="+rowspan+",cs="+colspan;
			}
		}
	}
}
