package io.sdmx.fusion.reporttemplate.api.manager;

import java.util.Map;

import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;

/**
 * Supports obtaining and setting passwords which are used to protect worksheets
 */
public interface ReportTemplatePasswordManager {

	/**
	 * Updates the passwords in the system
	 * @param agencyPasswords
	 * @throws SdmxUnauthorisedException if the user does not have write rules for any of the Agencies
	 */
	void updatePasswords(Map<String, String> agencyPasswords) throws SdmxUnauthorisedException;
	
	/**
	 * Returns all the passwords for each Agency the current user has permissions to view
	 * @return
	 */
	Map<String, String> getAgencyPasswords();
	
	/**
	 * Retrieves the password for an agency
	 * @param agency
	 */
	String getPassword(StructureReferenceBean agency);
	
}
