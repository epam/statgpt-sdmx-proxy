package io.sdmx.fusion.reporttemplate.model.worksheet;

import java.util.List;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.ITableCellChecking;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.TableCell;
import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;

public class TableCellChecking extends TableCellFormula implements ITableCellChecking {
	
	private EQUALITY equality;
	private ValidationRuleBean underlyingRule;

	public TableCellChecking(ValidationRuleBean underlyingRule, EQUALITY equality, String expression, List<TableCell> expressionInputs) {
		super(expression, expressionInputs);
		if(equality == null) {
			throw new SdmxException("TableCellChecking missing required argument, EQUALITY");
		}
		if(underlyingRule == null) {
			throw new SdmxException("TableCellChecking missing required argument, ValidationRuleBean");
		}
		this.underlyingRule = underlyingRule;
		this.equality = equality;
	}

	@Override
	public ValidationRuleBean getUnderlyingRule() {
		return underlyingRule;
	}

	@Override
	public EQUALITY getExpressionEquality() {
		return equality;
	}

	@Override
	public String toString() {
		return equality + getExpression();
	}
}
