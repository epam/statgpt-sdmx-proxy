package io.sdmx.fusion.reporttemplate.api.model.pivottable;

/**
 * Represents a Column in Excel for example A1
 */
public interface PartialKey {

	/**
	 * Returns the partial series key for the column, the array is the same size as Dimensions.size() for the DSD - but may contain null values where dimensions
	 * are not part of the header columns or fixed values, but instead part of the rows
	 * @return a String Array
	 */
	String[] getPartialKey();
	
}
