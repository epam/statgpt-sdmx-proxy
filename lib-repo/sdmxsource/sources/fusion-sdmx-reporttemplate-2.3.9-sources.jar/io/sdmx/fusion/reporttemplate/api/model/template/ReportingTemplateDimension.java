package io.sdmx.fusion.reporttemplate.api.model.template;

import java.util.List;

public interface ReportingTemplateDimension {
	
	/**
	 * Returns the Dimension/Concept information for this Dimension
	 * @return
	 */
	ReportingTemplateComponent getDimension();
	
	/**
	 * If show id, this will be the dimension id, if show id=false then this will be the concept name
	 * @return
	 */
	String getDimensionLabel();
	
	/**
	 * Returns the codes for this Dimension
	 * @return
	 */
	List<ReportingTemplateDimensionCode> getCodes();
	
}
