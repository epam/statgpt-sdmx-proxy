package io.sdmx.fusion.reporttemplate.factory;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.util.ZipSecureFile;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.engine.DataReaderEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.sdmx.api.error.DataValidationErrorHandler;
import io.sdmx.core.sdmx.api.factory.data.DataReaderFactory;
import io.sdmx.core.sdmx.error.DataErrorCategory;
import io.sdmx.fusion.reporttemplate.engine.ExcelReportingTemplateReader;
import io.sdmx.utils.core.application.FusionBeanStore;

public class ExcelTemplateDataReaderFactory implements DataReaderFactory {

	private static ExcelTemplateDataReaderFactory INSTANCE;

	public static ExcelTemplateDataReaderFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}
	
	public static ExcelTemplateDataReaderFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ExcelTemplateDataReaderFactory();
		}
		return INSTANCE;
	}
	
	private ExcelTemplateDataReaderFactory() {
		//TODO move to a central location where it can be controlled
		float minInflate = 0.007f;
		if(System.getProperty("zip.mininflate") != null) {
			try {
				minInflate = Float.parseFloat(System.getProperty("zip.mininflate"));
			} catch(Throwable th) {
				th.printStackTrace();
			}
		}
		ZipSecureFile.setMinInflateRatio(minInflate);
	}
	
	@Override
	public DataReaderEngine getDataReaderEngine(
			DataFormat format,
			ReadableDataLocation sourceData,
			DataStructureBean dsd,
			DataflowBean dataflowBean,
			ProvisionAgreementBean provisionAgreement,
			DataValidationErrorHandler exceptionHandler) {
		return getDataReaderEngine(format, sourceData, null, dsd, dataflowBean, provisionAgreement, exceptionHandler);
	}

	@Override
	public DataReaderEngine getDataReaderEngine(DataFormat format, ReadableDataLocation sourceData,
												SdmxBeanRetrievalManager retrievalManager,
												DataValidationErrorHandler exceptionHandler) {
		return getDataReaderEngine(format, sourceData, retrievalManager, null, null, null, exceptionHandler);
	}

	private DataReaderEngine getDataReaderEngine(DataFormat format, ReadableDataLocation sourceData,
			SdmxBeanRetrievalManager beanRetrieval,
			DataStructureBean defaultDsd,
			DataflowBean defaultDataflow,
			ProvisionAgreementBean defaultProvisionAgreement,
			DataValidationErrorHandler exceptionHandler) {

	    // Because some of the valid formats are part of mt codebase, cannot test format to determine if an ExcelReportingTemplateReader should be constructed
	    // Instead attempt to do it and return null on error
	    try {
			return new ExcelReportingTemplateReader(sourceData, beanRetrieval, defaultDsd, defaultDataflow, defaultProvisionAgreement, getDataReaderExceptionHandler(exceptionHandler));
	    } catch (Exception e) {
	        return null;
	    }
	}

	@Override
	public String getOverride() {
		return "com.metadatatechnology.fcee.factory.xlsx.XLSDataReaderFactory";
	}

    @Override
    public List<DataErrorCategory> getThrowableErrors() {
        return new ArrayList<>();
    }

    @Override
    public String getId() {
        return "ExcelForm";
    }

    @Override
    public String getName() {
        return "Excel Form";
    }
}
