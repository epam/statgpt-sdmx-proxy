package io.sdmx.fusion.reporttemplate.api.model.pivottable;

import java.util.SortedSet;

import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;

/**
 * Extends the pivot table model by reporting which validation rules are used in the checking table
 */
public interface ICheckingTableModel extends PivotTableModel {

	/**
	 * @return a sorted set of validation rules (sorteded by rule Id)
	 */
	SortedSet<ValidationRuleBean> getValidationRules();
	
}
