package io.sdmx.fusion.reporttemplate.model.reporttemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateDimensionCode;
import io.sdmx.api.sdmx.constants.TEXT_DISPLAY;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.superbeans.hierarchy.HierarchicalCodeSuperBean;
import io.sdmx.utils.core.object.ObjectUtil;

public class ReportingTemplateDimensionCodeImpl implements ReportingTemplateDimensionCode {
	private List<ReportingTemplateDimensionCode> childCodes = new ArrayList<ReportingTemplateDimensionCode>();
	
	private String id;
	private String label;
	private TEXT_DISPLAY textDisplay;
	private boolean hasData;

	/**
	 * Constructor for free text dimensions including the time dimension
	 * @param id
	 */
	public ReportingTemplateDimensionCodeImpl(String id) {
		this.id = id;
		this.label = id;
		this.textDisplay = TEXT_DISPLAY.ID;
		this.hasData = true;
	}

	public ReportingTemplateDimensionCodeImpl(EnumeratedItemBean code, TEXT_DISPLAY textDisplay) {
		this.id = code.getId();
		this.label = code.getName();
		this.textDisplay = textDisplay;
		this.hasData = true;
	}
	
	/**
	 * Build Implicit Hierarchy
	 * @param code
	 * @param validCodes
	 * @param textDisplay
	 * @return
	 */
	public static ReportingTemplateDimensionCode getInstance(CodeBean codeBean, Set<String> validCodes, TEXT_DISPLAY textDisplay) {
		ReportingTemplateDimensionCodeImpl code = new ReportingTemplateDimensionCodeImpl(codeBean, validCodes, textDisplay);
		if(code.isValid()) {
			return code;
		}
		return null;
	}
	
	private ReportingTemplateDimensionCodeImpl(CodeBean codeBean, Set<String> validCodes, TEXT_DISPLAY textDisplay) {
		this.textDisplay = textDisplay;
		this.hasData = validCodes.contains(codeBean.getId());
		this.id = codeBean.getId();
		this.label = codeBean.getName();
		for(CodeBean currentChild : codeBean.getItems()) {
			ReportingTemplateDimensionCodeImpl child = new ReportingTemplateDimensionCodeImpl(currentChild, validCodes, textDisplay);
			if(child.isValid()) {
				childCodes.add(child);
			}
		}
	}
	
	/**
	 * Build Explicit Hierarchy
	 * @param code
	 * @param validCodes
	 * @param testDisplay
	 * @return
	 */
	public static ReportingTemplateDimensionCode getInstance(HierarchicalCodeSuperBean hclSb, String codelistURN, Set<String> validCodes, TEXT_DISPLAY testDisplay) {
		ReportingTemplateDimensionCodeImpl code = new ReportingTemplateDimensionCodeImpl(hclSb, codelistURN, validCodes, testDisplay);
		if(code.isValid()) {
			return code;
		}
		return null;
	}
	
	private ReportingTemplateDimensionCodeImpl(HierarchicalCodeSuperBean hclSb, String codelistURN, Set<String> validCodes, TEXT_DISPLAY textDisplay) {
		this.textDisplay = textDisplay;
		CodeBean code = hclSb.getCode();
		if(code.getMaintainableParent().getUrn().equals(codelistURN)) {
			this.hasData = validCodes.contains(code.getId());
			validCodes.remove(code.getId());
		} else {
			this.hasData = false;
		}
		this.id = code.getId();
		this.label = code.getName();
		for(HierarchicalCodeSuperBean childBean : hclSb.getCodeRefs()) {
			ReportingTemplateDimensionCodeImpl dimCode = new ReportingTemplateDimensionCodeImpl(childBean, codelistURN, validCodes, textDisplay);
			if(dimCode.isValid()) {
				this.childCodes.add(dimCode);
			}
		}
	}

	@Override
	public boolean hasChildren() {
		return ObjectUtil.validCollection(childCodes);
	}
	
	@Override
	public int getDepth() {
		int i=0;
		if(hasChildren()) {
			if(!hasData) {
				i = 1;
			}
			int childDepth = 0;
			for(ReportingTemplateDimensionCode currentChild : getChildren()) {
				int cd = currentChild.getDepth();
				if(cd > childDepth) {
					childDepth = cd;
				}
			}
			i+=childDepth;
		}
		return i;
	}

	private boolean isValid() {
		if(this.hasData) {
			return true;
		}
		for(ReportingTemplateDimensionCode currentChild : getChildren()) {
			if(((ReportingTemplateDimensionCodeImpl)currentChild).isValid()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public List<ReportingTemplateDimensionCode> getChildren() {
		return childCodes;
	}
	
	@Override
	public List<ReportingTemplateDimensionCode> getChildren(boolean immediateWithData) {
		if(immediateWithData == false) {
			return childCodes;
		}
		List<ReportingTemplateDimensionCode> returnList = new ArrayList<>();
		for(ReportingTemplateDimensionCode currentChild : getChildren()) {
			if(currentChild.hasData()) {
				returnList.add(currentChild);
			} else {
				returnList.addAll(currentChild.getChildren(true));
			}
		}
		return returnList;
	}

	@Override
	public String getId() {
		return this.id;
	}

	@Override
	public String getCodeLabel() {
		if(textDisplay == TEXT_DISPLAY.ID) {
			return this.id;
		}
		if(textDisplay == TEXT_DISPLAY.NAME) {
			return this.label;
		}
		return this.id + "|" +this.label;
	}

	@Override
	public boolean hasData() {
		return hasData;
	}

	@Override
	public String toString() {
		return getCodeLabel();
	}
}
