package io.sdmx.fusion.reporttemplate.model.worksheet;

import java.util.HashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;

/**
 * Stores Information about the rows and columns of a worksheet
 */
public class WorksheetIndex {
	private Integer worksheet;  //Number
	private Integer roundDecimals; 
	private String attributeId; //If this worksheet is for an Attribute, otherwise null
	private IURNSingle<? extends IDSDRelatedBean> sRef; //Structure used to read worksheet
	private Map<Integer, String[]> columnKeys = new HashMap<>();  //Index to Partial Key
	private Map<Integer, String[]> rowKeys = new HashMap<>();     //Index to Partial Key
	private Map<String, String> fixedValues = new HashMap<>();     //AttrId to Attr Value
	private Map<Integer, String> variableDimensions = new HashMap<>();  //DimId to Cell Address
	
	private String[] variableAttributes; //In the case that there is a stand alone attribute table where the attributes are the 

	private Integer obsAttributeTableStart;
	private Integer seriesAttributeTableStart;
	private Map<String, Integer> noHeaderColMapObsTable = new HashMap<>();
	private Map<String, Integer> noHeaderColMapObsAttTable = new HashMap<>();
	private Map<String, Integer> noHeaderColMapSeriesAttTable = new HashMap<>();
	
	private XSSFSheet xlsxWorksheet;
	
	public WorksheetIndex(Integer worksheet) {
		this.worksheet = worksheet;
	}
	
	public XSSFSheet getXlsxWorksheet() {
		return xlsxWorksheet;
	}

	public void setXlsxWorksheet(XSSFSheet xlsxWorksheet) {
		this.xlsxWorksheet = xlsxWorksheet;
	}

	public Map<Integer, String> getVariableDimensions() {
		return variableDimensions;
	}

	public void addVariableDimension(Integer dimIdx, String cellAddress) {
		this.variableDimensions.put(dimIdx, cellAddress);
	}

	public Integer getRoundDecimals() {
		return roundDecimals;
	}

	public void setRoundDecimals(Integer roundDecimals) {
		this.roundDecimals = roundDecimals;
	}

	public Integer getObsAttributeTableStart() {
		return obsAttributeTableStart;
	}

	public void setObsAttributeTableStart(Integer attributeTableStart) {
		this.obsAttributeTableStart = attributeTableStart;
	}
	
	public Integer getSeriesAttributeTableStart() {
		return seriesAttributeTableStart;
	}

	public void setSeriesAttributeTableStart(Integer attributeTableStart) {
		this.seriesAttributeTableStart = attributeTableStart;
	}

	public Map<String, Integer> getNoHeaderColMapObsTable() {
		return noHeaderColMapObsTable;
	}

	public void setNoHeaderColMapObsTable(Map<String, Integer> noHeaderColMapObsTable) {
		this.noHeaderColMapObsTable = noHeaderColMapObsTable;
	}
	
	public void addNoHeaderColMapObsTable(String attId, Integer colIdx) {
		noHeaderColMapObsTable.put(attId, colIdx);
	}

	public Map<String, Integer> getNoHeaderColMapObsAttTable() {
		return noHeaderColMapObsAttTable;
	}
	
	public void addNoHeaderColMapObsAttTable(String attId, Integer colIdx) {
		noHeaderColMapObsAttTable.put(attId, colIdx);
	}

	public void setNoHeaderColMapObsAttTable(Map<String, Integer> noHeaderColMapObsAttTable) {
		this.noHeaderColMapObsAttTable = noHeaderColMapObsAttTable;
	}

	public Map<String, Integer> getNoHeaderColMapSeriesAttTable() {
		return noHeaderColMapSeriesAttTable;
	}
	
	public void addNoHeaderColMapSeriesAttTable(String attId, Integer colIdx) {
		noHeaderColMapSeriesAttTable.put(attId, colIdx);
	}

	public void setNoHeaderColMapSeriesAttTable(Map<String, Integer> noHeaderColMapObsAttTable) {
		this.noHeaderColMapSeriesAttTable = noHeaderColMapObsAttTable;
	}
	
	public String[] getVariableAttributes() {
		return variableAttributes;
	}

	public void setVariableAttributes(String[] variableAttributes) {
		this.variableAttributes = variableAttributes;
	}

	public Integer getWorksheet() {
		return worksheet;
	}
	public String getAttributeId() {
		return attributeId;
	}
	public void setAttributeId(String attributeId) {
		this.attributeId = attributeId;
	}
	public IURNSingle<? extends IDSDRelatedBean> getsRef() {
		return sRef;
	}
	public void setsRef(IURNSingle<? extends IDSDRelatedBean> sRef) {
		this.sRef = sRef;
	}

	public Map<Integer, String[]> getColumnKeys() {
		return columnKeys;
	}
	
	public void addColumnKey(Integer col, String[] key) {
		this.columnKeys.put(col, key);
	}
	
	public Map<Integer, String[]> getRowKeys() {
		return rowKeys;
	}

	public void addRowKey(Integer row, String[] key) {
		this.rowKeys.put(row, key);
	}

	public Map<String, String> getFixedValues() {
		return fixedValues;
	}

	public void addFixedValue(String id, String value) {
		this.fixedValues.put(id, value);
	}
}
