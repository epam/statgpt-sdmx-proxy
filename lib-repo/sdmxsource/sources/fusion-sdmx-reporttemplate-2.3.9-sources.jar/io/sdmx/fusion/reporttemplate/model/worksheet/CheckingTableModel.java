package io.sdmx.fusion.reporttemplate.model.worksheet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.CELL_TYPE;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.ICellFormula;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.ICheckingTableModel;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.ITableCellChecking;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.PivotTableModel;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.TableCell;
import io.sdmx.fusion.reporttemplate.api.model.pivottable.TableRow;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateSeries;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateWorksheet;
import io.sdmx.utils.sdmx.comparator.IdentifiableComparator;
import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.object.SeriesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CheckingTableModel implements ICheckingTableModel {
	private static final Logger LOG = LoggerFactory.getLogger(CheckingTableModel.class);
	private PivotTableModel obsTable;
	private List<TableRow> tRows;
	private SortedSet<ValidationRuleBean> validationRules = new TreeSet<>(IdentifiableComparator.INSTANCE);
	
	/**
	 * @param obsTable build checking table from the observation table model
	 */
	public CheckingTableModel(PivotTableModel obsTable) {
		this.obsTable = obsTable;

		tRows = new ArrayList<>();

		for(TableRow tr : obsTable.getTableRows()) {
			tRows.add(new CheckingTableRow(tr));
		}
		tRows = Collections.unmodifiableList(tRows);
		validationRules = Collections.unmodifiableSortedSet(validationRules);
	}
	
	

	@Override
	public SortedSet<ValidationRuleBean> getValidationRules() {
		return validationRules;
	}

	@Override
	public boolean hasHeaderDimensions() {
		return obsTable.hasHeaderDimensions();
	}

	@Override
	public boolean hasRowDimensions() {
		return obsTable.hasRowDimensions();
	}

	@Override
	public TABLE_TYPE getTableType() {
		return TABLE_TYPE.CHECKING;
	}

	@Override
	public String[] getAttributeIds() {
		return new String[]{};
	}

	@Override
	public int[] getColumnWidths() {
		return obsTable.getColumnWidths();
	}

	@Override
	public List<TableRow> getTableRows() {
		return tRows;
	}

	@Override
	public TableRow addTableRow(boolean isHeaderRow) {
		return null;
	}

	private class CheckingTableRow implements TableRow {
		private List<TableCell> tableCells = new ArrayList<>();
		private boolean isTableHead;
		private boolean isPresentational;


		public CheckingTableRow(TableRow basedOn) {
			this.isTableHead = basedOn.isTableHead();
			for(TableCell td : basedOn.getTableCells()) {
				tableCells.add(new CheckingTableCell(td));
			}
			this.tableCells = Collections.unmodifiableList(tableCells);
		}
		
		@Override
		public void setPresentational(boolean presentational) {
			this.isPresentational = presentational;
		}

		@Override
		public boolean isPresentational() {
			return this.isPresentational;
		}

		@Override
		public boolean isTableHead() {
			return isTableHead;
		}

		@Override
		public String[] getRowKey() {
			return null;
		}

		@Override
		public TableCell getCellAtIndex(int idx) {
			return tableCells.get(idx);
		}

		@Override
		public List<TableCell> getTableCells() {
			return tableCells;
		}

		@Override
		public TableCell addHeaderTitle(String value, int colspan, int rowspan) {
			throw new SdmxNotImplementedException("CheckingTableRow.addHeaderTitle");
		}

		@Override
		public TableCell addHeaderColValue(String value, int colspan, int rowspan, String[] partialKey) {
			throw new SdmxNotImplementedException("CheckingTableRow.addHeaderColValue");
		}

		@Override
		public TableCell addHeaderRowValue(String value, int colspan, int rowspan, String[] partialKey) {
			throw new SdmxNotImplementedException("CheckingTableRow.addHeaderRowValue");
		}

		@Override
		public TableCell addObsCell(ReportingTemplateWorksheet series) {
			throw new SdmxNotImplementedException("CheckingTableRow.addObsCell");
		}

		@Override
		public TableCell addObsCell(String value) {
			throw new SdmxNotImplementedException("CheckingTableRow.addObsCell");
		}

		@Override
		public TableCell addObsAttribute(ReportingTemplateWorksheet ws, ReportingTemplateSeries series, String attributeId, int colspan) {
			throw new SdmxNotImplementedException("CheckingTableRow.addObsAttribute");
		}
	}

	private class ExpressionBuilder {
		StringBuilder sb = new StringBuilder();
		List<TableCell> expressionInputs;
		private String expression;
		private String finalExpression;

		int ax;

		/**
		 * Starts the expression, which will wrap any expression built with an If inputs are not empty check
		 * 
		 * IF(AND(A1<>"",OR(A2<>"",A3<>""), [THIS IS THE EXPRESSION THE USER WILL BUILD], #)
		 *  
		 * @param check
		 */
		public ExpressionBuilder(TableCell basedOn, int offset, ITableCellChecking check) {
			this.expressionInputs = new ArrayList<TableCell>(check.getExpressionInputs());
			
			//ax is the total size of the expressions in this input, plus the offset due to previous expressions
			//existing in other formula
			this.ax = expressionInputs.size()+offset;
			
			String exprssion = check.getExpression();
			if(offset > 0) {
				//Rewrite a0+a1 if there are already inputs
				int inputLength = expressionInputs.size()-1;
				for(int i=inputLength; i >= 0; i--) {
					String toRewrite = "a"+i;
					String rewriteTo = "a"+(i+offset);
					exprssion= exprssion.replace(toRewrite, rewriteTo);
				}
			}
			
			this.expression = "("+exprssion+")";

			//First condition, if source cell is not empty and any of the input cells are not empty
			//IF(AND(A1<>"",OR(A2<>"",A3<>""), //then 
			this.appendString("IF(AND(?<>[],OR(");
			this.writeArgument(basedOn);
			String concat = "";
			for(TableCell expInput : check.getExpressionInputs()) {
				if(expInput != null) {
					this.appendString(concat+"?<>[]");
					concat = ",";
					this.writeArgument(expInput);
				}
			}
			this.appendString(")),");
		}

		public void appendString(String str, TableCell...cells) {
			sb.append(str);
			if(cells != null) {
				for(TableCell cell : cells) {
					writeArgument(cell);
				}
			}
		}
		
		public void writeArgument(TableCell cell) {
			expressionInputs.add(cell);
		}
		
		public void finish(String notCheckedPlaceholder) {
			//Complete first if statement
			this.appendString(","+notCheckedPlaceholder+")");
			finalExpression = sb.toString();
			while(finalExpression.indexOf("?")>0) {
				String replaceWith = "a"+ax;
				finalExpression = finalExpression.replaceFirst("\\?", replaceWith);
				ax++;
			}
			finalExpression = finalExpression.replace("[EXP]", expression);
			finalExpression = finalExpression.replace("[]", "\"\"");
			LOG.debug("Checking Expression: "+finalExpression);
		}

		public String getExpression(String notCheckedPlaceholder) {
			if(finalExpression == null) {
				finish(notCheckedPlaceholder);
			}
			return finalExpression;
		}
	}

	private class CheckingTableCell implements TableCell {
		private TableCell basedOn;
		private ICellFormula check;
		
		private CheckingTableCell(TableCell basedOn) {
			this.basedOn = basedOn;
			List<ITableCellChecking> checkingInputs = basedOn.getCheckingTableInputs();
			if(ObjectUtil.validCollection(checkingInputs)) {
				if(LOG.isDebugEnabled()) {
					String celKey = SeriesUtil.toSeriesKey(basedOn.getCellColKey());
					String rowKey = SeriesUtil.toSeriesKey(basedOn.getCellRowKey());
					LOG.debug("Checking Expression for cell: '"+celKey+"' row  key '"+rowKey+"'");
				}
				String expression = null;
				List<TableCell> expressionInputs = new ArrayList<>();
				int checkNum = 0;
				String passPlaceholder = "";
				String notCheckedPlaceholder = "";
				for(ITableCellChecking currentCheck : checkingInputs) {
					validationRules.add(currentCheck.getUnderlyingRule());
					String errorCode = "\""+currentCheck.getUnderlyingRule().getId()+"\"";
					EQUALITY equality = currentCheck.getExpressionEquality();
					ExpressionBuilder expBuilder = new ExpressionBuilder(basedOn, expressionInputs.size(), currentCheck);
					String newPassPlaceholder = "#"+checkNum;
					String newNotCheckedPlaceholder = "##"+checkNum;
					checkNum++;
					switch(equality) {
					case EQUAL:
						expBuilder.appendString("IF(?-[EXP]=0,"+newPassPlaceholder+",?-[EXP])", basedOn, basedOn); 
						break;
					case NOT_EQUAL :
						//First condition, if source cell is not empty and any of the input cells are not empty
						expBuilder.appendString("IF(?-[EXP]=0,"+errorCode+","+newPassPlaceholder+")", basedOn);
						break;
					case GT:
					case GT_EQUAL:
					case LT:
					case LT_EQUAL:
						expBuilder.appendString("IF(?"+equality+"[EXP],"+newPassPlaceholder+","+errorCode+")", basedOn);
						break;
					}
					String builtExpression = expBuilder.getExpression(newNotCheckedPlaceholder);
					if(expression != null) {
						expression = expression.replaceAll(notCheckedPlaceholder, builtExpression);
						expression = expression.replaceAll(passPlaceholder, builtExpression);
					} else {
						expression = builtExpression;
					}
					passPlaceholder = newPassPlaceholder;
					notCheckedPlaceholder = newNotCheckedPlaceholder;
					expressionInputs.addAll(expBuilder.expressionInputs);
				}
				expression = expression.replaceAll(notCheckedPlaceholder, "0");
				expression = expression.replaceAll(passPlaceholder, "0");
				check = new TableCellFormula(expression, expressionInputs);
			}
		}

		@Override
		public int getCellIndex() {
			return basedOn.getCellIndex();
		}

		@Override
		public int getRowIndex() {
			return basedOn.getRowIndex();
		}

		@Override
		public int getColspan() {
			return basedOn.getColspan();
		}

		@Override
		public int getRowspan() {
			return basedOn.getRowspan();
		}

		@Override
		public CELL_TYPE getCellType() {
			return basedOn.getCellType();
		}

		@Override
		public String getCellColour() {
			return basedOn.getCellColour();
		}

		@Override
		public boolean isHeaderCell() {
			return basedOn.isHeaderCell();
		}

		@Override
		public String getCellId() {
			return basedOn.getCellId();
		}

		@Override
		public String getCellValue() {
			//For writing a workbook that is populated with data, do not include the observation values in the checking table
			if(this.getCellType() == CELL_TYPE.OBSERVATION || this.getCellType() == CELL_TYPE.OBSERVATION_ATTRIBUTE) {
				return null;
			}
			return basedOn.getCellValue();
		}

		@Override
		public String getAttributeId() {
			return basedOn.getAttributeId();
		}

		@Override
		public String[] getCellSeriesKey() {
			return basedOn.getCellSeriesKey();
		}

		@Override
		public String[] getCellColKey() {
			return basedOn.getCellColKey();
		}

		@Override
		public String[] getCellRowKey() {
			return basedOn.getCellRowKey();
		}
		
		@Override
		public List<ITableCellChecking> getCheckingTableInputs() {
			return Collections.emptyList();
		}

		@Override
		public ICellFormula getCellFormula() {
			return check;
		}
	}

}
