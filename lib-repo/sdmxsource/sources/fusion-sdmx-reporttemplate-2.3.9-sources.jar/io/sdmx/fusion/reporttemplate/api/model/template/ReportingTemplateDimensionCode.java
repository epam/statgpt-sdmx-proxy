package io.sdmx.fusion.reporttemplate.api.model.template;

import java.util.List;

/**
 * Represents a Code in the reporting template
 */
public interface ReportingTemplateDimensionCode {

	/**
	 * Returns true if this code has Children
	 * @return
	 */
	boolean hasChildren();
	
	/**
	 * Returns the depth of this code how many levels there are.  0 indicates only this level - and is the minimum number returned from this method call
	 * @return
	 */
	int getDepth();
	
	/**
	 * Returns the child codes, or an empty array if there are no codes
	 * @return
	 */
	List<ReportingTemplateDimensionCode> getChildren();
	
	/**
	 * Returns the child codes, or an empty array if there are no codes
	 * @param immediateWithData if true then only child codes with data will be returned, these will be the first child codes that has data
	 * @return
	 */
	List<ReportingTemplateDimensionCode> getChildren(boolean immediateWithData);

	/**
	 * Returns the id for the value (CodeId or if Uncoded/Time then just the same as the Label)
	 * @return
	 */
	String getId();
	
	/**
	 * If show id, this will be the code id, if show id=false then this will be the code name
	 * @return
	 */
	String getCodeLabel();
	
	/**
	 * Returns true if this code is has Data only - no data in dataset, but child codes that do
	 * @return
	 */
	boolean hasData();
	
}

