package io.sdmx.fusion.reporttemplate.api.model.template;

import java.util.List;
import java.util.Set;

/**
 * A wrapper around data series providing useful functions such as aggregation
 */
public interface ReportingTemplateSeries {

	/**
	 * Returns a count of the number of series in this container
	 * @return
	 */
	int getSeriesCount();
	
	/**
	 * Aggregate the series keeping only the dimensions with the given indexes, for example
	 * 
	 * FREQ, REF_AREA, SEX
	 * 
	 * [A, UK, M]
	 * [A, UK, F]
	 * [A, FR, M]
	 * [A, FR, F]
	 * [M, UK, M]
	 * [M, UK, F]
	 * [M, FR, M]
	 * [M, FR, F]
	 * 
	 * aggregate({1,2})
	 * 
	 * Becomes:
	 * [null, UK, M]
	 * [null, UK, F]
	 * [null, FR, M]
	 * [null, FR, F]
	 * 
	 * @return a list of series
	 */
	List<String[]> aggregate(int[] dimIdx);
	
	/**
	 * Returns true if the series exists, false otherwise
	 * @param series
	 * @return
	 */
	boolean hasData(String[] series);
	
	/**
	 * Returns a set of matched series based on a wildcarded expression, a wildcarded expression must include * to denote wildcarded value, for example
	 * 
	 * A:B:*:E
	 * 
	 * @param wildcarded
	 * @return set of matches or an empty set if no matches are found
	 */
	Set<String> matches(String wildcarded);
	
}
