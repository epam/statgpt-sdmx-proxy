package io.sdmx.fusion.reporttemplate.application;

import io.sdmx.api.application.IFusionModule;
import io.sdmx.fusion.reporttemplate.engine.DeferredReportingTemplateReaderEngine;
import io.sdmx.fusion.reporttemplate.factory.ExcelTemplateDataReaderFactory;
import io.sdmx.fusion.reporttemplate.factory.ReportTemplateDataFormatFactory;

public class ReportingTemplateModule implements IFusionModule {

	public static void register() {
		ExcelTemplateDataReaderFactory.registerInstance();
		ReportTemplateDataFormatFactory.registerInstance();
		
		//Deferred
		DeferredReportingTemplateReaderEngine.getInstance();
	}

}
