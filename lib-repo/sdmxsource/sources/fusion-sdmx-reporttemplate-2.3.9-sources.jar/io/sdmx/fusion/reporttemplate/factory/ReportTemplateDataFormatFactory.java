package io.sdmx.fusion.reporttemplate.factory;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.IVNDHeader;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.core.sdmx.api.factory.data.DataFormatFactory;
import io.sdmx.fusion.reporttemplate.model.format.ReportTemplateDataFormat;
import io.sdmx.fusion.reporttemplate.util.ReportTemplateUtil;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.sdmx.structure.UrnUtil;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * Returns a ReportTemplateDataFormat if the format parameter or appicationVnd match the expected value.
 * Switch included for outputting a 'full workbook'
 * @see ReportTemplateDataFormat.isIncludeFullWorkbook
 *
 */
public class ReportTemplateDataFormatFactory  implements DataFormatFactory {

	private static ReportTemplateDataFormatFactory INSTANCE;
	
	private Map<String, FormatDetails> suppoprtedFormats = new HashMap<>();

	public static ReportTemplateDataFormatFactory registerInstance() {
		FusionBeanStore.registerInstance(getInstance());
		return getInstance();
	}
	
	public static ReportTemplateDataFormatFactory getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ReportTemplateDataFormatFactory();
		}
		return INSTANCE;
	}
	
	private ReportTemplateDataFormatFactory() {
		ReportTemplateDataFormat format = ReportTemplateDataFormat.getInstance(false);
		for(String acceptHeader : format.getFormatDetails().getAcceptHeaders()) {
			suppoprtedFormats.put(acceptHeader, format.getFormatDetails());
		}

		suppoprtedFormats = Collections.unmodifiableMap(suppoprtedFormats);
	}
	
	@Override
	public Map<String, FormatDetails> getSupportedFormats() {
		return suppoprtedFormats;
	}

	@Override
	public Class<DataFormat> getFormatClass() {
		return DataFormat.class;
	}

	@Override
	public DataFormat getFormat(Request request, IVNDHeader vndHeader) {
		if(vndHeader != null) {
			String appicationVnd = vndHeader.getVnd();
			
			String[] splitOnPlus = appicationVnd.split("\\+");
			String[] splitOnDot = splitOnPlus[0].split("\\.", 2);
			if(splitOnDot[0].equalsIgnoreCase("reporttemplate")) {
				boolean isPartial = splitOnPlus.length > 1 && splitOnPlus[1].equalsIgnoreCase("partial");
				String dpRefArg = vndHeader.getParameterValue("DATA_PROVIDER");  //Expects Agency.providerId or simply provider Id if agency is same as reporting template
				if(splitOnDot.length > 1 || dpRefArg != null) {
					IMaintainableRef templateRef = null;
					if(splitOnDot.length > 1) {
						templateRef = UrnUtil.getMaintainableRef(splitOnDot[1]);
					}
					IURNAbsolute<DataProviderBean> dpRef = null;
					if(dpRefArg != null) {
						String[] split = dpRefArg.split("\\.");
						String providerAgencyId = AgencyBean.DEFAULT_AGENCY;
						String providerId = null;
						if(split.length == 1) {
							providerId = split[0];
						} else {
							providerAgencyId = split[0];
							providerId = split[1];
						}
						dpRef = URN.builder().agencyId(providerAgencyId).identifableId(providerId).buildAbsolute(DataProviderBean.class);
					}
					return ReportTemplateDataFormat.getInstance(isPartial==false, toURN(templateRef), dpRef);
				}
				return ReportTemplateDataFormat.getInstance(isPartial==false);
			}
		}
		return null;
	}

	@Override
	public DataFormat getFormat(String format, Request request) {
		if(request == null) {
			return null;
		}
		if (format == null) {
			return null;
		}
		if (format.startsWith("reporttemplate")) {
			String partialStr = request.getParameter("partial");
			boolean isPartial = partialStr != null && partialStr.equalsIgnoreCase("true");
			
			String[] splitOnDot = format.split("\\.", 2);
			if(splitOnDot.length > 1) {
				IMaintainableRef templateRef = UrnUtil.getMaintainableRef(splitOnDot[1]);
				return ReportTemplateDataFormat.getInstance(isPartial==false, toURN(templateRef), null);
			}
			return ReportTemplateDataFormat.getInstance(isPartial==false);
		}
		return null;
	}
	
	private IURNSingle<ReportingTemplateBean> toURN(IMaintainableRef templateRef) {
		if(templateRef == null) {
			return null;
		}
		return URN.builder().maint(templateRef).buildSingle(ReportingTemplateBean.class);
	}

	@Override
	public DataFormat getDataFormat(ReadableDataLocation sourceData) {
		if(ReportTemplateUtil.isReportingTemplate(sourceData)) {
			return ReportTemplateDataFormat.getInstance(true);  //we don't know if it is a full or partial workbook
		}
		return null;
	}
}
