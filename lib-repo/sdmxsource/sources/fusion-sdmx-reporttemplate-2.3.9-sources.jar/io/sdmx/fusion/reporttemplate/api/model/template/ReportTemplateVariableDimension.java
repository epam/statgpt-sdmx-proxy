package io.sdmx.fusion.reporttemplate.api.model.template;

import java.util.List;

import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;

/**
 * Defines a dimension which is outside of the main table, the user is able to select a value from a drop down list of valid values
 */
public interface ReportTemplateVariableDimension {
	
	/**
	 * Provides information on the dimension id, name, and concept
	 * @return
	 */
	ReportingTemplateComponent getReportingTemplateComponent();

	/**
	 * Returns the list of valid codes for the dimension
	 * @return
	 */
	List<EnumeratedItemBean> getValidCodes();
}
