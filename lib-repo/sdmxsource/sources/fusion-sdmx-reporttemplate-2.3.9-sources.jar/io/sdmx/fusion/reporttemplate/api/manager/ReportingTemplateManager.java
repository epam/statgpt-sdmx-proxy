package io.sdmx.fusion.reporttemplate.api.manager;

import java.io.OutputStream;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;

/**
 * Manages retrieval and persistence of reporting templates
 */
public interface ReportingTemplateManager {
	/**
	 * Returns all the reporting templates broken down by data provider, data providers in the returned map are based on
	 * by the currently authenticated user:
	 * if admin - all providers in map
	 * if agency - only providers for agency are in map
	 * if data provider - only the data provider(s) that user belongs to
	 * @return
	 */
	Map<DataProviderBean, Set<ReportingTemplateBean>> getReportingTemplatesByProvider();
	
	/**
	 * Returns data providers for each template, if no providers exist for a template the set will be empty
	 * @return
	 */
	Map<ReportingTemplateBean, Set<DataProviderBean>> getProvidersForTemplate();

	
	/**
	 * Builds a Excel document and writes it to the output stream, based on the report template, data provider, reporting period (not required for non-time series data)
	 *  
	 * @param templateRef - Reference to the Report Template to use, if version information is missing, the latest is assumed
	 * @param providerRef - Reference to the Data Provider the Excel Template is being generated for
	 * @param periodFrom - Data Reporting Period - not required for non-time series data
	 * @param periodTo - Data Reporting Period - not required if exporting a single time period report
	 * @param out - the output stream to write to
	 */
	void buildExcelWorkbook(IMaintainableRef templateRef, IURNSingle<DataProviderBean> providerRef, String periodFrom,  String periodTo, OutputStream out);
	
	/**
	 * Returns a Set of codes that state which frequency codes are limited for the Reporting Template and Data Provider specified.
	 * Note that this method only works on a "standard" frequency codelist (with codes such as A, Q and M) and on Dimensions which must be called FREQ.
	 * @param reportingTemplateUrn
	 * @param dataProviderUrn
	 * @return an empty Set if there are no restrictions;
	 */
	Set<String> getValidFrequenciesForTemplate(String reportingTemplateUrn, String dataProviderUrn);
}