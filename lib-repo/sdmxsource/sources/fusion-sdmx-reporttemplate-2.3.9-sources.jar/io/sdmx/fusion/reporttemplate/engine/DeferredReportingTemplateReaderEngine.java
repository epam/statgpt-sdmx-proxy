package io.sdmx.fusion.reporttemplate.engine;

import io.sdmx.api.io.IDeferredLoader;
import io.sdmx.api.sdmx.model.beans.base.IMaintainableBeanDeferred;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.deferred.IDeferredBeanDefinition;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.core.sdmx.engine.structure.deferred.AbstractDeferredStructureReaderEngine;
import io.sdmx.im.beans.reporting.ReportingTemplateBeanDeferred;
import io.sdmx.utils.core.application.FusionBeanStore;

/**
 * Converts {@link IDeferredBeanDefinition} into {@link ReportingTemplateBeanDeferred}
 */
public class DeferredReportingTemplateReaderEngine extends AbstractDeferredStructureReaderEngine<ReportingTemplateBean> {
    private static DeferredReportingTemplateReaderEngine INSTANCE;
    
    private DeferredReportingTemplateReaderEngine() {
        super(ReportingTemplateBean.class);
    }
    
    public static DeferredReportingTemplateReaderEngine getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new DeferredReportingTemplateReaderEngine();
            FusionBeanStore.registerInstance(INSTANCE);
        }
        return INSTANCE;
    }
    

    @Override
    protected IMaintainableBeanDeferred<ReportingTemplateBean> readInternal(IDeferredBeanDefinition bean, IDeferredLoader<MaintainableBean> loader) {
        return new ReportingTemplateBeanDeferred(bean, loader);
    }

}
