package io.sdmx.fusion.reporttemplate.model.reporttemplate;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateSeries;
import io.sdmx.utils.core.object.SeriesUtil;

public class ReportingTemplateSeriesImpl implements ReportingTemplateSeries {
	private Set<String[]> series;
	private int dimLength = -1;
	private Set<String> serieskeys = new HashSet<String>();
	private Set<String> obskeys = new HashSet<String>();
	private Set<Integer> varaibleDimensions;
	
	/**
	 * @param series each series may include the time dimension, example [A, S, 5A, 4B, F, B, A, A, LC1, A, 5J, 2008]
	 * @param varaibleDimensions
	 */
	public ReportingTemplateSeriesImpl(Set<String[]> series, boolean istimeIncluded, Set<Integer> varaibleDimensions) {
		if(series == null || series.size() == 0) {
			throw new IllegalArgumentException("Can not build ReportingTemplateSeries, Series can not be empty");
		}
		this.series = series;
		this.varaibleDimensions = varaibleDimensions;
		for(String[] currentSeries : series) {
			if(dimLength == -1) {
				dimLength = currentSeries.length;
			} else if(dimLength != currentSeries.length) {
				throw new IllegalArgumentException("Can not build ReportingTemplateSeries, Series can not have differing lengths");
			}
			String seriesKey = SeriesUtil.toSeriesKey(currentSeries);
			obskeys.add(seriesKey);
		}
		if(istimeIncluded) {
			int toIndex = dimLength -1;
			for(String[] currentSeries : series) {
				String seriesKey = SeriesUtil.toSeriesKey(currentSeries, toIndex);
				serieskeys.add(seriesKey);
			}
		} else {
			serieskeys = obskeys;
		}
	}
	
	

	@Override
	public List<String[]> aggregate(int[] dimIdx) {
		Set<String> aggregated = new HashSet<String>();
		StringBuilder sb;
		String concat = "";
		for(String[] currentSeries : series) {
			sb = new StringBuilder();
			concat = "";
			for(int i : dimIdx) {
				sb.append(concat + currentSeries[i]);
				concat = ",";
			}
			aggregated.add(sb.toString());
		}
		List<String[]> returnList = new ArrayList<String[]>();
		for(String currentAggregated : aggregated) {
			returnList.add(currentAggregated.split(","));
		}
		return returnList;
	}

	@Override
	public boolean hasData(String[] series) {
		if(series == null) {
			return false;
		}
		String seriesKey = SeriesUtil.toSeriesKey(series, -1, "", varaibleDimensions);
		if(series.length == dimLength) {
			return obskeys.contains(seriesKey);
		}
		return serieskeys.contains(seriesKey);
	}

	@Override
	public Set<String> matches(String wildcarded) {
		int keySize = SeriesUtil.splitKey(wildcarded).length;
		if(keySize < this.dimLength) {
			for(int i=0; i < (this.dimLength-keySize); i++) {
				wildcarded+=":";
			}
		}
		Pattern p =  SeriesUtil.wildcardSeriesToPattern(wildcarded);
		
		Set<String> returnSet = new HashSet<String>();
		for(String series : obskeys) {
			if (p.matcher(series).matches()){
				returnSet.add(series);
			}
		}
		return returnSet;
	}

	@Override
	public int getSeriesCount() {
		return obskeys.size();
	}
}
