package io.sdmx.fusion.reporttemplate.model.reporttemplate;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.sdmx.exception.SdmxReferenceException;
import io.sdmx.api.sdmx.manager.structure.ConstraintRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.fusion.reporttemplate.api.model.template.IReportingTemplateInstructionSheet;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportTemplateVariableDimension;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplate;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateWorksheet;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.AgencyUtil;
import io.sdmx.utils.sdmx.xs.URN;
import io.sdmx.utils.xlsx.api.model.ICellStyle;
import io.sdmx.utils.xlsx.model.FusionCellStyle;

public class ReportingTemplateImpl implements ReportingTemplate {
	private static final Logger LOG = LoggerFactory.getLogger(ReportingTemplateImpl.class);

	private IReportingTemplateInstructionSheet instructionSheet;
	private List<ReportingTemplateWorksheet> worksheets = new ArrayList<>();
	private ReportingTemplateBean bean;
	private AgencyBean agency;
	private DataProviderBean provider;
	private SdmxDate reportingPeriod;
	private Set<ReportTemplateVariableDimension> globalVariableDimensions;


	public ReportingTemplateImpl(ReportingTemplateBean bean,
			SdmxBeanRetrievalManager beanRetrievalManager,
			SdmxSuperBeanRetrievalManager sbBeanRetrievalManager,
			ConstraintRetrievalManager constraintRetrievalManager,
			IURNSingle<DataProviderBean> providerRef,
			SdmxPeriod reportingPeriod,
			int maxObs) {
		this(bean, beanRetrievalManager, sbBeanRetrievalManager, constraintRetrievalManager, providerRef, null, reportingPeriod, maxObs);
	}

	/**
	 * 
	 * @param bean
	 * @param beanRetrievalManager
	 * @param sbBeanRetrievalManager
	 * @param constraintRetrievalManager
	 * @param providerRef
	 * @param observationsForFlow if there are observations to output in table
	 * @param reportingPeriod - not required if observationsForFlow is provided
	 * @param maxObs
	 */
	public ReportingTemplateImpl(ReportingTemplateBean bean,
			SdmxBeanRetrievalManager beanRetrievalManager,
			SdmxSuperBeanRetrievalManager sbBeanRetrievalManager,
			ConstraintRetrievalManager constraintRetrievalManager,
			IURNSingle<DataProviderBean> providerRef,
			Map<IURNMaintainable<DataflowBean>, List<Observation>> observationsForFlow,
			SdmxPeriod reportingPeriod,
			int maxObs) {
		this.bean = bean;
		if(bean.getInstructionSheet() != null) {
			ICellStyle backgroundStyle = new FusionCellStyle("bg");
			backgroundStyle.setHexColour("#FFFFCC");
			backgroundStyle.setWrapText(true);
			//			IFontStyle font = new FontStyle(FONT_COLOUR.WHITE, 20, true);
			//			font.setFontName("Segoe UI");
			//			backgroundStyle.setFontStyle(font);
			this.instructionSheet = new ReportingTemplateInstructionSheet(bean.getInstructionSheet(), backgroundStyle);
		}
		Map<String, ProvisionAgreementBean> flowToProvMap = null;
		if(providerRef != null) {
			flowToProvMap = new HashMap<>();
			for(ProvisionAgreementBean prov : beanRetrievalManager.getMaintainableBeans(URN.build(ProvisionAgreementBean.class))) {
				if(providerRef.isMatch(prov.getDataproviderRef().getReference())) {
					flowToProvMap.put(prov.getStructureUseage().getTargetUrn(), prov);
				}
			}
			provider = beanRetrievalManager.getBean(providerRef);
		}
		if(providerRef != null && provider == null) {
			throw new SdmxReferenceException(providerRef);
		}
		LOG.info("Create Report Template for Provider:"+provider+" and report period"+reportingPeriod);
		List<String> timePeriods = new ArrayList<>();
		Map<IURNSingle<DataflowBean>, List<String>> periodsForFlow = null;
		Map<IURNSingle<DataflowBean>, TIME_FORMAT> tfForFlow = null;
		//If there is a from period and no to period, then assume a single reporting period
		TIME_FORMAT tf = null;
		if(reportingPeriod != null) {
			tf = reportingPeriod.getStartPeriod().getTimeFormatOfDate();
			if(reportingPeriod.hasEndPeriod() == false || reportingPeriod.getEndPeriod().equals(reportingPeriod.getStartPeriod())) {
				//Singular period, on first page of workbook
				this.reportingPeriod = reportingPeriod.getStartPeriod();
			} else {
				timePeriods = DateUtil.createTimeValues(reportingPeriod.getStartPeriod().getDate(), reportingPeriod.getEndPeriod().getDate(), reportingPeriod.getStartPeriod().getTimeFormatOfDate());
			}
		} else if(observationsForFlow != null) {
			periodsForFlow = new HashMap<>();
			tfForFlow = new HashMap<>();
			boolean isSinglePeriod = true;
			String singlePeriod = null;
			for(IURNSingle<DataflowBean> flowRef : observationsForFlow.keySet()) {
				List<Observation> obs = observationsForFlow.get(flowRef);
				if(ObjectUtil.validCollection(obs)) {
					obs.sort(new Comparator<Observation>() {
						@Override
						public int compare(Observation o1, Observation o2) {
							return o1.getSdmxObsTime().compareTo(o2.getSdmxObsTime());
						}
					});
					Observation firstPeriod = obs.get(0);
					Observation lastPeriod = obs.get(obs.size() -1);

					List<String> flowTimePeriods = new ArrayList<>();
					String startPeriod = firstPeriod.getDimensionValue();
					String endPeriod = lastPeriod.getDimensionValue();
					if(startPeriod.equals(endPeriod)) {
						flowTimePeriods.add(startPeriod);
						if(singlePeriod == null) {
							singlePeriod = startPeriod;
						} else if(!singlePeriod.equals(startPeriod)) {
							isSinglePeriod = false;
						}
					} else {
						isSinglePeriod = false;
						flowTimePeriods = DateUtil.createTimeValues(firstPeriod.getSdmxObsTime().getDate(), lastPeriod.getSdmxObsTime().getDate(), lastPeriod.getSdmxObsTime().getTimeFormatOfDate());
					}
					tfForFlow.put(flowRef, firstPeriod.getSdmxObsTime().getTimeFormatOfDate());
					periodsForFlow.put(flowRef, flowTimePeriods);
				}
			}
			if(isSinglePeriod) {
				this.reportingPeriod = SdmxDateImpl.getSdmxDate(singlePeriod);
			}
		}

		for(ReportingTemplateWorksheetBean ws : bean.getWorksheets()) {
			List<Observation> obs = observationsForFlow != null ? observationsForFlow.get(ws.getDataflow().getReference()) : null;
			List<String> flowTimePeriods = timePeriods;
			if(this.reportingPeriod == null && ObjectUtil.validMap(periodsForFlow)) {
				flowTimePeriods = periodsForFlow.get(ws.getDataflow().getReference());
				if(flowTimePeriods == null) {
					//No periods - pick a time period from another flow
					for(IURNSingle<DataflowBean> sRef : observationsForFlow.keySet()) {
						flowTimePeriods = periodsForFlow.get(sRef);
						tf = tfForFlow.get(sRef);
					}
				} else {
					tf = tfForFlow.get(ws.getDataflow().getReference());
				}
			}
			ReportingTemplateWorksheet rt = ReportingTemplateWorksheetImpl.getInstance(this, ws, obs, beanRetrievalManager, sbBeanRetrievalManager, constraintRetrievalManager, flowTimePeriods, tf, flowToProvMap, maxObs);
			if(rt != null) {
				worksheets.add(rt);
			}
		}
		if(worksheets.size() == 0) {
			throw new IllegalArgumentException("Report Template contains no worksheets with valid series for Data Provider: "+provider.getShortURN());
		}
		this.agency = beanRetrievalManager.getBean(AgencyUtil.toRef(bean));
	}

	@Override
	public ReportingTemplateBean getReportingTemplateBean() {
		return bean;
	}

	@Override
	public IReportingTemplateInstructionSheet getInstructionSheet() {
		return instructionSheet;
	}

	@Override
	public List<ReportingTemplateWorksheet> getDataSheets() {
		return worksheets;
	}

	@Override
	public AgencyBean getAgency() {
		return agency;
	}


	@Override
	public DataProviderBean getDataProvider() {
		return provider;
	}

	@Override
	public SdmxDate getReportingPeriod() {
		return reportingPeriod;
	}

	@Override
	public boolean isGlobalVariableDimension(String dimId) {
		for(ReportTemplateVariableDimension gV : getGlobalVariableDimensions()) {
			if(gV.getReportingTemplateComponent().getComponent().getId().equals(dimId)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public Set<ReportTemplateVariableDimension> getGlobalVariableDimensions() {
		if(globalVariableDimensions == null) {
			Map<String, Set<String>> variableDimensionsAndValidCodesForWorksheet = new HashMap<>();
			Map<String, ReportTemplateVariableDimension> dimIdToReportTemplateVariableDimension = new HashMap<>();
			int i = 0;

			for(ReportingTemplateWorksheet ws : getDataSheets()) {
				Set<String> variableIdsForWorksheet = ws.getVariableDimensions().keySet();
				Set<String> variableIdsForWorkbook = dimIdToReportTemplateVariableDimension.keySet();
				variableIdsForWorkbook.retainAll(variableIdsForWorksheet);

				for(ReportTemplateVariableDimension variableDimension : ws.getVariableDimensions().values()) {
					String dimId = variableDimension.getReportingTemplateComponent().getComponent().getId();
					dimIdToReportTemplateVariableDimension.put(dimId, variableDimension);
					Set<String> validCodes = ObjectUtil.collectToSet(variableDimension.getValidCodes().stream().map(c -> c.getId() + ": " + c.getName()));
					if(i == 0) {
						variableDimensionsAndValidCodesForWorksheet.put(dimId, validCodes);
					} else {
						Set<String> validCodesFromOtherWorksheet = variableDimensionsAndValidCodesForWorksheet.get(dimId);
						if(validCodesFromOtherWorksheet != null && !validCodesFromOtherWorksheet.containsAll(validCodes)) {
							variableDimensionsAndValidCodesForWorksheet.remove(dimId);
						}
					}
				}
				i++;
			}
			globalVariableDimensions = new HashSet<>(dimIdToReportTemplateVariableDimension.values());
		}
		return globalVariableDimensions;
	}
}