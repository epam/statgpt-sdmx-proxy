package io.sdmx.fusion.reporttemplate.api.model.template;

import java.util.List;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.sdmx.model.beans.base.AgencyBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;


/**
 * Built from MSD (report)
 * 
 * WORKSHEET 					(1-~)
 *   DATAFLOW: "urn"
 *   CONSTRAINT : "urn"
 *   SHEET_NAME : "name"
 *   TABLE_ROWS
 *     DIM_ID : "REF_ARA"   	(1-~) 
 * 	 TABLE_COLS
 *     DIM_ID : "INDICATOR"   	(1-~) 
 *   FIXED_DIMENSION 			(1-~)
 *     DIM_ID : "FREQ" 
 *     CODE_ID : "A"
 *   FIXED_ATTRIBUTE           	(1-~)
 *     DIM_ID : "OBS_STATUS" 
 *     CODE_ID : "A"
 *   REPORT_ATTR : "PRE_BREAk" 	(1-~)
 *   COLOUR_ATT 
 *     ATT_ID : "OBS_CONF"
 *     COLOUR					(1-~)
 *       CODE_ID : "C",
 *       COLOUR : "#C2C2C2"
 */
public interface ReportingTemplate {
	
	/**
	 * 
	 * @return an optional instruction sheet
	 */
	IReportingTemplateInstructionSheet getInstructionSheet();
	
	/**
	 * @return list of excel data sheets in order or appearanvce
	 */
	List<ReportingTemplateWorksheet> getDataSheets();
	
	/**
	 * @return the underlying report tempalte bean
	 */
	ReportingTemplateBean getReportingTemplateBean();
	
	/**
	 * Returns the agency that owns and maintains this template
	 * @return
	 */
	AgencyBean getAgency();
	
	/**
	 * Returns the id of this template
	 * @return
	 */
	default String getId() {
		return getReportingTemplateBean().getId();
	}
	
	/**
	 * Returns the version of this template, default version is 1.0
	 * <p/>
	 * Version is a integer value with period '.' separators between integers, for example 1.2.3.19 
	 * @return
	 */
	default String getVersion() {
		return getReportingTemplateBean().getVersion().toString();
	}
	
	/**
	 * Returns the name in the default locale
	 * @return
	 */
	default String getName() {
		return getReportingTemplateBean().getName();
	}
	
	/**
	 * Returns the Data Provider Reference that is generating a report from this template
	 * @return
	 */
	DataProviderBean getDataProvider();
	
	/**
	 * Returns the Reporting Period for the user, defaults to start period if multiple periods are reported
	 * @return
	 */
	SdmxDate getReportingPeriod();
	
	/**
	 * Returns a set of variable dimensions that are globally relevant
	 * @return
	 */
	Set<ReportTemplateVariableDimension> getGlobalVariableDimensions();
	
	/**
	 * @return true if the variable dimension is global, false if it is local to the worksheet
	 */
	boolean isGlobalVariableDimension(String dimId);
	
	/**
	 * @return true if the formula checking summary should be included
	 */
	default boolean includeFormulaCheckingSummary() {
		return getReportingTemplateBean().includeFormulaCheckingSummary();
	}
}
