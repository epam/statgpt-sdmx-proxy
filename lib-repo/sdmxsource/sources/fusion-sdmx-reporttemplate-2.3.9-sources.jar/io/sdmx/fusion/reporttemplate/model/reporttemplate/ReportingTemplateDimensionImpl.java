package io.sdmx.fusion.reporttemplate.model.reporttemplate;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateComponent;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateDimension;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateDimensionCode;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.TEXT_DISPLAY;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodeBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DimensionSuperBean;
import io.sdmx.api.sdmx.model.superbeans.hierarchy.HierarchicalCodeSuperBean;
import io.sdmx.api.sdmx.model.superbeans.hierarchy.HierarchySuperBean;

public class ReportingTemplateDimensionImpl implements ReportingTemplateDimension {
	private ReportingTemplateComponent reportingTemplateComponent;
	private List<ReportingTemplateDimensionCode> codes = new ArrayList<ReportingTemplateDimensionCode>();
	
	public ReportingTemplateDimensionImpl(ReportingTemplateComponent reportingTemplateComponent, 
											TEXT_DISPLAY textDisplay,
										  DimensionSuperBean dimSb, 
										  Set<String[]> seriesCodes, 
										  HierarchySuperBean hierarchy, 
										  boolean implicitHierarchy) {
		this.reportingTemplateComponent = reportingTemplateComponent;
		int dimIdx = dimSb.getBuiltFrom().getMaintainableParent().getDimensionIndex(dimSb.getId()); 
		 
		Set<String> validCodes = new HashSet<String>();
		for(String[] series : seriesCodes) {
			validCodes.add(series[dimIdx]);
		}
		
		EnumeratedListBean<EnumeratedItemBean> cl = dimSb.getCodelist(true);
		if(cl == null) {
			validCodes = new TreeSet<String>(validCodes);
			for(String code : validCodes) {
				this.codes.add(new ReportingTemplateDimensionCodeImpl(code));
			}
		} else if(hierarchy != null) {
			for(HierarchicalCodeSuperBean hCode : hierarchy.getCodeRefs()) {
				ReportingTemplateDimensionCode code = ReportingTemplateDimensionCodeImpl.getInstance(hCode, cl.getUrn(), validCodes, textDisplay);
				if(code != null) {
					codes.add(code);
				}
			}
			if(validCodes.size() > 0) {
				//Build Flat hierarchy
				for(EnumeratedItemBean code : cl.getItems()) {
					if(validCodes.contains(code.getId())) {
						codes.add(new ReportingTemplateDimensionCodeImpl(code, textDisplay));
					}
				}
			}
		} else if(implicitHierarchy) {
			for(EnumeratedItemBean codeBean : cl.getItems()) {
				if(codeBean.getStructureType() == SDMX_STRUCTURE_TYPE.CODE) {
					CodeBean sdmxCode = (CodeBean) codeBean;
					if(sdmxCode.getParentCode() == null) {
						ReportingTemplateDimensionCode code = ReportingTemplateDimensionCodeImpl.getInstance(sdmxCode, validCodes, textDisplay);
						if(code != null) {
							codes.add(code);
						}
					}
				}
			}
		} else {
			for(EnumeratedItemBean code : cl.getItems()) {
				if(validCodes.contains(code.getId())) {
					codes.add(new ReportingTemplateDimensionCodeImpl(code, textDisplay));
				}
			}
		}
	}
	

	@Override
	public ReportingTemplateComponent getDimension() {
		return reportingTemplateComponent;
	}

	@Override
	public String getDimensionLabel() {
		return reportingTemplateComponent.getLabel();
	}

	@Override
	public List<ReportingTemplateDimensionCode> getCodes() {
		return codes;
	}

	@Override
	public String toString() {
		return getDimension().getComponent().getId() +" : "+ getDimension().getConcept().getName();
	}
}
