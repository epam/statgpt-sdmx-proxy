package io.sdmx.fusion.reporttemplate.api.model.pivottable;

import io.sdmx.api.sdmx.constants.EQUALITY;
import io.sdmx.api.sdmx.model.beans.calculation.ValidationRuleBean;

/**
 * Describes a checking formula for a table cell, this extends a cell formula 
 * which is based on the this=that, with the equality operator, so a checking cell can say
 * this>that or this<that 
 *
 */
public interface ITableCellChecking extends ICellFormula {
	
	/**
	 * @return returns the validation rule from which this cell formula was written
	 */
	ValidationRuleBean getUnderlyingRule();

	/**
	 * @return the equality operation to use on the expression 
	 */
	EQUALITY getExpressionEquality();
	
}
