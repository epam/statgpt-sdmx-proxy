package io.sdmx.fusion.reporttemplate.engine;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.engine.ISeriesObsDataWriterEngine;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.IDatasetStructures;
import io.sdmx.api.sdmx.model.beans.base.AnnotationBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.data.FooterMessage;
import io.sdmx.api.sdmx.model.data.IDatasetAttributes;
import io.sdmx.api.sdmx.model.data.Keyable;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.header.DatasetHeaderBean;
import io.sdmx.api.sdmx.model.header.HeaderBean;
import io.sdmx.fusion.reporttemplate.api.manager.ReportTemplatePasswordManager;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplate;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.sdmx.xs.URN;

public abstract class AbstractReportTemplateDataWriter implements ISeriesObsDataWriterEngine {
	
	protected ReportTemplatePasswordManager passwordManager = SingletonStore.getSingleton(ReportTemplatePasswordManager.class, false);
	
	protected SdmxBeanRetrievalManager beanRetrievalManager;
	protected SdmxSuperBeanRetrievalManager superBeanRetrievalManager;
	
	protected ReportingTemplateWorksheetBean currentWorksheet;
	//Dataflow URN to Worksheet
	private Map<String, ReportingTemplateWorksheetBean> worksheetsForFlows;
	
	protected OutputStream out;
	
	protected List<Observation> obsList = new ArrayList<>();
	protected Set<String> obsTimes = new TreeSet<>();
	
	protected List<DataflowBean> flows;
	
	private boolean includeMetadataToReadWorkbook;
	
	protected DataflowBean flow;
	protected DataStructureBean dsd;
	private boolean isClosed;
	
	protected IDatasetStructures structures;
	
	public AbstractReportTemplateDataWriter(SdmxBeanRetrievalManager beanRetrievalManager,
			  SdmxSuperBeanRetrievalManager superBeanRetrievalManager, 
			  boolean includeMetadataToReadWorkbook,
			  OutputStream out) {
		this.out = out;
		this.includeMetadataToReadWorkbook = includeMetadataToReadWorkbook;
		this.beanRetrievalManager = beanRetrievalManager;
		this.superBeanRetrievalManager = superBeanRetrievalManager;
	}
	
	@Override
	public void writeHeader(HeaderBean header) {}

	@Override
	public void startDataset(IDatasetStructures structures, DatasetHeaderBean header, IDatasetAttributes datasetAttributes, AnnotationBean... annotations) {
		flushWorksheet();
		this.structures = structures;
		this.dsd = structures.getDataStructure();
		this.flow = structures.getDataflow();
		this.currentWorksheet = getWorksheetForCurrentDataset();
	}
	
	@Override
	public void writeKey(Keyable key) {}

	@Override
	public void writeObservation(Observation obs) {
		if(this.currentWorksheet != null) {
			this.obsList.add(obs);
			this.obsTimes.add(obs.getDimensionValue());
		}
	}
	
	
	@Override
	public void close(FooterMessage... footer) {
		if(isClosed) {
			return;
		}
		isClosed = true;
		flushWorksheet();
		closeInternal();
		ReportingTemplate reportTemplate = getReportTemplate();
		
		String password = reportTemplate.getAgency() == null || passwordManager == null ? null : passwordManager.getPassword(reportTemplate.getAgency().asReference());
		ExcelReportingTemplateWriter.INSTANCE.writeReportForm(reportTemplate, includeMetadataToReadWorkbook, password, out);
	}
	
	/**
	 * Informs the writer that there was an error, the exception handler may attempt to close this writer, which may not be
	 * desireable in some cases
	 */
	protected void terminateWriter() {
		this.isClosed = true;
	}
	
	/**
	 * Tells the class to finish off all the data, and ensure the ReportingTemplate is built
	 */
	protected abstract void closeInternal();
	
	/**
	 * Dataset complete, write any observations to the worksheet
	 */
	protected abstract void flushWorksheet();
	
	/**
	 * @return the built report template (built by the time closeInternal() call has completed)
	 */
	protected abstract ReportingTemplate getReportTemplate();
	protected abstract ReportingTemplateBean getReportTemplateBean();
	
	/**
	 * The current dataset is either against a Dataflow (either directly or via the Provision Agreement) in which case we search for 
	 * worksheets that are connected to the dataflow, or against the Data Structure in which case we need to find all dataflows for the structure and 
	 * find a worksheet that matches
	 * @return
	 */
	private ReportingTemplateWorksheetBean getWorksheetForCurrentDataset() {
		if(this.worksheetsForFlows == null) {
			this.worksheetsForFlows = getReportTemplateBean().getWorksheets().stream().collect(Collectors.toMap(e->e.getDataflow().getTargetUrn(), e->e));
		}
		if(this.flow != null) {
			return this.worksheetsForFlows.get(this.flow.getUrn());
		}
		flows = new ArrayList<>();
		ReportingTemplateWorksheetBean ws = null;
		for(DataflowBean currentFlow : this.beanRetrievalManager.getMaintainableBeans(URN.build(DataflowBean.class))) {
			if(currentFlow.getDataStructureRef().isMatch(dsd)) {
				ReportingTemplateWorksheetBean thisWorksheet = this.worksheetsForFlows.get(currentFlow.getUrn());
				if(thisWorksheet != null) {
					if(ws == null || ws.getMaintainableParent() == thisWorksheet.getMaintainableParent()) {
						flows.add(currentFlow);
						this.flow = currentFlow;
						ws = thisWorksheet;
					}
				}
			}
		}
		return ws;
	}
}
