package io.sdmx.fusion.reporttemplate.model.reporttemplate;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import io.sdmx.api.collection.KeyValue;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateColouredAttribute;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateComponent;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplateSeries;
import io.sdmx.utils.sdmx.comparator.EnumeratedItemPositionComparator;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateColourBean;
import io.sdmx.api.sdmx.model.data.Observation;
import io.sdmx.api.sdmx.model.superbeans.base.ComponentSuperBean;
import io.sdmx.api.sdmx.model.superbeans.datastructure.DataStructureSuperBean;
import io.sdmx.utils.core.object.SeriesUtil;

public class ReportingTemplateColouredAttributeImpl implements ReportingTemplateColouredAttribute {
	private ReportingTemplateComponent attribute;
	private Map<EnumeratedItemBean, String> attributeColor;
	private Map<String, EnumeratedItemBean> attributeHexToCode;
	private Map<String, String>  seriesColours; //Series key to Hex Colour to use
	private String defaultColour;


	/**
	 * Constructor for when we know what data exists, so we build the colours off that
	 * @param obsMap
	 * @param series optional, if provided default colours will be set on the series where there is not an observation present
	 * @param rtColour
	 * @param attribute
	 * @param dsdSb
	 */
	public ReportingTemplateColouredAttributeImpl(
			Map<String, Observation> obsMap,
			ReportingTemplateSeries series,
			ReportingTemplateColourBean rtColour,
			ReportingTemplateComponent attribute, 
			DataStructureSuperBean dsdSb) {
		String attrId = attribute.getComponent().getId();
		Map<String, String> colourCodes = rtColour.getColourCodes();
		Set<String> attributesInWorksheet = new HashSet<>();
		seriesColours = getSeriesColours(rtColour, series);
		for(String seriesKey : obsMap.keySet()) {
			Observation obs = obsMap.get(seriesKey);
			KeyValue kv = obs.getAttribute(attrId);
			if(kv != null) {
				String reportedAttrVal = kv.getCode();
				attributesInWorksheet.add(reportedAttrVal);
				String colourHex = colourCodes.get(reportedAttrVal);
				if(colourHex != null) {
					seriesColours.put(seriesKey, colourHex);
				}
			}
		}
		this.defaultColour = series == null ? null : rtColour.getDefaultColour();
		seriesColours = Collections.unmodifiableMap(seriesColours);
		populateObject(rtColour, attribute, dsdSb, attributesInWorksheet);
	}


	/**
	 * Constructor for when we don't know the observations, but know the series, so we use the templates settings for default colours
	 * based on series
	 * @param series
	 * @param rtColour
	 * @param attribute
	 * @param dsdSb
	 */
	public ReportingTemplateColouredAttributeImpl(ReportingTemplateSeries series,
			ReportingTemplateColourBean rtColour,
			ReportingTemplateComponent attribute, 
			DataStructureSuperBean dsdSb) {
		populateObject(rtColour, attribute, dsdSb, null);
		this.defaultColour = rtColour.getDefaultColour();
		seriesColours = Collections.unmodifiableMap(getSeriesColours(rtColour, series));
	}
	
	/**
	 * If ReportingTemplateSeries is not null, this will determine which colour each series should be based on defaults set
	 * <p/>
	 * If ReportingTemplateSeries is null, returns an empty map
	 * @param rtColour
	 * @param series
	 * @return
	 */
	private Map<String, String>  getSeriesColours(ReportingTemplateColourBean rtColour, ReportingTemplateSeries series) {
		 Map<String, String> seriesColours = new HashMap<>();
		if(series != null) {
			Map<Set<String>, String>  seriesColoursLocal = rtColour.getSeriesColours();
			for(Set<String> seriesSet : seriesColoursLocal.keySet()) {
				String colourHex = seriesColoursLocal.get(seriesSet);
				for(String seriesKey : seriesSet) {
					if(SeriesUtil.hasWildcards(seriesKey)) {
						for(String seriesExploded : series.matches(seriesKey)) {
							seriesColours.put(seriesExploded, colourHex);
						}
					}  else {
						seriesColours.put(seriesKey, colourHex);
					}
					
//					if(seriesKey.contains("*")) {
//						//Explode
//						for(String seriesExploded : series.matches(seriesKey)) {
//							seriesColours.put(seriesExploded, colourHex);
//						}
//					} else {
//						seriesColours.put(seriesKey, colourHex);
//					}
				}
			}
		}
		return seriesColours;
	}

	private void populateObject(ReportingTemplateColourBean rtColour,
			ReportingTemplateComponent attribute, 
			DataStructureSuperBean dsdSb,
			Set<String> reportedAttributes) {
		ComponentSuperBean attSb = dsdSb.getComponentById(rtColour.getAttributeId());
		EnumeratedListBean cl = attSb.getCodelist(true);
		this.attribute = attribute;
		this.attributeColor = new TreeMap<EnumeratedItemBean, String>(EnumeratedItemPositionComparator.INSTANCE);
		this.attributeHexToCode = new HashMap<>();
		Map<String, String> colourCodes = rtColour.getColourCodes();
		for(String codeId : colourCodes.keySet()) {
			if(reportedAttributes != null && !reportedAttributes.contains(codeId)) {
				//We know what was reported as the set is not null, and this code was not one of them!
				continue;
			}
			EnumeratedItemBean code = cl.getItemById(codeId);
			attributeColor.put(code, colourCodes.get(codeId));
			attributeHexToCode.put(colourCodes.get(codeId), code);
		}
		attributeColor = Collections.unmodifiableMap(attributeColor);
	}

	@Override
	public ReportingTemplateComponent getAttribute() {
		return attribute;
	}

	@Override
	public Map<EnumeratedItemBean, String> getAttributeColorKey() {
		return attributeColor;
	}
	
	@Override
	public EnumeratedItemBean getColorCode(String hex) {
		return attributeHexToCode.get(hex);
	}

	@Override
	public String getColour(String[] seriesKey) {
		String skStr = SeriesUtil.toSeriesKey(seriesKey);
		String colour = seriesColours.get(skStr);
		if(colour != null) {
			return colour;
		}
		return defaultColour;
	}

	@Override
	public String toString() {
		return attribute.getLabel();
	}

}
