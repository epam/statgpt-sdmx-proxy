package io.sdmx.fusion.reporttemplate.manager;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.date.SdmxPeriod;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.api.sdmx.exception.SdmxReferenceException;
import io.sdmx.api.sdmx.manager.constraint.ConstrainedDataStructureRetrievalManager;
import io.sdmx.api.sdmx.manager.security.IDataWriteAuthorisationManager;
import io.sdmx.api.sdmx.manager.structure.ConstraintRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeanRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.SdmxSuperBeanRetrievalManager;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedItemBean;
import io.sdmx.api.sdmx.model.beans.base.EnumeratedListBean;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.datastructure.DataflowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.ProvisionAgreementBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateWorksheetBean;
import io.sdmx.api.sdmx.model.beans.xs.IMaintainableRef;
import io.sdmx.core.structure.api.manager.ProvisionBeanRetrievalManager;
import io.sdmx.fusion.reporttemplate.api.manager.ReportTemplatePasswordManager;
import io.sdmx.fusion.reporttemplate.api.manager.ReportTemplateSecurityManager;
import io.sdmx.fusion.reporttemplate.api.manager.ReportTemplateSettingsManager;
import io.sdmx.fusion.reporttemplate.api.manager.ReportingTemplateManager;
import io.sdmx.fusion.reporttemplate.api.model.template.ReportingTemplate;
import io.sdmx.fusion.reporttemplate.engine.ExcelReportingTemplateWriter;
import io.sdmx.fusion.reporttemplate.model.reporttemplate.ReportingTemplateImpl;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.date.SdmxPeriodImpl;
import io.sdmx.utils.sdmx.xs.URN;

public class ReportingTemplateManagerImpl implements ReportingTemplateManager {

	private IDataWriteAuthorisationManager dataWriteAuthManager;
	private ReportTemplatePasswordManager passwordManager;
	private ReportTemplateSecurityManager securityManager;
	private ReportTemplateSettingsManager rtSettingsManager;

	private SdmxBeanRetrievalManager beanRetrievalManager;
	private SdmxSuperBeanRetrievalManager superBeanRetrievalManager;
	private ConstraintRetrievalManager constraintRetrievalManager;
	private ProvisionBeanRetrievalManager provisionRetrievalManager;

	private CrossReferencingRetrievalManager crossReferencingRetrievalManager;

	private ConstrainedDataStructureRetrievalManager constrainedDataStructureRetrievalManager;

	public ReportingTemplateManagerImpl(SdmxBeanRetrievalManager beanRetrievalManager,
			ConstraintRetrievalManager constraintRetrievalManager,
			SdmxSuperBeanRetrievalManager superBeanRetrievalManager,
			ProvisionBeanRetrievalManager provisionBeanRetrievalManager,
			CrossReferencingRetrievalManager crossReferencingRetrievalManager,
			IDataWriteAuthorisationManager dataWriteAuthManager,
			ReportTemplatePasswordManager passwordManager,
			ReportTemplateSecurityManager securityManager,
			ReportTemplateSettingsManager rtSettingsManager,
			ConstrainedDataStructureRetrievalManager constrainedDataStructureRetrievalManager ) {
		this.beanRetrievalManager = beanRetrievalManager;
		this.superBeanRetrievalManager = superBeanRetrievalManager;
		this.constraintRetrievalManager = constraintRetrievalManager;
		this.crossReferencingRetrievalManager = crossReferencingRetrievalManager;
		this.provisionRetrievalManager = provisionBeanRetrievalManager;
		
		this.dataWriteAuthManager = dataWriteAuthManager;
		this.passwordManager = passwordManager;
		this.securityManager = securityManager;
		this.rtSettingsManager = rtSettingsManager;
		this.constrainedDataStructureRetrievalManager = constrainedDataStructureRetrievalManager;
	}
	
	@Override
	public Map<DataProviderBean, Set<ReportingTemplateBean>> getReportingTemplatesByProvider() {
		Map<DataProviderBean, Set<ReportingTemplateBean>> returnMap = new HashMap<>();

		Set<ReportingTemplateBean> allTemplates = beanRetrievalManager.getMaintainableBeans(URN.build(ReportingTemplateBean.class));

		for(DataProviderBean provider : getUserProviders()) {
			Set<ReportingTemplateBean> providerTemplates = new HashSet<>();
			Set<String> provisionRefs = new HashSet<>();
			for(ProvisionAgreementBean provision : provisionRetrievalManager.getProvisions(provider.getURN())) {
				provisionRefs.add(provision.getUrn());
				provisionRefs.add(provision.getStructureUseage().getTargetUrn());
			}
			outer:
				for(ReportingTemplateBean template : allTemplates) {
					for(ReportingTemplateWorksheetBean worksheet : template.getWorksheets()) {
						ICrossReferenceBean dataflowRef = worksheet.getDataflow();
						if(provisionRefs.contains(dataflowRef.getTargetUrn())) {
							providerTemplates.add(template);
						}
						continue outer;
					}
				}
			if(providerTemplates.size() > 0) {
				returnMap.put(provider, providerTemplates);
			}
		}
		return returnMap;
	}

	@Override
	public Map<ReportingTemplateBean, Set<DataProviderBean>> getProvidersForTemplate() {
		Map<ReportingTemplateBean, Set<DataProviderBean>> returnMap = new HashMap<>();
		Set<DataProviderBean> userProviders = getUserProviders();

		Set<ReportingTemplateBean> allTemplates = beanRetrievalManager.getMaintainableBeans(URN.build(ReportingTemplateBean.class));
		Map<DataProviderBean, Set<String>> providerProvisions = new HashMap<>();  //Provider to provision and dataflow URN
		for(DataProviderBean provider : userProviders) {
			Set<String> providerRefs = new HashSet<>();

			for(ProvisionAgreementBean provision : provisionRetrievalManager.getProvisions(provider.getURN())) {
				providerRefs.add(provision.getUrn());
				providerRefs.add(provision.getStructureUseage().getTargetUrn());
			}
			providerProvisions.put(provider, providerRefs);
		}

		for(ReportingTemplateBean template : allTemplates) {
			Set<DataProviderBean> templateProviders = new HashSet<>();
			for(ReportingTemplateWorksheetBean worksheet : template.getWorksheets()) {
				ICrossReferenceBean<DataflowBean> dataflowRef = worksheet.getDataflow();
				for(DataProviderBean provider : providerProvisions.keySet()) {
					if(providerProvisions.get(provider).contains(dataflowRef.getTargetUrn())) {
						templateProviders.add(provider);
					}
				}
			}
			returnMap.put(template, templateProviders);
		}
		return returnMap;
	}

	@Override
	public void buildExcelWorkbook(IMaintainableRef templateRef, IURNSingle<DataProviderBean> providerRef, String startPeriod, String endPeriod, OutputStream out) {
		DataProviderBean provider = beanRetrievalManager.getBean(providerRef);
		if(provider == null) {
			throw new SdmxReferenceException(providerRef);
		}
		if(!getUserProviders().contains(provider)) {
			throw new SdmxUnauthorisedException("User does not have permission to create template for provider: "+providerRef);
		}
		ReportingTemplateBean rtFlat = beanRetrievalManager.getBean(URN.builder().maint(templateRef).buildSingle(ReportingTemplateBean.class));
		if (rtFlat == null) {
			throw new SdmxNoResultsException("Unable to locate a Reporting Template from the following reference: " + providerRef);
		}

		SdmxPeriod period = new SdmxPeriodImpl(startPeriod, endPeriod);
		if(period.hasEndPeriod()) {
			long periodCount = DateUtil.getTimePeriodCount(period.getStartPeriod().getDate(), period.getEndPeriod().getDate(), period.getStartPeriod().getTimeFormatOfDate());
			if(periodCount > 1000) {
				throw new SdmxNotImplementedException("Invalid  template from/to periods of '"+period.getStartPeriod().getDateInSdmxFormat()+"' to '"+period.getEndPeriod().getDateInSdmxFormat()+"'.  This will create '"+periodCount+"' distinct time periods, which exceeds the limit of 1000");
			}
		}
		ReportingTemplate rt = new ReportingTemplateImpl(rtFlat, beanRetrievalManager, superBeanRetrievalManager, constraintRetrievalManager, providerRef, period, rtSettingsManager.getMaxObsLimit());
		String password = passwordManager.getPassword(rt.getAgency().asReference());
		ExcelReportingTemplateWriter.INSTANCE.writeReportForm(rt, true, password, out);
	}




	/**
	 * Returns a set of what the current user can see with regards to data provider templates
	 * @return
	 */
	protected Set<DataProviderBean> getUserProviders() {
		if(dataWriteAuthManager == null || (securityManager != null && securityManager.isSecurityDisabled())) {
			Set<DataProviderBean> userProviders = new HashSet<>();
			for(DataProviderSchemeBean dps : beanRetrievalManager.getMaintainableBeans(URN.build(DataProviderSchemeBean.class))) {
				userProviders.addAll(dps.getItems());
			}
			return userProviders;
		}
		return dataWriteAuthManager.getDataProviderWritePermissions();
	}

	@Override
	public Set<String> getValidFrequenciesForTemplate(String reportingTemplateUrn, String dataProviderUrn) {
		// From the ReportingTemplate URN, obtain the ReportingTemplate bean and get its worksheets
		ReportingTemplateBean repTemplateBean = beanRetrievalManager.getBean(URN.builder(reportingTemplateUrn).buildSingle(ReportingTemplateBean.class));
		if (repTemplateBean == null) {
			throw new IllegalArgumentException("Unable to resolve the supplied reporting template urn to a bean.");
		}

		Set<ProvisionAgreementBean> paSet = new HashSet<>();
		// For each Worksheet, obtain any Provision Agreements that reference this data provider
		for (ReportingTemplateWorksheetBean rtWorksheet : repTemplateBean.getWorksheets()) {
			ICrossReferenceBean<DataflowBean> dataflowRef = rtWorksheet.getDataflow();
			Set<ProvisionAgreementBean> referencingPAs = crossReferencingRetrievalManager.getCrossReferencingStructures(dataflowRef.getReference(), false, ProvisionAgreementBean.class);
			// Store any PAs that match the Data Provider URN
			for (ProvisionAgreementBean aProvAgr : referencingPAs) {
				if (aProvAgr.getDataproviderRef().getTargetUrn().equals(dataProviderUrn)) {
					paSet.add(aProvAgr);
				}
			}
		}

		// For each PA with a "FREQ" dimension, get all of the codes.
		Set<EnumeratedItemBean> constrainedFreqCodes = new HashSet<>();
		for (ProvisionAgreementBean provisionAgreementBean : paSet) {
			 EnumeratedListBean<? extends EnumeratedItemBean> cl = constrainedDataStructureRetrievalManager.getPartialCodelist(provisionAgreementBean.getURN(), "FREQ", null, null);
			if (cl != null) {
				constrainedFreqCodes.addAll(cl.getItems());
			}
		}

		// Evaluate the codes, looking for valid SDMX Frequency code IDs
		Set<String> foundCodes = new HashSet<>();
		for (EnumeratedItemBean aCode : constrainedFreqCodes) {
			if (TIME_FORMAT.isValidCodeId(aCode.getId())) {
				foundCodes.add(aCode.getId());
			} else {
				// As soon as a bad code is found, abort, returning an empty array
				return new HashSet<>();
			}
		}
		return foundCodes;
	}

}
