package io.sdmx.fusion.reporttemplate.model.worksheet;

import io.sdmx.fusion.reporttemplate.api.model.template.IInstructionSheetTextArea;
import io.sdmx.utils.xlsx.api.model.ICellStyle;
import io.sdmx.utils.xlsx.constant.BORDER_STYLE;
import io.sdmx.api.sdmx.model.beans.reporting.ReportTemplateInstructionTextBean;

/**
 * Immutable instruction sheet
 */
public class InstructionSheetTextArea implements IInstructionSheetTextArea {
	private String content;
	private ICellStyle contentStyle;
	private int colWidth;
	private int colHeight;
	private BORDER_STYLE borderStyle = BORDER_STYLE.NONE;
	
	public InstructionSheetTextArea(ReportTemplateInstructionTextBean textBean, ICellStyle contentStyle) {
		this.content = textBean.getContent();
		this.colWidth = textBean.getColWidth();
		this.colHeight = textBean.getColHeight();
		this.contentStyle = contentStyle;
	}

	public InstructionSheetTextArea(String content, ICellStyle contentStyle, int colWidth, int colHeight, BORDER_STYLE borderStyle) {
		this.content = content;
		this.contentStyle = contentStyle;
		this.colWidth = colWidth;
		this.colHeight = colHeight;
		if(borderStyle != null) {
			this.borderStyle = borderStyle;
		}
	}
	
	@Override
	public ICellStyle getContentStyle() {
		return contentStyle;
	}

	@Override
	public String getContent() {
		return content;
	}

	@Override
	public int getColWidth() {
		return colWidth;
	}

	@Override
	public int getColHeight() {
		return colHeight;
	}

	@Override
	public BORDER_STYLE getBorderStyle() {
		return borderStyle;
	}

}
