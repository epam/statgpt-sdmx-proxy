package io.sdmx.fusion.reporttemplate.util;

import java.util.List;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.reporting.ReportingTemplateBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateMutableBean;
import io.sdmx.api.sdmx.model.mutable.reporting.ReportingTemplateWorksheetMutableBean;
import io.sdmx.im.mutable.reporting.ReportingTemplateMutableBeanImpl;
import io.sdmx.im.mutable.reporting.ReportingTemplateWorksheetMutableBeanImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

public class TestReportingTemplateInstances {

    
    public static ReportingTemplateBean getInstance() {
        ReportingTemplateMutableBean rt = new ReportingTemplateMutableBeanImpl();
        rt.setAgencyId("BIS");
        rt.setId("RT");
        rt.setVersion("1.0");
        rt.addName("en", "Reporting Template");
        ReportingTemplateWorksheetMutableBean worksheet = new ReportingTemplateWorksheetMutableBeanImpl();
        worksheet.setId("WS_1");
        worksheet.setDataflow(new StructureReferenceBeanImpl("BIS", "EER", "1.0", SDMX_STRUCTURE_TYPE.DATAFLOW));
        worksheet.setTableCols(List.of("TIME_PERIOD"));
        worksheet.setTableRows(List.of("CURRENCY", "REF_AREA"));
        rt.setWorksheets(List.of(worksheet));
        return rt.getImmutableInstance();
    }
    
}
