package io.sdmx.fusion.service.model.servletresponse;

import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

import io.sdmx.api.io.IGzipResponseStream;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.io.WriteableDataLocationFactory;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.io.StreamUtil;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.WriteListener;
import jakarta.servlet.http.HttpServletResponse;

public class GZIPResponseStream extends ServletOutputStream implements IGzipResponseStream {

	protected WriteableDataLocationFactory wdlFactory = SingletonStore.getSingleton(WriteableDataLocationFactory.class);

	protected HttpServletResponse response;
	protected ServletOutputStream output;
	protected WriteableDataLocation wdl;
	protected GZIPOutputStream gzipstream;
	private boolean isClosed;

	public GZIPResponseStream(HttpServletResponse response) throws IOException {
		super();
		isClosed = false;
		this.response = response;
		this.output = response.getOutputStream();
		this.wdl = wdlFactory.getTemporaryWriteableDataLocation();
		gzipstream = new GZIPOutputStream(wdl.getOutputStream());
	}


	@Override
	public OutputStream getGZipStream() {
		return this;
	}

	/**
	 * Returns the underlying output stream, sets the content-encoding on the HTTP Header to gzip
	 * @return
	 */
	@Override
	public OutputStream writeGZipDirectToStream() {
		addHeader("Content-Encoding", "gzip");
		return output;
	}

	@Override
	public void close() throws IOException {
		close(true);
	}

	/**
	 * @param flushToGzipStream the condition where this is false is if the user has already written directly to the Stream using writeGZipDirectToStream()
	 * @throws IOException
	 */
	@Override
	public void close(boolean flushToGzipStream)  {
		if (isClosed) {
			return;
		}
		try {
			if(flushToGzipStream == true) {
				try {
					gzipstream.finish();
				} catch (IOException e) {
					e.printStackTrace();
				}
				addHeader("Content-Encoding", "gzip");
				StreamUtil.copyStream(wdl.getInputStream(), output);
			}
		} finally {
			wdl.close();
			isClosed = true;
		}
	}
	
	private void addHeader(String header, String value) {
		String headerVal = response.getHeader(header);
		if(headerVal == null || !headerVal.equals(value)) {
			response.addHeader(header, value);
		}
	}
	
	@Override
	public void flush() throws IOException {
		if (isClosed) {
			return;
		}
		gzipstream.flush();
	}

	@Override
	public void write(int b) throws IOException {
		if (isClosed) {
			return;
		}
		gzipstream.write((byte)b);
	}

	@Override
	public void write(byte b[]) throws IOException {
		if (isClosed) {
			return;
		}
		gzipstream.write(b);
	}

	@Override
	public void write(byte b[], int off, int len) throws IOException {
		if (isClosed) {
			return;
		}
		gzipstream.write(b, off, len);
	}

	public boolean closed() {
		return this.isClosed;
	}

	public void reset() {
		// No operations required here
	}
	
	@Override
	public boolean isReady() {
		return true;  // Stream is always ready to write
	}

	@Override
	public void setWriteListener(WriteListener writeListener) {
		// Not supporting async writes
	    throw new UnsupportedOperationException("Async WriteListener not supported");
	}
}
