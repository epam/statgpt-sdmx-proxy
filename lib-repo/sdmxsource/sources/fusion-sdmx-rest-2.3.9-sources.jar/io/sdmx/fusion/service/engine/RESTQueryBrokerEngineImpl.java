package io.sdmx.fusion.service.engine;

import java.io.IOException;
import java.util.zip.GZIPInputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import io.sdmx.api.exception.SDMX_ERROR_CODE;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.sdmx.constants.MESSAGE_TYPE;
import io.sdmx.api.sdmx.model.ResolutionSettings;
import io.sdmx.api.sdmx.model.ResolutionSettings.RESOLVE_CROSS_REFERENCES;
import io.sdmx.api.sdmx.model.ResolutionSettings.RESOLVE_EXTERNAL_SETTING;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.core.sdmx.model.ref.StructureParseConfiguration;
import io.sdmx.fusion.service.api.engine.RESTQueryBrokerEngine;
import io.sdmx.fusion.service.builder.StructureQueryBuilderRest;
import io.sdmx.fusion.service.constant.REST_API_VERSION;
import io.sdmx.im.beans.container.SdmxBeansImmutable;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.application.FusionSystem;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.logging.LoggingUtil;
import io.sdmx.utils.http.api.model.IHTTPResponse;
import io.sdmx.utils.http.broker.RestMessageBroker;
import io.sdmx.utils.sdmx.structure.SdmxMessageUtil;

@Service
public class RESTQueryBrokerEngineImpl implements RESTQueryBrokerEngine {
    private static final Logger LOG = LoggerFactory.getLogger(RESTQueryBrokerEngineImpl.class);

    @Override
    public SdmxBeans getMaintainables(String baseUrl, REST_API_VERSION apiVersion, RESTStructureQuery sQuery, StructureFormat structureFormat) {
        try {
            ResolutionSettings settings = new ResolutionSettings(RESOLVE_EXTERNAL_SETTING.DO_NOT_RESOLVE, RESOLVE_CROSS_REFERENCES.DO_NOT_RESOLVE);
            return queryRest(baseUrl, apiVersion, structureFormat, settings, sQuery);
        } catch (SdmxNoResultsException e) {
            return new SdmxBeansImpl();
        }
    }

    private SdmxBeans queryRest(String restURLPrefix,
                                REST_API_VERSION apiVersion,
                                StructureFormat structureFormat,
                                ResolutionSettings settings,
                                RESTStructureQuery... queryObjects) {

        try (WriteableDataLocation outputDataLocation = FusionSystem.getWdlFactory().getTemporaryWriteableDataLocation()) {
            LoggingUtil.debug(LOG, "Query REST at location: " + restURLPrefix);
            SdmxBeans beans = null;

            String mimeType = null;
            if (structureFormat != null) {
                FormatDetails formatDetails = structureFormat.getFormatDetails();
                if (formatDetails.getAcceptHeaders() != null && formatDetails.getAcceptHeaders().length > 0) {
                    mimeType = formatDetails.getAcceptHeaders()[0];
                }
            }


            for (RESTStructureQuery sQuery : queryObjects) {
                String restURL = SingletonStore.getSingleton(StructureQueryBuilderRest.class).buildStructureQuery(restURLPrefix, sQuery, apiVersion.getVersion());
                IHTTPResponse resp = RestMessageBroker.sendMessage(outputDataLocation.getOutputStream(), restURL, mimeType);
                
                if(resp.getStatus() != 200) {
                	SDMX_ERROR_CODE error = SDMX_ERROR_CODE.parseClientCode(resp.getStatus());
                	if(error != null) {
                		if(error == SDMX_ERROR_CODE.NO_RESULTS_FOUND) {
                			return SdmxBeansImmutable.EMPTY_BEANS;
                		}
                		throw new SdmxException("Error calling service: "+restURL, error);
                	}
                }

                //RFS-166: Guard against receiving data that is Gzipped without the GZIP header being set.
                try (WriteableDataLocation outputDataLocationCopy = FusionSystem.getWdlFactory().getTemporaryWriteableDataLocation()){

                    ReadableDataLocation outputLocation;

                    if (outputDataLocation.getFormat() == FILE_FORMAT.GZIP) {
                        try (GZIPInputStream gzis = new GZIPInputStream(outputDataLocation.getInputStream())) {
                            StreamUtil.copyStream(gzis, outputDataLocationCopy.getOutputStream());
                        } catch (IOException e) {
							throw new SdmxException(e, "Error copying gzip stream");
						}
                        outputLocation = outputDataLocationCopy;
                    }
                    else {
                        outputLocation = outputDataLocation;
                    }


                    MESSAGE_TYPE messageType = SdmxMessageUtil.getMessageType(outputLocation);

                    if (messageType == MESSAGE_TYPE.ERROR) {
                        SdmxMessageUtil.parseSdmxErrorMessage(outputLocation);
                    }
                    try {
                        SdmxBeans responseBean = SingletonStore.getSingleton(StructureReaderManager.class).parseStructures(outputLocation, StructureParseConfiguration.build().resolution(settings));
                        if (beans != null) {
                            beans.merge(responseBean);
                        } else {
                            beans = responseBean;
                        }

                    } catch (SdmxSyntaxException e) {
                        throw new SdmxSyntaxException(e, "Can not process response recieved from URL:" + restURL);
                    }
                } 
            }
            LoggingUtil.debug(LOG, "Query Complete");
            return beans;
        }
    }
}
