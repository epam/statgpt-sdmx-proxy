package io.sdmx.fusion.service.filter;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.http.ClientRequest;
import io.sdmx.api.sdmx.engine.CacheEngine;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.security.SecurityDetails;
import io.sdmx.fusion.security.util.SdmxSecurityContext;
import io.sdmx.fusion.service.api.manager.HTTPCacheManager;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.sdmx.structure.TextTypeUtil;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class HTTPCacheHeaderFilter implements CacheEngine, Filter {
    private static final Logger LOG = LoggerFactory.getLogger(HTTPCacheHeaderFilter.class);

	private HTTPCacheManager cacheManager = SingletonStore.getSingleton(HTTPCacheManager.class, false);

	private long lastStructureUpdate = System.currentTimeMillis();
	private Map<String, Long> lastDataUpdate = new HashMap<>();
	private long lastRefMetadataUpdate= System.currentTimeMillis();

	
	public HTTPCacheHeaderFilter() {
		if(cacheManager != null) {
			cacheManager.registerCacheEngine(this);
		}
	}

	@Override
	public void destroy() {
	    // Left intentionally empty
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	    // Left intentionally empty
	}

	@Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		try {
			boolean cacheCheck = false;
			HttpServletResponse resp = (HttpServletResponse)response;
			HttpServletRequest req = (HttpServletRequest)request;
			LOG.info("Request issued for: " + req.getRequestURL().toString());
			cacheCheck = cacheCheck(req, resp);
			if(!cacheCheck) {
				LOG.debug("304 Cache Miss");
				chain.doFilter(request, response);
			} else {
				LOG.debug("304 Cache Hit");
			}
			LOG.info("Request completed");
		} catch(Throwable th) {
			LOG.info("Request failed");
			chain.doFilter(request, response);
		}
	}

	/**
	 * Returns a boolean stating whether this was obtained from the cache (true) or not (false).
	 * If true, will also modify the response object so that a 304 is returned.
	 * @param req
	 * @param resp
	 * @return
	 */
	private boolean cacheCheck(HttpServletRequest req, HttpServletResponse resp) {
		String cacheHeader = req.getHeader("If-None-Match");
		LOG.debug("Cache Check - If-None-Match="+cacheHeader);
		
		if(cacheHeader != null) {
			try {
				String decoded = new String(Base64.getDecoder().decode(cacheHeader));
				LOG.debug("Cache Check - If-None-Match (decoded)="+decoded);

				if (ObjectUtil.validString(decoded)) {
					if(useCache(decoded)) {
						resp.setStatus(304);
						return true;
					}
				}
			} catch (Exception e) {
				// Do nothing here.
				// If anything goes wrong checking the cache header, simply add the ETag to the header.
			}
		}

		addETagToHeader(resp);
		return false;
	}
	
	private boolean useCache(String decoded) {
		String[] split = decoded.split("\\$");
		String username = split[0];
		SecurityDetails currentUser = SdmxSecurityContext.getCurrentUser();
		boolean useCache = false;
		if(currentUser != null) {
			if(!username.equals(currentUser.getUsername())) {
				return false;
			}
		}
		if(username.length() > 0) {
			return false;
		}
		
		long decodeTime = Long.valueOf(split[1]);

		Locale locale = TextTypeUtil.getLocaleFilter();
		String lang = locale == null ? "*" : locale.getLanguage();
		if(lang.equals(split[2])) {

			int action = Integer.valueOf(split[3]);
			switch(action) {
			case 1 :
				String flowId = split[4];
				Long lastUpdate = lastDataUpdate.get(flowId);
				LOG.debug("Cache Check Dataflow '"+flowId+"' - Last Updated '"+lastUpdate+"' Against Cached Copy:"+decodeTime);
				if(lastUpdate != null) {
					useCache = lastUpdate < decodeTime;
				} else {
					lastDataUpdate.put(flowId, System.currentTimeMillis());
				}
				break;
			case 2 :
				LOG.debug("Cache Check Reference Metadata - Last Updated '"+lastRefMetadataUpdate+"' Against Cached Copy:"+decodeTime);
				useCache =  lastRefMetadataUpdate < decodeTime;
				break;
			case 3 :
				LOG.debug("Cache Check Data Registration - Last Updated '"+lastRefMetadataUpdate+"' Against Cached Copy:"+decodeTime);
				useCache =  lastStructureUpdate < decodeTime;
				break;
			case 4 :
				LOG.debug("Cache Check Structure - Last Updated '"+lastRefMetadataUpdate+"' Against Cached Copy:"+decodeTime);
				useCache =  lastStructureUpdate < decodeTime;
				break;
			}
			if(useCache) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Encodes the following
	 * user$time$lang$[num]$flowId$
	 * 
	 * where [num] represents the type of query
	 * @param resp
	 */
	private void addETagToHeader(HttpServletResponse resp) {
		ClientRequest cr = ThreadLocalUtil.getClientRequest();
		String path = cr.getPathInfo();
		// NPE defence
		if (path == null) {
			return;
		}
		SecurityDetails currentUser = SdmxSecurityContext.getCurrentUser();
		StringBuilder sb = new StringBuilder();
		if(currentUser != null) {
			sb.append(currentUser.getUsername());
		}
		sb.append("$"+ System.currentTimeMillis());
		Locale locale = TextTypeUtil.getLocaleFilter();
		
		
		String lang = locale == null ? "*" : locale.getLanguage();
		
		
		sb.append("$"+ lang);

		if(path.startsWith("/data/")) {
			String[] flow = path.split("/")[2].split(",");
			String flowId = "";
			switch(flow.length) {
			case 1 :
				flowId = flow[0];
				break;
			case 2 :
			case 3 :
				flowId = flow[1];
				break;
			}
			sb.append("$1$"+flowId);
		}else if(path.startsWith("/metadata/")) {
			sb.append("$2");
		} else if(path.startsWith("/registration/")) {
			sb.append("$3");
		} else {
			return;
		}

		String encoded = Base64.getEncoder().encodeToString(sb.toString().getBytes());
		resp.setHeader("ETag", encoded);
	}

	@Override
	public void banDataForDataFlow(StructureReferenceBean flowRef) {
		// If not flowRef specified the clear ALL dataflows
		if (flowRef == null) {
			LOG.debug("Clear Cache Control on data for ALL dataflows");
			lastDataUpdate = new HashMap<>();
		} else {
			LOG.debug("Update Cache Control on data for flow: "+flowRef.getTargetUrn());
			lastDataUpdate.put(flowRef.getMaintainableId(), System.currentTimeMillis());
		}
	}


	@Override
	public void banReferenceMetadata() {
		LOG.debug("Update Cache Control on Reference Metadata");
		lastRefMetadataUpdate = System.currentTimeMillis();
	}

	@Override
	public void banAllStructures() {
		LOG.debug("Update Cache Control on structures");
		lastStructureUpdate = System.currentTimeMillis();

	}

	@Override
	public void banAll() {
		LOG.debug("Update Cache Control on all: ");
		lastStructureUpdate = System.currentTimeMillis();
		lastRefMetadataUpdate = System.currentTimeMillis();
		lastDataUpdate = new HashMap<>();
	}
}
