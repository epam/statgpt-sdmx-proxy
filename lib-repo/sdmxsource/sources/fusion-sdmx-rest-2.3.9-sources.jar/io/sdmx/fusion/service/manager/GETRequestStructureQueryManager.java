package io.sdmx.fusion.service.manager;

import java.io.OutputStream;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.http.HTTP_METHOD;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.structure.IQueryStructureRequestManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.core.sdmx.api.manager.structure.RegistrationBeanRetrievalManager;
import io.sdmx.format.ml.engine.structure.reader.v21.registration.StaxQueryRegistrationReaderEngine;
import io.sdmx.format.ml.engine.structure.writer.v21.StaxStructureWriterEngineV21;
import io.sdmx.fusion.service.api.manager.IGETRequestStructureQueryManager;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.fusion.service.model.queryresponse.StructureQueryRequest;
import io.sdmx.fusion.service.model.request.GETRequest;
import io.sdmx.fusion.service.model.request.WebServiceRequest;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.xml.StaxReader;
import io.sdmx.utils.sdmx.audit.SdmxAuditUtil;

public class GETRequestStructureQueryManager implements IGETRequestStructureQueryManager {
	private static final Logger LOG = LoggerFactory.getLogger(GETRequestStructureQueryManager.class);


	private StaxStructureWriterEngineV21 staxStructureWriterEngineV21 = StaxStructureWriterEngineV21.getInstance();

	private RegistrationBeanRetrievalManager registrationBeanRetrievalManager;
	private IQueryStructureRequestManager queryStructureRequestManager;


	public GETRequestStructureQueryManager(IQueryStructureRequestManager queryStructureRequestManager, 
			RegistrationBeanRetrievalManager registrationBeanRetrievalManager) {
		this.registrationBeanRetrievalManager = registrationBeanRetrievalManager;
		this.queryStructureRequestManager = queryStructureRequestManager;
	}

	@Override
	public void processQuery(ReadableDataLocation dataLocation, WebServiceRequest webServiceRequest) {
		//Only Supports query Registrations
		FILE_FORMAT format = dataLocation.getFormat();
		if(format == FILE_FORMAT.XML) {
			StaxReader reader = new StaxReader(dataLocation);
			OutputStream out = webServiceRequest.getOutputStream();
			reader.moveNextStartNode();
			String nodeName = reader.getElementName();
			if(nodeName.equals("RegistryInterface")) {
				reader.moveNextNode();
				nodeName = reader.getElementName();
				if(nodeName.equals("QueryRegistrationRequest")) {
					SdmxAuditUtil.startSdmxEvent(SDMX_REST_RESOURCE.REGISTRATION.getResource(), HTTP_METHOD.POST, ()-> {
						StructureReferenceBean sRef = StaxQueryRegistrationReaderEngine.getInstance().parseQueryRegistrationRequest(reader);
						
						Set<RegistrationBean> registrations;
						if(sRef.getTargetReference() == SDMX_STRUCTURE_TYPE.ANY) {
							registrations = registrationBeanRetrievalManager.getAllRegistrations();
						} else {
							IURN<?> urnQuery = sRef.getURN();
							if(urnQuery.isType(DataProviderBean.class)) {
								registrations = registrationBeanRetrievalManager.getRegistrationsByDataProvider(urnQuery.toType(DataProviderBean.class));
							} else {
								IURN<? extends IDSDRelatedBean>  urn = urnQuery.toType(IDSDRelatedBean.class);
								registrations = registrationBeanRetrievalManager.getRegistrations(urn);
							}
						}
						SdmxBeans beans = new SdmxBeansImpl(registrations);
						staxStructureWriterEngineV21.writeStructures(beans, null, out);
					});
				} else {
					throw new SdmxNotImplementedException("Can not process request of type: "+nodeName);
				}
			} else {
				throw new SdmxNotImplementedException("Can not process request of type: "+nodeName);
			}

		} else {
			throw new IllegalArgumentException("Can not process request of type: "+format);
		}

	}

	@Override
	public void processQuery(GETRequest structureQuery) {
		RESTStructureQuery restStructureQuery = structureQuery.getGetRequestStructureQuery();
		if(restStructureQuery == null) {
			throw new IllegalArgumentException("GETRequest expected to contain GetRequestStructureQuery but was null");
		}
		StructureQueryRequest structureQueryRequest = new StructureQueryRequest(restStructureQuery,
				structureQuery.getRequest(),
				structureQuery.getResponse(),
				structureQuery.getWebServiceRequestInfo().getStructureFormat());
		if(structureQuery.getWebServiceRequestInfo().isDefault()) {
			structureQueryRequest.setWasFormatDefaulted(true);
		}
		queryStructureRequestManager.processQuery(structureQueryRequest);
	}
}
