package io.sdmx.fusion.service.model.servletresponse;

import java.io.IOException;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

public class UnflushableResponseWrapper extends BaseHttpServletResponseWrapper {

	public UnflushableResponseWrapper(HttpServletResponse origResponse) {
		super(origResponse);
	}

	@Override
	protected ServletOutputStream createOutputStream() {
		try {
			return new UnflushableResponseStream(super.origResponse.getOutputStream());
		} catch (IOException e) {
			throw new RuntimeException("I/O Eception on getOutputStream", e);
		}
	}
	
}
