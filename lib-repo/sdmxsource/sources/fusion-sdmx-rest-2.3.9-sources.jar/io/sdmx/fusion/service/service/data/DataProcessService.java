package io.sdmx.fusion.service.service.data;

import java.io.IOException;

import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocationFactory;
import io.sdmx.api.service.data.IDataProcessService;
import io.sdmx.fusion.service.model.request.HttpRequest;
import io.sdmx.fusion.service.model.servletresponse.StreamingResponseWriter;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.json.JsonObjectUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;

@Path("/dataprocess")
/**
 * Runs data processing instructions on a dataset
 */
public class DataProcessService extends AbstractRestService {

	private IDataProcessService dataService = SingletonStore.getSingleton(IDataProcessService.class);
	private WriteableDataLocationFactory wdlFactory = SingletonStore.getSingleton(WriteableDataLocationFactory.class);

	/**
	 * Loads one or more files (if zipped multiple files can be loaded) responds with a token which can be used to process the data
	 */
	@POST
	@Path("/load/")
	@Produces("application/json")
	public Response loadData(final @Context HttpServletRequest httpRequest) {
		Request request = new HttpRequest(httpRequest, true);  //Enforce RDL
		return super.performWebService(out -> {
			ReadableDataLocation dataFile = request.getReadableDataLocation();
			String token = dataService.loadData(dataFile);
			JSONObject returnObj = new JSONObject();
			returnObj.put("token", token);
			return returnObj;
		});
	}

	/**
	 * Runs the process as described by the description, in the format:
	 * <pre>
	 * {
	 * 	  ""
	 *    "Structure" : "urn"     //metadata to read the data, only required if overriding the structure reference from the dataset
	 *    "ProcessSteps" : [
	 *      {
	 *      	"ProcessId"  : "VALIDATE"  //Id of a registered process
	 *      	"StepId"     : "STEP1"     //Unique Id for the step
	 *      	"Metrics"    : true        //true to capture metrics for the process
	 *      	"Properties" : {}  		   //optional map of properties specific to the process
	 *      }
	 *    ]
	 * }
	 * </pre>
	 * 
	 * @param processDescription
	 * @param data
	 * @return token to track the process
	 */
	@POST
	@Path("/run/{token}")
	@Produces("application/json")
	public Response runProcess(final @PathParam("token") String token, final @Context HttpServletRequest httpRequest, final @Context HttpServletResponse httpResponse) {
		Request request = new HttpRequest(httpRequest, true);
		return super.performWebService(out -> {
			ReadableDataLocation dataFile = request.getReadableDataLocation();
			JSONObject processDescription = JsonObjectUtil.getJsonObject(dataFile.getInputStream());
			String processToken = dataService.runProcess(token, processDescription);
			JSONObject returnObj = new JSONObject();
			returnObj.put("token", processToken);
			return returnObj;
		});
	}
			
	
	/**
	 * Writes the status of the process to the output stream, includes more information about any steps
	 * where metrics were requested:
	 * <pre>
	 * {
	 *   "ProcessToken" : "abcd",
	 *   "StartTime"    : 123456,
	 *   "EndTime"      : null,
	 *   "Status"       : 1      //0=running,1=success,2=error
	 *   "Steps"        : {
	 *   	"Step1" : {
	 *   	 	"StartTime"    : 123456,
	 *   	 	"EndTime"      : null,
	 *   		"Series" 	   : 12,
	 *   		"Rows"		   : 132
	 *    	}
	 *   }
	 * }
	 * </pre>
	 * @param token process token as returned by runProcess
	 * @param out stream to write to
	 */
	@GET
	@Path("/status/{token}")
	@Produces("application/json")
	public Response writeProcessStatus(final @PathParam("token") String token) {
		//LOG.debug("replace request");
		return super.streamWriter(out -> {
			dataService.writeProcessStatus(token, out);
		});
	}
	
	/**
	 * Writes the data as output by running a process step, optionally filtered by additional parameters
	 * @param token process token as returned by runProcess
	 * @param queryFiters optional filters to run against the data
	 * @param format the output format for the data
	 * @param out the otutput stream to write to
	 * @throws IOException
	 */
	@GET
	@Path("/download/{token}/{processstep}")
	public Response writeDataset(
			final @Context HttpServletRequest httpRequest,
			final @Context HttpServletResponse httpResponse,
			final @PathParam("token") String token,
			final @PathParam("processstep") String processStep,
			final @QueryParam("saveAs") String saveAs) throws IOException {
		Request request = new HttpRequest(httpRequest);
		StreamingResponseWriter response = new StreamingResponseWriter(wdlFactory.getTemporaryWriteableDataLocation());
		try {
			dataService.writeDataset(token, processStep, saveAs, request, response);
		} catch(Throwable th) {
			super.writeError(th, httpResponse.getOutputStream());
		}
		return response.buildResponse();
	}
	
}
