package io.sdmx.fusion.service.manager;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.im.beans.reference.RESTStructureQueryImpl;

public class WsCrossReferencingRetrievalManager implements CrossReferencingRetrievalManager {

	private ISdmxBeanRestRetrievalManager beanRetrievalManager;
	
	public WsCrossReferencingRetrievalManager(ISdmxBeanRestRetrievalManager beanRetrievalManager) {
		this.beanRetrievalManager = beanRetrievalManager;
	}

	@Override
	public <T extends MaintainableBean> Set<T> getCrossReferencingStructures(IURN<?> sourceStructureURN,
																			 boolean includeIndirectReferences,
																			 Class<T> type) {
		RESTStructureQuery restQuery = new RESTStructureQueryImpl(STRUCTURE_QUERY_DETAIL.FULL, STRUCTURE_REFERENCE_DETAIL.PARENTS, null, sourceStructureURN);
		SdmxBeans beans = beanRetrievalManager.getMaintainables(restQuery);
		return filterList(beans.getAllMaintainables(), type);
	}
	

    @Override
    public <T extends MaintainableBean> Set<T> getAllAncestors(IURNAbsolute<?> sourceStructureURN, Class<T> type) {
        RESTStructureQuery restQuery = new RESTStructureQueryImpl(STRUCTURE_QUERY_DETAIL.FULL, STRUCTURE_REFERENCE_DETAIL.ANCESTORS, null, sourceStructureURN);
        SdmxBeans beans = beanRetrievalManager.getMaintainables(restQuery);
        return filterList(beans.getAllMaintainables(), type);
    }
	
	private <T extends MaintainableBean> Set<T> filterList(Set<MaintainableBean> maints, Class<T> structures) {
		if(maints == null) {
			return Collections.emptySet();
		}
		Set<MaintainableBean> returnSet = new HashSet<>();
		if(structures == null || structures == MaintainableBean.class) {
			return (Set<T>)maints;
		}
		return (Set<T>)maints.stream().filter(e-> structures.isAssignableFrom(e.getStructureClass().getClassType())).collect(Collectors.toSet());
	}
	
}
