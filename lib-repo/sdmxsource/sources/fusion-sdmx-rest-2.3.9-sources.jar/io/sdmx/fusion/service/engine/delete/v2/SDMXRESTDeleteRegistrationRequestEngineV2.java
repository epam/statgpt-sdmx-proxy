package io.sdmx.fusion.service.engine.delete.v2;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.manager.persist.RegistrationPersistenceManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.fusion.service.api.engine.ISDMXRESTDeleteRequestEngine;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.fusion.service.engine.get.v2.SDMXRESTRegistrationGetRequestEngineV2;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

/**
 * Performs a delete on each registration matched by the GET query
 */
public class SDMXRESTDeleteRegistrationRequestEngineV2 implements ISDMXRESTDeleteRequestEngine {
	private static final ISdmxVersion REST_VERSION = SdmxVersion.getInstance(2, 0, 0);

	private SDMXRESTRegistrationGetRequestEngineV2 registrationGetRequestEngine;
	private RegistrationPersistenceManager registrationPersistenceManager;
	
	public SDMXRESTDeleteRegistrationRequestEngineV2(SDMXRESTRegistrationGetRequestEngineV2 registrationGetRequestEngine, RegistrationPersistenceManager registrationPersistenceManager) {
		this.registrationGetRequestEngine = registrationGetRequestEngine;
		this.registrationPersistenceManager = registrationPersistenceManager;
	}

	@Override
	public void processRequest(InformationFormat responseFormat, Request request, IResponse response) {
		SdmxBeans beans =  registrationGetRequestEngine.getRegistrations(request);
		for(RegistrationBean currentReg : beans.getRegistrations()) {
			registrationPersistenceManager.deleteRegistration(currentReg);
		}
		response.setStatus(200);
	}

	@Override
	public IResource getResourceType() {
		return SDMX_REST_RESOURCE.REGISTRATION.getResource();
	}

	@Override
	public ISdmxVersion getRestVersion() {
		return REST_VERSION;
	}
}
