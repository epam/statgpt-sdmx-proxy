package io.sdmx.fusion.service.api.engine;

import io.sdmx.api.http.HTTP_METHOD;


/**
 * Processes a specific type of SDMX GET request (data, structures, metadata, schema)
 */
public interface ISDMXRESTGetRequestEngine extends ISDMXRESTRequestEngine {
	
	default HTTP_METHOD getSupportedMethod() {
		return HTTP_METHOD.GET;
	}
}
