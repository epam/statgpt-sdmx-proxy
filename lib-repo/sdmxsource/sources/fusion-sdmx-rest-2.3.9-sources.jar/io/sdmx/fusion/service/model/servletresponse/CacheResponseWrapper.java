package io.sdmx.fusion.service.model.servletresponse;

import java.io.OutputStream;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

public class CacheResponseWrapper extends BaseHttpServletResponseWrapper {
	private OutputStream cache;

	public CacheResponseWrapper(HttpServletResponse response, OutputStream cache) {
		super(response);
		origResponse = response;
		this.cache = cache;
	}

	@Override
	public ServletOutputStream createOutputStream() {
		return (new CacheResponseStream(origResponse, cache));
	}
	
}