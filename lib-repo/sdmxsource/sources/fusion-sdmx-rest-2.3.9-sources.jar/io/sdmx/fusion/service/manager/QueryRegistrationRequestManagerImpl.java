package io.sdmx.fusion.service.manager;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.AUDITABLE_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.manager.output.StructureWriterManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IDSDRelatedBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.query.RESTRegistrationQuery;
import io.sdmx.core.sdmx.api.manager.structure.RegistrationBeanRetrievalManager;
import io.sdmx.fusion.service.api.manager.QueryRegistrationRequestManager;
import io.sdmx.fusion.service.model.request.GETRequest;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.sdmx.comparator.MaintainableSortByIdentifiers;

public class QueryRegistrationRequestManagerImpl implements QueryRegistrationRequestManager {

	private RegistrationBeanRetrievalManager registrationBeanRetrievalManager;
	protected StructureWriterManager structureWriterManager;


	public QueryRegistrationRequestManagerImpl(RegistrationBeanRetrievalManager registrationBeanRetrievalManager, StructureWriterManager structureWriterManager) {
		this.registrationBeanRetrievalManager = registrationBeanRetrievalManager;
		this.structureWriterManager = structureWriterManager;
	}

	@Override
	public void processQuery(GETRequest getRequest) {
		RESTRegistrationQuery registrationQuery = getRequest.getGetRequestRegistrationQuery();
		SdmxBeans beans = getSdmxBeans(getRequest.getRequest(), registrationQuery);
		// FR-2363
		IResponse response = getRequest.getResponse();
		StructureFormat structureFormat = getRequest.getWebServiceRequestInfo().getStructureFormat();
		writeStructures(response, beans, structureFormat);
		
	}
	
	protected void writeStructures(IResponse response, SdmxBeans beans, StructureFormat format) {
		response.setContentType(format.getFormatDetails().getMimeType());
		structureWriterManager.writeStructures(beans, format, response.getOutputStream());
	}
	
	protected SdmxBeans getSdmxBeans(Request request, RESTRegistrationQuery registrationQuery) {
		ThreadLocalUtil.storeOnThread(AUDITABLE_TYPE.class.getName(), AUDITABLE_TYPE.REGISTRATION_QUERY);

		StructureReferenceBean sRef = registrationQuery.getReference();
		
		Set<RegistrationBean> queryResult;
		if(sRef.getTargetReference() == SDMX_STRUCTURE_TYPE.ANY) {
			queryResult = registrationBeanRetrievalManager.getAllRegistrations();
		} else {
			IURN<?> urnQuery = sRef.getURN();
			if(urnQuery.isType(DataProviderBean.class)) {
				queryResult = registrationBeanRetrievalManager.getRegistrationsByDataProvider(urnQuery.toType(DataProviderBean.class));
			} else {
				IURN<? extends IDSDRelatedBean>  urn = urnQuery.toType(IDSDRelatedBean.class);
				queryResult = registrationBeanRetrievalManager.getRegistrations(urn);
			}
		}
		
		if(queryResult.size() == 0) {
			throw new SdmxNoResultsException("No Results Found");
		}
		SdmxDate updatedAfter = registrationQuery.getUpdatedAfter();
		SdmxDate updatedBefore = registrationQuery.getUpdatedBefore();
		
		//Sort the result for consistency and to ensure API testing is okay
		Set<RegistrationBean> queryResultSorted = new TreeSet<>(MaintainableSortByIdentifiers.INSTANCE);
		queryResultSorted.addAll(queryResult);
		queryResult = queryResultSorted;
		if(updatedAfter != null || updatedBefore != null) {
			Set<RegistrationBean> removeSet = new HashSet<>();
			for(RegistrationBean currentReg : queryResult) {
				if(updatedAfter != null && !currentReg.getLastUpdated().isLater(updatedAfter)) {
					removeSet.add(currentReg);
				}
				if(updatedBefore != null && currentReg.getLastUpdated().isLater(updatedBefore)) {
					removeSet.add(currentReg);
				}
			}
			queryResult.removeAll(removeSet);
		}
		return new SdmxBeansImpl(queryResult);
	}
}
