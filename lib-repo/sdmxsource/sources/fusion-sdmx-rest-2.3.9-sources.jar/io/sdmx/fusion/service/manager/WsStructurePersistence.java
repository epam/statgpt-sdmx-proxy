package io.sdmx.fusion.service.manager;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.http.HTTP_METHOD;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.process.IVisitor;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;
import io.sdmx.api.sdmx.manager.output.StructureWriterManager;
import io.sdmx.api.sdmx.manager.persist.RegistryStructurePersistenceManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanResolved;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.submissionresponse.SubmitStructureResponse;
import io.sdmx.core.sdmx.api.engine.structure.CrossReferenceResolverEngine;
import io.sdmx.core.sdmx.api.model.xs.IReferenceResolution;
import io.sdmx.core.sdmx.engine.structure.CrossReferenceResolverEngineImpl;
import io.sdmx.core.sdmx.format.SdmxStructureFormat;
import io.sdmx.core.sdmx.manager.structure.InMemoryRetrievalManager;
import io.sdmx.format.ml.engine.structure.reader.v21.registry.SubmitStructureResponseReaderV21;
import io.sdmx.fusion.service.builder.StructureQueryBuilderRest;
import io.sdmx.fusion.service.constant.REST_API_DELETE_BEHAVIOUR;
import io.sdmx.fusion.service.constant.REST_API_VERSION;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.beans.reference.RESTStructureQueryImpl;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.collection.Graph;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.http.api.model.IAuthentication;
import io.sdmx.utils.http.api.model.IHTTPResponse;
import io.sdmx.utils.http.api.model.IRESTRequest;
import io.sdmx.utils.http.model.RESTRequest;

public class WsStructurePersistence extends AbstractSdmxSubmission implements RegistryStructurePersistenceManager {

	private StructureWriterManager submitWriterManager = SingletonStore.getSingleton(StructureWriterManager.class);
	private StructureFormat strucFormat = new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V3_STRUCTURE_DOCUMENT);
	private REST_API_DELETE_BEHAVIOUR deleteBehvaiour = REST_API_DELETE_BEHAVIOUR.HTTP_POST;

	public WsStructurePersistence(String restService) {
		super(restService);
	}

	public WsStructurePersistence(String restService,
								  IAuthentication authentication,
								  StructureFormat strucFormat,
								  int responseTimeoutSeconds) {
		super(restService, authentication, responseTimeoutSeconds);
		if(strucFormat != null) {
			this.strucFormat = strucFormat;
		}
	}
	
	public WsStructurePersistence(String restService, String username, String password) {
		super(restService, username, password);
	}

	/**
	 * Create a WsStructurePersistence object with a defined Structure format to used when the structures are written to the output stream and sent to the target webservice
	 * @param endpoint
	 * @param username
	 * @param password
	 * @param strucFormat
	 */
	public WsStructurePersistence(String restService, String username, String password, StructureFormat strucFormat) {
		super(restService, username, password);
		if(strucFormat != null) {
			this.strucFormat = strucFormat;
		}
	}
	

	/**
	 * @param deleteBehvaiour either POSTs a file to a web service with the action DELETE, or calls the REST API with method DELETE ensuring the the deleted structures
	 * are processed in an order so that referenced structures are deleted after the structures that reference them
	 * @return
	 */
	public WsStructurePersistence setDeleteBehvaiour(REST_API_DELETE_BEHAVIOUR deleteBehvaiour) {
		this.deleteBehvaiour = deleteBehvaiour;
		return this;
	}

	@Override
	public boolean saveStructure(MaintainableBean maintainable) {
		SdmxBeans beans = new SdmxBeansImpl();
		beans.addIdentifiable(maintainable);
		Map<DATASET_ACTION, Set<IURNMaintainable<?>>> saveStructures = saveStructures(beans);
		return saveStructures.size() > 0;
	}

	@Override
	public boolean deleteStructure(MaintainableBean maintainable) {
		SdmxBeans beans = new SdmxBeansImpl();
		beans.addIdentifiable(maintainable);
		return deleteStructures(beans);
	}

	@Override
	public Map<DATASET_ACTION, Set<IURNMaintainable<?>>> saveStructures(SdmxBeans beans) {
		try (WriteableDataLocation wdl = wdlFactory.getTemporaryWriteableDataLocation();){
			submitWriterManager.writeStructures(beans, strucFormat, wdl.getOutputStream());
			return super.performSubmission(wdl, beans.getAction());
		}
	}

	public Map<DATASET_ACTION, Set<IURNMaintainable<?>>> saveStructures(ReadableDataLocation rdl, DATASET_ACTION action) {
		return super.performSubmission(rdl, action);
	}
	
	@Override
	/**
	 * Deletes structures based on the deleteBehaviour (HTTP POST or HTTP DELETE)
	 */
	public boolean deleteStructures(SdmxBeans beans) {
		switch(deleteBehvaiour) {
		case HTTP_DELETE:
			return httpDelete(beans);
		case HTTP_POST:
			return postDelete(beans);
		default:
			return false;
		}
	}
	
	private boolean httpDelete(SdmxBeans beans) {
		Set<MaintainableBean> toDelete = beans.getAllMaintainables();
		if(toDelete.size() > 1) {
			CrossReferenceResolverEngine xsEngine = new CrossReferenceResolverEngineImpl();
			InMemoryRetrievalManager brm = new InMemoryRetrievalManager(beans);
			IReferenceResolution refResolution = xsEngine.resolveReferences(beans, false, true, -1, brm);
			
			Map<MaintainableBean, Set<MaintainableBean>> dependsOnMap = new HashMap<>();
			Map<MaintainableBean, Set<ICrossReferenceBeanResolved<?>>> mRefMap = refResolution.getMaintainableReferenceMap(true);
			for(MaintainableBean maint : toDelete) {
				Set<ICrossReferenceBeanResolved<?>> refs = mRefMap.get(maint);
				if(!ObjectUtil.validCollection(refs)) {
					dependsOnMap.put(maint, null);
				} else {
					Set<MaintainableBean> mRefs = new HashSet<>();
					for(ICrossReferenceBeanResolved<?> currentRef : refs) {
						mRefs.add(currentRef.getResolvedBean().getMaintainableParent());
					}
					dependsOnMap.put(maint, mRefs);
				}
			}
			
			Graph<MaintainableBean> graph = new Graph<MaintainableBean>(dependsOnMap);
			
			final List<MaintainableBean> deleted = new ArrayList<>();
			graph.visit(new IVisitor<MaintainableBean>() {
				
				@Override
				public void visit(MaintainableBean el) {
					if(restDelete(el)) {
						deleted.add(el);
					}
				}
			});
			return deleted.size() == toDelete.size();
		} else if(toDelete.size() == 1){
			return restDelete((MaintainableBean)toDelete.toArray()[0]);
		}
		return false;
	}
	
	private boolean restDelete(MaintainableBean maint) {
		String restURL = SingletonStore.getSingleton(StructureQueryBuilderRest.class).buildStructureQuery(getWebService(), new RESTStructureQueryImpl(maint.getURN()), REST_API_VERSION.v1_5_0.getVersion());
		restURL = restURL.split("\\?")[0];
		if(restURL.endsWith("/")) {
			restURL = restURL.substring(0, restURL.length()-1);
		}
		IRESTRequest request = new RESTRequest(null, restURL, HTTP_METHOD.DELETE).setAuthentication(authentication);
		IHTTPResponse response = getHttpQueryEngine().sendMessage(request, System.out);
		return response.getStatus() == 200;
	}
	
	private boolean postDelete(SdmxBeans beans) {
		beans.setAction(DATASET_ACTION.DELETE);
		Map<DATASET_ACTION, Set<IURNMaintainable<?>>> saveStructures = saveStructures(beans);
		return saveStructures.size() > 0;
	}

	@Override
	protected Map<DATASET_ACTION, Set<StructureReferenceBean>> validateSdmxResponse(ReadableDataLocation dataLocation) {
		Map<DATASET_ACTION, Set<StructureReferenceBean>> responseMap = new EnumMap<>(DATASET_ACTION.class);

		// this is strange, the super is used to validate that it has an error only, where the default response is null, it now returns an empty map if error, but needs to be checked here too
		Map<DATASET_ACTION, Set<StructureReferenceBean>> validateSdmxResponse = super.validateSdmxResponse(dataLocation);
		if(validateSdmxResponse != null && validateSdmxResponse.isEmpty()) {
			return validateSdmxResponse;
		}
		List<SubmitStructureResponse> response;
		try {
			response = SubmitStructureResponseReaderV21.getInstance().build(dataLocation);
		} catch(Throwable th) {
			StringBuilder sb = new StringBuilder();
			if (dataLocation.getInputStream() == null) {
				return responseMap;
			}
			List<String> xLines = StreamUtil.copyFirstXLines(dataLocation.getInputStream(), 5);
			for(String s : xLines) {
				sb.append(System.getProperty("line.separator") + s);
			}
			String responseStr = sb.toString();
			if(responseStr.trim().length() ==0) {
				throw new SdmxException("No Response from server");
			}
			throw new SdmxException("Could not read response from server, response was: "+sb.toString());
		}

		for(SubmitStructureResponse currentResponse : response) {
			if(currentResponse.isError()) {
				super.throwError(currentResponse.getErrorList());
			}
			DATASET_ACTION actionType = currentResponse.getActionType();
			Set<StructureReferenceBean> aSet = responseMap.get(actionType);
			if (aSet == null) {
				aSet = new HashSet<>();
				responseMap.put(actionType, aSet);
			}
			aSet.add(currentResponse.getStructureReference());
		}

		return responseMap;
	}
}
