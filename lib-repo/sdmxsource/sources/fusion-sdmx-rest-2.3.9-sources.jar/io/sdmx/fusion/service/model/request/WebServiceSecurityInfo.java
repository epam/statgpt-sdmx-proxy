package io.sdmx.fusion.service.model.request;

public class WebServiceSecurityInfo {
	private boolean allowStructureQueries;
	private boolean allowDataQueries;
	private boolean allowMetadataQueries;
	
	private boolean allowDataSubmission;
	private boolean allowStructureSubmission;
	private boolean allowMetadataSubmission;
	
	
	public WebServiceSecurityInfo(boolean allowStructureQueries,
			boolean allowDataQueries, boolean allowMetadataQueries,
			boolean allowDataSubmission, boolean allowStructureSubmission,
			boolean allowMetadataSubmission) {
		this.allowStructureQueries = allowStructureQueries;
		this.allowDataQueries = allowDataQueries;
		this.allowMetadataQueries = allowMetadataQueries;
		this.allowDataSubmission = allowDataSubmission;
		this.allowStructureSubmission = allowStructureSubmission;
		this.allowMetadataSubmission = allowMetadataSubmission;
	}

	public boolean isAllowQueries() {
		return isAllowStructureQueries() || isAllowDataQueries() || isAllowMetadataQueries();
	}
	
	public boolean isAllowSubmissions() {
		return isAllowDataSubmission() || isAllowStructureSubmission() || isAllowMetadataSubmission();
	}
	
	public boolean isAllowStructureQueries() {
		return allowStructureQueries;
	}
	public boolean isAllowDataQueries() {
		return allowDataQueries;
	}
	public boolean isAllowMetadataQueries() {
		return allowMetadataQueries;
	}
	public boolean isAllowDataSubmission() {
		return allowDataSubmission;
	}
	public boolean isAllowStructureSubmission() {
		return allowStructureSubmission;
	}
	public boolean isAllowMetadataSubmission() {
		return allowMetadataSubmission;
	}
}
