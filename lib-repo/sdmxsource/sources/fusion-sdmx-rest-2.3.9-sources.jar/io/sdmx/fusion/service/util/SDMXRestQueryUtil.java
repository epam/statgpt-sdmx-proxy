package io.sdmx.fusion.service.util;

import java.util.Set;

import io.sdmx.api.chars.CHARS;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.reference.IMultiMaintainableRef;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class SDMXRestQueryUtil {


	/**
	 * Appends to the StringBuilder a maintainable URL path e.g. /[acy id(s)]/[id(s)]/[version]
	 * 
	 * Example all parts present
	 * /BIS/CL_FREQ
	 * 
	 * Example multiple parts present
	 * /BIS,ECB/CL_FREQ
	 * 
	 * If the agency or id is missing a star * will be in the path
	 * 
	 * @param ref
	 * @param resource
	 * @param missingValue which value to use in the path if there is no filter, i.e. if there is no agency Id use '*' or 'all'
	 * @return
	 */
	public static void buildMaintainablePath(IURN<?> ref, StringBuilder postfix, String missingValue) {
		if(ref == null) {
			appendSlash(postfix);
			postfix.append(missingValue+"/"+missingValue);
		} else {
			switch(ref.getReferenceType()) {
			case ABSOLUTE:
			case SEMANTIC:
			case WILDCARD:
				appendRESTPath(postfix, ref.getAgencyId(), missingValue);
				appendRESTPath(postfix, ref.getMaintainableId(), missingValue);
				break;
			case MULTIPLE:
				IMultiMaintainableRef multiRef = ref.asMultiple().getMutltiReference();
				appendRESTPath(postfix, multiRef.getAgencyId(), missingValue);
				appendRESTPath(postfix, multiRef.getId(), missingValue);
				break;
			default:
				break;
			}
		}
	}
	
	/**
	 * Only append the slash if it is not previuos char 
	 */
	public static void appendSlash(StringBuilder postfix) {
		if(postfix.length() == 0 || postfix.charAt(postfix.length()-1) != CHARS.SLASH.getChar()) {
			postfix.append("/");
		}
	}
	
	private static void appendRESTPath(StringBuilder postfix, String string, String missingValue) {
		appendSlash(postfix);
		if(ObjectUtil.validString(string)) {
			postfix.append(string);
		} else {
			postfix.append(missingValue);
		}
	}
	
	private static void appendRESTPath(StringBuilder postfix, Set<String> strings, String missingValue) {
		appendSlash(postfix);
		if(ObjectUtil.validCollection(strings)) {
			postfix.append(CollectionUtil.join(",", "", strings));
		} else {
			postfix.append(missingValue);
		}
	}
}
