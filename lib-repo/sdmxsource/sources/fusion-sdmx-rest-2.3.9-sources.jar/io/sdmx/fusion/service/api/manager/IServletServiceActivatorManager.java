package io.sdmx.fusion.service.api.manager;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;

public interface IServletServiceActivatorManager {

	
	void processRequest(Request req, IResource resource, IResponse response, ISdmxVersion apiVersion, InformationFormat responseFormat);
}
