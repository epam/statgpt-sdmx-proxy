package io.sdmx.fusion.service.api.engine;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.fusion.service.constant.REST_API_VERSION;

public interface RESTQueryBrokerEngine {

	/**
	 * Get the SdmxBeans VIA an SDMX web service
	 * @param baseUrl the base URL or entry point to the web service, this is the URL prefix
	 * @param apiVersion the version of the REST API to build the query against
	 * @param sQuery the Structure query itself
	 * @param structureFormat This is the query format used when asking for structures
	 * @return
	 */
	SdmxBeans getMaintainables(String baseUrl, REST_API_VERSION apiVersion, RESTStructureQuery sQuery, StructureFormat structureFormat);
	
			  
}
