package io.sdmx.fusion.service.util;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SDMX_ERROR_CODE;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.manager.output.ErrorWriterManager;
import io.sdmx.format.json.model.JsonErrorFormat;
import io.sdmx.format.ml.model.SdmxErrorFormat;
import io.sdmx.fusion.service.model.request.WebServiceRequest;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.object.ObjectUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ServletUtil {
	public static final String SAVE_AS_FILENAME_PARAM = "saveAs";
	
	private static final Logger LOG = LoggerFactory.getLogger(ServletUtil.class);
	private static final Pattern IPV4 = Pattern.compile("^(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.){3}([01]?\\d\\d?|2[0-4]\\d|25[0-5])$");
	private static final Pattern IPV6 = Pattern.compile("(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))");
	
	public static String obtainIpAddress(HttpServletRequest request) {
		// Obtain the Client IP address from either the X-Forwarded-For value or the Remote Address
		String clientIpAddr;
		String xForwardedFor = request.getHeader("X-Forwarded-For");
		if (ObjectUtil.validString(xForwardedFor)) {
			LOG.debug("Client IP address will be obtained from X-Forwarded-For value. x value is " + xForwardedFor);
			// Let's use the forwarded-for value. This is of the structure:
			//    X-Forwarded-For: client, proxy1, proxy2  (http://en.wikipedia.org/wiki/X-Forwarded-For)
			// so let's take everything up to the first comma
			int firstComma = xForwardedFor.indexOf(",");
			if (firstComma == -1) {
				clientIpAddr = xForwardedFor;
			} else {
				clientIpAddr = xForwardedFor.substring(0, firstComma);
			}
		} else {
			clientIpAddr = request.getRemoteAddr();
		}
		
		if(validateIpAddress(clientIpAddr)) {
			LOG.debug("Client IP address: " + clientIpAddr);
			return clientIpAddr;
		}
		LOG.debug("Client IP address is invalid: " + clientIpAddr);
		return null;
	}
	
	public static boolean validateIpAddress(final String ip) {
		if(!ObjectUtil.validString(ip)) {
			return false;
		}
		
		// Test for IPV6 before IPv4
		if (IPV6.matcher(ip).matches()) {
			return true;
		}
		
		if (IPV4.matcher(ip).matches()) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * Sets the saveFile value on the response object, if the user has provided the save as parameter the content disposition
	 * will be set to attachment, otherwise it will be inline - allowing the browser to determine if the file can be rendered
	 * in the browser or is in a download only format (i.e a zip file) which will prompt a save as modal
	 * 
	 * @param request
	 * @param response
	 * @param saveAsFilename the file name to use if not provided by the saveas query parameter
	 * @param getRequest
	 * @param requestWrapper
	 * @param formatDetails
	 * @throws UnsupportedEncodingException
	 */
	public static void applyContentDisposition(HttpServletRequest request, HttpServletResponse response, String saveAsFilename,
			WebServiceRequest getRequest, Request requestWrapper, FormatDetails formatDetails) throws UnsupportedEncodingException {
		// This accepts an additional GET parameter to indicate the filename when it is required that the response
		// is to be downloaded rather than appear in a browser page and processed by a DOM.
		// This is useful to avoid large results blowing a DOM in browsers like Firefox.
		boolean hasSaveAsParameter = false;
		if (ObjectUtil.validString(requestWrapper.getParameter(ServletUtil.SAVE_AS_FILENAME_PARAM))) {
			hasSaveAsParameter = true;
			saveAsFilename = requestWrapper.getParameter(ServletUtil.SAVE_AS_FILENAME_PARAM);
		}
		String fileExtension = formatDetails != null ? formatDetails.getFileExtension() : "";

		if (ObjectUtil.validString(saveAsFilename)) {
			int i = saveAsFilename.lastIndexOf('.');

			boolean includeExtension = true;
			if(i > 0) {
				//FR-1771 Some files downloads do not include file extension from web service
				String extension = saveAsFilename.substring(i+1);
				if(extension.equals("zip") || extension.equalsIgnoreCase(fileExtension)) {
					includeExtension = false;
				}
			}
			if (includeExtension) {
				saveAsFilename = saveAsFilename+"."+fileExtension;
			}
			if(!saveAsFilename.contains(".") && ObjectUtil.validString(fileExtension)) {
				saveAsFilename += "."+fileExtension;
			}
		}

		if (!ObjectUtil.validString(saveAsFilename)) {
			// Not enough information to determine a name
			return;
		}


		int idx = saveAsFilename.lastIndexOf(".");
		String extension = saveAsFilename.substring(idx, saveAsFilename.length());
		if(extension.equals(".zip")) {
			String saveAsFile = saveAsFilename.substring(0, idx);
			if(ObjectUtil.validString(fileExtension)) {
				saveAsFile += "."+fileExtension;
			}
			getRequest.zipOutput(saveAsFile);
		}

		// Set the appropriate value in the response header.
		String attachmentType = (hasSaveAsParameter ? "attachment; " : "inline; ");
		String ua = request.getHeader("user-agent");
		boolean isChrome = (ua != null && ua.indexOf("Chrome/") != -1);
		boolean isFirefox = (ua != null && ua.indexOf("Firefox/") != -1);
//		if(isChrome) {
//			response.setHeader("Content-Disposition", attachmentType + "filename=\"" + MimeUtility.encodeWord(StringEscapeUtils.unescapeHtml3(saveAsFilename), "utf-8", "Q") + "\"");
//		}else if(isFirefox) {
//			response.setHeader("Content-Disposition", attachmentType + "filename=\"" + MimeUtility.encodeWord(saveAsFilename, "utf-8", "Q") + "\"");
//		}else {
			response.setHeader("Content-Disposition", attachmentType + "filename=\"" + URLEncoder.encode(saveAsFilename, "utf-8") + "\"");
//		}
	}

	
	public static void handleError(HttpServletRequest request, HttpServletResponse resp, Throwable th) {
		resp.setCharacterEncoding(StandardCharsets.UTF_8.toString());
		OutputStream out;
		try {
			out = resp.getOutputStream();
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		if(th instanceof NullPointerException) {
			th.printStackTrace();
			LOG.error("NullPointerException", th);
			th = new RuntimeException("Internal System Error. Please see logs for more details.");
		}
		if(resp.getContentType() == null) {
			String requestContentType = request.getHeader("Content-Type");
			if(requestContentType != null) {
				if(requestContentType.toLowerCase().contains("json")) {
					resp.setContentType("application/json;");
				}
			}
		}
		if(th instanceof SdmxException) {
			SDMX_ERROR_CODE errorCode = ((SdmxException) th).getSdmxErrorCode();


			//if(request.getParameter(FORCED_SAVE_AS_FILENAME_PARAM)==null && errorCode.getHttpRestErrorCode() == SDMX_ERROR_CODE.NO_RESULTS_FOUND.getHttpRestErrorCode()) {

			// FR-972 - Modified the next IF condition to only NOT set the status if its a "force save". This should still work for FM-331. Original IF condition is commented out above.
			boolean isSaveAs = request.getParameter(SAVE_AS_FILENAME_PARAM)!=null;
			if(isSaveAs == false) {
				if (th instanceof SdmxNotAcceptableException) {
					resp.setStatus(406);
				} else {
					resp.setStatus(errorCode.getHttpRestErrorCode());
				}
			} else if(!errorCode.getHttpRestErrorCode().equals(SDMX_ERROR_CODE.NO_RESULTS_FOUND.getHttpRestErrorCode())) {
				//FM-331 If the response is to be written to a file, do not include a 404 response code
				resp.setStatus(errorCode.getHttpRestErrorCode());
			}
			printError(out, th, errorCode, resp);
		} else {
			printError(out, th, SDMX_ERROR_CODE.INTERNAL_SERVER_ERROR, resp);
			resp.setStatus(500);
		}
	}

	private static void printError(OutputStream out, Throwable th, SDMX_ERROR_CODE code, HttpServletResponse resp) {
		String contentType = resp.getContentType();
		if (contentType !=null && contentType.startsWith("application/json;")) {
			SingletonStore.getSingleton(ErrorWriterManager.class).writeError(th, out, JsonErrorFormat.getInstance());
		} else {
			// Ensure that all other content types are set to XML
			resp.setContentType("application/xml");
			SingletonStore.getSingleton(ErrorWriterManager.class).writeError(th, out, SdmxErrorFormat.getInstance());
		}
	}
}