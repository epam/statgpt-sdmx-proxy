package io.sdmx.fusion.service.api.manager;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;

/**
 * Processes a specific type of SDMX request (data, structures, metadata, schema) and method (GET, POST, DELETE)
 */
public interface ISDMXRESTRequestManager {
	
	/**
	 * Process the GET request, writing the response to the output stream, in the format defined by the InformationFormat
	 * 
	 * @param responseFormat - the format to write the response in
	 * @param apiVersion     - major version of the API
	 * @param resourceType   - The resource that is being requested, i.e data, structure, metadata
	 * @param request        - containing the request details
	 * @param response       - to write the response message and response status to
	 */
	void processRequest(InformationFormat responseFormat, 
						ISdmxVersion apiVersion,
						IResource resourceType, 
						Request request, 
						IResponse response);
	
}
