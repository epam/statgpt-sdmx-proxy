package io.sdmx.fusion.service.model.session;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import io.sdmx.utils.core.thread.ThreadLocalUtil;
import jakarta.servlet.http.HttpSession;

public class SessionMap<K,V> implements Map<K, V> {
	private String uid = UUID.randomUUID().toString();
	
	private Map<K,V> getFromSession() {
		Map<K,V> map = (Map<K,V>)getSession().getAttribute(uid);
		if(map == null) {
			map = storeMap();
		}
		return map;
	}
	
	
	private Map<K,V> storeMap() {
		Map<K,V> hashMap = new HashMap<>();
		getSession().setAttribute(uid, hashMap);
		return hashMap;
	}
	
	private HttpSession getSession() {
		return (HttpSession)ThreadLocalUtil.retrieveFromThread(ThreadLocalUtil.SESSION);
	}

	@Override
	public int size() {
		return getFromSession().size();
	}

	@Override
	public boolean isEmpty() {
		return getFromSession().isEmpty();
	}

	@Override
	public boolean containsKey(Object key) {
		return getFromSession().containsKey(key);
	}

	@Override
	public boolean containsValue(Object value) {
		return getFromSession().containsValue(value);
	}

	@Override
	public V get(Object key) {
		return getFromSession().get(key);
	}

	@Override
	public V put(K key, V value) {
		return getFromSession().put(key, value);
	}

	@Override
	public V remove(Object key) {
		return getFromSession().remove(key);
	}

	@Override
	public void putAll(Map<? extends K, ? extends V> m) {
		getFromSession().putAll(m);
	}

	@Override
	public void clear() {
		getFromSession().clear();
	}

	@Override
	public Set<K> keySet() {
		return getFromSession().keySet();
	}

	@Override
	public Collection<V> values() {
		return getFromSession().values();
	}

	@Override
	public Set<java.util.Map.Entry<K, V>> entrySet() {
		return getFromSession().entrySet();
	}
}
