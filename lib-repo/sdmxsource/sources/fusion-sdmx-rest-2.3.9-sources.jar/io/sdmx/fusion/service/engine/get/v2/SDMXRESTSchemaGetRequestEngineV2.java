package io.sdmx.fusion.service.engine.get.v2;

import io.sdmx.api.sdmx.manager.schema.ISdmxSchemaManager;
import io.sdmx.fusion.service.engine.get.SDMXRESTSchemaGetRequestEngineAbstract;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class SDMXRESTSchemaGetRequestEngineV2 extends SDMXRESTSchemaGetRequestEngineAbstract {

	public SDMXRESTSchemaGetRequestEngineV2(ISdmxSchemaManager schemaManager) {
		super(schemaManager,  SdmxVersion.getInstance(2, 0, 0));
	}
}
