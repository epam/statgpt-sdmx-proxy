package io.sdmx.fusion.service.model.servletresponse;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.http.IResponse;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.io.StreamUtil;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.StreamingOutput;

public class StreamingResponseWriter implements StreamingOutput, IResponse {
	private WriteableDataLocation wdl;
	private String contentType = "application/text";
	private Map<String, String> header = new HashMap<>();
	private int status = 200;
	
	public StreamingResponseWriter(WriteableDataLocation wdl) {
		this.wdl = wdl;
	}
	
	public Response buildResponse() {
		Response.ResponseBuilder response =  Response.status(status).entity(this).type(contentType);
		for(String headerId : header.keySet()) {
			response = response.header(headerId, header.get(headerId));
		}
		return response.build();
	}
	
	@Override
	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public void setContentType(String contentType) {
		if(contentType != null) {
			this.contentType = contentType;
		}
	}

	@Override
	public void setLastUpdated(Long epochTime) {
		if(epochTime == null) {
			return;
		}
		setHeader("Last-Updated", DateUtil.convertEpochTimeToIso8601(epochTime));
	}
	
	@Override
	public void setHeader(String header, String value) {
		this.header.put(header, value);
	}

	@Override
	public void sendError(int responseCode, String message) {
		setStatus(responseCode);
	}

	@Override
	public OutputStream getOutputStream() {
		return wdl.getOutputStream();
	}
	
	@Override
	public void write(OutputStream output) throws IOException, WebApplicationException {
		try {
			StreamUtil.copyStream(wdl.getInputStream(), output);
		} finally {
			wdl.close();
		}
	}
}
