package io.sdmx.fusion.service.service.security;

import java.io.IOException;
import java.io.OutputStream;

import org.codehaus.jettison.json.JSONArray;

import io.sdmx.api.service.security.IUserSettingsService;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.StreamingOutput;

@Path("/usersettings")
/**
 * Manages the persistence of user settings
 *
 */
public class UserSettingsService extends AbstractRestService {
	
	private IUserSettingsService fusionUserSettingsManager = SingletonStore.getSingleton(IUserSettingsService.class);
	
	@POST
	@Produces("application/json")
	@Path("/savesetting")
	public StreamingOutput saveSetting(final String arr) {
		return new StreamingOutput() {
			
			@Override
			public void write(OutputStream output) throws IOException, WebApplicationException {
				try {
					JSONArray json = new JSONArray(arr);
					String settingName = json.getString(0);
					String settingValue = json.getString(1);
					fusionUserSettingsManager.storeSetting(settingName, settingValue);
					writeSuccess(output);
				} catch (Throwable th) {
					writeError(th, output);
				}
			}
		};
	}
}
