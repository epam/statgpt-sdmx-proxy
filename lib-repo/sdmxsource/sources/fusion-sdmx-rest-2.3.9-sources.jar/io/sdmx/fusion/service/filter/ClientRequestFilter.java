package io.sdmx.fusion.service.filter;

import java.io.IOException;

import io.sdmx.api.http.ClientRequest;
import io.sdmx.fusion.service.model.request.ClientRequestImpl;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Simple Filter which supplies the URL of the service that is running.
 */
public class ClientRequestFilter implements Filter {
	
	@Override
	public void destroy() {
		// Does nothing
	}
	
	@Override
	public void init(FilterConfig filterConfig) {
	}
	
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		final HttpServletRequest request = (HttpServletRequest) req;
		
		ClientRequest clientRequest = new ClientRequestImpl(request);
		ThreadLocalUtil.storeClientRequest(clientRequest);
		ThreadLocalUtil.storeOnThread(ThreadLocalUtil.SESSION, request.getSession());
		
		try {
			chain.doFilter(req, res);
		} finally {
			ThreadLocalUtil.clearFromThread(ThreadLocalUtil.CLIENT_REQUEST);
			ThreadLocalUtil.clearFromThread(ThreadLocalUtil.SESSION);
		}
	}
}