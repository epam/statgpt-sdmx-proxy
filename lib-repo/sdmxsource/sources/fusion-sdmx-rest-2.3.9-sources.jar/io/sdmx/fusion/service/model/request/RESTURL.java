package io.sdmx.fusion.service.model.request;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.http.IRESTURL;

public class RESTURL implements IRESTURL {
	private String originalString;
	private Map<String, String> queryParameters = null;
	private Map<String, String> caseInsensitiveParameters = Collections.emptyMap();
	private List<String> pathParts;
	
	public RESTURL(String originalString) {
		this(originalString, null);
	}
	
	public RESTURL(String originalString, Map<String, String> additionalParameters) {
		if(originalString == null) {
			originalString = "";
		}
		if(originalString.startsWith("/")) {
			originalString = originalString.substring(1);
		}
		this.originalString = originalString;
		
		String[] splitQueryParam = originalString.split("\\?", 2);
		
		String path = splitQueryParam[0];
		String[] pathSplit = path.split("/");
		
		pathParts = new ArrayList<>(pathSplit.length);
		for(String pathPart : pathSplit) {
			pathParts.add(pathPart);
		}
		this.pathParts = Collections.unmodifiableList(pathParts);
		
		if(additionalParameters != null) {
			queryParameters = new HashMap<>(additionalParameters);
		}
		
		if(splitQueryParam.length > 1) {
			String[] params = splitQueryParam[1].split("&");
			if(queryParameters == null) {
				queryParameters = new HashMap<>(params.length);
			}
			for(String param : params) {
				String[] paramArs = param.split("=");
				queryParameters.put(paramArs[0], paramArs[1]);
			}
			queryParameters = Collections.unmodifiableMap(queryParameters);
		}
		if(queryParameters == null) {
			queryParameters = Collections.emptyMap();
		} else {
			caseInsensitiveParameters  = new HashMap<>(queryParameters.size());
			for(String param : queryParameters.keySet()) {
				caseInsensitiveParameters.put(param.toLowerCase(), queryParameters.get(param));
			}
		}
	}
	
	/**
	 * @param parameterName
	 * @return the value for the query parameter, or null if no query parameter exists with for the parameterName
	 */
	public String getParameter(String parameterName) {
		String value = getParameters().get(parameterName);
		if(value == null) {
			return caseInsensitiveParameters.get(parameterName.toLowerCase());
		}
		return value;
	}
	
	@Override
	public String getUrl() {
		return originalString;
	}
	
	@Override
	public Map<String, String> getParameters() {
		return queryParameters;
	}

	@Override
	public List<String> getPathParts() {
		return pathParts;
	}

	@Override
	public int hashCode() {
		return originalString.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof RESTURL) {
			return obj.toString().equals(this.toString());
		}
		return false;
	}

	@Override
	public String toString() {
		return originalString;
	}
}
