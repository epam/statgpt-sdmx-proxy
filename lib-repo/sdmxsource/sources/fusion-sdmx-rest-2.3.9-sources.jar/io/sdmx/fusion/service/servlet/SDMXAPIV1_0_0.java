package io.sdmx.fusion.service.servlet;

import io.sdmx.api.http.IResource;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

/**
 * Version 1.0.0 of the SDMX API, the REST path to determine the resource differs from the v2 API
 */
public class SDMXAPIV1_0_0 extends SDMXAPI {
	private static final long serialVersionUID = 1L;
	
	public SDMXAPIV1_0_0() {
		super(SdmxVersion.getInstance(1, 0, 0));
	}
	
	

	@Override
	/**
	 * Maps the first path parameter to the resource
	 * The V1 API does uses 'availableconstraint' this was changed in the V2 API
	 * The V1 API does not have a structure entry point so all structure Class names map to the structure resource,
	 * there are also some explicit mappings where the rest resource exists but there is no corresponding class name
	 *
	 */
	protected void buildResourceMap() {
		super.buildResourceMap();

		super.allResources.put("availableconstraint", SDMX_REST_RESOURCE.AVAILABILITY.getResource());
		
		//Structure Resources
		IResource structureResource = SDMX_REST_RESOURCE.STRUCTURE.getResource();
		super.allResources.put("organisationscheme", structureResource);
		super.allResources.put("advancereleasecalendar", structureResource);
		super.allResources.put("allowedconstraint", structureResource);
		super.allResources.put("attribute", structureResource);
		super.allResources.put("hierarchicalCodelist", structureResource);
		for(SDMX_STRUCTURE_TYPE st : SDMX_STRUCTURE_TYPE.values()) {
			if(st.getUrnClass() != null) {
				super.allResources.put(st.getUrnClass().toLowerCase(), structureResource);
			}
		}
	}
}
