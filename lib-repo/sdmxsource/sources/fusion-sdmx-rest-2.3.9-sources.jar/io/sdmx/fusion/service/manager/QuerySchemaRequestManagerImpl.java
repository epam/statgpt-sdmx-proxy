package io.sdmx.fusion.service.manager;

import java.io.OutputStream;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.fusion.service.api.manager.QuerySchemaRequestManager;
import io.sdmx.fusion.service.model.request.GETRequest;
import io.sdmx.fusion.service.model.request.WebServiceRequest;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_VERSION;
import io.sdmx.api.sdmx.manager.schema.ISdmxSchemaManager;
import io.sdmx.api.sdmx.model.format.SchemaFormat;
import io.sdmx.api.sdmx.model.query.RESTSchemaQuery;
import io.sdmx.format.ml.model.SDMX_XSDSchemaFormat;
import io.sdmx.utils.core.application.FusionSystem;
import io.sdmx.utils.core.io.StreamUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class QuerySchemaRequestManagerImpl implements QuerySchemaRequestManager {
	private static final Logger LOG = LoggerFactory.getLogger(QuerySchemaRequestManagerImpl.class);

	private ISdmxSchemaManager schemaGenerationManager;
	public QuerySchemaRequestManagerImpl(ISdmxSchemaManager schemaGenerationManager) {
		this.schemaGenerationManager = schemaGenerationManager;
		if(schemaGenerationManager == null) {
			throw new IllegalArgumentException("QuerySchemaRequestManagerImpl missing required ISdmxSchemaManager");
		}
	}

	@Override
	public void processQuery(ReadableDataLocation dataLocation, WebServiceRequest request) {
		// FUNC - this has not been implemented yet.
		throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, "Query for schema via HTTP POST - please use REST");
	}

	@Override
	public void processQuery(GETRequest getRequest) {
		RESTSchemaQuery schemaQuery = getRequest.getGetRequestSchemaQuery();

		LOG.info("Process Schema Query:" +schemaQuery);
		SchemaFormat format = null;
		SDMX_SCHEMA responseSchema = getRequest.getWebServiceRequestInfo().getSchemaVersion();
		switch (responseSchema) {
		case VERSION_ONE:
			format = SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V1_0);
			break;
		case VERSION_TWO:
			format = SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V2_0);
			break;
		case VERSION_TWO_POINT_ONE:
			format = SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V2_1);
			break;
		case VERSION_THREE:
			format = SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V3_0);
			break;
		default:
			format = SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V3_0);
		}
		
		try(WriteableDataLocation wdl = FusionSystem.getWdlFactory().getTemporaryWriteableDataLocation()) {
				OutputStream tmpOut = wdl.getOutputStream();
				schemaGenerationManager.generateSchema(format, schemaQuery, tmpOut);
				OutputStream out = getRequest.getOutputStream();
				StreamUtil.copyStream(wdl.getInputStream(), out);
		}
	}
}