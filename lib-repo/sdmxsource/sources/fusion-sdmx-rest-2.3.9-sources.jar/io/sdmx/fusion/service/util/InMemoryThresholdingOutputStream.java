package io.sdmx.fusion.service.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.io.output.ThresholdingOutputStream;

/**
 * This class writes to memory the first number of bytes (up to the Threshold), before switching and writing to the specified OutputStream.
 * This is useful for scenarios where we need to write HTTP Response status' correctly.
 * When writing to an HTTP OutputStream we may want to reach a certain threshold first. We are assuming that an error will occur fairly on,
 * so if this threshold is reached then we have a level of confidence that no error has occurred and it should be HTTP 200.
 * 
 * Note: This class relies upon Apache "commons.io" which is a 500Mb dependency.  "commons.io" is used in the project "fusion-sdmx-rest" but NOT "fusion-utils".
 */
public class InMemoryThresholdingOutputStream extends ThresholdingOutputStream {

	private OutputStream outputStream;
	private ByteArrayOutputStream memoryOutputStream;
	private boolean inMemory;

	public InMemoryThresholdingOutputStream(OutputStream outputStream, int threshold) {
		super(threshold);
		this.outputStream = outputStream;
		this.memoryOutputStream = new ByteArrayOutputStream(threshold);
		inMemory = true;
	}

	@Override
	protected OutputStream getStream() throws IOException {
		return inMemory ? memoryOutputStream : outputStream;
	}

	@Override
	public void thresholdReached() throws IOException {
		// Defence against this method being called more than once
		if (!inMemory) {
			return;
		}
		memoryOutputStream.writeTo(outputStream);
		inMemory = false;
		memoryOutputStream = null;
	}
	
	@Override
    public void close() throws IOException {
		if (inMemory) {
			thresholdReached();
		}
		outputStream.close();
		super.close();
    }
}
