package io.sdmx.fusion.service.model.request;

import java.io.IOException;
import java.io.OutputStream;

import io.sdmx.fusion.service.api.model.ISdmxResponse;

public class SdmxResponse implements ISdmxResponse {
	private int statusCode;
	private byte[] response;
	
	public SdmxResponse(int statusCode, byte[] response) {
		this.statusCode = statusCode;
		this.response = response;
	}

	@Override
	public int getHttpStatusCode() {
		return statusCode;
	}

	@Override
	public void writeResponse(OutputStream out) {
		try {
			out.write(response);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
