package io.sdmx.fusion.service.api.manager;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.fusion.service.model.request.GETRequest;
import io.sdmx.fusion.service.model.request.POSTRequest;


/**
 * Manages the processing of messages, file based (HTTP POST) or parameter based (HTTP GET) that have been sent to the a web service interface.  
 * <p/>
 * This Manager is responsible for determining what the message is requesting, and brokering that request to the correct interface for managing the request.  
 * <p/>
 * The MessageProcessManager ensures that the request action has been allowed by the ServletSecurityModel before passing it onto a more specific manager.
 * <p/>
 * If structure submissions are accepted, and the POST message is any of the following, then the StructureSubmissionRequestManager will be called:
 * <ul>
 *   <li>Registry Interface - SubmitStructureRequest</li>
 *   <li>Registry Interface - SubmitProvisionRequest</li>
 *   <li>Registry Interface - SubmitRegistrationRequest</li>
 *   <li>Structure Document</li>
 * </ul>
 * <p/>
 * If data submissions are accepted, and the POST message is any of the following, then the StructureSubmissionRequestManager will be called:
 * <ul>
 *   <li>GenericData</li>
 *   <li>UtilityData</li>
 *   <li>CompactData</li>
 *   <li>CrossSectionalData</li>
 * </ul>
 * If metadata submissions are accepted, and the POST message is any of the following, then the StructureSubmissionRequestManager will be called:
 * <ul>
 *   <li>GenericMetadata</li>
 *   <li>MetadataReport</li>
 * </ul>
 * If structure queries are accepted, and the POST message is any of the following, then the QueryStructureRequestManager will be called:
 * <ul>
 *   <li>Registry Interface - QueryStructureRequest</li>
 *   <li>Registry Interface - QueryProvisionRequest</li>
 *   <li>Registry Interface - QueryRegistrationRequest</li>
 *   <li>Query Message - any Structure Where</li>
 * </ul>
 * <p/>
 * If data queries are accepted, and the POST message is any of the following, then the QueryDataRequestManager will be called:
 * <ul>
 *   <li>Query Message - DataWhere</li>
 * </ul>
 * If metadata queries are accepted, and the POST message is any of the following, then the QueryMetadataRequestManager will be called:
 * <ul>
 *   <li>Query Message - MetadataWhere</li>
 * </ul>  
 * 
 * 
 * @author Matt Nelson
 * @deprecated use ISDMXRESTRequestManager and ISDMXRESTGetRequestEngine
 */
@Deprecated
public interface MessageProcessManager {
	
	/**
	 * Processes an input stream containing a SDMX-ML or SDMX-EDI message.
	 * <p/>
	 * This processes the message and then writes an SDMX response to the output stream.
	 * <p/>
	 * The MessageProcessManager will process the message by determining what the message is trying to do (query, submit) and will extract the 
	 * appropriate information and call the appropriate interface with the extracted data.
	 * 
	 * @param postRequest
	 * @return HTTP response Code
	 * 
	 * @throws SdmxNotImplementedException if a query or submit message was passed in when the parameters stated these were not accepted
	 * @throws SdmxUnauthorisedException if a message was supplied that is not allowed under the terms of the supplied security model
	 */
	int processMessage(POSTRequest postRequest) throws SdmxNotImplementedException, SdmxUnauthorisedException;
	
	/**
	 * Processes an parameterised URL, parsing it to build a query model and passes the message onto the correct QueryManager.
	 * <p/>
	 * This processes the message and then writes an SDMX response to the output stream.
	 * <p/>
	 * The MessageProcessManager will process the message by determining what the message is trying to do (query, submit) and will extract the 
	 * appropriate information and call the appropriate interface with the extracted data.
	 * 
	 * @param getRequest
	 * 
	 * @throws SdmxNotImplementedException if a query or submit message was passed in when the parameters stated these were not accepted
	 * @throws SdmxUnauthorisedException if a message was supplied that is not allowed under the terms of the supplied security model
	 */
	void processMessage(GETRequest getRequest) throws SdmxNotImplementedException, SdmxUnauthorisedException;
}