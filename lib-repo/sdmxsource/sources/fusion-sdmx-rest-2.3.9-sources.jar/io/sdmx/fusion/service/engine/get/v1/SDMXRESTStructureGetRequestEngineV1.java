package io.sdmx.fusion.service.engine.get.v1;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.manager.structure.IQueryStructureRequestManager;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.fusion.service.builder.RESTStructureQueryBuilder;
import io.sdmx.fusion.service.engine.get.SDMXRESTStructureGetRequestEngineAbstract;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class SDMXRESTStructureGetRequestEngineV1 extends SDMXRESTStructureGetRequestEngineAbstract {
	
	//@Autowired(required=false)
	//private ISdmxTransactionManager txManager;
	
	
	public SDMXRESTStructureGetRequestEngineV1(IQueryStructureRequestManager queryStructureRequestManager) {
		super(queryStructureRequestManager, SdmxVersion.getInstance(1, 0, 0));
	}

	@Override
	public void processRequest(InformationFormat responseFormat, Request request, IResponse response) {
		String txId = request.getParameter("txId");
		if(ObjectUtil.validString(txId)) {
//			if(txManager == null) {  //TODO
//				throw new SdmxNotImplementedException("Get structure by transaction ID not implemented");
//			}
//			StructureQueryRequest queryRequest = getStructureQueryRequest(responseFormat, request, response);
//			StructureReferenceBean structureReference = queryRequest.getStructureQueryRequest().getStructureReference();
//			if(structureReference == null || structureReference.getMaintainableUrn() == null) {
//				throw new SdmxSemmanticException("Get structure by transaction ID requires all strucutre parameters to be present (structure type, agencyid, id, version)");
//			}
//			try {
//				StructureFormat structureFormat = queryRequest.getFormat();
//				txManager.writeTransactionMaintainable(Integer.parseInt(txId), structureReference.getMaintainableUrn(), structureFormat, response.getOutputStream());
//			} finally {
//				ThreadLocalUtil.clearFromThread(AnnotableBean.INCLUDE_INTERNAL_KEY);
//			}
		} else {
			super.processRequest(responseFormat, request, response);
		}
	}

	@Override
	protected RESTStructureQuery buildRESTQuery(Request request) {
		return RESTStructureQueryBuilder.build(request.getPath(), request.getParameters());
	}

}
