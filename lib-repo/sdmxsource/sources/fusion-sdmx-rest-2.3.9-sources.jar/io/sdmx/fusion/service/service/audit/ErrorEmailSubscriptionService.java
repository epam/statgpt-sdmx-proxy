package io.sdmx.fusion.service.service.audit;

import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.service.audit.IErrorSubscriptionService;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.json.JsonObjectUtil;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Response;

@Path("/error/subscribe/email")
/**
 * Create, fined and delete subscriptions to error events, to be notified via email
 * @author Metadata Technology
 *
 */
public class ErrorEmailSubscriptionService extends AbstractRestService {

	private IErrorSubscriptionService errorSubscriptionService = SingletonStore.getSingleton(IErrorSubscriptionService.class);
	
	@GET
	@Path("subscription")
	@Produces("application/json")
	/**
	 * Returns a subscriptions that match the email queyr parameter, or all subscriptions if no email was provided - admin only:
	 * 
	 * @param post
	 * @return
	 */
	public Response getSubscription(@QueryParam("email") final String email, @QueryParam("service") final String service, @QueryParam("category") final String category) {
		return super.performWebService((response) -> {
			return errorSubscriptionService.getSubscriptions(email, service, category).toString();
		});
	}

	@POST
	@Path("subscription")
	@Produces("application/json")
	/**
	 * Subscribe to be notified by email on error - admin only, json as follows:
	 * 
	 * 
	 * Service and Category are optional - if not provided any events which match are notified
	 * 
	 * {
	 *   Email : "blah",
	 *   Service : "blah",
	 *   Category : "blah",
	 * }
	 * 
	 * @param post
	 * @return
	 */
	public Response subscribe(final String post) {
		return super.performWebService((response) -> {
			JSONObject json = new JSONObject(post);
			String email = JsonObjectUtil.getString(json, "Email", true);
			String service = JsonObjectUtil.getString(json, "Service", true);
			String category = JsonObjectUtil.getString(json, "Category", true);
			errorSubscriptionService.subscribe(email, service, category);
			return super.getSuccess();
		});
	}

	@DELETE
	@Path("subscription")
	@Produces("application/json")
	/**
	 * Deletes a subscription - admin only, json as follows:
	 * 
	 * Service and Category are optional - if not provided any subscriptions which match will be deleted
	 * 
	 *  {
	 *   Email : "blah",
	 *   Service : "blah",
	 *   Category : "blah",
	 * }
	 * 
	 * @param post
	 * @return
	 */
	public Response deleteSubscription(final String post) {
		return super.performWebService((response) -> {
			JSONObject json = new JSONObject(post);
			String email = JsonObjectUtil.getString(json, "Email", true);
			String service = JsonObjectUtil.getString(json, "Service", true);
			String category = JsonObjectUtil.getString(json, "Category", true);
			errorSubscriptionService.unsubscribe(email, service, category);
			return super.getSuccess();
		});
	}
}
