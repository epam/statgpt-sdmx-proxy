package io.sdmx.fusion.service.filter;

import java.io.IOException;

import io.sdmx.fusion.service.model.servletresponse.UnflushableResponseWrapper;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletResponse;

public class UnflushableStreamFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		chain.doFilter(request, new UnflushableResponseWrapper((HttpServletResponse)response));
	}

	@Override
	public void destroy() {
	}

}
