package io.sdmx.fusion.service.service.audit;

import io.sdmx.api.service.audit.IErrorService;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Response;

/**
 * Provides information about which error services and categories exist
 * @author Metadata Technology
 *
 */
@Path("/error/")
public class ErrorService extends AbstractRestService {

	private IErrorService errorService = SingletonStore.getSingleton(IErrorService.class);
	
	@GET
	@Path("notifiers")
	@Produces("application/json")
	/**
	 * Returns a subscriptions that match the email query parameter, or all subscriptions if no email was provided - admin only:
	 * 
	 * @param post
	 * @return
	 */
	public Response getNotifiers() {
		return super.performWebService((response) -> {
			return errorService.getErrorNotifiers();
		});
	}

	@GET
	@Path("categories/{service}")
	@Produces("application/json")
	/**
	 * Returns error categories for the service with the given id
	 * 
	 * @param post
	 * @return
	 */
	public Response getCategories(@PathParam("service") final String serviceId) {
		return super.performWebService((response) -> {
			return errorService.getErrorCategories(serviceId);
		});
	}
	
	@GET
	@Path("categories")
	@Produces("application/json")
	/**
	 * Returns all the error categories:
	 * 
	 * @param post
	 * @return
	 */
	public Response getCategories() {
		return super.performWebService((response) -> {
			return errorService.getCategories();
		});
	}
	
	
	@GET
	@Path("reports")
	@Produces("application/json")
	/**
	 * returns all the error reports that match the query criteria
	 * @return
	 */
	public Response getErrorReports(@QueryParam("service") final String serviceId,
			@QueryParam("category") final String categoryId,
			@QueryParam("audit") final String auditId,
			@QueryParam("from") final String from,
			@QueryParam("to") final String to,
			@QueryParam("full") final Boolean full,
			@QueryParam("limit") final Integer limit,
			@QueryParam("offset") final Integer offset) {
		return super.performWebService((response) -> {
			boolean fullBool = full != null && full == Boolean.TRUE;
			return errorService.getErrorReports(serviceId, categoryId, auditId, from, to, fullBool, limit, offset);
		});
	}
	
	@GET
	@Path("report/{id}")
	@Produces("application/json")
	/**
	 * returns the full error report with the given id
	 * @return
	 */
	public Response getErrorReports(@PathParam("id") final String id) {
		return super.performWebService((response) -> {
			return errorService.getErrorReport(id);
		});
	}
}
