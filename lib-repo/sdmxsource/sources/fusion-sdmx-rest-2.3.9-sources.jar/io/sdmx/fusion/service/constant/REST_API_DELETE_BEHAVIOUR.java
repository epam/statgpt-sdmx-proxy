package io.sdmx.fusion.service.constant;

/**
 * Describes 3 different delete behaviours
 */
public enum REST_API_DELETE_BEHAVIOUR {
	HTTP_DELETE,						//Use the REST URL to describe a single Maintainable to delete
	HTTP_POST,							//Use the HTTP POST to POST the SDMX Structures to delete
}
