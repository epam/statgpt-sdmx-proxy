package io.sdmx.fusion.service.service.data;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.mapping.v3.IStructureMapBean;
import io.sdmx.api.service.data.IDataMappingService;
import io.sdmx.fusion.service.model.request.HttpRequest;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.rest.SdmxRESTUtil;
import io.sdmx.utils.sdmx.xs.URN;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.StreamingOutput;

/**
 * A public REST web service for accessing structure map functions, such as explain map
 */
@Path("/structuremap")
public class StructureMapRest extends AbstractRestService {
	private static final Logger LOG = LoggerFactory.getLogger(StructureMapRest.class);

	private IDataMappingService dataMappingService = SingletonStore.getSingleton(IDataMappingService.class);

	@POST
	@Path("/explainmap")
	@Produces("application/json")
	/**
	 * Writes a JSON report of which series mapped and which did not map based on the input data and structure map
	 *
	 * The report looks like the following:
	 * {
	 *   "source" : "dsdurn";
	 *   "target" : "dsdurn";
	 *   "mapped" : {
	 *   	 "A:B:C:D" : "A:X:X:X",
	 *   	 "A:B:C:E" : "B:X:X:X",
	 *
	 *   },
	 *   "unmapped" :["A:B:C:F"]
	 * }
	 *
	 * @param rdl
	 * @param structureMap
	 */
	public StreamingOutput explainMap(@Context final HttpServletRequest post) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					Request httprequest = new HttpRequest(post);
					ReadableDataLocation rdl = httprequest.getReadableDataLocation();
					String structureMapUrn = httprequest.getHeader("StructureMap");
					String mapFrom = httprequest.getHeader("MapFrom");  //Source or Target, default=Source
					String strIsValidating = httprequest.getHeader("IsValidating");

					if(!ObjectUtil.validString(structureMapUrn)) {
						throw new SdmxSemmanticException("Missing 'StructureMap' Header");
					}
					boolean isSource = mapFrom == null || !mapFrom.equalsIgnoreCase("Target");
					boolean isValidating = (ObjectUtil.validString(strIsValidating) && strIsValidating.equalsIgnoreCase("true"));
					
					IURNSingle<IStructureMapBean> mapRef = URN.builder(structureMapUrn).buildSingle(IStructureMapBean.class);
					dataMappingService.explainMap(rdl, mapRef, isSource, out, isValidating);
				} catch (Throwable th) {
					writeError(th, out);
				}
			}
		};
	}

	@POST
	@Path("/explainmapseries")
	@Produces("application/json")
	/**
	 * Writes a JSON report of which series mapped and which did not map based on the input data and structure map
	 * Expects a JSON input like the following:
	 * {
	 *   "StructureMap": "urn:sdmx:org.sdmx.infomodel.structuremapping.StructureMap=MAPPING_TEST:DF_MAP(1.0)",
	 *   "Series": "A B.C.BAR.2003",
	 *   "MapFrom": "source",
	 *   "ComponentValues": {
	 *     "OBS_STATUS": "5D",
	 *     "OBS_VALUE": "9993"
	 *   }
	 * }
	 * @param post
	 * @return
	 */
	public StreamingOutput explainMapSeries(final String post) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					JSONObject json = new JSONObject(post);
					
					if (!json.has("StructureMap")) {
						throw new SdmxSemmanticException("Missing 'StructureMap' value");
					}
					String structureMap = json.getString("StructureMap");
					
					if (!json.has("Series")) {
						throw new SdmxSemmanticException("Missing 'Series' value");
					}
					String series = json.getString("Series");
					
					boolean isSource = true;
					if (!json.has("MapFrom")) {
						String mapFrom = json.getString("MapFrom");    //Source or Target, default=Source
						isSource = (mapFrom == null) || !mapFrom.equalsIgnoreCase("Target");
					}
					
					if (!json.has("ComponentValues")) {
						throw new SdmxSemmanticException("Missing 'ComponentValues' value");
					}
					Map<String, String> componentValuesMap  = new HashMap<>();
					JSONObject cv = json.getJSONObject("ComponentValues");
					Iterator<?> iter = cv.keys();
					while (iter.hasNext()) {
						String key = (String)iter.next();
						componentValuesMap.put(key, cv.getString(key));
					}

					IURNSingle<IStructureMapBean> mapRef = URN.builder(structureMap).buildSingle(IStructureMapBean.class);
					String[] seriesSplit = series.split("\\.");
					// I really think this npe defence is required!
					//Or maybe it should be done on the client side? and then turn blank entries into nulls?
//					System.out.println("explainMapSeries");
//					for (int i=0; i < seriesSplit.length; i++) {
//						if ("null".equals(seriesSplit[i])) {
//							System.out.println("\t-------- An element was the string 'null'");
//							seriesSplit[i] = null;
//						}
//					}
					dataMappingService.explainMap(mapRef, isSource, seriesSplit, componentValuesMap, out);
				} catch (Throwable th) {
					writeError(th, out);
				}
			}
		};
	}
	
	@GET
	@Path("/explainmap/{mapagency}/{mapid}/{mapversion}/{key}")
	@Produces("application/json")
	@Deprecated
	/**
	 * Writes a JSON report of which series mapped and which did not map based on the input data and structure map
	 * @deprecated
     * This method should no longer be used. Use the POST method 'explainmapseries' instead.
	 *
	 * @param rdl
	 * @param structureMap
	 */
	public StreamingOutput explainMap(final @PathParam("mapagency") String mapAgency,
									   final @PathParam("mapid") String mapId,
									   final @PathParam("mapversion") String mapVersion,
									   final @PathParam("key") String key,
									   final @QueryParam("mapfrom") String mapFrom,
									   final @Context HttpServletRequest httpRequest) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					Request request = new HttpRequest(httpRequest);
					Map<String, String> queryParams = SdmxRESTUtil.processComponentQueryParamters(request);

					IURNSingle<IStructureMapBean> mapRef = URN.builder(SDMX_STRUCTURE_TYPE.STRUCTURE_MAP, mapAgency, mapId, mapVersion).buildSingle(IStructureMapBean.class);

					boolean isSource = mapFrom == null || !mapFrom.equalsIgnoreCase("Target");
					dataMappingService.explainMap(mapRef, isSource, key.split("\\."), queryParams, out);
				} catch (Throwable th) {
					writeError(th, out);
				}
			}
		};
	}

}
