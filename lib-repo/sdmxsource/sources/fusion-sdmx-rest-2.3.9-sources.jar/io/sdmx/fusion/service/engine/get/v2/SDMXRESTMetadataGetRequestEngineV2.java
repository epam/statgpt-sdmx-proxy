package io.sdmx.fusion.service.engine.get.v2;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.manager.structure.IQueryMetadataRequestManager;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.sdmx.model.query.IRESTMetadataQuery;
import io.sdmx.format.json.model.SdmxJsonMetadataFormat;
import io.sdmx.fusion.service.api.engine.ISDMXRESTGetRequestEngine;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.fusion.service.model.queryresponse.MetadataQueryRequest;
import io.sdmx.im.beans.reference.RESTMetadataQuery;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class SDMXRESTMetadataGetRequestEngineV2 implements ISDMXRESTGetRequestEngine {
	private static final ISdmxVersion REST_VERSION = SdmxVersion.getInstance(2, 0, 0);
	private IQueryMetadataRequestManager queryMetadataRequestManager;
	private final IMetadataFormat DEFAULT_METADATA_FORMAT = SdmxJsonMetadataFormat.defaultInstance();
	
	public SDMXRESTMetadataGetRequestEngineV2(IQueryMetadataRequestManager queryMetadataRequestManager) {
		this.queryMetadataRequestManager = queryMetadataRequestManager;
	}

	@Override
	public void processRequest(InformationFormat responseFormat, Request request, IResponse response) {
		boolean wasFormatDefaulted = false;
		if(responseFormat == null) {
			wasFormatDefaulted = true;
			responseFormat = DEFAULT_METADATA_FORMAT; 
		}
		IMetadataFormat mf = (IMetadataFormat) responseFormat;
		IRESTMetadataQuery metadataQuery = new RESTMetadataQuery(request);
		MetadataQueryRequest mqr = new MetadataQueryRequest(metadataQuery, request, response, mf);
		mqr.setWasFormatDefaulted(wasFormatDefaulted);
		queryMetadataRequestManager.processQuery(mqr);
	}
	
	@Override
	public IResource getResourceType() {
		return SDMX_REST_RESOURCE.METADATA.getResource();
	}

	@Override
	public ISdmxVersion getRestVersion() {
		return REST_VERSION;
	}
}
