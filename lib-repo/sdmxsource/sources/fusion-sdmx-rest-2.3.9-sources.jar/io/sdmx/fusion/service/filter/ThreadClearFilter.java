package io.sdmx.fusion.service.filter;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.utils.core.thread.ThreadLocalUtil;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class ThreadClearFilter implements Filter {
    private static final Logger LOG = LoggerFactory.getLogger(ThreadClearFilter.class);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	    // Left intentionally empty
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		LOG.debug("Clear Thread Local");
		ThreadLocalUtil.clearThread();
		
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
	    // Left intentionally empty
	}
	
}
