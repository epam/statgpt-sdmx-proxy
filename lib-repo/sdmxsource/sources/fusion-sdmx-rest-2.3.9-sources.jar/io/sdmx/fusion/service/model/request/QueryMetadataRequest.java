package io.sdmx.fusion.service.model.request;

public class QueryMetadataRequest {
	private WebServiceRequest webServiceRequest;

	
	public WebServiceRequest getWebServiceRequest() {
		return webServiceRequest;
	}
}
