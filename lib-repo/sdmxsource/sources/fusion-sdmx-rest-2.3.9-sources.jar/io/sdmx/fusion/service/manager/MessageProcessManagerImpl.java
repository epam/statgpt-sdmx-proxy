package io.sdmx.fusion.service.manager;

import java.io.ByteArrayOutputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import io.sdmx.api.exception.ErrorUtil;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.http.HTTP_METHOD;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.BASE_QUERY_MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.QUERY_MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.REGISTRY_MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.manager.output.ErrorWriterManager;
import io.sdmx.format.json.model.JsonErrorFormat;
import io.sdmx.format.json.util.SdmxJsonUtil;
import io.sdmx.format.ml.model.SdmxErrorFormat;
import io.sdmx.fusion.service.api.manager.IGETRequestStructureQueryManager;
import io.sdmx.fusion.service.api.manager.MessageProcessManager;
import io.sdmx.fusion.service.api.manager.QueryRegistrationRequestManager;
import io.sdmx.fusion.service.api.manager.QuerySchemaRequestManager;
import io.sdmx.fusion.service.api.manager.StructureSubmissionRequestManager;
import io.sdmx.fusion.service.api.model.ISdmxResponse;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.fusion.service.model.request.GETRequest;
import io.sdmx.fusion.service.model.request.POSTRequest;
import io.sdmx.fusion.service.model.request.SdmxResponse;
import io.sdmx.fusion.service.model.request.WebServiceSecurityInfo;
import io.sdmx.utils.sdmx.audit.SdmxAuditUtil;
import io.sdmx.utils.sdmx.structure.SdmxMessageUtil;

public class MessageProcessManagerImpl implements MessageProcessManager {

	@Autowired(required=false)
	protected StructureSubmissionRequestManager submissionManager;

	@Autowired(required=false)
	private IGETRequestStructureQueryManager queryStructureRequestManager;
	
	@Autowired(required=false)
	private QueryRegistrationRequestManager queryRegistrationRequestManager;

	@Autowired
	private ErrorWriterManager errorWriterManager;

	@Autowired(required=false)
	private QuerySchemaRequestManager querySchemaRequestManager;

	@Override
	public int processMessage(POSTRequest postRequest) throws SdmxNotImplementedException, SdmxUnauthorisedException {
		try {
			return processSubmission(postRequest);
		} finally {
			if(postRequest.getReadableDataLocation() != null) {
				postRequest.getReadableDataLocation().close();
			}
		}
	}

	private int processSubmission(POSTRequest postRequest) {
		ReadableDataLocation submissionData = postRequest.getReadableDataLocation();
		if (submissionData == null) {
			throw new SdmxException("Can not process POST, no Input Stream found (no submission data).  To POST to this service please set the Content type to 'application/text' or 'application/xml'.  To post "
					+ "from a HTML form with a file upload, please set the content type to 'multipart/form-data' with the input file field name set to 'uploadFile'.  "
					+ "If sending from a HTML form where the XML is in a form element such as a text box, please se tthe content type to 'application/x-www-form-urlencoded' "
					+ "and have the name of the form element set to 'xml'");
		}

		ISdmxResponse response = null;

		FILE_FORMAT format = submissionData.getFormat();
		try {
			MESSAGE_TYPE messageType =  MESSAGE_TYPE.STRUCTURE; 	//Default to a structure submission
			DATASET_ACTION datasetAction = postRequest.getAction();  //Default to Append
			if(format == FILE_FORMAT.XML) {
				//An SDMX Message
				messageType = SdmxMessageUtil.getMessageType(submissionData);
				if(datasetAction == null) {
					datasetAction = SdmxMessageUtil.getDataSetAction(submissionData);
				}
			} else if(datasetAction == null && format == FILE_FORMAT.JSON) {
				datasetAction = SdmxJsonUtil.getAction(submissionData);
			}
			if(datasetAction == null) {
				datasetAction = DATASET_ACTION.REPLACE;
			}
			response = processPost(messageType, postRequest, datasetAction, submissionData);
		} catch (Throwable th) {
			response = getErrorResponse(th, format == FILE_FORMAT.JSON);
		} finally {
			writeResponse(response, postRequest, submissionData);
			submissionData.close();
		}
		if(response != null) {
			return response.getHttpStatusCode();
		}
		return 200;
	}

	protected ISdmxResponse processPost(MESSAGE_TYPE messageType, POSTRequest postRequest, DATASET_ACTION datasetAction, ReadableDataLocation submissionData) {
		WebServiceSecurityInfo securityModel = postRequest.getWebServiceRequestInfo().getWebServiceSecurityInfo();
		SDMX_SCHEMA schemaVersion = postRequest.getWebServiceRequestInfo().getSchemaVersion();

		switch(messageType)  {
		case QUERY :
			if(!securityModel.isAllowQueries()) {
				throw new SdmxUnauthorisedException(ExceptionCode.SECURITY_UNAUTHORISED, "[Queries]");
			}
			List<QUERY_MESSAGE_TYPE> queries = SdmxMessageUtil.getQueryMessageTypes(submissionData);
			BASE_QUERY_MESSAGE_TYPE baseQuery=null;
			for(QUERY_MESSAGE_TYPE queryMessage : queries) {
				if(baseQuery != null) {
					if(baseQuery != queryMessage.getBaseQueryMessageType()) {
						throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, "Can not query for "+baseQuery.getType()+" and "+queryMessage.getBaseQueryMessageType().getType());
					}
				}
				baseQuery = queryMessage.getBaseQueryMessageType();
			}
			if(baseQuery == null) {
				throw new IllegalArgumentException("Could not process Query Messsage as it did not contain any queries");
			}
			procesPOSTQuery(baseQuery, postRequest, submissionData);
			break;
		case REGISTRY_INTERFACE :
			REGISTRY_MESSAGE_TYPE registryMessageType = SdmxMessageUtil.getRegistryMessageType(submissionData);
			if(registryMessageType.isSubmissionRequest()) {
				if(!securityModel.isAllowStructureSubmission()) {
					throw new SdmxUnauthorisedException(ExceptionCode.SECURITY_UNAUTHORISED, "[Structure Submissions]");
				}
				if(submissionManager == null) {
					throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, "Could not process Submission, StructureSubmissionRequestManager has not been configured");
				}
				return submissionManager.processSubmission(registryMessageType, schemaVersion, submissionData, postRequest, datasetAction);
			} else if(registryMessageType.isQueryRequest()) {
				if(!securityModel.isAllowStructureQueries()) {
					throw new SdmxUnauthorisedException(ExceptionCode.SECURITY_UNAUTHORISED, "[Structure Queries]");
				}
				if(queryStructureRequestManager == null) {
					throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, "Could not process Structure Query, QueryStructureRequestManager has not been configured");
				}
				queryStructureRequestManager.processQuery(submissionData, postRequest);
				return null;
			}  else if(registryMessageType == REGISTRY_MESSAGE_TYPE.QUERY_REGISTRATION_RESPONSE) {
				return submissionManager.processSubmission(registryMessageType, schemaVersion, submissionData, postRequest, datasetAction);
			}
			throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, "Could not process Registry message of type: "+registryMessageType.getType());
		case STRUCTURE :
			if(!securityModel.isAllowStructureSubmission()) {
				throw new SdmxUnauthorisedException(ExceptionCode.SECURITY_UNAUTHORISED, "[Structure Submissions]");
			}
			if(submissionManager == null) {
				throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, "Could not process Submission, StructureSubmissionRequestManager has not been configured");
			}
			return submissionManager.processSubmission(REGISTRY_MESSAGE_TYPE.SUBMIT_STRUCTURE_REQUEST, schemaVersion, submissionData, postRequest, datasetAction);
		default : throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, messageType);
		}
		return null;
	}

	protected void procesPOSTQuery(BASE_QUERY_MESSAGE_TYPE baseQuery, POSTRequest postRequest, ReadableDataLocation submissionData) {
		switch(baseQuery) {
		case STRUCTURE:
			if(queryStructureRequestManager == null) {
				throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, "Could not process Structure Query, QueryStructureRequestManager has not been configured");
			}
			queryStructureRequestManager.processQuery(submissionData, postRequest);
		case SCHEMA:
			if(querySchemaRequestManager == null) {
				throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, "Could not process Schema Query, QuerySchemaRequestManager has not been configured");
			}
			querySchemaRequestManager.processQuery(submissionData, postRequest);
		default:
			throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, baseQuery);
		}
	}

	/**
	 * Writes the error as a general error message
	 * @param th
	 * @return
	 */
	private ISdmxResponse getErrorResponse(Throwable th, boolean jsonFormat) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		errorWriterManager.writeError(th, out, jsonFormat ? JsonErrorFormat.getInstance() : SdmxErrorFormat.getInstance());
		return new SdmxResponse(ErrorUtil.getHTTPStatusCode(th), out.toByteArray());
	}


	protected void writeResponse(ISdmxResponse response, POSTRequest request, ReadableDataLocation rdl) {
		if(response != null) {
			response.writeResponse(request.getOutputStream());
		}
	}

	@Override
	public void processMessage(GETRequest getRequest) throws SdmxNotImplementedException, SdmxUnauthorisedException {
		WebServiceSecurityInfo securityModel = getRequest.getWebServiceRequestInfo().getWebServiceSecurityInfo();
		switch(getRequest.getQueryType()) {
		case STRUCTURE:
			if(!securityModel.isAllowStructureQueries()) {
				throw new SdmxUnauthorisedException(ExceptionCode.SECURITY_UNAUTHORISED, "[Structure Queries]");
			}
			if(queryStructureRequestManager == null) {
				throw new SdmxNotImplementedException("Structure Query Not Implemented");
			}
			SdmxAuditUtil.startSdmxEvent(SDMX_REST_RESOURCE.STRUCTURE.getResource(), HTTP_METHOD.GET, ()-> {
				queryStructureRequestManager.processQuery(getRequest);
			});
			break;
		case SCHEMA:
			if(querySchemaRequestManager == null) {
				throw new SdmxNotImplementedException("Schema Query Not Implemented");
			}
			SdmxAuditUtil.startSdmxEvent(SDMX_REST_RESOURCE.SCHEMA.getResource(), HTTP_METHOD.GET, ()-> {
				querySchemaRequestManager.processQuery(getRequest);
			});
			break;
		case REGISTRATION:
			if(queryRegistrationRequestManager == null) {
				throw new SdmxNotImplementedException("Data Registration Query Not Implemented");
			}
			SdmxAuditUtil.startSdmxEvent(SDMX_REST_RESOURCE.REGISTRATION.getResource(), HTTP_METHOD.GET, ()-> {
				queryRegistrationRequestManager.processQuery(getRequest);
			});
			break;
			default : throw new SdmxNotImplementedException("Query type: "+getRequest.getQueryType());
		}
	}
}