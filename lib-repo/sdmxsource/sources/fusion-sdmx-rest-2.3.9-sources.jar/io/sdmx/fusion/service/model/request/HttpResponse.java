package io.sdmx.fusion.service.model.request;

import java.io.IOException;
import java.io.OutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.http.IResponse;
import io.sdmx.utils.core.date.DateUtil;
import jakarta.servlet.http.HttpServletResponse;

public class HttpResponse implements IResponse {
	private static final Logger LOG = LoggerFactory.getLogger(HttpResponse.class);
	private HttpServletResponse response;
	private OutputStream out;

	public HttpResponse(HttpServletResponse response) {
		this.response = response;
	}

	public HttpResponse(HttpServletResponse response, OutputStream out) {
		this.response = response;
		this.out = out;
	}

	@Override
	public OutputStream getOutputStream() {
		if(out != null) {
			return out;
		}
		try {
			return response.getOutputStream();
		} catch (IOException e) {
			throw new SdmxException(e, "Error getting output stream from client request");
		}
	}

	@Override
	public void setStatus(int status) {
		response.setStatus(status);
	}

	@Override
	public void setContentType(String contentType) {
		response.setContentType(contentType);
	}

	@Override
	public void setLastUpdated(Long epochTime) {
		if(epochTime == null) {
			return;
		}
		response.setHeader("Last-Updated", DateUtil.convertEpochTimeToRFC1123(epochTime));
	}

	@Override
	public void setHeader(String header, String value) {
		response.setHeader(header, value);
	}

	@Override
	public void sendError(int responseCode, String message) {
		try {
			response.sendError(responseCode, message);
		} catch (IOException e) {
			LOG.error("send error failed", e);
		}
	}

}
