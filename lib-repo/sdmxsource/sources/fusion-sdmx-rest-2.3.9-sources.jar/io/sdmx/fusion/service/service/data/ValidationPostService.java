package io.sdmx.fusion.service.service.data;

import java.io.IOException;

import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.service.data.IDataValidationService;
import io.sdmx.fusion.service.model.request.HttpRequest;
import io.sdmx.fusion.service.model.request.HttpResponse;
import io.sdmx.utils.core.application.SingletonStore;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.core.Context;

public class ValidationPostService extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IDataValidationService dataValidationService = SingletonStore.getSingleton(IDataValidationService.class);
	
	@Override
	public void doPost(@Context HttpServletRequest req, @Context HttpServletResponse resp) throws ServletException, IOException {
		Request request = new HttpRequest(req, false);
		IResponse response = new HttpResponse(resp);
		dataValidationService.validateData(request, response);
	}
}
