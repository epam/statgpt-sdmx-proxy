package io.sdmx.fusion.service.filter;

import java.io.IOException;

import io.sdmx.utils.core.thread.ThreadLocalUtil;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;

public class RestFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	    // Left intentionally empty
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse response,FilterChain chain) throws IOException, ServletException {
		final HttpServletRequest request = (HttpServletRequest) req;
		
		ThreadLocalUtil.storeOnThread(ThreadLocalUtil.WEB_SERVICE_TYPE, request.getMethod());
		try {
			chain.doFilter(request, response);
		} finally {
			ThreadLocalUtil.clearFromThread(ThreadLocalUtil.WEB_SERVICE_TYPE);
		}
	}

	@Override
	public void destroy() {
	    // Left intentionally empty
	}
}