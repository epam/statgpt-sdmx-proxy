package io.sdmx.fusion.service.model.request;

import io.sdmx.core.sdmx.format.SdmxStructureFormat;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.format.StructureFormat;

public class WebServiceRequestInfo {
	private DataFormat dataTypeResponseFormat;
	private StructureFormat structureFormat;
	private WebServiceSecurityInfo webServiceSecurityInfo;
	private SDMX_SCHEMA schemaVersion;
	private boolean isDefault = false;
	
	public WebServiceRequestInfo(StructureFormat structureFormat,
			DataFormat dataTypeResponseFormat,
			WebServiceSecurityInfo webServiceSecurityInfo) {
		this.dataTypeResponseFormat = dataTypeResponseFormat;
		this.webServiceSecurityInfo = webServiceSecurityInfo;
		if(structureFormat == null) {
			isDefault = true;
			structureFormat = new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V21_STRUCTURE_DOCUMENT);
		}
		this.structureFormat = structureFormat;
		if(structureFormat.getSdmxOutputFormat() == null) {
			this.schemaVersion = SDMX_SCHEMA.VERSION_TWO_POINT_ONE;
		} else {
			this.schemaVersion = structureFormat.getSdmxOutputFormat().getOutputVersion();
		}
	}

	/**
	 * @return true if the structure format was defaulted
	 */
	public boolean isDefault() {
		return isDefault;	
	}

	public SDMX_SCHEMA getSchemaVersion() {
		return schemaVersion;
	}

	public StructureFormat getStructureFormat() {
		return structureFormat;
	}
	
	public DataFormat getDataTypeResponseFormat() {
		return dataTypeResponseFormat;
	}
	
	public WebServiceSecurityInfo getWebServiceSecurityInfo() {
		return webServiceSecurityInfo;
	} 	
}
