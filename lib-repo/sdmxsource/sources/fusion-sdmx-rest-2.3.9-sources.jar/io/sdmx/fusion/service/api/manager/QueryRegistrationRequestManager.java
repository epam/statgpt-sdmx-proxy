package io.sdmx.fusion.service.api.manager;

import io.sdmx.fusion.service.model.request.GETRequest;

public interface QueryRegistrationRequestManager {

	/**
	 * Processes a schema query message from a REST web service.
	 * <p/>
	 * The GETRequest is expected to have a populated GETRequestRegistrationQuery which identifies the 
	 * schema type to be returned and any filter parameters.  The GETRequest is expected to contain
	 * an output stream, which the results from the query will be written to.  The GETRequest is also 
	 * expected to have a WebServiceRequestInfo specifying the format of the response.
	 * 
	 * @param schemaQuery
	 */
	void processQuery(GETRequest registrationQuery);
}
