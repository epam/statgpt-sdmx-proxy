package io.sdmx.fusion.service.api.manager;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.fusion.service.model.request.GETRequest;
import io.sdmx.fusion.service.model.request.WebServiceRequest;

public interface QuerySchemaRequestManager {

	/**
	 * Processes a schema query message from a REST web service.
	 * <p/>
	 * The GETRequest is expected to have a populated GETRequestSchemaQuery which identifies the 
	 * schema type to be returned and any filter parameters.  The GETRequest is expected to contain
	 * an output stream, which the results from the query will be written to.  The GETRequest is also 
	 * expected to have a WebServiceRequestInfo specifying the format of the response.
	 * 
	 * @param schemaQuery
	 */
	void processQuery(GETRequest schemaQuery);
	
	/**
	 * Process a POST request as a schema query. The dataLocation contains a stream from which the the POSTed document can be read.
	 * @param dataLocation
	 * @param webServiceRequest
	 */
	void processQuery(ReadableDataLocation dataLocation, WebServiceRequest webServiceRequest);
}
