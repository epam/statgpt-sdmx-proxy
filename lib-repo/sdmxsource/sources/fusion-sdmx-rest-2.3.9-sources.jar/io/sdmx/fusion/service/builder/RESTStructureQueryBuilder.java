package io.sdmx.fusion.service.builder;

import java.util.Map;

import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.im.beans.reference.RESTStructureQueryImpl;
import io.sdmx.im.beans.reference.StructureQueryMetadataImpl;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * RESTStructureQuery builder which uses the V1 Web Service - defined in the version 2 SDMX standard
 */
public class RESTStructureQueryBuilder extends AbstractRestStructureQueryBuilder {

	private static RESTStructureQueryBuilder INSTANCE = new RESTStructureQueryBuilder();
	
	private RESTStructureQueryBuilder() { }
	
	/**
	 * Constructs a RESTStructureQuery from the rest query string
	 * @param restString example: /dataflow/ALL/ALL/ALL
	 * @return a RESTStructureQuery object
	 */
	public static RESTStructureQuery build(String restQuery) {
		return build(restQuery, determineQueryParameters(restQuery));
	}

	/**
	 * Constructs a RESTStructureQuery from the rest query string
	 * @param restString example: /dataflow/ALL/ALL/ALL
	 * @param queryParameters
	 * @return a RESTStructureQuery object
	 */
	public static RESTStructureQuery build(String restQuery, Map<String, String> queryParameters) {
		return INSTANCE.buildRESTQuery(restQuery, queryParameters);
	}

	/**
	 * Constructs a RESTStructureQuery from the array of rest query strings
	 * @param queryString
	 * @param queryParameters
	 * @return a RESTStructureQuery object
	 */
	public static RESTStructureQuery build(String[] restQuery, Map<String, String> queryParameters) {
		IURN<?> sRef = INSTANCE.parserQueryString(restQuery);
		return new RESTStructureQueryImpl(sRef, new StructureQueryMetadataImpl(restQuery, queryParameters));
	}

	@Override
	protected String parseVersionString(String query) {
		if(!ObjectUtil.validString(query)) {
			return null;
		}
		if(query.equalsIgnoreCase("all")) {
			return "*";
		}
		// Convert the word "latest" into a "+" symbol so it will be processed correctly
		if(query.equalsIgnoreCase("latest")) {
			return "+";
		}
		return query;
	}

}
