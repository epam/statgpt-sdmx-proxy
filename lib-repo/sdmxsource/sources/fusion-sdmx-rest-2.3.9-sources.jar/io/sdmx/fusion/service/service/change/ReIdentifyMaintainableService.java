package io.sdmx.fusion.service.service.change;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;

import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.service.change.IReIndentifactionService;
import io.sdmx.format.json.engine.structure.writer.sdmx.v1.SdmxJsonStructureWriterEngine;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;

@Path("/change")
public class ReIdentifyMaintainableService extends AbstractRestService {

    private static final Logger LOG = LoggerFactory.getLogger(ReIdentifyMaintainableService.class);

    private IReIndentifactionService reIdentificationService = SingletonStore.getSingleton(IReIndentifactionService.class);

    /**
     * Re-identifies the source reference to the target. The expected JSON is of the format:
     * {
     *    "srcRef": "urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow=TEST_ACY_1:DF_1(1.0)",
     *    "tgtRef": "urn:sdmx:org.sdmx.infomodel.datastructure.Dataflow=TEST_ACY_2:DF_5(9.9)",
     * }
     */
    @POST
    @Path("/reIdentifyMaintainable")
    @Produces(MediaType.APPLICATION_JSON_VALUE)
    public Response reIdentify(String jsonPost) {
        LOG.debug("saveEmailErrorSubscriber");
        return super.performWebService(response -> {
            JSONObject jsonObject = new JSONObject(jsonPost);
            SdmxBeans modifiedBeans = reIdentificationService.reIdentifyMaintainable(jsonObject);
            OutputStream out = new ByteArrayOutputStream();
            SdmxJsonStructureWriterEngine writer = SdmxJsonStructureWriterEngine.getInstance();
            writer.writeStructures(modifiedBeans, null, out);
            return out;
        });
    }

}
