package io.sdmx.fusion.service.model.customrxjs;

// PRL - why did you comment this out?
public class RestProviderConfig { // extends ResourceConfig{
//	public RestProviderConfig() {
//		property("jersey.config.server.provider.packages", "io.sdmx.fusion.service.model.customrxjs");
//    }
}
