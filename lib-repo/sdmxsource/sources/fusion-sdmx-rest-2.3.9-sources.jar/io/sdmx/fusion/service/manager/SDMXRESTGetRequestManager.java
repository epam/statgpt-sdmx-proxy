package io.sdmx.fusion.service.manager;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.HTTP_METHOD;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.fusion.service.api.engine.ISDMXRESTRequestEngine;
import io.sdmx.fusion.service.api.manager.ISDMXRESTRequestManager;
import io.sdmx.utils.core.application.FusionBeanStore;
import io.sdmx.utils.core.audit.AuditUtil;

public class SDMXRESTGetRequestManager implements ISDMXRESTRequestManager {
	private Table<IResource, ISdmxVersion, ISDMXRESTRequestEngine> getEngines;
	private Table<IResource, ISdmxVersion, ISDMXRESTRequestEngine> postEngines;
	private Table<IResource, ISdmxVersion, ISDMXRESTRequestEngine> deleteEngines;
	
	@Override
	public void processRequest(InformationFormat responseFormat, ISdmxVersion apiVersion, IResource resourceType, Request request, IResponse response) {
		if(responseFormat != null && responseFormat.getFormatDetails() != null) {
			AuditUtil.addAuditProperty("ResponseFormat", responseFormat.getFormatDetails().getFormatAsString());
		}
		getEngine(resourceType, apiVersion, request.getMethod()).processRequest(responseFormat, request, response);
	}
	
	private ISDMXRESTRequestEngine getEngine(IResource resource, ISdmxVersion apiVersion, HTTP_METHOD method) {
		if(this.getEngines == null) {
			setup();
		}
		ISDMXRESTRequestEngine engine = null;
		switch(method) {
		case DELETE:
			 engine = deleteEngines.get(resource, apiVersion);
			break;
		case GET:
		case HEAD:
			 engine = getEngines.get(resource, apiVersion);
			break;
		case POST:
			 engine = postEngines.get(resource, apiVersion);
			break;
		default:
			break;
		}
		if(engine == null) {
			throw new SdmxNotImplementedException(resource.getResource()+" resource not supported for API version "+apiVersion.getMajor());
		}
		return engine;
	}

	private void setup() {
		Table<IResource, ISdmxVersion, ISDMXRESTRequestEngine> getEngines = HashBasedTable.create();
		Table<IResource, ISdmxVersion, ISDMXRESTRequestEngine> postEngines = HashBasedTable.create();
		Table<IResource, ISdmxVersion, ISDMXRESTRequestEngine> deleteEngines = HashBasedTable.create();
		for(ISDMXRESTRequestEngine queryEngine : FusionBeanStore.getBeans(ISDMXRESTRequestEngine.class)) {
			switch(queryEngine.getSupportedMethod()) {
			case DELETE:
				deleteEngines.put(queryEngine.getResourceType(), queryEngine.getRestVersion(), queryEngine);
				break;
			case GET:
				getEngines.put(queryEngine.getResourceType(), queryEngine.getRestVersion(), queryEngine);
				break;
			case POST:
				postEngines.put(queryEngine.getResourceType(), queryEngine.getRestVersion(), queryEngine);
				break;
			default:
				break;
			}
		}
		this.deleteEngines = deleteEngines;
		this.getEngines = getEngines;
		this.postEngines = postEngines;
	}
}
