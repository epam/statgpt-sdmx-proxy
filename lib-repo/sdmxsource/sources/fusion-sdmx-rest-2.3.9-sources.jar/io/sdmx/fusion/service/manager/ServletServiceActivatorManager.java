package io.sdmx.fusion.service.manager;

import io.sdmx.api.format.IResponseFormatManager;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.fusion.service.api.manager.ISDMXRESTRequestManager;
import io.sdmx.fusion.service.api.manager.IServletServiceActivatorManager;

public class ServletServiceActivatorManager implements IServletServiceActivatorManager {
	private ISDMXRESTRequestManager getRequestManager; 
	
	public ServletServiceActivatorManager(ISDMXRESTRequestManager getRequestManager, IResponseFormatManager reponseFormatManager) {
		this.getRequestManager = getRequestManager;
	}


	@Override
	public void processRequest(Request request, IResource resource, IResponse response, ISdmxVersion apiVersion, InformationFormat responseFormat) {
		getRequestManager.processRequest(responseFormat, apiVersion, resource, request, response);
	}
	
}
