package io.sdmx.fusion.service.model.request;

import io.sdmx.api.http.IResource;

public class Resource implements IResource {
	private String resource;
	
	public static IResource getInstance(String resource) {
		return new Resource(resource);
	}
	
	private Resource(String resource) {
		this.resource = resource;
	}

	@Override
	public String getResource() {
		return resource;
	}

	@Override
	public int hashCode() {
		return resource.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof IResource) {
			return resource.equals(obj.toString());
		}
		return false;
	}

	@Override
	public String toString() {
		return resource;
	}

	
	
}
