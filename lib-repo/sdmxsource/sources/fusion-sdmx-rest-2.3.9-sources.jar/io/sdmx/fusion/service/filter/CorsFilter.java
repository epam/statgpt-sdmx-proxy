package io.sdmx.fusion.service.filter;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.cache.Cache;
import io.sdmx.api.http.CORSBase;
import io.sdmx.api.http.CORSSettingsRetrievalManager;
import io.sdmx.api.notification.Listener;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class CorsFilter implements Listener<List<CORSBase>>, Filter, Cache {
	private static final Logger LOG = LoggerFactory.getLogger(CorsFilter.class);

	private CORSSettingsRetrievalManager corsManager;
	private Map<String, CORSBase> domainMap;
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		corsManager = SingletonStore.getSingleton(CORSSettingsRetrievalManager.class);
		rebuildDomainMap(corsManager.getCORSSettings());
		corsManager.registerListener(this);
	}


	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		if (request instanceof HttpServletRequest) {
			
			if (domainMap == null)
			{
				rebuildDomainMap(corsManager.getCORSSettings());
			}
			
			HttpServletRequest httpReq = ((HttpServletRequest) request);
			String origin = httpReq.getHeader("Origin");

			if (ObjectUtil.validString(origin)) {
				if(LOG.isDebugEnabled()) {
					LOG.debug("CORS filter - request origin = " + origin);
				}
				ThreadLocalUtil.storeOnThread(ThreadLocalUtil.REQUEST_ORIGIN, origin);

				CORSBase corsEntry = domainMap.get(origin.toLowerCase());

				if (corsEntry == null) {
					corsEntry = domainMap.get("*");
				}

				if (corsEntry != null) {
					if (response instanceof HttpServletResponse) {
						HttpServletResponse httpResp = (HttpServletResponse) response;

						StringBuilder methods = new StringBuilder();
						StringBuilder headers = new StringBuilder();
						StringBuilder exposeHeaders = new StringBuilder();

						for (String method : corsEntry.getMethods()) {
							methods.append(method + ", ");
						}

						if (methods.length() != 0) {
							methods.delete(methods.lastIndexOf(", "), methods.length());
						}

						for (String header : corsEntry.getHeaders()) {
							headers.append(header + ", ");
						}

						if (headers.length() != 0) {
							headers.delete(headers.lastIndexOf(", "), headers.length());
						}

						for (String header : corsEntry.getExposedHeaders()) {
							exposeHeaders.append(header + ", ");
						}
						
						if (exposeHeaders.length() != 0) {
							exposeHeaders.delete(exposeHeaders.lastIndexOf(", "), exposeHeaders.length());
						}

						httpResp.addHeader("Access-Control-Allow-Methods", methods.toString());
//						httpResp.addHeader("Allow", methods.toString());
						httpResp.addHeader("Access-Control-Expose-Headers", exposeHeaders.toString());
						httpResp.addHeader("Access-Control-Allow-Origin", origin);
						String heads = headers.toString();
						httpResp.addHeader("Access-Control-Allow-Headers", heads);
						//httpResp.addHeader("Access-Control-Expose-Headers", "*");
						httpResp.addHeader("Access-Control-Allow-Credentials",
								String.valueOf(corsEntry.getAllowCreds()));
						httpResp.addHeader("Access-Control-Max-Age", "1800");
					}
				}
			}

		}

		try {
			chain.doFilter(request, response);
		}

		finally {
			ThreadLocalUtil.clearFromThread(ThreadLocalUtil.REQUEST_ORIGIN);
		}

		//
		// if(response instanceof HttpServletResponse) {
		// HttpServletResponse httpResp = (HttpServletResponse)response;
		// httpResp.addHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS,
		// POST");
		// httpResp.addHeader("Allow", "GET, HEAD, OPTIONS, POST");
		// httpResp.addHeader("Access-Control-Expose-Headers", "Content-Disposition");
		// if (request instanceof HttpServletRequest) {
		// HttpServletRequest httpReq = (HttpServletRequest)request;
		//
		//
		//
		// String origin = httpReq.getHeader("Origin");
		// if(ObjectUtil.validString(origin)) {
		// LOG.info("CORS filter - request origin = "+origin);
		// ThreadLocalUtil.storeOnThread(ThreadLocalUtil.REQUEST_ORIGIN, origin);
		// httpResp.addHeader("Access-Control-Allow-Origin", origin);
		// }
		// String requestH=httpReq.getHeader("Access-Control-Request-Headers");
		//
		// if(ObjectUtil.validString(requestH)) {
		// httpResp.addHeader("Access-Control-Allow-Headers", requestH);
		// }
		// }
		// }
		// try {
		// chain.doFilter(request,response);
		// } finally {
		// ThreadLocalUtil.clearFromThread(ThreadLocalUtil.REQUEST_ORIGIN);
		// }
	}

	@Override
	public void destroy() {
		// Left intentionally empty
	}

	@Override
	public void invoke(List<CORSBase> settings) {
		rebuildDomainMap(settings);
	}

	private void rebuildDomainMap(List<CORSBase> settings) {
		Map<String, CORSBase> newDomainMap = new HashMap<>();

		for (CORSBase entry : settings) {
			newDomainMap.put(entry.getUrl().toLowerCase(), entry);
		}
		this.domainMap = newDomainMap;
	}

	@Override
	public void clearCache() {
		domainMap = null;
	}

}