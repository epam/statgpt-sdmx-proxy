package io.sdmx.fusion.service.service.audit;

import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.service.audit.IAuditService;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.json.JsonObjectUtil;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/audit")
public class AuditService extends AbstractRestService {

	private IAuditService auditService = SingletonStore.getSingleton(IAuditService.class);
	

	@GET
	@Path("/log/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	/**
	 * Writes the logs for the audit with the given id, format:
	 * 
	 * 	<pre>
	 * 	{
	 * 		"AuditId" : "uid",
	 * 		"Logs" 	  : [
	 * 			{
	 * 				"LogLevel" : "DEBUG"
	 * 				"LogName" : "org.bis.MyClassName"
	 * 				"Message" : "log message"
	 * 				"Time" : 123456789
	 * 			}
	 * 			...
	 * 		]
	 *  }
	 * </pre>
	 * @return
	 */
	public Response writeAuditLogs(final @PathParam("id") String id,
			final @QueryParam("children") Boolean includeChildren,
			final @QueryParam("ancestors") Boolean includeAncestor) {
		return super.streamWriter( out -> {
			auditService.writeAuditLogs(id, includeChildren, includeAncestor, out);
		});
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	/**
	 * Writes the audit with the given id, 	writes an Array of objects
	 * <pre>
	 * [
	 *   {
	 *   	"UID" : "uid",
	 *   	"Parent" : null,
	 *   	"ProcessId" : "SAVE_DATA",
	 *   	"Username" : "mnelson",
	 *   	"ProcessStart" : 1234567,
	 *   	"ProcessEnd" : 12345678,
	 *   	"Status" : 200,
	 *   	"IsError" : false,
	 *   	"UID" : "",
	 *   	"Properties" : {					--only if not a stub
	 *   		"key" : "value"
	 *      },
	 *      "VMID" : "",
	 *      "MachineId" : "",
	 *      "SoftwareVersion" : "",
	 *   }
	 * ]
	 * </pre>
	 * @return
	 * 
	 * @param id
	 * @param includeChildren if true will include child audits (if the process was multithreadded)
	 * @param includeAncestor if true will include parent audits (if the process was multithreadded)
	 * @return
	 */
	public Response findById(final @PathParam("id") String id,
			final @QueryParam("children") Boolean includeChildren,
			final @QueryParam("ancestors") Boolean includeAncestor) {
		return super.streamWriter( out -> {
			auditService.writeAudits(id, includeChildren, includeAncestor, out);
		});
	}
	
	@GET
	@Path("/")
	@Produces(MediaType.APPLICATION_JSON)
	/**
	 * 
	 */
	public Response find(final @QueryParam("parent") String parentId,
			final @QueryParam("properties") String properties,
			final @QueryParam("software_version") String softwareVersion,
			final @QueryParam("username") String username,
			final @QueryParam("process_id") String processId,
			final @QueryParam("event_type") String eventType,
			final @QueryParam("ip") String ip,
			final @QueryParam("process_start") String startPeriod,
			final @QueryParam("process_end") String endPeriod,
			final @QueryParam("children") Boolean includeChildren,
			final @QueryParam("ancestors") Boolean includeAncestor,
			final @QueryParam("max_duration") Long maxDuration,
			final @QueryParam("min_duration") Long minDuration,
			final @QueryParam("status") Integer status,
			final @QueryParam("limit") Integer limit,
			final @QueryParam("offset") Integer offset) {
		return super.streamWriter( out -> {
			JSONObject json = new JSONObject();
			JsonObjectUtil.writeString(json, "process_id", processId);
			JsonObjectUtil.writeString(json, "event_type", eventType);
			JsonObjectUtil.writeString(json, "parent", parentId);
			JsonObjectUtil.writeString(json, "ip", ip);
			JsonObjectUtil.writeString(json, "username", username);
			JsonObjectUtil.writeString(json, "software_version", softwareVersion);
			if(startPeriod != null) {
				JsonObjectUtil.writeLong(json, "process_start", DateUtil.formatDate(startPeriod, true).getTime());
			}
			if(endPeriod != null) {
				JsonObjectUtil.writeLong(json, "process_end", DateUtil.formatDate(endPeriod, false).getTime());
			}
			JsonObjectUtil.writeLong(json, "max_duration", maxDuration);
			JsonObjectUtil.writeLong(json, "min_duration", minDuration);

			JsonObjectUtil.writeInteger(json, "status", status);
			JsonObjectUtil.writeInteger(json, "offset", offset);
			JsonObjectUtil.writeInteger(json, "limit", limit);
			

			JsonObjectUtil.writeBoolean(json, "children", includeChildren);
			JsonObjectUtil.writeBoolean(json, "ancestors", includeAncestor);
			auditService.writeAudits(json, out);
		});
	}
}
