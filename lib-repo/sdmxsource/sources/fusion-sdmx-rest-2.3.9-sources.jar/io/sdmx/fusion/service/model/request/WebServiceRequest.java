package io.sdmx.fusion.service.model.request;

import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebServiceRequest {
	private static final Logger LOG = LoggerFactory.getLogger(WebServiceRequest.class);
	
	protected OutputStream outputStream;
	private WebServiceRequestInfo webServiceRequestInfo;
	private boolean returnStructuresAsRegistryStructureResponse;
	
	public WebServiceRequest(OutputStream outputStream,
			WebServiceRequestInfo webServiceRequestInfo,
			boolean returnStructuresAsRegistryStructureResponse) {
		this.outputStream = outputStream;
		this.webServiceRequestInfo = webServiceRequestInfo;
		this.returnStructuresAsRegistryStructureResponse = returnStructuresAsRegistryStructureResponse;
	}
	
	public boolean zipOutput(String fileName) {
		ZipOutputStream out = new ZipOutputStream(outputStream);
		// Add ZIP entry to output stream.
		try {
			out.putNextEntry(new ZipEntry(fileName));
			outputStream = out;
			return true;
		} catch (IOException e) {
			LOG.error("Could not create zip output - revert to standard output stream", e);
			return false;
		}
	}
	
	public OutputStream getOutputStream() {
		return outputStream;
	}
	public WebServiceRequestInfo getWebServiceRequestInfo() {
		return webServiceRequestInfo;
	}
	public boolean isReturnStructuresAsRegistryStructureResponse() {
		return returnStructuresAsRegistryStructureResponse;
	}

}
