package io.sdmx.fusion.service.model.servletresponse;

import java.io.IOException;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.WriteListener;

public class ProxyResponseWrapper extends ServletOutputStream {
	private ServletOutputStream proxy;
	
	public ProxyResponseWrapper(ServletOutputStream proxy) {
		this.proxy = proxy;
	}

	@Override
	public void print(String s) throws IOException {
		this.proxy.print(s);
	}

	@Override
	public void print(boolean b) throws IOException {
		this.proxy.print(b);
	}

	@Override
	public void print(char c) throws IOException {
		this.proxy.print(c);
	}

	@Override
	public void print(int i) throws IOException {
		this.proxy.print(i);
	}

	@Override
	public void print(long l) throws IOException {
		this.proxy.print(l);
	}

	@Override
	public void print(float f) throws IOException {
		this.proxy.print(f);
	}

	@Override
	public void print(double d) throws IOException {
		this.proxy.print(d);
	}

	@Override
	public void println() throws IOException {
		this.proxy.println();
	}

	@Override
	public void println(String s) throws IOException {
		this.proxy.println(s);
	}

	@Override
	public void println(boolean b) throws IOException {
		this.proxy.println(b);
	}

	@Override
	public void println(char c) throws IOException {
		this.proxy.println(c);
	}

	@Override
	public void println(int i) throws IOException {
		this.proxy.println(i);
	}

	@Override
	public void println(long l) throws IOException {
		this.proxy.println(l);
	}

	@Override
	public void println(float f) throws IOException {
		this.proxy.println(f);
	}

	@Override
	public void println(double d) throws IOException {
		this.proxy.println(d);
	}

	@Override
	public void write(int b) throws IOException {
		this.proxy.write(b);
	}

	@Override
	public void write(byte[] b) throws IOException {
		this.proxy.write(b);
	}

	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		this.proxy.write(b, off, len);
	}

	@Override
	public void flush() throws IOException {
		this.proxy.flush();
	}

	@Override
	public void close() throws IOException {
		this.proxy.close();
	}

	@Override
	public boolean isReady() {
		return this.proxy.isReady();
	}

	@Override
	public void setWriteListener(WriteListener writeListener) {
		this.proxy.setWriteListener(writeListener);
	}
}
