package io.sdmx.fusion.service.api.manager;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.fusion.service.model.request.GETRequest;
import io.sdmx.fusion.service.model.request.WebServiceRequest;

public interface IGETRequestStructureQueryManager {
	/**
	 * Processes a query message, this could either be a query structure/provision/registration/data 
	 * <p/>
	 * The query may also be in the form of a QueryMessage document (non-registry)
	 * <p/>
	 * The response is written to the output stream in the version of SDMX specified
	 * 
	 * @param uri - the location of the submitted SDMX query 
	 * @param webServiceRequest - the request
	 */
	void processQuery(ReadableDataLocation dataLocation, WebServiceRequest webServiceRequest);
	
	/**
	 * Processes a structure query message from a REST web service.
	 * <p/>
	 * The GETRequest is expected to have a populated GETRequestStructureQuery which identifies the 
	 * structure type to be returned and any filter parameters.  the GETRequest is expected to contain
	 * an output stream, which the results from the query will be written to.  The GETRequest is also 
	 * expected to have a WebServiceRequestInfo specifying the format of the response.
	 * 
	 * @param structureQuery
	 */
	void processQuery(GETRequest structureQuery);
}
