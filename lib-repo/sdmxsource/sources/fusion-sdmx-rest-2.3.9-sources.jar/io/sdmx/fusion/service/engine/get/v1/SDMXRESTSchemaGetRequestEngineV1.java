package io.sdmx.fusion.service.engine.get.v1;

import io.sdmx.api.sdmx.manager.schema.ISdmxSchemaManager;
import io.sdmx.fusion.service.engine.get.SDMXRESTSchemaGetRequestEngineAbstract;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class SDMXRESTSchemaGetRequestEngineV1 extends SDMXRESTSchemaGetRequestEngineAbstract {

	public SDMXRESTSchemaGetRequestEngineV1(ISdmxSchemaManager schemaManager) {
		super(schemaManager,  SdmxVersion.getInstance(1, 0, 0));
	}

}
