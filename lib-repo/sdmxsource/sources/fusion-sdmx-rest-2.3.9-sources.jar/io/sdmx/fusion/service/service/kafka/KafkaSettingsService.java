package io.sdmx.fusion.service.service.kafka;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;

import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.service.kafka.IKafkaSettingsService;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Response;

@Path("/settings/kafka")
public class KafkaSettingsService extends AbstractRestService {
	private static final Logger LOG = LoggerFactory.getLogger(KafkaSettingsService.class);

	private IKafkaSettingsService kafkaSettingsService = SingletonStore.getSingleton(IKafkaSettingsService.class);
	
	@GET
	@Path("/email/admin")
	@Produces("application/json")
	public final Response getEmailErrorSubscriber() {
		LOG.debug("getEmailErrorSubscriber");
		return super.performWebService(response -> {
			return kafkaSettingsService.getEmailErrorSubscriber();
		});
	}

	@POST
	@Path("/email/admin")
	@Produces("application/json")
	public final Response saveEmailErrorSubscriber(String email) {
		LOG.debug("saveEmailErrorSubscriber");
		return super.performWebService(response -> {
			kafkaSettingsService.saveEmailErrorSubscriber(email);
			return getSuccess();
		});
	}

	@DELETE
	@Path("/email/admin")
	@Produces("application/json")
	public final Response deleteEmailErrorSubscriber() {
		LOG.debug("deleteEmailErrorSubscriber");
		return super.performWebService(response -> {
			kafkaSettingsService.deleteEmailErrorSubscriber();
			return getSuccess();
		});
	}
	
	@GET
	@Path("/regStartupAction")
	@Produces("application/json")
	public final Response getRegistryStartupAction() {
		LOG.debug("getRegistryStartupAction");
		return super.performWebService(response -> {
			return kafkaSettingsService.getRegistryStartupAction();
		});
	}
	
	@POST
	@Path("/regStartupAction")
	@Produces("application/json")
	public final Response saveRegistryStartupAction(String startupAction) {
	    LOG.debug("saveRegistryStartupAction");
	    return super.performWebService(response -> {
			kafkaSettingsService.saveRegistryStartupAction(startupAction);
			return getSuccess();
		});
	}


	@GET
	@Path("/producer/tx/{id}")
	@Produces("application/json")
	/**
	 * Returns the transaction history for the structure producer in the format
	 * <pre>
	 * [
	 *   {
	 *   	"Tx" : "1",
	 *   	"StartTime" : 123123,
	 *   	"EndTime" : 55555,
	 *   	"Messages" : 2,
	 *   	"Size" : 1234,
	 *   	"Status" : 1,
	 *   }
	 * ]
	 * </pre>
	 *
	 * @return
	 */
	public final Response getTransactions(final @PathParam("id") String producerId,  final @QueryParam("lastN") Integer lastN) {
		LOG.debug("getTransactions request structure producer");
		return super.performWebService(response -> {
			return kafkaSettingsService.getTransactions(producerId, lastN);
		});
	}

	@POST
	@Path("/producer/status/structure")
	@Produces("application/json")
	/**
	 * Posts an action for the kafka producer:
	 * START_NO_ACTION,
	 * START_LAST_TX,
	 * START_FULL_FLUSH
	 * STOP
	 */
	public final Response updateProducerStatus(String jsonPost) {
		LOG.debug("chageProducerStatus request");
		return super.performWebService(response -> {
			kafkaSettingsService.updateProducerStatus(jsonPost);
			return getSuccess();
		});
	}

	@POST
	@Path("/connection")
	@Produces("application/json")
	/**
	 * Posts JSON connection for a service
	 * <pre>
	 * {
	 * 	connection.key : value
	 * }
	 * </pre>
	 *
	 * @return
	 */
	public final Response setKafkaConnection(String jsonPost) {
		LOG.debug("setKafkaConnection request");
		return super.performWebService(response -> {
			JSONObject connJSON = new JSONObject(jsonPost);
			kafkaSettingsService.setKafkaConnection(connJSON);
			return getSuccess();
		});
	}


	@DELETE
	@Path("/connection")
	@Produces("application/json")
	/**
	 * Posts JSON connection for a service
	 * @return
	 */
	public final Response deleteKafkaConnection() {
		LOG.debug("deleteKafkaConnection request");
		return super.performWebService(response -> {
			kafkaSettingsService.deleteKafkaConnection();
			return getSuccess();
		});
	}

	@GET
	@Path("/connection")
	@Produces("application/json")
	/**
	 * returns JSON connection for the requested service type
	 * <pre>
	 * {
	 * 	key : value
	 * }
	 * </pre>
	 *
	 * If the object does not exists, writes and empty object
	 * <pre>
	 * { }
	 * </pre>
	 * @return
	 */
	public final Response getKafkaConnection() {
		LOG.debug("getKafkaConnection request");
		return super.performWebService(response -> {
			return kafkaSettingsService.getKafkaConnection();
		});
	}


	@GET
	@Path("/connection/describe")
	@Produces("application/json")
	/**
	 * returns a description of each setting along with default value
	 * <pre>
	 * {
	 *   key : {
	 *   	"description" : ""
	 *   }
	 * }
	 * </pre>
	 *
	 * If the object does not exists, writes and empty object
	 * <pre>
	 * { }
	 * </pre>
	 * @return
	 */
	public final Response getKafkaConnectionSettings() {
		LOG.debug("getKafkaConnectionSettings request");
		return super.performWebService(response -> {
			return kafkaSettingsService.getKafkaConnectionSettings();
		});
	}

	@GET
    @Path("/connection/test/{topic}")
    @Produces("application/json")
	/**
	 * Sends a series of test messages to the given topic to produce the following report:
	 * @param topic can be any topic,
	 *
	 * {
	 * 	"Topic" : "TopicName",
	 *  "TestStart" : 12345,
	 *  "TestEnd"  : 12345
	 *  "SucessMessages" : 2
	 *  "FailedMessages" : 0,
	 *  "MaxBytes" : 31200,
	 *  "Messages" : [
	 *    {
	 *      "SizeBytes" : 123,
	 *      "DurationMs"  : 50
	 *      "Success"     : false,
	 *      "Error"       : "Message"  //optional
	 *    }
	 *  ]
	 * }
	 *
	 */
	public final Response generateTestMessage(@PathParam("topic") final String topic, @QueryParam("maxMessages") int maxMessages, @QueryParam("maxBytes") int maxBytes) {
        return super.performWebService(response -> {
        	OutputStream out = new ByteArrayOutputStream();
        	kafkaSettingsService.generateTestMessage(topic, maxMessages, maxBytes, out);
            return out;
        });
    }


	@GET
	@Path("/producer/config/{id}")
	@Produces("application/json")
	/**
	 * Writes all the topic configurations including topics which are not configured
	 * (yet) to talk to a kafka queue
	 *
	 * <pre>
	 *  {
	 *    Producer: "structure",
	 *    Topic: "structure.topic",
	 *    Format: "application/vnd.sdmx.json",
	 *  }
	 *  </pre>
	 * @return
	 */
	public final Response getProducer(final @PathParam("id") String producerId) {
		LOG.debug("getTopics request");
		return super.performWebService(response -> {
			OutputStream out = new ByteArrayOutputStream();
			kafkaSettingsService.getProducer(producerId, out);
			return out;
		});
	}

	@POST
	@Path("/producer/config/{id}")
	@Produces("application/json")
	/**
	 * Posts JSON connection for a service
	 * <pre>
	 * {
	 *     Producer: "structure",
	 *     Topic: "structure.topic",
	 *     Format: "application/vnd.sdmx.json",
	 *     Properties : [
	 *     	{
	 *         "Key" : "exclude",
	 *         "Value" : "codelist"
	 *      }
	 *     ]
	 * }
	 * </pre>
	 *
	 * @return
	 */
	public final Response setProducer(final @PathParam("id") String producerId, String jsonPost) {
		LOG.debug("setProducer request");
		return super.performWebService(response -> {
			JSONObject json = new JSONObject(jsonPost);
			kafkaSettingsService.setProducer(producerId, json);
			return getSuccess();
		});
	}


	@DELETE
	@Path("/producer/config/{id}")
	@Produces("application/json")
	/**
	 * Deletes a topic configuration
	 */
	public Response deleteProducer(final @PathParam("id") String producerId) {
		LOG.debug("deleteProducer request");
		return super.performWebService( request -> {
			kafkaSettingsService.deleteProducer(producerId);
			return super.getSuccess();
		});
	}
}
