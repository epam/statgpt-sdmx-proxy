package io.sdmx.fusion.service.engine.delete.v2;

import java.util.Set;
import java.util.stream.Collectors;

import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.manager.persist.IMetadataPersistenceManager;
import io.sdmx.api.sdmx.manager.structure.IQueryMetadataRequestManager;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.query.IRESTMetadataQuery;
import io.sdmx.fusion.service.api.engine.ISDMXRESTDeleteRequestEngine;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.im.beans.reference.RESTMetadataQuery;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class SDMXRESTDeleteMetadataRequestEngineV2 implements ISDMXRESTDeleteRequestEngine {
	private static final ISdmxVersion REST_VERSION = SdmxVersion.getInstance(2, 0, 0);

	private IQueryMetadataRequestManager queryMetadataRequestManager;
	private IMetadataPersistenceManager metadataPersistenceManager;
	
	public SDMXRESTDeleteMetadataRequestEngineV2(IQueryMetadataRequestManager queryMetadataRequestManager, IMetadataPersistenceManager metadataPersistenceManager) {
		this.queryMetadataRequestManager = queryMetadataRequestManager;
		this.metadataPersistenceManager = metadataPersistenceManager;
	}

	@Override
	public void processRequest(InformationFormat responseFormat, Request request, IResponse response) {
		IRESTMetadataQuery metadataQuery = new RESTMetadataQuery(request);
		IReferenceMetadataContainer container = null;
		try {
		    container = queryMetadataRequestManager.processQuery(metadataQuery);
		} catch(SdmxNoResultsException e) {
		    //no metadata to delete
		}
		if(container != null) {
		    Set<IURNMaintainable<IReportedMetadataSetBean>> urns = container.getReferenceMetadata().stream().map(e->e.getURN()).collect(Collectors.toSet());
		    metadataPersistenceManager.deleteMetadata(urns);
		}
	}

	@Override
	public IResource getResourceType() {
		return SDMX_REST_RESOURCE.METADATA.getResource();
	}

	@Override
	public ISdmxVersion getRestVersion() {
		return REST_VERSION;
	}
}
