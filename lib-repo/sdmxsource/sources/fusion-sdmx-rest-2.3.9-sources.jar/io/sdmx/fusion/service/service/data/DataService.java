package io.sdmx.fusion.service.service.data;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;

import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import io.sdmx.api.exception.HttpException;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.io.WriteableDataLocationFactory;
import io.sdmx.api.service.data.IAsyncDataService;
import io.sdmx.fusion.service.model.request.HttpRequest;
import io.sdmx.fusion.service.model.servletresponse.StreamingResponseWriter;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.error.ErrorReport;
import io.sdmx.utils.json.ErrorUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.StreamingOutput;

@Path("/data")
/**
 * The load service is called to load a dataset, further functions of Download, Transform, Revalidate can be called by passing in the UID
 * for the dataset loaded in.
 */
public class DataService extends AbstractRestService {

	@Autowired
	private IAsyncDataService dataService = SingletonStore.getSingleton(IAsyncDataService.class);


	@Autowired
	private WriteableDataLocationFactory wdlFactory = SingletonStore.getSingleton(WriteableDataLocationFactory.class);
	
	@POST
	@Path("/load")
	@Produces("application/json")
	/**
	 * Loads a dataset, and writes the uid back to the client, which can be used in future calls to obtain the Dataset details
	 * @param httpResponse
	 * @param request
	 * @return
	 */
	public StreamingOutput performDataLoad(final @Context HttpServletResponse httpResponse, @Context final HttpServletRequest request) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) {
				Request req = new HttpRequest(request);
				String uid;
				try {
					uid = dataService.performDataLoad(req);
				} catch (HttpException e) {
					ErrorUtil.writeError(e.getErrorMessage(), e.getHttpErrorCode(), out);
					return;
				} catch (Throwable th) {
					writeError(th, out);
					return;
				}
				if(uid == null) {
					return;
				}
				// Send JSON success message back
				httpResponse.setStatus(200);
				httpResponse.setContentType("application/json");
				JSONObject successResponse = new JSONObject();
				try {
					successResponse.put("Success", true);
					successResponse.put("uid",uid);
					OutputStreamWriter writer = new OutputStreamWriter(httpResponse.getOutputStream());
					successResponse.write(writer);
					writer.close();
				} catch (Throwable th) {
					writeError(th, out);
				}
			}
		};
	}

	@GET
	@Path("/loadStatus")
	@Produces("application/json")
	/**
	 * Returns information about the dataset (load status, content, validity) identified with the given UID, example response JSON
	 * {
	 * 	Status : [LOADING_STATUS]
	 *  DatasetDetails : {  		//optional
	 *    seriesCount : num
	 *    obsCount : num
	 *  }
	 *  Error : error				//optional
	 * }
	 * @param uid
	 * @return
	 */
	public StreamingOutput loadStatus(final @QueryParam("uid") String uid) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) {
				try {
					dataService.writeLoadStatus(uid, out);
				} catch (Throwable th) {
					writeError(th, out);
				}
			}
		};
	}

	@POST
	@Path("/revalidate")
	@Produces("application/json")
	/**
	 * Asynchronous request to re-validate a previously validated Dataset (stored against a uid), against the structure with the given URN, the loadStatus can be found by calling the load status method
	 *
	 * Expects a JSON message containing the UID and the Structure URN to use for each dataset, example:
	 * {
	 *   UID  : "uid",
	 *   SRef : ["urn1", "urn2", urn3"]
	 * }
	 *
	 *
	 * @param uid
	 * @return
	 */
	public StreamingOutput revalidate(final String post) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) {
				try {
					JSONObject json = new JSONObject(post);
					dataService.revalidate(json, out);
					writeSuccess(out);
				} catch (Throwable th) {
					writeError(th, out);
				}
			}
		};
	}

	@POST
	@Path("/map")
	/**
	 * Maps a previously loaded Dataset (defined by the UID) -
	 *
	 * Expects a JSON message containing the UID and the Structure URN to use for each dataset, example:
	 * {
	 *   UID  : "uid",
	 *   IDX : 0,
	 *   Map : "urn"
	 * }
	 *
	 *
	 * @param uid
	 * @return
	 */
	public StreamingOutput map(final String post) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) {
				try {
					JSONObject json = new JSONObject(post);
					dataService.map(json);
					writeSuccess(out);
				} catch (Throwable th) {
					writeError(th, out);
				}
			}
		};
	}

	@GET
	@Path("/download")
	/**
	 * Downloads a previously loaded dataset (defined by the UID) in the requested format, optionally mapped
	 * @param uid
	 * @param format
	 * @param resolveCodes
	 * @param delimiter
	 * @param keyDelimiter
	 * @param xAxis
	 * @param senderId
	 * @param datasetIndex
	 * @param map
	 * @param isZip
	 * @param includeUnmappedData
	 * @param includeMetrics
	 * @param request
	 * @return
	 */
	public Response getData(final @QueryParam("uid") String uid,
			final @QueryParam("format") String format,
			final @QueryParam("resolve") Boolean resolveCodes,
			final @QueryParam("delimiter") String delimiter,
			final @QueryParam("keyDelimiter") String keyDelimiter,
			final @QueryParam("xAxis") Boolean xAxis,
			final @QueryParam("senderId") String senderId,
			final @QueryParam("datasetIndex") Integer datasetIndex,
			final @QueryParam("map") String map,
			final @QueryParam("zip") Boolean isZip,
			final @QueryParam("unmapped") Boolean includeUnmappedData,
			final @QueryParam("unmappedReport") Boolean includeUnmappedReport,
			final @QueryParam("includeMetrics") Boolean includeMetrics,
			final @QueryParam("skipValidation") Boolean skipValidation,
			@Context final HttpServletRequest request) {
		WriteableDataLocation wdl = wdlFactory.getTemporaryWriteableDataLocation();
		try {
			HttpRequest req = new HttpRequest(request);
			StreamingResponseWriter res = new StreamingResponseWriter(wdl);
			dataService.getData(uid, format, resolveCodes, delimiter, keyDelimiter, xAxis, senderId,
					datasetIndex, map, isZip, includeUnmappedData, includeUnmappedReport, includeMetrics, req, res, skipValidation);
			return res.buildResponse();
		} catch (Throwable th) {
			int status = HttpURLConnection.HTTP_INTERNAL_ERROR;
			if(th instanceof SdmxException) {
				SdmxException e = (SdmxException)th;
				if(e.getHttpRestErrorCode() != null) {
					status = e.getHttpRestErrorCode();
				}
			}
			wdl.close();  //do not close on finally, as it is closed by the StreamingResponseWriter on success
			throw new WebApplicationException(
					Response.status(status)
					.entity("Can not create output file:"+System.lineSeparator()+ErrorReport.build(th).getStringForHtml()).build());
		}
	}
}
