package io.sdmx.fusion.service.model.servletresponse;

import java.io.IOException;

import jakarta.servlet.ServletOutputStream;

/**
 * Prevent underlying stream from being flushed or closed (leave that up to the application container)
 */
public class UnflushableResponseStream extends ProxyResponseWrapper {

	public UnflushableResponseStream(ServletOutputStream proxy) {
		super(proxy);
	}

	@Override
	public void flush() throws IOException {}

	@Override
	public void close() throws IOException {}

	
}
