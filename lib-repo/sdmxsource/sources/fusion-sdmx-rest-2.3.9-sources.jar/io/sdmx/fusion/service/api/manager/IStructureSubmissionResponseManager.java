package io.sdmx.fusion.service.api.manager;

import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.error.IStructureValidationErrorHandler;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.fusion.service.api.model.ISdmxResponse;

public interface IStructureSubmissionResponseManager {
	/**
	 * Returns an error response based on the submitted beans and exception
	 * @param th the error
	 * @param errorBean the beans that caused the error
	 * @param schemaVersion the version of the schema to output the response in
	 * @return
	 */
	ISdmxResponse buildErrorResponse(Throwable th, IURNSingle<?> errorReference, SDMX_SCHEMA schemaVersion);
	
	/**
	 * Builds a success response based on the submitted beans
	 * @param beans the beans that were successfully submitted
	 * @param schemaVersion the version of the schema to output the response in
	 * @param errorHandler an optional error handler which may have reports of errors
	 * @return
	 */
	ISdmxResponse buildSuccessResponse(SdmxBeans beans, SDMX_SCHEMA schemaVersion, IStructureValidationErrorHandler errorHandler);
	
}
