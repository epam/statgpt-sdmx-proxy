package io.sdmx.fusion.service.service.search;
        
import java.io.IOException;
import java.io.OutputStream;

import org.springframework.beans.factory.annotation.Autowired;

import io.sdmx.api.service.search.ISearchService;
import io.sdmx.utils.core.application.SingletonStore;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.StreamingOutput;

@Path("/search")
public class SearchService {

	@Autowired
	private ISearchService searchService = SingletonStore.getSingleton(ISearchService.class);
	
	@GET
	@Produces("application/json")
	public StreamingOutput search(final @QueryParam("query") String searchTerm, final  @QueryParam("auto") Boolean autoComplete) {
		
		return new StreamingOutput() {
			
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				if(autoComplete != null && autoComplete==true) {
					searchService.writeAutoCompleteSuggestions(searchTerm, 10, out);
				} else {
					searchService.writeSearchResults(searchTerm, out);
				}
			}
		};
	}
}
