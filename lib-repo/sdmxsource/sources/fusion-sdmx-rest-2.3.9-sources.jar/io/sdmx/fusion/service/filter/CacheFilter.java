package io.sdmx.fusion.service.filter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Locale;

import io.sdmx.fusion.service.model.servletresponse.CacheResponseWrapper;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class CacheFilter implements Filter {
	protected ServletContext sc;
	protected FilterConfig fc;
	protected long cacheTimeout = Long.MAX_VALUE;

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;

		// Check to see if was a resource that shouldn't have been cached.
		String realPath = sc.getRealPath("");
		String path = fc.getInitParameter(request.getRequestURI());
		if (path!= null && path.equals("nocache")) {
			chain.doFilter(request, response);
			return;
		}
		path = realPath + path;

		// Customize to match request parameters
		String id = request.getRequestURI() + request.getQueryString();
		
		// Optionally append I18N sensitivity
		String localeSensitive = fc.getInitParameter("locale-sensitive");
		if (localeSensitive != null) {
			StringWriter ldata = new StringWriter();
			Enumeration<?> locales = request.getLocales();
			while (locales.hasMoreElements()) {
				Locale locale = (Locale)locales.nextElement();
				ldata.write(locale.getISO3Language());
			}
			id = id + ldata.toString();
		}
		
		File tempDir = (File)sc.getAttribute("javax.servlet.context.tempdir");

		// Get a possible cache
		String temp = tempDir.getAbsolutePath();
		File file = new File(temp+id);

		// Get the current resource
		path = sc.getRealPath(request.getRequestURI());

		File current = new File(path);

		try {
			long millisNow = Calendar.getInstance().getTimeInMillis();
			// Perform a time check
			if (!file.exists() ||
				(file.exists() && current.lastModified() > file.lastModified()) ||
				cacheTimeout < millisNow - file.lastModified()) {
				String name = file.getAbsolutePath();
				name = name.substring(0,name.lastIndexOf("/")==-1?0:name.lastIndexOf("/"));
				new File(name).mkdirs();
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				CacheResponseWrapper wrappedResponse = new CacheResponseWrapper(response, baos);
				chain.doFilter(req, wrappedResponse);

				try ( FileOutputStream fos = new FileOutputStream(file) ) {
    				fos.write(baos.toByteArray());
    				fos.flush();
				}
			}
		} catch (ServletException se) {
			if (!file.exists()) {
				throw new ServletException(se);
			}
		} catch (IOException ioe) {
			if (!file.exists()) {
				throw ioe;
			}
		}

		try ( FileInputStream fis = new FileInputStream(file) ) {
    		String mimeType = sc.getMimeType(request.getRequestURI());
    		response.setContentType(mimeType);
    		ServletOutputStream servletOutputStream = res.getOutputStream();
    		for (int i = fis.read(); i!= -1; i = fis.read()) {
    			servletOutputStream.write((byte)i);
    		}
		}
	}

	@Override
	public void init(FilterConfig filterConfig) {
		this.fc = filterConfig;
		String cacheTimeoutString = fc.getInitParameter("cacheTimeout");
		if (cacheTimeoutString != null) {
			cacheTimeout = 60*1000*Long.parseLong(cacheTimeoutString);
		}
		this.sc = filterConfig.getServletContext();
	}

	@Override
	public void destroy() {
		this.sc = null;
		this.fc = null;
	}
}