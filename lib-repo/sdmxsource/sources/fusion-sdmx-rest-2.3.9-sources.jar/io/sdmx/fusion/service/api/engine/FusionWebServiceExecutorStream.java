package io.sdmx.fusion.service.api.engine;

import java.io.OutputStream;

/**
 * Execute web service writing response to output stream
 */
public interface FusionWebServiceExecutorStream {


	void apply(OutputStream out) throws Throwable;
	
}
