package io.sdmx.fusion.service.servlet;

import io.sdmx.utils.sdmx.xs.SdmxVersion;

/**
 * Version 2.0.0 of the SDMX API
 */
public class SDMXAPIV2_0_0 extends SDMXAPI {
	private static final long serialVersionUID = 1L;
	
	public SDMXAPIV2_0_0() {
		super(SdmxVersion.getInstance(2, 0, 0));
	}
	
}
