package io.sdmx.fusion.service.constant;

import io.sdmx.api.application.IVersion;
import io.sdmx.utils.core.version.Version;

public enum REST_API_VERSION {
	v2_0_0("2.0.0"),
	v1_5_0("1.5.0"),
	v1_4_0("1.4.0"),
	v1_3_0("1.3.0"),
	v1_2_0("1.2.0"),
	v1_1_0("1.1.0");
	
	private IVersion version;

	private REST_API_VERSION(String version) {
		this.version = new Version(version);
	}

	public static REST_API_VERSION parseVersion(String version) {
		for(REST_API_VERSION v : REST_API_VERSION.values()) {
			if(v.getVersion().toString().equals(version)) {
				return v;
			}
		}
		return null;
	}
	
	public IVersion getVersion() {
		return version;
	}

}
