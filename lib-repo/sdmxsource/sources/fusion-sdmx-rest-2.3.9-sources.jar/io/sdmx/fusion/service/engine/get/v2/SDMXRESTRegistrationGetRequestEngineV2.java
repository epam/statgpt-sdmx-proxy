package io.sdmx.fusion.service.engine.get.v2;

import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;
import io.sdmx.api.sdmx.manager.output.StructureWriterManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.query.RESTRegistrationQuery;
import io.sdmx.core.sdmx.api.manager.structure.RegistrationBeanRetrievalManager;
import io.sdmx.core.sdmx.format.SdmxStructureFormat;
import io.sdmx.fusion.service.api.engine.ISDMXRESTGetRequestEngine;
import io.sdmx.fusion.service.builder.RESTRegistrationQueryBuilder_V2;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.fusion.service.manager.QueryRegistrationRequestManagerImpl;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class SDMXRESTRegistrationGetRequestEngineV2 extends QueryRegistrationRequestManagerImpl implements ISDMXRESTGetRequestEngine {
	private static final ISdmxVersion REST_VERSION = SdmxVersion.getInstance(2, 0, 0);
	private final SdmxStructureFormat DEFAULT_STRUCTURE_FORMAT = new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V21_STRUCTURE_DOCUMENT);
	
	public SDMXRESTRegistrationGetRequestEngineV2(RegistrationBeanRetrievalManager registrationBeanRetrievalManager, StructureWriterManager structureWriterManager) {
		super(registrationBeanRetrievalManager, structureWriterManager);
	}
	
	@Override
	public void processRequest(InformationFormat responseFormat, Request request, IResponse response) {
		if(responseFormat == null) {
			responseFormat = DEFAULT_STRUCTURE_FORMAT; 
		}
		StructureFormat sf = (StructureFormat) responseFormat;
		SdmxBeans beans = getRegistrations(request);
		writeStructures(response, beans, sf);
	}
	
	public SdmxBeans getRegistrations(Request request) {
		RESTRegistrationQuery query = RESTRegistrationQueryBuilder_V2.build(request.getRestURL()); 
		SdmxBeans beans = getSdmxBeans(request, query);
		if(beans == null || beans.getAllMaintainables().size() == 0) {
			throw new SdmxNoResultsException("No Results Found");
		}
		return beans;
	}

	@Override
	public IResource getResourceType() {
		return SDMX_REST_RESOURCE.REGISTRATION.getResource();
	}

	@Override
	public ISdmxVersion getRestVersion() {
		return REST_VERSION;
	}
}
