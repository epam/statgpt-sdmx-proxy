package io.sdmx.fusion.service.filter;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.filter.OncePerRequestFilter;

import io.sdmx.api.security.SecurityDetails;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Service
public class UsernameStoreFilter extends OncePerRequestFilter {
	private static final Logger LOG = LoggerFactory.getLogger(UsernameStoreFilter.class);

	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		ThreadLocalUtil.clearFromThread("username");
		if(authentication != null && authentication.getPrincipal() instanceof SecurityDetails) {
			SecurityDetails user = (SecurityDetails) authentication.getPrincipal() ;
			LOG.debug("Store username '"+user.getUsername()+"' on thread");
			ThreadLocalUtil.storeOnThread("username", user.getUsername());
		}
		super.doFilter(request, response, filterChain);
	}
}
