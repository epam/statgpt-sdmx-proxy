package io.sdmx.fusion.service.filter;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Map;

import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.process.IProcess;
import io.sdmx.fusion.service.model.servletresponse.StatusExposingServletResponse;
import io.sdmx.utils.core.audit.AuditUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.JsonObjectUtil;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AuditFilter implements Filter {
	private boolean alwaysAudit = false;
	private static boolean enabled = true;
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		String always = filterConfig.getInitParameter("AlwaysAudit");
		alwaysAudit = "on".equals(always);
	}
	
	public static void disableFilter() {
		AuditFilter.enabled = false;
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		if(!enabled) {
			chain.doFilter(request, response);
			return;
		}
		
		IProcess filterProcess = ()-> {
			try {
				Map<String, String[]> paramMap =  req.getParameterMap();
				if(ObjectUtil.validMap(paramMap)) {
					JSONObject paramsJson = new JSONObject();
					for(String paramId :paramMap.keySet()) {
						String[] vals = paramMap.get(paramId);
						if(vals != null && vals.length > 0) {
							if(vals.length == 1) {
								JsonObjectUtil.writeString(paramsJson, paramId, vals[0]);
							} else {
								JsonObjectUtil.appendStringArray(paramsJson, paramId, vals);
							}
						}
					}
					AuditUtil.addAuditProperty("QueryParameters", paramsJson);
				}
				Enumeration<String> enumHeader = req.getHeaderNames();
				JSONObject headerJson = new JSONObject();
				boolean hasHeader = false;
				while(enumHeader.hasMoreElements()) {
					String headerId = enumHeader.nextElement();
					if(headerId == null) {
						continue;
					}
					hasHeader = true;
					String headerValue = req.getHeader(headerId);
					if(headerId.equalsIgnoreCase("Authorization")) {
						headerValue  = "*****";
					}
					JsonObjectUtil.writeString(headerJson, headerId, headerValue);
				}
				if(hasHeader) {
					AuditUtil.addAuditProperty("HttpHeaders", headerJson);
				}
				AuditUtil.addAuditProperty("Path", req.getServletPath());
				AuditUtil.addAuditProperty("PathInfo", req.getPathInfo());

				HttpServletResponse resp = (HttpServletResponse) response;
				StatusExposingServletResponse statResp = new StatusExposingServletResponse(resp);
				try {
					chain.doFilter(request, statResp);
				} finally {
					AuditUtil.addAuditProperty("HttpStatus", statResp.getStatus());
				}
			} catch (IOException e) {
				throw new RuntimeException(e);
			} catch (ServletException e) {
				throw new RuntimeException(e);
			}
		};
		if(alwaysAudit) {
			AuditUtil.startAuditEvent("REST_API", req.getMethod(), filterProcess);
		} else {
			AuditUtil.prepareAudit("REST_API", req.getMethod(),  filterProcess);
		}
	}

	@Override
	public void destroy() {}



}
