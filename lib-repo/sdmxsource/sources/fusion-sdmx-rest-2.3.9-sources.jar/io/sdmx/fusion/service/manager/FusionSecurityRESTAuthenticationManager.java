package io.sdmx.fusion.service.manager;

import java.io.ByteArrayOutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Base64;

import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.SpringSecurityMessageSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.util.Assert;

import io.sdmx.api.application.ApplicationStartupAware;
import io.sdmx.api.cache.Cache;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxServiceUnavailableException;
import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.exception.SdmxUnauthorisedException;
import io.sdmx.api.exception.UnrecognisedFormatException;
import io.sdmx.api.http.ClientRequest;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.OrganisationSchemeBean;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.fusion.security.api.manager.FusionAuthenticationManager;
import io.sdmx.fusion.security.api.manager.FusionSecurityAuthenticationServiceManager;
import io.sdmx.fusion.security.api.model.user.SdmxSecurityDetails;
import io.sdmx.fusion.security.exception.NoRolesException;
import io.sdmx.fusion.security.model.ReadOnlySecurityDetails;
import io.sdmx.fusion.service.constant.REST_API_VERSION;
import io.sdmx.im.beans.reference.RESTStructureQueryImpl;
import io.sdmx.utils.core.http.AuthorizationUtil;
import io.sdmx.utils.core.io.InMemoryReadableDataLocation;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.http.broker.RestMessageBroker;
import io.sdmx.utils.sdmx.xs.URN;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Authenticates against the REST web service of Fusion Security
 */
public class FusionSecurityRESTAuthenticationManager implements AuthenticationProvider,
																ApplicationStartupAware,
																UserDetailsService,
																FusionAuthenticationManager,
																Cache {

	static {
	    javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
	    (hostname, sslSession) -> {
         if (hostname.equals("localhost")) {
		return true;
         }
         return false;
      });
	}

	private static final Logger LOG = LoggerFactory.getLogger(FusionSecurityRESTAuthenticationManager.class);

	private MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();

	protected WsRestBeanRetrievalManager wsRestBeanRetrievalManager;
	private String restUrl;

	@Autowired(required=false)
	private FusionSecurityAuthenticationServiceManager authenticationServiceManager;

	@Autowired
	private StructureReaderManager srm;

	@Override
	public boolean supports(Class<?> authentication) {
		return wsRestBeanRetrievalManager != null && (UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication));
	}

	@Override
	public void doAutoLogin(String username, String password, HttpServletRequest request) {
	    try {
	        // Must be called from request filtered by Spring Security, otherwise SecurityContextHolder is not updated
	        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(username, password);
	        token.setDetails(new WebAuthenticationDetails(request));
	        Authentication authentication = authenticate(token);
	        LOG.debug("Logging in with [{}]", authentication.getPrincipal());
	        SecurityContextHolder.getContext().setAuthentication(authentication);
	    } catch (Exception e) {
	        SecurityContextHolder.getContext().setAuthentication(null);
	        LOG.error("Failure in autoLogin", e);
	    }
	}

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		Assert.isInstanceOf(UsernamePasswordAuthenticationToken.class, authentication,
				messages.getMessage("AbstractUserDetailsAuthenticationProvider.onlySupports",
						"Only UsernamePasswordAuthenticationToken is supported"));

		UsernamePasswordAuthenticationToken usernamePassword = (UsernamePasswordAuthenticationToken) authentication;

		String username = (String) usernamePassword.getPrincipal();
		String password = (String) usernamePassword.getCredentials();

		SdmxSecurityDetails principle = authenticate(wsRestBeanRetrievalManager, username, password);
		LOG.debug("Authenticating username: " + username);
		return UsernamePasswordAuthenticationToken.authenticated(principle, null, principle.getAuthorities());
	}

	/**
	 * Tests that the authentication service is valid
	 * throw a SdmxSyntaxException
	 * @param url
	 * @param username
	 * @param password
	 */
	public void testAuthenticationService(String url, String username, String password) {
		if (!ObjectUtil.validString(url)) {
			setAuthenticationService(null);
			return;
		}

		if(!ObjectUtil.validString(username)) {
			throw new SdmxSyntaxException("No username was provided");
		}
		if(!ObjectUtil.validString(password)) {
			throw new SdmxSyntaxException("No password was provided");
		}


		url = cleanURL(url);
		verifyURL(url);
		WsRestBeanRetrievalManager retrievalManager = new  WsRestBeanRetrievalManager(url, REST_API_VERSION.v1_5_0);
		authenticate(retrievalManager, username, password);
	}

	protected SdmxSecurityDetails authenticate(WsRestBeanRetrievalManager beanRetrievalManager, String username, String password) {
		try {
			LOG.info("Attempting authentication for: " + username);

			ClientRequest clientRequest = ThreadLocalUtil.getClientRequest();
			String xForwarded = clientRequest.getClientIP();
			AuthorizationUtil.storeAuthorizationInThreadLocal(username, password, xForwarded);
			SdmxBeans beans = beanRetrievalManager.getMaintainables(new RESTStructureQueryImpl(URN.build(OrganisationSchemeBean.class)));
			SdmxSecurityDetails sd = new  ReadOnlySecurityDetails(beans);

			LOG.info("User: " + username + " is permitted to log into the system");
			return sd;
		}  catch(UnrecognisedFormatException e) {
			//The response was not expected
			throw new BadCredentialsException("The Security URL is not a valid Fusion Security Service");
		} catch(SdmxUnauthorisedException e) {
			//TODO Different exception types
			throw new BadCredentialsException("Invalid User Credentials for Fusion Security Service");
		} catch(SdmxServiceUnavailableException e) {
			throw new AuthenticationServiceException("Can not communicate with Fusion Security Service");
		} catch(SdmxNotImplementedException e) {
			throw new AuthenticationServiceException("Fusion Security Service is not valid", e);
		} catch(NoRolesException e) {
		    // FR-4790: It is important to catch and re-throw a NoRolesException so it doesn't get converted into an SdmxException
		    throw e;
		} catch(Throwable e) {
			throw new SdmxException("Fusion Security Service Error:" + e.getMessage());
		} finally {
			AuthorizationUtil.clearAuthorizationFromThreadLocal();
		}
	}

	@Override
	public UserDetails loadUserByUsername(String username) {
		LOG.info("Looking for user: " + username);
		String urlPrefix = getRestUrlRaw();
		String restQuery = urlPrefix+"/secure/rest/organisations/find?username="+username;
		LOG.info("sec url: " + restQuery);
		String certB64 = this.getCertificate();
		LOG.debug(certB64);

		String CertificateRawData = certB64.substring(certB64.indexOf(",") + 1);// strip the mime type

		byte[] p12Cert = Base64.getDecoder().decode(CertificateRawData.getBytes());
		String p12CertPass =  getCertificatePass();

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		AuthorizationUtil.storeCertificateAuthorizationInThreadLocal(p12Cert, p12CertPass);
		try {
			RestMessageBroker.sendMessage(bos, restQuery);
		} finally {
			AuthorizationUtil.clearAuthorizationFromThreadLocal();
		}

		SdmxBeans beans = srm.parseStructures(new InMemoryReadableDataLocation(bos.toByteArray()));
		return buildSecurityDetails(beans, username);

	}


	private SdmxSecurityDetails buildSecurityDetails(SdmxBeans beans, String username) {
		SdmxSecurityDetails sd = new  ReadOnlySecurityDetails(beans);
		LOG.info("User: " + username + " is permitted to log into the system");
		return sd;
	}

	protected String getCertificate() {
		throw new SdmxNotImplementedException("Not Implemented");
	}

	protected String getCertificatePass() {
		throw new SdmxNotImplementedException("Not Implemented");
	}

	private TrustManager[] getTrustAllCerts() {
		return new TrustManager[]{
				new X509TrustManager() {
					@Override
					public X509Certificate[] getAcceptedIssuers() {
						return null;
					}

					@Override
					public void checkServerTrusted(X509Certificate[] certs, String authType) throws CertificateException {
					}

					@Override
					public void checkClientTrusted(X509Certificate[] certs, String authType) throws CertificateException{
					}
				}
		};
	}


	public String getRestUrlRaw() {
		if (restUrl == null) {
			return null;
		}
		int indx = restUrl.lastIndexOf("/ws/auth");
		if (indx == -1) {
			return restUrl;
		}
		return restUrl.substring(0, indx);
	}

	public String getRestUrl() {
		return restUrl;
	}

	/**
	 * Returns true if this authentication manager has been set up to talk to a Fusion Security
	 * URL.
	 * @return
	 */
	public boolean isEnabled() {
		return this.wsRestBeanRetrievalManager != null;
	}

	/**
	 * FusionSecurity URL, expecting http(s)://[server]:[port]/FusionSecurity/
	 * @param securityURL
	 */
	public void setAuthenticationService(String url) {
		LOG.debug("Setting AuthenticationService to: " + url);
		if(ObjectUtil.validString(url)) {
			url = cleanURL(url);
			verifyURL(url);
			this.restUrl = url;
		} else {
		    this.restUrl = null;
			this.wsRestBeanRetrievalManager = null;
		}
	}

	private String cleanURL(String url) {
		Assert.notNull(url, "Authentication URL can not be null");
		if(url.endsWith("/ws/auth")) {
			return url;
		}
		if(!url.endsWith("/")) {
			url += "/";
		}
		url += "ws/auth";
		return url;
	}

	private void verifyURL(String url) {
		try {
			new URL(url);
		} catch (MalformedURLException e) {
			throw new SdmxSyntaxException("Illegal URL: " + e.getMessage());
		}
	}

	@Override
	public void applicationStarted() {
		createRetreivalManager();
	}

	private void createRetreivalManager() {
		if(authenticationServiceManager != null) {
			if(authenticationServiceManager.getFusionSecurityServiceURL() != null) {
				setAuthenticationService(authenticationServiceManager.getFusionSecurityServiceURL().toString());
			}
		}
		if(ObjectUtil.validString(restUrl)) {
			this.wsRestBeanRetrievalManager = new WsRestBeanRetrievalManager(restUrl, REST_API_VERSION.v1_5_0);
		}
	}

	@Override
	public void applicationRestarting() {
		clearCache();
	}

	@Override
	public void clearCache() {
		this.restUrl = null;
	}

	@Override
	public Class<?>[] getDependsOn() {
		return null;
	}

}