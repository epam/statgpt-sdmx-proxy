package io.sdmx.fusion.service.manager;

import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.fusion.service.constant.REST_API_VERSION;
import io.sdmx.utils.core.http.AuthorizationUtil;
import io.sdmx.utils.core.object.ObjectUtil;

public class WsRestBeanRetrievalManager extends RESTSdmxBeanRetrievalManager {
	private String username;
	private String password;
	private byte[] p12Certificate;
	private String p12CertificatePass;

	public WsRestBeanRetrievalManager(String restURL, REST_API_VERSION apiVersion) {
		this(restURL, apiVersion, null, null);
	}


	public static WsRestBeanRetrievalManager getInstanceUsingP12Cert(String restURL, REST_API_VERSION apiVersion, byte[] p12Certificate, String password) {
		WsRestBeanRetrievalManager returnObj = new WsRestBeanRetrievalManager(restURL, apiVersion);
		returnObj.p12Certificate = p12Certificate;
		returnObj.p12CertificatePass = password;
		return returnObj;
	}

	public WsRestBeanRetrievalManager(String restURL, REST_API_VERSION apiVersion, String username, String password) {
		super(restURL, apiVersion);
		this.username = username;
		this.password = password;
	}
	
	public WsRestBeanRetrievalManager(String restURL, REST_API_VERSION apiVersion, StructureFormat structureFormat, String username, String password) {
		super(restURL, structureFormat, apiVersion);
		this.username = username;
		this.password = password;
	}

	@Override
	public SdmxBeans getMaintainables(RESTStructureQuery sQuery) {
		try {
			if(ObjectUtil.validString(username, password)) {
				AuthorizationUtil.storeAuthorizationInThreadLocal(username, password);
			} else if(p12Certificate != null && ObjectUtil.validString(p12CertificatePass)) {
				AuthorizationUtil.storeCertificateAuthorizationInThreadLocal(p12Certificate, p12CertificatePass);
			}
			return super.getMaintainables(sQuery);
		} finally {
			AuthorizationUtil.clearAuthorizationFromThreadLocal();
		}
	}
}