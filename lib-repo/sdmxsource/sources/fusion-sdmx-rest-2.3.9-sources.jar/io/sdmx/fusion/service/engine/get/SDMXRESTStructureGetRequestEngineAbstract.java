package io.sdmx.fusion.service.engine.get;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;
import io.sdmx.api.sdmx.manager.structure.IQueryStructureRequestManager;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.core.sdmx.format.SdmxStructureFormat;
import io.sdmx.fusion.service.api.engine.ISDMXRESTGetRequestEngine;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.fusion.service.model.queryresponse.StructureQueryRequest;

public abstract class SDMXRESTStructureGetRequestEngineAbstract implements ISDMXRESTGetRequestEngine {
	private final ISdmxVersion REST_VERSION;
		
	private IQueryStructureRequestManager queryStructureRequestManager;
	
	private SdmxStructureFormat DEFAULT_STRUCTURE_FORMAT = new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V3_STRUCTURE_DOCUMENT);
	
	
	public SDMXRESTStructureGetRequestEngineAbstract(IQueryStructureRequestManager queryStructureRequestManager,
													 ISdmxVersion restVersion) {
		this.queryStructureRequestManager = queryStructureRequestManager;
		this.REST_VERSION = restVersion;
	}

	@Override
	public void processRequest(InformationFormat responseFormat, Request request, IResponse response) {
		StructureQueryRequest structureQueryRequest = getStructureQueryRequest(responseFormat, request, response);
		queryStructureRequestManager.processQuery(structureQueryRequest);
	}
	/**
	 * Override the default format
	 * @param defaultFormat
	 */
	public void setDefaultFormat(SdmxStructureFormat defaultFormat) {
		this.DEFAULT_STRUCTURE_FORMAT = defaultFormat;
	}
	
	protected StructureQueryRequest getStructureQueryRequest(InformationFormat responseFormat, Request request, IResponse response) {
		boolean wasFormatDefaulted = false;
		if(responseFormat == null) {
			wasFormatDefaulted = true;
			responseFormat = DEFAULT_STRUCTURE_FORMAT;
		}
		StructureFormat sf = (StructureFormat) responseFormat;
		
		RESTStructureQuery query = buildRESTQuery(request);
		StructureQueryRequest structureQueryRequest = new StructureQueryRequest(query, request, response, sf);
		structureQueryRequest.setWasFormatDefaulted(wasFormatDefaulted);
		return structureQueryRequest;
	}
	
	protected abstract RESTStructureQuery buildRESTQuery(Request request);
	

	@Override
	public IResource getResourceType() {
		return SDMX_REST_RESOURCE.STRUCTURE.getResource();
	}

	@Override
	public ISdmxVersion getRestVersion() {
		return REST_VERSION;
	}
}
