package io.sdmx.fusion.service.manager;

import java.io.ByteArrayOutputStream;

import io.sdmx.api.application.FusionProductInformation;
import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.utils.http.broker.RestMessageBroker;
import io.sdmx.utils.sdmx.application.FusionProductInformationImpl;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

public class FusionProductInformationRetrievalManagerRest implements FusionProductInformationRetrievalManager {
	private static final Logger LOG = LoggerFactory.getLogger(FusionProductInformationRetrievalManagerRest.class);

	private String fusionService;

	public FusionProductInformationRetrievalManagerRest(String fusionService) {
		Assert.notNull(fusionService, "Fusion Service required");

		if(!fusionService.endsWith("/ws/fusion/info/product")) {

			if(!fusionService.endsWith("/")) {
				fusionService+="/";
			}
			fusionService+="ws/fusion/info/product";
		}
		this.fusionService = fusionService;
	}

	@Override
	public FusionProductInformation getFusionProductInformation() {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		RestMessageBroker.sendMessage(out, fusionService);
		JSONObject responseJson;
		try {
			String aStr = new String(out.toByteArray());
			responseJson = new JSONObject(aStr);
		} catch(JSONException e) {
			// Do NOT put the cause of the ORIGINAL exception in the returned Exception, since the RETURNED Exception message is
			// displayed on the screen to the user. Instead LOG the error and it should be passed on to Fusion Audit.
			LOG.error("JSONException", e);
			String entryPoint = fusionService.substring(0, fusionService.length()-23);
			throw new SdmxException("Service " + entryPoint + " is not valid.");
		}
		return new FusionProductInformationImpl(responseJson);
	}
}
