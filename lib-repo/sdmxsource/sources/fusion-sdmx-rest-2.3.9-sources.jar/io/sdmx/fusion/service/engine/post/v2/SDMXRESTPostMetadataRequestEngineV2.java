package io.sdmx.fusion.service.engine.post.v2;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.manager.persist.IMetadataPersistenceManager;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.core.sdmx.api.manager.metadata.IReferenceMetadataReaderManager;
import io.sdmx.fusion.service.api.engine.ISDMXRESTPostRequestEngine;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class SDMXRESTPostMetadataRequestEngineV2 implements ISDMXRESTPostRequestEngine {
	private static final ISdmxVersion REST_VERSION = SdmxVersion.getInstance(2, 0, 0);

	private IReferenceMetadataReaderManager metadataReaderManager;
	private IMetadataPersistenceManager metadataPersistenceManager;
	
	public SDMXRESTPostMetadataRequestEngineV2(IReferenceMetadataReaderManager metadataReaderManager, 
											 IMetadataPersistenceManager metadataPersistenceManager) {
		this.metadataReaderManager = metadataReaderManager;
		this.metadataPersistenceManager = metadataPersistenceManager;
	}

	@Override
	public void processRequest(InformationFormat responseFormat, Request request, IResponse response) {
		ReadableDataLocation rdl = request.getReadableDataLocation();
		IReferenceMetadataContainer mc = metadataReaderManager.parse(rdl);
		metadataPersistenceManager.saveMetadata(mc);
	}

	@Override
	public IResource getResourceType() {
		return SDMX_REST_RESOURCE.METADATA.getResource();
	}

	@Override
	public ISdmxVersion getRestVersion() {
		return REST_VERSION;
	}

	
	
}
