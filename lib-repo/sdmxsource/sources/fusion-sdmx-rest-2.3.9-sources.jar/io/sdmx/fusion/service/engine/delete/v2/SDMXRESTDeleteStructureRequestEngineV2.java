package io.sdmx.fusion.service.engine.delete.v2;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.manager.persist.StructurePersistenceManager;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.fusion.service.api.engine.ISDMXRESTDeleteRequestEngine;
import io.sdmx.fusion.service.builder.RESTStructureQueryBuilder_V2;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class SDMXRESTDeleteStructureRequestEngineV2 implements ISDMXRESTDeleteRequestEngine {
	private static final ISdmxVersion REST_VERSION = SdmxVersion.getInstance(2, 0, 0);

	private ISdmxBeanRestRetrievalManager beanRetrievalManager;
	private StructurePersistenceManager spm;
	
	public SDMXRESTDeleteStructureRequestEngineV2(ISdmxBeanRestRetrievalManager beanRetrievalManager, StructurePersistenceManager spm) {
		this.beanRetrievalManager = beanRetrievalManager;
		this.spm = spm;
	}

	@Override
	public void processRequest(InformationFormat responseFormat, Request request, IResponse response) {
	    RESTStructureQuery restQuery = buildRESTQuery(request);
	    SdmxBeans queryResult = beanRetrievalManager.getMaintainables(restQuery);
	    spm.deleteStructures(queryResult);
	    
	}
	
    private RESTStructureQuery buildRESTQuery(Request request) {
        String path = request.getPath();
        if(!path.startsWith("/")) {
            path = "/" + path;
        }
        String[] pathSplit = request.getPath().split("/", 3);
        path = pathSplit.length == 2 ? "*" : request.getPath().split("/", 3)[2];  //Remove the leading /structure from the path
        Map<String, String> parameters = new HashMap<>();
        parameters.put("detail", "allstubs");
        
        return RESTStructureQueryBuilder_V2.build(path, parameters);
    }

	@Override
	public IResource getResourceType() {
		return SDMX_REST_RESOURCE.STRUCTURE.getResource();
	}

	@Override
	public ISdmxVersion getRestVersion() {
		return REST_VERSION;
	}
}
