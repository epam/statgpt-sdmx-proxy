package io.sdmx.fusion.service.model.servletresponse;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletResponseWrapper;

public abstract class BaseHttpServletResponseWrapper extends HttpServletResponseWrapper {
	protected HttpServletResponse origResponse;
	protected ServletOutputStream stream;
	private PrintWriter writer;
	
	public BaseHttpServletResponseWrapper(HttpServletResponse origResponse) {
		super(origResponse);
		this.origResponse = origResponse;
	}

	protected abstract ServletOutputStream createOutputStream();

	@Override
	public void flushBuffer() throws IOException {
		getOutputStream().flush();
	}

	@Override
	public ServletOutputStream getOutputStream() throws IOException {
		// Create a Stream if required
		if (stream == null) {
			stream = createOutputStream();
		}
		return stream;
	}

	@Override
	public PrintWriter getWriter() throws IOException {
		if (writer != null) {
			return writer;
		}

		if (stream != null) {
			throw new IllegalStateException("The method: getOutputStream() has already been invoked!");
		}

		stream = createOutputStream();
		writer = new PrintWriter(new OutputStreamWriter(stream, "UTF-8"));
		return writer;
	}

}
