package io.sdmx.fusion.service.model.servletresponse;

import java.io.OutputStream;

import io.sdmx.api.http.IResponse;

public abstract class ProxyResponse implements IResponse {
	private IResponse proxy;
	
	public ProxyResponse(IResponse proxy) {
		this.proxy = proxy;
	}

	@Override
	public OutputStream getOutputStream() {
		return proxy.getOutputStream();
	}

	@Override
	public void setStatus(int status) {
		proxy.setStatus(status);
	}

	@Override
	public void setContentType(String contentType) {
		proxy.setContentType(contentType);
	}

	@Override
	public void setHeader(String header, String value) {
		proxy.setHeader(header, value);
	}
	
	@Override
	public void sendError(int responseCode, String message) {
		proxy.sendError(responseCode, message);
	}

	@Override
	public void setLastUpdated(Long epochTime) {
		proxy.setLastUpdated(epochTime);
	}
}