package io.sdmx.fusion.service.util;

import java.util.Date;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.http.client.utils.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.http.ClientRequest;
import io.sdmx.api.http.HTTP_STATUS;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.sdmx.manager.structure.StrucutreInformationManager;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.fusion.security.api.model.user.SdmxSecurityDetails;
import io.sdmx.fusion.security.util.SdmxSecurityContext;
import io.sdmx.utils.core.http.AuthorizationUtil;
import io.sdmx.utils.core.io.WriteableDataLocationTmp;
import io.sdmx.utils.core.object.HashUtils;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.security.FusionSecurityContext;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.http.broker.RestMessageBroker;
import io.sdmx.utils.sdmx.comparator.MaintainableSortByIdentifiers;
import jakarta.servlet.http.HttpServletRequest;

public class RequestManagerUtil {

    private static final Logger LOG = LoggerFactory.getLogger(RequestManagerUtil.class);

    /**
     * Process the ETag, adding it to the response if necessary.
     * @param infoManager
     * @param request
     * @param response
     * @param allMaintainables
     * @return whether the ETag was already present
     */
    public static boolean processEtag(StrucutreInformationManager infoManager, Request request, IResponse response, Set<MaintainableBean> allMaintainables) {
		if(infoManager == null) {
			return false;
		}
		ClientRequest cr = ThreadLocalUtil.getClientRequest();
		String path = cr.getPathInfo();
		if(path == null) {
			return false;
		}

		if(!(allMaintainables instanceof SortedSet)) {
			SortedSet<MaintainableBean> sortedMaints = new TreeSet<>(MaintainableSortByIdentifiers.INSTANCE);
			sortedMaints.addAll(allMaintainables);
			allMaintainables = sortedMaints;
		}
		return RequestManagerUtil.addAndCheckETag(infoManager, request, response, allMaintainables);
	}
    
    /**
	 * Check if the request has an ETag.
	 * If it does, return true if it matches the hash of the response.
	 * If not, then add it to the response, along with the 'Last-Modified' value and return false.
	 * @param request
	 * @param response
	 * @param allMaints
	 * @return
	 */
    public static boolean addAndCheckETag(StrucutreInformationManager infoManager, Request request, IResponse response, Set<MaintainableBean> allMaints) {
    	// Iterate the maintainables to determine the "most recent date" and setup the "stringToHash"
		StringBuilder stringToHash = new StringBuilder(request.getHash());
		// FMR-969: Reverted feature of "Last-Modified" in header as it was causing serious caching issues in the UI
//		Long mostRecentUpdate = -1l;
		for (MaintainableBean maint : allMaints) {
			Long lastUpdatedDate = infoManager.getLastModifiedTime(maint);
			if(lastUpdatedDate == null) {
				return false;
			}
			/*
			if (lastUpdatedDate > mostRecentUpdate) {
				mostRecentUpdate = lastUpdatedDate;
			}
			*/
			stringToHash.append(lastUpdatedDate+";");
		}
		
		SdmxSecurityDetails userDetails = SdmxSecurityContext.getCurrentUser();
		if(userDetails != null) {
			stringToHash.append(userDetails.getUsername()+";");
		}
		
		// process vary tags
		String acceptHeader = request.getHeader("Accept");
		if(ObjectUtil.validString(acceptHeader)) {
			stringToHash.append(acceptHeader+";");
		}
		String acceptLanguage = request.getHeader("Accept-Language");
		if(ObjectUtil.validString(acceptLanguage)) {
			stringToHash.append(acceptLanguage+";");
		}
		String stringHashCode = HashUtils.hashString(stringToHash.toString(), false);
		if(!cacheCheck(request, response, stringHashCode)) {
			response.setHeader("ETag", stringHashCode);
			
			// The last-modified value is of the format: Tue, 10 Jun 2025 23:59:59 GMT
			/*
			SimpleDateFormat dateFormat = DateUtil.getDateFormatter("EEE, dd MMM yyyy HH:mm:ss z");
			dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			String mostRecentModification = dateFormat.format(mostRecentUpdate);
			response.setHeader("Last-Modified", mostRecentModification);
			*/
			return false;
		}
		return true;
	}
    
	/**
	 * Check to see if the request has an ETag, and if it matches the supplied hash
	 * @param req
	 * @param resp
	 * @param hashToCheck
	 * @return
	 */
	private static boolean cacheCheck(Request req, IResponse resp, String hashToCheck) {
		String cacheHeader = req.getHeader("If-None-Match");
		LOG.debug("Cache Check - If-None-Match="+cacheHeader);
		if(cacheHeader != null) {
			LOG.debug("Cache Check - If-None-Match (decoded)="+cacheHeader);
			if(hashToCheck.equals(cacheHeader)) {
				resp.setStatus(HTTP_STATUS.SC_NOT_MODIFIED.getHttpStatus());
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Process the response, returning true (if there has NOT been modifications since the date) or false (if there have been modifications).
	 * "True" is returned only if the request header contains an "If-Modified-Since" value (note this value is of the format: Thu, 11 May 2023 08:00:00 GMT
	 * Returning "true" will also set the HTTP status to 304.
	 * @param txMgr
	 * @param infoManager
	 * @param request
	 * @param response
	 * @param refMetadata
	 * @return true if structures have been modified since the date, in which case no further action is required on the request
	 */
	public static boolean processIfModifiedSince(StrucutreInformationManager infoManager, Request request, IResponse response, Set<MaintainableBean> refMetadata ) {
		if(infoManager == null) {
			return false;
		}
		String dateStr = request.getHeader("If-Modified-Since");
		if(!ObjectUtil.validString(dateStr)) {
			return false;
		}
		Date headerDate = DateUtils.parseDate(dateStr);
		if(headerDate == null) {
			return false;
		}
		LOG.info("If-Modified-Since header found, time: " + headerDate.toString());
		for (MaintainableBean maint : refMetadata) {
			Long lastUpdatedDate = infoManager.getLastModifiedTime(maint);
			if (lastUpdatedDate == null) {
			    continue;
			}
			Date maintDate = new Date(lastUpdatedDate);
			if(maintDate.after(headerDate)) {
				return false;
			}
		}

		response.setStatus(304);
		return true;
	}
	
	/**
     * Returns a ReadableDataLocation object obtained from the supplied Request.
     * The request could refer to a file on disk or a URL.
     * @param request
     * @return
     */
    public static ReadableDataLocation getReadableDataLocation(Request request) {
		// DEV-2777: SSRF vulnerability allowing unauthenticated users to access internal network resources
		// or the file system (DEV-2789).
		if (!FusionSecurityContext.CTX().isAuthenticated()) {
			throw new SecurityException("User must be authenticated to upload data from a URL.");
		}

		String uploadType = request.getParameter("uploadType");
		if(uploadType != null && uploadType.equals("file")) {
			ReadableDataLocation rdl = request.getReadableDataLocation();
			if (rdl == null) {
				throw new SdmxException("Specified file is empty");
			}
			return rdl;
		}

		// Not a file, so assume the request refers to a URL
		String uploadUrl = request.getParameter("uploadUrl");
		if (uploadUrl == null) {
			throw new SdmxException("Error: neither file nor uploadUrl has been specified");
		}
		
		String urlLocation = uploadUrl.trim();
		if (!urlLocation.startsWith("http")) {
			urlLocation = "http://" + urlLocation;
		}
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		try {
			if (ObjectUtil.validString(username, password)) {
				AuthorizationUtil.storeAuthorizationInThreadLocal(username.trim(), password.trim());
			}
			WriteableDataLocation wdl = new WriteableDataLocationTmp();
			RestMessageBroker.sendMessage(wdl.getOutputStream(), urlLocation);
			return wdl;
		} finally {
			AuthorizationUtil.clearAuthorizationFromThreadLocal();
		}
	}
    
    /**
	 * Obtain whether the "skip invalid" setting has been specified on either the header or as a parameter
	 * @param request
	 * @param requestWrapper
	 * @return
	 */
    public static boolean shouldSkipInvalid(HttpServletRequest request) {
		// If specified as a parameter this takes priority over the header
		String skipInvalidParamStr = request.getParameter("skipInvalid");
		if (skipInvalidParamStr != null && skipInvalidParamStr.toLowerCase().equals("true")) {
			return true;
		}
		// Obtain value from the request header
		String skipInvalidStr = request.getHeader("Skip-Invalid");
		if (skipInvalidStr != null && skipInvalidStr.toLowerCase().equals("true")) {
			return true;
		}

		return false;
	}
}
