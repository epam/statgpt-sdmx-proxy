package io.sdmx.fusion.service.api.manager;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.fusion.service.api.model.ISdmxResponse;
import io.sdmx.fusion.service.model.request.POSTRequest;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.REGISTRY_MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;

/**
 * The StructureSubmissionRequestManager processes
 */
public interface StructureSubmissionRequestManager {

	/**
	 * Processes a registry submission, this could either be a submit structure/provision/registration or notification
	 * <p/>
	 * The response is an SDMX response message in the same version as the submission
	 * @param registryMessageType
	 * @param schemaVersion - the version to write the response in
	 * @param uri
	 * @param datasetAction
	 * @return
	 */
	ISdmxResponse processSubmission(REGISTRY_MESSAGE_TYPE registryMessageType, SDMX_SCHEMA schemaVersion, ReadableDataLocation dataLocation, POSTRequest post, DATASET_ACTION datasetAction);

	/**
	 * 
	 * @param beans
	 * @param schemaVersion - the version to write the response in
	 * @param actionType
	 * @param post
	 * @return
	 */
	ISdmxResponse processSubmitStructureRequest(SdmxBeans beans, SDMX_SCHEMA schemaVersion, DATASET_ACTION actionType, POSTRequest post);
	
	/**
	 * Submits registrations
	 * @param dataLocation
	 * @param post
	 * @return
	 */
	ISdmxResponse processSubmitRegistrationRequest(ReadableDataLocation dataLocation, POSTRequest post);

}