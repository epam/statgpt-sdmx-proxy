package io.sdmx.fusion.service.model.customrxjs;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import jakarta.ws.rs.Produces;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.ext.MessageBodyWriter;
import jakarta.ws.rs.ext.Provider;

@Produces({MediaType.APPLICATION_OCTET_STREAM, "*/*"})
@Provider
/**
 * Provides ByteArrayOutputStream Message body marshaling
 *
 */
public class ByteArrayOutputStreamProvider implements MessageBodyWriter<ByteArrayOutputStream>{

	@Override
	public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		 return ByteArrayOutputStream.class.isAssignableFrom(type);
	}
	
	@Override
		public long getSize(ByteArrayOutputStream t, Class<?> type, Type genericType, Annotation[] annotations,
				MediaType mediaType) {
		return t.size();
		}

	@Override
	public void writeTo(ByteArrayOutputStream t, Class<?> type, Type genericType, Annotation[] annotations,
			MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
			throws IOException, WebApplicationException {
		t.writeTo(entityStream);
	}
}
