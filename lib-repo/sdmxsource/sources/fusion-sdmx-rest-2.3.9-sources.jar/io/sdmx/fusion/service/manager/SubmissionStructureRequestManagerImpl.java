package io.sdmx.fusion.service.manager;

import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.ErrorUtil;
import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SDMX_ERROR_CODE;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FILE_FORMAT;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.AUDITABLE_TYPE;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.REGISTRY_MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.event.SdmxBeansEvent;
import io.sdmx.api.sdmx.exception.CrossReferenceException;
import io.sdmx.api.sdmx.manager.output.ErrorWriterManager;
import io.sdmx.api.sdmx.manager.persist.RegistrationPersistenceManager;
import io.sdmx.api.sdmx.manager.persist.StructurePersistenceManager;
import io.sdmx.api.sdmx.manager.structure.SdmxBeansRetreivalManager;
import io.sdmx.api.sdmx.model.ResolutionSettings;
import io.sdmx.api.sdmx.model.ResolutionSettings.RESOLVE_CROSS_REFERENCES;
import io.sdmx.api.sdmx.model.ResolutionSettings.RESOLVE_EXTERNAL_SETTING;
import io.sdmx.api.sdmx.model.beans.RegistrationInformation;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.IdentifiableBean;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.core.sdmx.api.manager.structure.StructureReaderManager;
import io.sdmx.core.sdmx.model.ref.StructureParseConfiguration;
import io.sdmx.core.structure.exception.MaintainableBeanException;
import io.sdmx.format.json.model.JsonErrorFormat;
import io.sdmx.format.ml.api.manager.RegistrationParsingManager;
import io.sdmx.format.ml.engine.structure.writer.v21.SubmitStructureResponseBuilderV21;
import io.sdmx.format.ml.engine.structure.writer.v21.registration.StaxSubmitRegistrationResponseWriterEngineV21;
import io.sdmx.format.ml.model.SdmxErrorFormat;
import io.sdmx.fusion.service.api.manager.IStructureSubmissionResponseManager;
import io.sdmx.fusion.service.api.manager.StructureSubmissionRequestManager;
import io.sdmx.fusion.service.api.model.ISdmxResponse;
import io.sdmx.fusion.service.model.request.POSTRequest;
import io.sdmx.fusion.service.model.request.SdmxResponse;
import io.sdmx.im.beans.SdmxBeansEventImpl;
import io.sdmx.im.beans.builder.DeferredImmutableBeanBuilder;
import io.sdmx.im.beans.builder.V3BeansBuilder;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * Manages the submission of structures and registrations.
 * <p/>
 * This class is responsible for delegating the message to the correct method on the provided interface.
 * @author Matt Nelson
 */
public class SubmissionStructureRequestManagerImpl implements StructureSubmissionRequestManager {
    private static final Logger LOG = LoggerFactory.getLogger(SubmissionStructureRequestManagerImpl.class);

	//PARSING MANAGERS
	private StructureReaderManager structureParsingManager;

	//RESPONSE BUILDERS
	protected IStructureSubmissionResponseManager structureSubmissionResponseManager;
	private SubmitStructureResponseBuilderV21 submitStructureResponseBuilder = SubmitStructureResponseBuilderV21.getInstance();
	private ErrorWriterManager errorWriterManager;

	private RegistrationParsingManager registrationParsingManager;
	private StaxSubmitRegistrationResponseWriterEngineV21 submitRegistrationResponseBuilder = StaxSubmitRegistrationResponseWriterEngineV21.getInstance();

	private ResolutionSettings resolutionSettings = new ResolutionSettings(RESOLVE_EXTERNAL_SETTING.RESOLVE_SUBSTITUTE, RESOLVE_CROSS_REFERENCES.DO_NOT_RESOLVE);
	protected StructurePersistenceManager structurePersistenceManager;
	protected SdmxBeansRetreivalManager sdmxBeansRetreivalManager;
	private RegistrationPersistenceManager registrationPersistenceManager;
	
	public SubmissionStructureRequestManagerImpl(StructurePersistenceManager structurePersistenceManager,
												 SdmxBeansRetreivalManager sdmxBeansRetreivalManager,
												 RegistrationPersistenceManager registrationPersistenceManager,
												 ResolutionSettings resolutionSettings,
												 RegistrationParsingManager registrationParsingManager,
												 ErrorWriterManager errorWriterManager,
												 IStructureSubmissionResponseManager structureSubmissionResponseManager,
												 StructureReaderManager structureReaderManager) {
		this.structurePersistenceManager = structurePersistenceManager;
		this.sdmxBeansRetreivalManager = sdmxBeansRetreivalManager;
		if(resolutionSettings != null) {
			this.resolutionSettings = resolutionSettings;
		}
		this.registrationPersistenceManager = registrationPersistenceManager;
		
		this.registrationParsingManager  = registrationParsingManager;
		this.errorWriterManager  = errorWriterManager;
		this.structureSubmissionResponseManager  = structureSubmissionResponseManager;
		this.structureParsingManager  = structureReaderManager;
	}


	@Override
	public ISdmxResponse processSubmission(REGISTRY_MESSAGE_TYPE registryMessageType, SDMX_SCHEMA schemaVersion, ReadableDataLocation dataLocation,  POSTRequest post, DATASET_ACTION datasetAction) {
		switch(registryMessageType) {
		case SUBMIT_STRUCTURE_REQUEST:
			return processSubmitStructureRequest(dataLocation, post, schemaVersion, datasetAction);
		case SUBMIT_REGISTRATION_REQUEST :
		case QUERY_REGISTRATION_RESPONSE :
			ThreadLocalUtil.storeOnThread(AUDITABLE_TYPE.class.getName(), AUDITABLE_TYPE.REGISTRATION);
			return processSubmitRegistrationRequest(dataLocation, post);
		default : throw new SdmxNotImplementedException(ExceptionCode.UNSUPPORTED, registryMessageType);
		}
	}
	
	@Override
	public ISdmxResponse processSubmitRegistrationRequest(ReadableDataLocation dataLocation, POSTRequest post) {
		if(registrationPersistenceManager == null) {
			throw new SdmxNotImplementedException("Registration submission not supported");
		}
		boolean isJson = dataLocation != null && dataLocation.getFormat() == FILE_FORMAT.JSON;
		List<RegistrationInformation> registrations;
		try {
			registrations = registrationParsingManager.parseRegistrations(dataLocation);
		} catch(Throwable th) {
			return getErrorResponse(th, isJson);
		}

		Set<String> registrationIds = new HashSet<>();
		for(RegistrationInformation currentRegistrationInfo : registrations) {
			String id = currentRegistrationInfo.getRegistration().getId();
			if(registrationIds.contains(id)) {
				throw new SdmxSemmanticException("Two registrations contain the same id '"+id+"'.  The submission should be modified so that all registrations have unique identifiers.");
			}
			registrationIds.add(id);
		}

		Map<RegistrationBean, Throwable> resultMap = Collections.synchronizedMap(new HashMap<RegistrationBean, Throwable>());
		resultMap = processRegistrations(registrations, post);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		submitRegistrationResponseBuilder.buildResponse(resultMap, out);
		int status = 200;
		for(RegistrationBean reg : resultMap.keySet()) {
			Throwable th = resultMap.get(reg);
			if(th != null) {
				int statusLocal = ErrorUtil.getHTTPStatusCode(th);
				if(status == 200) {
					status = statusLocal;
				} else if(status != statusLocal) {
					status = 207;  //mixed
				}
			}
		}
		return new SdmxResponse(status, out.toByteArray());
	}
	
	
	protected Map<RegistrationBean, Throwable> processRegistrations(List<RegistrationInformation> registrations, POSTRequest post) {
		Map<RegistrationBean, Throwable> resultMap = Collections.synchronizedMap(new HashMap<RegistrationBean, Throwable>());
		
		for(RegistrationInformation currentRegistrationInfo : registrations) {
			registerData(currentRegistrationInfo, resultMap);
		}
		processRegistrationResults(resultMap, post);
		return resultMap;
	}
	
	protected void processRegistrationResults(Map<RegistrationBean, Throwable> resultMap, POSTRequest post) {
		for(RegistrationBean reg : resultMap.keySet()) {
			Throwable th = resultMap.get(reg);
			if(th != null) {
				// NPE defence
				String causeMessage;
				if (th.getCause() == null) {
					causeMessage = "";
				} else {
					causeMessage = " - " + th.getCause().getMessage();
				}
				LOG.error("Failed Registration: "+reg.getDataSource().getDataUrl() + " - " + causeMessage);
				post.addFailedModification(reg, th);
			} else {
				post.addModification(reg);
			}
		}
	}
	
	
	protected ISdmxResponse processSubmitStructureRequest(ReadableDataLocation dataLocation, POSTRequest post, SDMX_SCHEMA schemaVersion, DATASET_ACTION actionType) {
		boolean isJson = dataLocation.getFormat() == FILE_FORMAT.JSON;
		try {
			if(structurePersistenceManager == null) {
				throw new SdmxNotImplementedException("Structure Submission");
			}
			ThreadLocalUtil.storeOnThread(AUDITABLE_TYPE.class.getName(), AUDITABLE_TYPE.STRUCTURE_SUBMISSION);
			StructureParseConfiguration config = StructureParseConfiguration.build();
			if(actionType != DATASET_ACTION.DELETE) {
				config.validate(true).resolution(resolutionSettings);
			}
			config.beansBuilder(new V3BeansBuilder(DeferredImmutableBeanBuilder.INSTANCE));
			SdmxBeans beans = structureParsingManager.parseStructures(dataLocation, config);
			if (actionType != null) {
				beans.setAction(actionType);
			}
			return processSubmitStructureRequest(beans, schemaVersion, actionType, post);
		} catch (Throwable th) {
			return getErrorResponse(th, isJson);
		}
	}

	@Override
	public ISdmxResponse processSubmitStructureRequest(SdmxBeans beans, SDMX_SCHEMA schemaVersion, DATASET_ACTION actionType, POSTRequest post) {
		boolean isJson = post.getReadableDataLocation().getFormat() == FILE_FORMAT.JSON;
		try {
			ThreadLocalUtil.storeOnThread(AUDITABLE_TYPE.class.getName(), AUDITABLE_TYPE.STRUCTURE_SUBMISSION);

			if(structurePersistenceManager == null) {
				throw new SdmxNotImplementedException("Structure Submission");
			}
			if(beans.getAllMaintainables().isEmpty()) {
				throw new SdmxException("Could not process submission - no structures found");
			}

			//FUNC 2.1 Provisions now part of the structure message and should be put into a single submission
			if (actionType == DATASET_ACTION.DELETE) {
				structurePersistenceManager.deleteStructures(beans);
			} else if (actionType == DATASET_ACTION.FULL_REPLACE) {
				// Obtain all of the beans BEFORE doing the replace
				SdmxBeans beansBefore = sdmxBeansRetreivalManager.getSdmxBeans();

				structurePersistenceManager.saveStructures(beans);
				if (beans.getAllMaintainables().size() == 0) {
					throw new SdmxException("Either no structures were submitted, or the submitted structures contain no changes from the ones currently stored in the system", SDMX_ERROR_CODE.NOT_MODIFIED);
				}

				// Obtain all of the beans AFTER doing the replace
				SdmxBeans beansAfter = sdmxBeansRetreivalManager.getSdmxBeans();
				
				// FR-2020: Construct a beansEvent from the before and after beans
				SdmxBeansEvent beansEvent = new SdmxBeansEventImpl(beansBefore, beansAfter);

				ByteArrayOutputStream out = new ByteArrayOutputStream();
				submitStructureResponseBuilder.buildSuccessResponse(beansEvent, out);
				SdmxResponse response = new SdmxResponse(200, out.toByteArray());
				post.setModifications(beans.getAllMaintainables());
				return response;
			} else {
				structurePersistenceManager.saveStructures(beans, post.getErrorHandler());
			}
			
			if (beans.getAllMaintainables().isEmpty() && post.getErrorHandler() != null && post.getErrorHandler().getErrors().isEmpty()) {
				throw new SdmxException("Either no structures were submitted, or the submitted structures contain no changes from the ones currently stored in the system", SDMX_ERROR_CODE.NOT_MODIFIED);
			}
			ISdmxResponse response = structureSubmissionResponseManager.buildSuccessResponse(beans, schemaVersion, post.getErrorHandler());
			post.setModifications(beans.getAllMaintainables());
			return response;
		} catch (MaintainableBeanException ex) {
			if(post.isReturnStructuresAsRegistryStructureResponse()) {
				return getErrorResponse(ex, URN.builder().agencyId(ex.getAgencyId()).maintId(ex.getId()).version(ex.getVersion()).structure(ex.getStructureType()).buildSingle(), schemaVersion);
			}
			return getErrorResponse(ex, isJson);
		} catch (CrossReferenceException ex) {
			if(ex.getCrossReference() != null) {
				SDMXBean referencedFrom = ex.getCrossReference().getReferencedFrom();
				if(post.isReturnStructuresAsRegistryStructureResponse()) {
					getErrorResponse(ex, referencedFrom.getParent(IdentifiableBean.class, true).getURN(), schemaVersion);
				} else {
					return getErrorResponse(ex, isJson);
				}
			}
			return getErrorResponse(ex, isJson);
		} catch (Throwable th) {
			return getErrorResponse(th, isJson);
		}
	}

	/**
	 * Writes the response as a RegistrySubmit response message
	 * @param th
	 * @param sRef
	 * @return
	 */
	private ISdmxResponse getErrorResponse(Throwable th, IURNSingle<?> sRef, SDMX_SCHEMA schemaVersion) {
		return structureSubmissionResponseManager.buildErrorResponse(th, sRef, schemaVersion);
	}

	/**
	 * Writes the error as a general error message
	 * @param th
	 * @return
	 */
	protected ISdmxResponse getErrorResponse(Throwable th, boolean isJson) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		errorWriterManager.writeError(th, out, isJson ? JsonErrorFormat.getInstance() : SdmxErrorFormat.getInstance());
		return new SdmxResponse(ErrorUtil.getHTTPStatusCode(th), out.toByteArray());
	}
	
	protected void registerData(RegistrationInformation registrationInfo, Map<RegistrationBean, Throwable> resultMap) {
		RegistrationBean registration = registrationInfo.getRegistration();
		String regURL = registration.getDataSource().getDataUrl().toString();
		try {
			switch(registrationInfo.getRegistrationAction()) {
			case DELETE :
				LOG.info("Process Delete Registration: "+regURL);
				registrationPersistenceManager.deleteRegistration(registration);	break;
			case REPLACE :
				LOG.info("Process Replace Registration: "+regURL);
				registrationPersistenceManager.replaceRegistration(registration);	 break;
			default :
				LOG.info("Process Save Registration: "+regURL);
				registrationPersistenceManager.saveRegistration(registration);	 break;
			}
			LOG.info("Process Registration Completed Successfully: "+regURL);
			resultMap.put(registration, null);
		} catch(Throwable th) {
			LOG.error("Failed to process Registration: "+regURL);
			resultMap.put(registration, th);
		}
	}
}
