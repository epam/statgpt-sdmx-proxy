package io.sdmx.fusion.service.api.model;

import io.sdmx.fusion.service.model.request.WebServiceRequestInfo;

/**
 * An SdxmServlet is a HttpServelt that is capable of performing SDMX actions, such as executing an SDMX REST query, or executing a 
 * HTTP Post.  The SdmxServlet contains a WebServiceRequestInfo, which describes which actions can be performed on this servlet, and 
 * the default response format. 
 */
public interface SdmxServlet {

	/**
	 * Returns the WebServiceRequestInfo for this servlet - this contains information such as
	 * the response format/version and the allowed actions on the servlet (such as a DataQuery, or Structure Submission)
	 * @return
	 */
	WebServiceRequestInfo getWebServiceRequestInfo();
	
}
