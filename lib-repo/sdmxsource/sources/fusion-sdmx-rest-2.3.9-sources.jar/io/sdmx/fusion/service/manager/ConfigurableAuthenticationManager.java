package io.sdmx.fusion.service.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.SpringSecurityMessageSource;
import org.springframework.util.Assert;

import io.sdmx.fusion.security.api.model.user.SdmxSecurityDetails;
import io.sdmx.fusion.security.model.SecurityDetailsImpl;

/**
 * Can be configured to authenticate via Fusion Security - if the Fusion Security URL is provided, in which case
 * the authentication is passed to the FusionSecurityRESAuthenticationManager
 * <br/>
 * If Fusion Security URL is not configured, then will authenticate using default user credentials
 */
public class ConfigurableAuthenticationManager implements AuthenticationProvider {
	private static final Logger LOG = LoggerFactory.getLogger(ConfigurableAuthenticationManager.class);
	
	private MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
	
	@Autowired
	private FusionSecurityRESTAuthenticationManager fusionSecurityAuthManager;

	
	private String defaultUsername;
	private String defaultPassword;
	private Boolean isLoginEnabled = true;
	
	public ConfigurableAuthenticationManager(String defaultUsername, String defaultPassword) {
		this.defaultUsername = defaultUsername;
		this.defaultPassword = defaultPassword;
	}
	
	@Override
	public boolean supports(Class<?> authentication) {
		return (UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication));
	}
	
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		if(!isLoginEnabled) {
			throw new BadCredentialsException("Login is not supported");
		}
		if(fusionSecurityAuthManager.supports(authentication.getClass())) {
			return fusionSecurityAuthManager.authenticate(authentication);
		}
		Assert.isInstanceOf(UsernamePasswordAuthenticationToken.class, authentication,
				messages.getMessage("AbstractUserDetailsAuthenticationProvider.onlySupports",
						"Only UsernamePasswordAuthenticationToken is supported"));
		
		UsernamePasswordAuthenticationToken usernamePassword = (UsernamePasswordAuthenticationToken) authentication;
		
		String username = (String) usernamePassword.getPrincipal();
		String password = (String) usernamePassword.getCredentials();
		
		if(defaultPassword.equals(password) && defaultUsername.equals(username)) {
			LOG.debug("User authenticated against default authentication credentials, create default admin user");
			SdmxSecurityDetails principle = new SecurityDetailsImpl(false, "root", username, password, "root@sdmxfusion.com", true, true);
			return UsernamePasswordAuthenticationToken.authenticated(principle, null, principle.getAuthorities());
		}
		throw new BadCredentialsException("Not Authorised");
	}

	public void setIsLoginEnabled(Boolean isLoginEnabled) {
		this.isLoginEnabled = isLoginEnabled;
	}
}
