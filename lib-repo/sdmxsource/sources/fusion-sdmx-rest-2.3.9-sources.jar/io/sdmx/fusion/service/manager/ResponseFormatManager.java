package io.sdmx.fusion.service.manager;

import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.format.IResponseFormatFactory;
import io.sdmx.api.format.IResponseFormatManager;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.Request;
import io.sdmx.utils.core.application.FusionBeanStore;

public class ResponseFormatManager implements IResponseFormatManager {
	private Set<IResponseFormatFactory> factories;

	@Override
	public InformationFormat getInformationFormat(Request request, IResource resource) {
		for(IResponseFormatFactory currentFact : getFactories()) {
			InformationFormat inf = currentFact.getInformationFormat(request, resource);
			if(inf != null) {
				return inf;
			}
		}
		return null;
	}
	
	private Set<IResponseFormatFactory> getFactories() {
		if(factories == null) {
			 Set<IResponseFormatFactory> factories = new HashSet<>(FusionBeanStore.getBeans(IResponseFormatFactory.class));
			 this.factories = factories;
		}
		return this.factories;
	}

}
