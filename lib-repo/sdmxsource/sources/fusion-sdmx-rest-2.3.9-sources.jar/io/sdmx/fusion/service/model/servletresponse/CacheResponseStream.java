package io.sdmx.fusion.service.model.servletresponse;

import java.io.IOException;
import java.io.OutputStream;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.WriteListener;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Writes to two locations - the servlet output stream, and another output stream (the cache)
 * @author Metadata Technology
 *
 */
public class CacheResponseStream extends ServletOutputStream {
	protected HttpServletResponse response;
	protected ServletOutputStream output;
	protected OutputStream cache;
	private boolean isClosed;

	public CacheResponseStream(HttpServletResponse response, OutputStream cache) {
		super();
		isClosed = false;
		this.response = response;
		this.cache = cache;
	}

	@Override
	public void close() throws IOException {
		if (isClosed) {
			throw new IOException("The output stream has already been closed");
		}
		cache.close();
		isClosed = true;
	}

	@Override
	public void flush() throws IOException {
		if (isClosed) {
			throw new IOException("The Output Stream is closed and cannot be flushed!");
		}
		cache.flush();
	}

	@Override
	public void write(int b) throws IOException {
		if (isClosed) {
			throw new IOException("The Output Stream is closed and cannot be written to!");
		}
		cache.write((byte)b);
	}

	@Override
	public void write(byte b[]) throws IOException {
		write(b, 0, b.length);
	}

	@Override
	public void write(byte b[], int off, int len) throws IOException {
		if (isClosed) {
			throw new IOException("The Output Stream is closed and cannot be written to!");
		}
		cache.write(b, off, len);
	}

	public boolean closed() {
		return this.isClosed;
	}

	public void reset() {
		// No operations required here
	}

	@Override
	public boolean isReady() {
		return true;
	}

	@Override
	public void setWriteListener(WriteListener writeListener) {
		throw new UnsupportedOperationException("This has not been implemented");
	}
}
