package io.sdmx.fusion.service.filter;

import java.io.IOException;

import io.sdmx.fusion.service.model.servletresponse.GZIPResponseWrapper;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class GZIPFilter implements Filter {

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain fChain) throws IOException, ServletException {
		// Ensure that this request is HTTP
		if (servletRequest instanceof HttpServletRequest) {
			HttpServletRequest request = (HttpServletRequest)servletRequest;
			HttpServletResponse response = (HttpServletResponse)servletResponse;
			String saveas = request.getParameter("saveAs");
			if(saveas == null) {
				saveas = request.getParameter("saveas");
			}
			String acceptEncodingStr = request.getHeader("accept-encoding");
			boolean zip = acceptEncodingStr != null && acceptEncodingStr.indexOf("gzip") != -1;
			if(saveas != null && saveas.endsWith(".zip")) {
				zip = false;
			}
			
			if (zip) {
				GZIPResponseWrapper gzipResponse = new GZIPResponseWrapper(response);
				ThreadLocalUtil.storeOnThread(GZIPResponseWrapper.THREAD_KEY, gzipResponse);
				try {
					fChain.doFilter(servletRequest, gzipResponse);
					gzipResponse.finishResponse();
				} finally {
					ThreadLocalUtil.clearFromThread(GZIPResponseWrapper.THREAD_KEY);
				}
				return;
			}
			fChain.doFilter(servletRequest, servletResponse);
		}
	}

	@Override
	public void init(FilterConfig filterConfig) {
		// No operations required here
	}

	@Override
	public void destroy() {
		// No operations required here
	}
}
