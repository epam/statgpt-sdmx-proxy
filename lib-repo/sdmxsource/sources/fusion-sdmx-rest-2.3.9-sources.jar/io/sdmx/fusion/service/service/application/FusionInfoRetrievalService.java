package io.sdmx.fusion.service.service.application;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.application.FusionProductInformation;
import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.lang.LanguageInformationManager;
import io.sdmx.core.sdmx.api.manager.structure.StructureFormatManager;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.StreamingOutput;

@Path("/info")
public class FusionInfoRetrievalService extends AbstractRestService {

	private FusionProductInformationRetrievalManager fusionProductInformationRetrievalManager = SingletonStore.getSingleton(FusionProductInformationRetrievalManager.class);
	private LanguageInformationManager langInformationManager = SingletonStore.getSingleton(LanguageInformationManager.class);
	private StructureFormatManager structureFormatManager = SingletonStore.getSingleton(StructureFormatManager.class);
	
	@GET
	@Produces("application/json")
	@Path("/formats/structure")
	/**
	 * Returns the application VND header along with the structure format
	 * 
	 * Example Response :
	 * 
	 * {
	 *  application/vnd.sdmx.json: "JSON",
		application/vnd.sdmx.structure+xml;version=1.0: "SDMX_V1_STRUCTURE_DOCUMENT",
		application/vnd.sdmx.structure+xml;version=2.0: "SDMX_V2_STRUCTURE_DOCUMENT",
	 * }
	 * 
	 * @return
	 */
	public Response getSupportedStructureFormats(final @QueryParam("callback") String callback) {
		return super.performWebService(response -> {
			JSONObject json = new JSONObject();
			Map<String, FormatDetails> formats = structureFormatManager.getSupportedFormats();
			for(String vndHeader : structureFormatManager.getSupportedFormats().keySet()) {
				FormatDetails format = formats.get(vndHeader);
				json.put(vndHeader, format.getFormatAsString());
			}
			return json;
		});
	}
	

	@GET
	@Produces("application/json")
	@Path("/product")
	/**
	 * 
	 * @param callback if provided then this is a JSONP request and the response should be in a jsonp wrapper
	 * @return
	 */
	public StreamingOutput getProductInformation(final @QueryParam("callback") String callback) {
		return new StreamingOutput() {

			@Override
			public void write(OutputStream output) throws IOException, WebApplicationException {
				try {
					FusionProductInformation fusionProductInformation = fusionProductInformationRetrievalManager.getFusionProductInformation();
					
					String productInfo = fusionProductInformation.toString();
					if(callback != null) {
						productInfo = callback+"("+productInfo+")";
					}
					output.write(productInfo.getBytes(StandardCharsets.UTF_8));
				} catch (Throwable th) {
					writeError(th, output);
				}
			}
		};
	}
	

	@GET
	@Produces("application/json")
	@Path("/product/public")
	/**
	 * 
	 * @param callback if provided then this is a JSONP request and the response should be in a jsonp wrapper
	 * @return
	 */
	public StreamingOutput getPublicProductInformation(final @QueryParam("callback") String callback) {
		return new StreamingOutput() {

			@Override
			public void write(OutputStream output) throws IOException, WebApplicationException {
				try {
					FusionProductInformation fusionProductInformation = fusionProductInformationRetrievalManager.getFusionProductInformation();

					String productInfo = fusionProductInformation.publicApiToString();
					if(callback != null) {
						productInfo = callback+"("+productInfo+")";
					}
					output.write(productInfo.getBytes(StandardCharsets.UTF_8));
				} catch (Throwable th) {
					writeError(th, output);
				}
			}
		};
	}

	@GET
	@Produces("application/json")
	@Path("/lang")
	/**
	 * Returns Supported Languages of the Registry (based on the languages defined in the current metadata), the Browser Locale, and User Locale (saved on user's session) if appliable
	 * @param callback
	 * @param request
	 * @return
	 */
	public StreamingOutput getApplicationInformation(final @QueryParam("callback") String callback, @Context final HttpServletRequest request) {
		return new StreamingOutput() {

			@Override
			public void write(OutputStream output) throws IOException, WebApplicationException {
				try {
					if (langInformationManager != null) {
						try {
							JSONObject jsonObject = new JSONObject();
							JSONArray langauges = new JSONArray(langInformationManager.getSupportedLanguages());
							jsonObject.put("SupportedLanguages", langauges);
							Locale local = request.getLocale();
							String userLocale = (String) request.getSession().getAttribute("locale");

							if(local != null) {
								jsonObject.put("BrowserLocale", local.toString());
							}
							if(userLocale != null) {
								jsonObject.put("UserLocale", userLocale);
							}

							String langInfo = jsonObject.toString();
							if(callback != null) {
								langInfo = callback+"("+langInfo+")";
							}
							output.write(langInfo.getBytes(StandardCharsets.UTF_8));

						} catch (Throwable e) {
							e.printStackTrace();
						}
					} else {
						throw new SdmxNotImplementedException("Applicaiton Information is not implemented on this server");
					}
				} catch (Throwable th) {
					writeError(th, output);
				}
			}
		};
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/setlang")
	/**
	 * Sets the desired locale on the user session
	 * @param postMsg
	 * @return
	 */
	public  StreamingOutput setLocale(final String lang, @Context final HttpServletRequest request) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					HttpSession session = request.getSession();
					session.setAttribute("locale", lang);
					writeSuccess(out);
				} catch(Throwable th) {
					writeError(th, out);
				}
			}
		};
	}

}
