package io.sdmx.fusion.service.service.http;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;

import org.codehaus.jettison.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.service.http.ICORSSettingsService;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/settings/cors")
@Produces(MediaType.APPLICATION_JSON)
public class CORSSettingsService extends AbstractRestService {
	private static final Logger LOG = LoggerFactory.getLogger(CORSSettingsService.class);
	
	private ICORSSettingsService corsSettingsServiceService = SingletonStore.getSingleton(ICORSSettingsService.class);

	@DELETE
	@Path("/settings")
	@Consumes(MediaType.APPLICATION_JSON)
	public final Response replaceSettings(final String jsonPost) {
		LOG.debug("replace request");
		return super.performWebService(response -> {
			JSONArray array = new JSONArray(jsonPost);
			corsSettingsServiceService.replaceSettings(array);
			return getSuccess();
		});
	}

	@GET
	@Path("/settings")
	@Produces("application/json")
	public final Response getSettings() {
		LOG.debug("getCorsSettings request");
		return super.performWebService(response -> {
			OutputStream out = new ByteArrayOutputStream();
			corsSettingsServiceService.writeSettings(out);
			return out;
		});
	}

}