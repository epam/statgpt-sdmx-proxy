package io.sdmx.fusion.service.engine.post.v2;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.fusion.service.api.engine.ISDMXRESTPostRequestEngine;
import io.sdmx.fusion.service.api.manager.StructureSubmissionRequestManager;
import io.sdmx.fusion.service.api.model.ISdmxResponse;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.fusion.service.model.request.POSTRequest;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class SDMXRESTPostRegistrationRequestEngineV2 implements ISDMXRESTPostRequestEngine {
	private static final ISdmxVersion REST_VERSION = SdmxVersion.getInstance(2, 0, 0);

	private StructureSubmissionRequestManager submissionRequestManager;
	
	public SDMXRESTPostRegistrationRequestEngineV2(StructureSubmissionRequestManager submissionRequestManager) {
		this.submissionRequestManager = submissionRequestManager;
	}

	@Override
	public void processRequest(InformationFormat responseFormat, Request request, IResponse response) {
		ReadableDataLocation rdl = request.getReadableDataLocation();
		ISdmxResponse sdmxResponse = submissionRequestManager.processSubmitRegistrationRequest(rdl, new POSTRequest(rdl, null, null, true, null, null));
		response.setStatus(sdmxResponse.getHttpStatusCode());
		sdmxResponse.writeResponse(response.getOutputStream());
	}

	@Override
	public IResource getResourceType() {
		return SDMX_REST_RESOURCE.REGISTRATION.getResource();
	}

	@Override
	public ISdmxVersion getRestVersion() {
		return REST_VERSION;
	}

	
	
}
