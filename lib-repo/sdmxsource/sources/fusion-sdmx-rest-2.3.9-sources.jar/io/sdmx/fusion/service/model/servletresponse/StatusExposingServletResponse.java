package io.sdmx.fusion.service.model.servletresponse;

import java.io.IOException;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletResponseWrapper;

public class StatusExposingServletResponse extends HttpServletResponseWrapper {
	private int httpStatus = 200;

	public StatusExposingServletResponse(HttpServletResponse response) {
		super(response);
	}

	@Override
	public void sendError(int sc) throws IOException {
		httpStatus = sc;
		super.sendError(sc);
	}

	@Override
	public void sendError(int sc, String msg) throws IOException {
		httpStatus = sc;
		super.sendError(sc, msg);
	}

	@Override
	public void sendRedirect(String location) throws IOException {
		httpStatus = HttpServletResponse.SC_SEE_OTHER;
		super.sendRedirect(location);
	}

	@Override
	public void setStatus(int sc) {
		httpStatus = sc;
		super.setStatus(sc);
	}

	@Override
    public int getStatus() {
		return httpStatus;
	}
}