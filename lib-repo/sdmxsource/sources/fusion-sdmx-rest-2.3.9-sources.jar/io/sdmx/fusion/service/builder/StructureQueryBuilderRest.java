package io.sdmx.fusion.service.builder;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import io.sdmx.api.application.IVersion;
import io.sdmx.api.sdmx.builder.StructureQueryBuilder;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.reference.IVersionRef;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.api.sdmx.model.query.StructureQueryMetadata;
import io.sdmx.fusion.service.util.SDMXRestQueryUtil;

@Service
public class StructureQueryBuilderRest implements StructureQueryBuilder<String> {
	private Map<SDMX_STRUCTURE_TYPE, String> maint2PathV1 = new HashMap<>();
	private Map<SDMX_STRUCTURE_TYPE, String> maint2PathV2 = new HashMap<>();
	
	
	public StructureQueryBuilderRest() {
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.DSD, "datastructure");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.MSD, "metadatastructure");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME, "categoryscheme");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME, "conceptscheme");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.CODE_LIST, "codelist");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.HIERARCHY, "hierarchicalcodelist");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.ORGANISATION_SCHEME, "organisationscheme");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.AGENCY_SCHEME, "agencyscheme");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.DATA_PROVIDER_SCHEME, "dataproviderscheme");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.DATA_CONSUMER_SCHEME, "dataconsumerscheme");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.ORGANISATION_UNIT_SCHEME, "organisationunitscheme");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.DATAFLOW, "dataflow");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.METADATA_FLOW, "metadataflow");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.REPORTING_TAXONOMY, "reportingtaxonomy");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT, "provisionagreement");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.STRUCTURE_MAP, "structureset");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP, "structureset");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.STRUCTURE_SET, "structureset");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.PROCESS, "process");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.CATEGORISATION, "categorisation");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT, "contentconstraint");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.VTL_TRANSFORMATION_SCHEME, "transformationscheme");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.VTL_RULESET_SCHEME, "rulesetscheme");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.VTL_USER_DEFINED_OPERATOR_SCHEME, "userdefinedoperatorscheme");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.VTL_CUSTOM_TYPE_SCHEME, "customtypescheme");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.VTL_NAME_PERSONALISATION_SCHEME, "namepersonalisationscheme");
		maint2PathV1.put(SDMX_STRUCTURE_TYPE.VTL_MAPPING_SCHEME, "vtlmappingscheme");
		
		maint2PathV2 = new HashMap<>(maint2PathV1); //Copy V1 then override/extend where required
		maint2PathV2.put(SDMX_STRUCTURE_TYPE.HIERARCHY, "hierarchy");  							//override
		maint2PathV2.put(SDMX_STRUCTURE_TYPE.HIERARCHY_ASSOCIATION, "hierarchyassociation");  	//extend
		maint2PathV2.put(SDMX_STRUCTURE_TYPE.VALUE_LIST, "valuelist");  						//extend
		maint2PathV2.put(SDMX_STRUCTURE_TYPE.STRUCTURE_MAP, "structuremap");
		maint2PathV2.put(SDMX_STRUCTURE_TYPE.REPRESENTATION_MAP, "representationmap");
		maint2PathV2.put(SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME_MAP, "categoryschememap");
		maint2PathV2.put(SDMX_STRUCTURE_TYPE.CONCEPT_SCHEME_MAP, "conceptschememap");
		maint2PathV2.put(SDMX_STRUCTURE_TYPE.ORGANISATION_SCHEME_MAP, "organisationschememap");
		maint2PathV2.put(SDMX_STRUCTURE_TYPE.CONTENT_CONSTRAINT, "dataconstraint");
		maint2PathV2.put(SDMX_STRUCTURE_TYPE.METADATA_CONSTRAINT, "metadataconstraint");
	}
	

	@Override
	public String buildStructureQuery(RESTStructureQuery sQuery, IVersion apiVersion) {
		StringBuilder sb = new StringBuilder();
		return buildStructureQuery(sb, sQuery, apiVersion);
	}

	@Override
	public String buildStructureQuery(String prefix, RESTStructureQuery sQuery, IVersion apiVersion) {
		if(prefix == null) {
			return buildStructureQuery(sQuery, apiVersion);
		}
		return buildStructureQuery(new StringBuilder(prefix), sQuery, apiVersion);
	}

	private String buildStructureQuery(StringBuilder sb, RESTStructureQuery sQuery, IVersion apiVersion) {
		if(sQuery == null) {
			throw new IllegalArgumentException("StructureQueryBuilderRest.buildStructureQuery StructureQuery is required, null was passed");
		}
		boolean isV2 = apiVersion.getMajor() == 2;
		
		if(isV2) {
			appendPathPart(sb, "structure");
		}
		IURN<?> sRef = sQuery.getStructureReference();
		if(sRef == null || sRef.getSdmxStructure() == SDMX_STRUCTURE_TYPE.ANY
				        || sRef.getSdmxStructure() == SDMX_STRUCTURE_TYPE.MAINTAINABLE) {
			appendPathPart(sb, isV2 ?  "*" : "structure");
		} else if(sRef.getSdmxStructure() == SDMX_STRUCTURE_TYPE.ORGANISATION_SCHEME) {
			appendPathPart(sb, "organisationscheme");
		}
		else {
			Map<SDMX_STRUCTURE_TYPE, String> paths = isV2 ? maint2PathV2 : maint2PathV1;
			String path = paths.get(sRef.getSdmxStructure().getMaintainableStructureType());
			if(path == null) {
				path = sRef.getSdmxStructure().getUrnClass().toLowerCase();
			}
			appendPathPart(sb, path);
		}
		String all = isV2 ? "*" : "all";
		SDMXRestQueryUtil.buildMaintainablePath(sRef, sb, all);
		
		StructureQueryMetadata sQueryMetadata = sQuery.getStructureQueryMetadata();
		IVersionRef strVersion = sRef.getVersion();
		
		if(!isV2) {
			if(strVersion.isLatest()) {
				appendPathPart(sb, "latest");
			} else if(strVersion.isAll()) {
				appendPathPart(sb, "all");
			} else {
				appendPathPart(sb, strVersion.toString());
			}
		} else {
			appendPathPart(sb, strVersion.toString());
		}
		//Identifiable Reference
		if(sRef.getIdentifiableId() != null) {
			switch(sRef.getMaintainableURN().getSdmxStructure()) {
			case AGENCY_SCHEME:
			case DATA_PROVIDER_SCHEME:
			case DATA_CONSUMER_SCHEME:
			case ORGANISATION_SCHEME:
			case CATEGORY_SCHEME:
			case CONCEPT_SCHEME:
			case CODE_LIST:
				String childRef = sRef.getIdentifiableId().replaceAll("\\.", "/");
				sb.append("/"+childRef);
			default :
				//query for identifiable not supported
			}
		}
		SDMXRestQueryUtil.appendSlash(sb);
		if(sQueryMetadata != null) {
			String concat = "?";
			if(sQueryMetadata.getSpecificStructureReference() != null) {
				sb.append(concat + "references=" +sQueryMetadata.getSpecificStructureReference().getUrnClass().toLowerCase());
				concat = "&";
			} else if(sQueryMetadata.getStructureReferenceDetail() != null) {
				sb.append(concat + "references=" +sQueryMetadata.getStructureReferenceDetail().toString());
				concat = "&";
			}
			if(sQueryMetadata.getStructureQueryDetail() != null) {
				sb.append(concat + "detail=" +sQueryMetadata.getStructureQueryDetail().toString());
				concat = "&";
			}
		}
		return sb.toString();
	}
	
	private void appendPathPart(StringBuilder sb, String append) {
		SDMXRestQueryUtil.appendSlash(sb);
		sb.append(append);
	}
	
}
