package io.sdmx.fusion.service.filter;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

/**
 * A Character set filter.
 */
public class CharsetFilter implements Filter {
    private String encoding;

    @Override
	public void init(FilterConfig config) throws ServletException {
        encoding = config.getInitParameter("requestEncoding");
        if (encoding == null) {
			encoding = "UTF-8";
		}
    }

    @Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain next)
            throws IOException, ServletException {
        request.setCharacterEncoding(encoding);
        next.doFilter(request, response);
    }
 
    @Override
	public void destroy() {
        // Left intentionally empty
    }
}