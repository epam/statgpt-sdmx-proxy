package io.sdmx.fusion.service.manager;

import java.util.Set;

import io.sdmx.api.application.ApplicationCacheInfoManager;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.manager.output.IMetadataWriterManager;
import io.sdmx.api.sdmx.manager.structure.IQueryMetadataRequestManager;
import io.sdmx.api.sdmx.manager.structure.StrucutreInformationManager;
import io.sdmx.api.sdmx.model.beans.IReferenceMetadataContainer;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.reference.IOrganisationRef;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.sdmx.model.query.IMetadataQueryRequest;
import io.sdmx.api.sdmx.model.query.IRESTMetadataQuery;
import io.sdmx.core.sdmx.api.manager.structure.ServiceRetrievalManager;
import io.sdmx.core.structure.api.manager.IMetadataRetrievalManager;
import io.sdmx.fusion.service.util.RequestManagerUtil;
import io.sdmx.im.beans.container.ReferenceMetadataContainer;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.OrganisationRef;
import io.sdmx.utils.sdmx.xs.URN;

public class QueryMetadataRequestManager implements IQueryMetadataRequestManager {
	
	private IMetadataRetrievalManager metadataRetrievalManager;
	private IMetadataWriterManager metadataWriterManager;
	private ServiceRetrievalManager serviceRetrievalManager;

	private ApplicationCacheInfoManager cacheInfoManager;
	private StrucutreInformationManager infoManager;
	
	public QueryMetadataRequestManager(IMetadataRetrievalManager metadataRetrievalManager,
									   IMetadataWriterManager metadataWriterManager,
									   ServiceRetrievalManager serviceRetrievalManager,
									   StrucutreInformationManager infoManager,
									   ApplicationCacheInfoManager cacheInfoManager) {
		this.metadataRetrievalManager = metadataRetrievalManager;
		this.metadataWriterManager = metadataWriterManager;
		this.serviceRetrievalManager = serviceRetrievalManager;
		this.infoManager = infoManager;
		this.cacheInfoManager = cacheInfoManager;
	}

	@Override
	public void processQuery(IMetadataQueryRequest metadataQueryRequest) {
		IRESTMetadataQuery restQuery = metadataQueryRequest.getMetadataQueryRequest();
		IReferenceMetadataContainer container = processQuery(restQuery);

		if(processHttp304(metadataQueryRequest.getRequest(), metadataQueryRequest.getResponse(), container)) {
			return;
		}
		if (container.getReferenceMetadata().size() == 0) {
			throw new SdmxNoResultsException("No Results Found");
		}
		
		IMetadataFormat toWriteFormat = metadataQueryRequest.getFormat();
		metadataQueryRequest.getResponse().setContentType(toWriteFormat.getFormatDetails().getMimeType());
		metadataWriterManager.write(container, toWriteFormat, metadataQueryRequest.getResponse().getOutputStream());
	}

	@Override
	public IReferenceMetadataContainer processQuery(IRESTMetadataQuery restQuery) {
		Set<IReportedMetadataSetBean> queryResponse = null;
		if(restQuery.getQueryType() == null) {
			throw new SdmxException("Missing query type");
		}
		IURN<?> maintRef = restQuery.getURN();
		switch(restQuery.getQueryType()) {
		case BY_METADATAFLOW:
			//A string identifying the metadata provider. The syntax is agency id, provider id, separated by a ",".
			//For example: AGENCY_ID,PROVIDER_ID. In case the string only contains one out of these 2 elements, it is considered to be the provider id, i.e. all,PROVIDER_ID.
			String providerId = restQuery.getAdditionalPathParameters().size() > 0 ? restQuery.getAdditionalPathParameters().get(0) : null;
			IOrganisationRef provRef = providerId == null ? null : OrganisationRef.fromString(providerId, SDMX_STRUCTURE_TYPE.METADATA_PROVIDER);
			IURNSingle<IMetadataProviderBean> metadataProviderRef = provRef == null ? null : URN.builder().agencyId(provRef.getAgencyId()).identifableId(CollectionUtil.join(",", "", provRef.getOrganisationIds())).buildSingle(IMetadataProviderBean.class);
			queryResponse = metadataRetrievalManager.findByMetadataflow(maintRef.toType(MetadataFlowBean.class), metadataProviderRef, restQuery.getAsOf());
			break;
		case BY_METADATASET:
			queryResponse = metadataRetrievalManager.findByMetadataSet(maintRef.toType(IReportedMetadataSetBean.class), restQuery.getAsOf());
			break;
		case BY_STRUCTURE:
			queryResponse = metadataRetrievalManager.findByStructure(maintRef, restQuery.getAsOf());
			break;
		}
		
		if(!ObjectUtil.validCollection(queryResponse)) {
			throw new SdmxNoResultsException("No Results Found");
		}
		boolean isCompleteStub = restQuery.getStructureQueryDetail() == STRUCTURE_QUERY_DETAIL.ALL_COMPLETE_STUBS;
		boolean isStub = restQuery.getStructureQueryDetail() == STRUCTURE_QUERY_DETAIL.ALL_STUBS || isCompleteStub;
		
		IReferenceMetadataContainer container = new ReferenceMetadataContainer();
		for(IReportedMetadataSetBean metadataSet : queryResponse) {
			if(isStub) {
				metadataSet = (IReportedMetadataSetBean) serviceRetrievalManager.createStub(metadataSet, isCompleteStub);
			}
			container.addReferenceMetadata(metadataSet);
		}
		return container;
	}
	
	private boolean processHttp304(Request request, IResponse response, IReferenceMetadataContainer container) {
		if(cacheInfoManager != null && cacheInfoManager.isNotModifiedEanbled()) {
			Set<? extends MaintainableBean> refMetadata = container.getReferenceMetadata();
			return RequestManagerUtil.processIfModifiedSince(infoManager, request, response, (Set<MaintainableBean>)refMetadata) ||
					RequestManagerUtil.processEtag(infoManager, request, response, (Set<MaintainableBean>)refMetadata);
	    }
		return false;
	}
	
}
