package io.sdmx.fusion.service.model.request;

import java.util.List;

import io.sdmx.api.sdmx.model.data.query.DataQuery;

public class QueryDataRequest {
	private WebServiceRequest webServiceRequest;
	private List<DataQuery> dataQueries;

	public List<DataQuery> getDataQueries() {
		return dataQueries;
	}

	public WebServiceRequest getWebServiceRequest() {
		return webServiceRequest;
	}
}
