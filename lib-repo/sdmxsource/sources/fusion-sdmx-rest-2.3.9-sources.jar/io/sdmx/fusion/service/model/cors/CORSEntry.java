package io.sdmx.fusion.service.model.cors;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import io.sdmx.api.exception.SdmxSyntaxException;
import io.sdmx.api.http.CORSBase;
import io.sdmx.utils.json.JsonObjectUtil;
import org.codehaus.jettison.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CORSEntry implements CORSBase {
    private static final CORSEntry PERMISSIVE_SETTING = new CORSEntry("*", Arrays.asList("*"), Arrays.asList("*"), Arrays.asList("Content-Disposition"), false);
    private static final CORSEntry EMPTY_INDICATOR = new CORSEntry("EMPTY_INDICATOR", Arrays.asList("*"), Arrays.asList("*"), Arrays.asList("EMPTY_INDICATOR"), false);

	private boolean allowCreds;
	private String url;
	private List<String> methods = new ArrayList<>();
	private List<String> headers = new ArrayList<>();
	private List<String> exposedHeaders = new ArrayList<>();

	/**
	 * @return CORSEntry that allows anything
	 */
	public static CORSEntry getPermissive() {
	    return PERMISSIVE_SETTING;
	}

	/**
     * @return CORSEntry that indicates that explicitly no CORS settings have been specified
     */
    public static CORSEntry getEmptyIndicator() {
        return EMPTY_INDICATOR;
    }

	public CORSEntry(JSONObject jsonObject) {
		this.url = JsonObjectUtil.getString(jsonObject, "url", false);
		this.methods = Collections.unmodifiableList(JsonObjectUtil.unpackStringArray(jsonObject, "methods", false));
		this.headers = Collections.unmodifiableList(JsonObjectUtil.unpackStringArray(jsonObject, "headers", false));
		this.exposedHeaders = Collections.unmodifiableList(JsonObjectUtil.unpackStringArray(jsonObject, "exposedHeaders", false));
		this.allowCreds = JsonObjectUtil.getBoolean(jsonObject, "allowCreds", false);
		validate();
	}

	public CORSEntry(String url, List<String> methods, List<String> headers, List<String> exposedHeaders, boolean allowCreds) {
		this.url = url;
		this.methods = Collections.unmodifiableList(methods);
		this.headers = Collections.unmodifiableList(headers);
		this.allowCreds = allowCreds;
		this.exposedHeaders = Collections.unmodifiableList(exposedHeaders);
		validate();
	}

	@Override
	public String getUrl() {
		return url;
	}

	@Override
	public List<String> getMethods() {
		return methods;
	}

	@Override
	public List<String> getHeaders() {
		return headers;
	}

	@Override
	public List<String> getExposedHeaders() {
		return exposedHeaders;
	}

	@Override
	public boolean getAllowCreds() {
		return allowCreds;
	}

	@Override
	public String toJSONString() {
		try {
			return new ObjectMapper().writeValueAsString(this);
		} catch (JsonProcessingException e) {
			throw new UnsupportedOperationException();
		}
	}

	private void validate() {
		if ((this.url == null) || (this.exposedHeaders == null) || (this.headers == null) || (this.methods == null)) {
			throw new SdmxSyntaxException("CORS Settings parameters cannot be null");
		}

		if (this.allowCreds) {
			if (this.url.equals("*")) {
				throw new SdmxSyntaxException("Allow Credentials = True cannot be cobined with wildcard url \'*\'.");
			}
		}

		if (this.exposedHeaders.contains("*")) {
			throw new SdmxSyntaxException("Exposed Headers cannot be \'*\'");
		}
	}

	@Override
    public boolean equals(Object obj) {
        if (!(obj instanceof CORSEntry)) {
            return false;
        }
        CORSEntry that = (CORSEntry)obj;

        return this.getAllowCreds() == that.getAllowCreds() &&
               this.getUrl().equals(that.getUrl()) &&
               this.getMethods().equals(that.getMethods()) &&
               this.getHeaders().equals(that.getHeaders()) &&
               this.getExposedHeaders().equals(that.getExposedHeaders());
	}

	@Override
    public int hashCode() {
	    return (this.getAllowCreds() + this.getUrl()).hashCode() +
	            this.getMethods().hashCode() +
	            this.getHeaders().hashCode() +
	            this.getExposedHeaders().hashCode();
	}
}
