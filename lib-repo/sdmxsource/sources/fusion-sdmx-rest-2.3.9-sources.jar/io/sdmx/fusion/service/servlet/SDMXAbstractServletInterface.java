package io.sdmx.fusion.service.servlet;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.error.IStructureValidationErrorHandler;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;
import io.sdmx.core.sdmx.api.manager.structure.StructureFormatManager;
import io.sdmx.core.sdmx.error.StructureValidationErrorHandler;
import io.sdmx.fusion.service.api.manager.MessageProcessManager;
import io.sdmx.fusion.service.api.model.SdmxServlet;
import io.sdmx.fusion.service.model.request.GETRequest;
import io.sdmx.fusion.service.model.request.HttpRequest;
import io.sdmx.fusion.service.model.request.POSTRequest;
import io.sdmx.fusion.service.model.request.WebServiceRequestInfo;
import io.sdmx.fusion.service.util.RequestManagerUtil;
import io.sdmx.fusion.service.util.ServletUtil;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.format.FormatDetailsImpl;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public abstract class SDMXAbstractServletInterface extends HttpServlet implements SdmxServlet {
	private static final Logger LOG = LoggerFactory.getLogger(SDMXAbstractServletInterface.class);

	//SerializeId
	private static final long serialVersionUID = 1L;

	protected MessageProcessManager manager = SingletonStore.getSingleton(MessageProcessManager.class);
	protected DataFormatManager dataFormatManager = SingletonStore.getSingleton(DataFormatManager.class);
	protected StructureFormatManager structureFormatManager = SingletonStore.getSingleton(StructureFormatManager.class);

	private boolean enabled;

	private WebServiceRequestInfo webServiceRequestInfo;

	@Override
	public WebServiceRequestInfo getWebServiceRequestInfo() {
		return webServiceRequestInfo;
	}

	public void setWebServiceRequestInfo(WebServiceRequestInfo webServiceRequestInfo) {
		this.webServiceRequestInfo = webServiceRequestInfo;
		this.enabled = true;
	}

	// HTML GENERATION ---------------------------------------------------------------------------------------
	/*
	 */
	/**
	 * Returns a HTML form as a String, the form contains an upload file input field, with a upload form button
	 * @return
	 */
	public String getFileUploadForm(HttpServletRequest httpServletRequest) {
		String context = httpServletRequest.getContextPath();
		String action = httpServletRequest.getServletPath();
		StringBuilder sb = new StringBuilder();
		sb.append("<div class=\"rest_upload_form_div\">");
		sb.append("<form method='post' enctype='multipart/form-data' action='"+context+action+"'>");
		sb.append("<div class=\"rest_upload_form_file_div\"><input class=\"rest_upload_form_file_input\" name='uploadFile' type='file' size='45'></div>");
		sb.append("<div class=\"rest_upload_form_submit_div\"><input class=\"rest_upload_form_submit_input\" name='submit' type='submit' value='Upload Document'></div>");
		sb.append("</form></div>");
		return sb.toString();
	}

	/**
	 * Returns an HTML form to login using Spring Security 3
	 * @return
	 */
	public String getLoginForm(HttpServletRequest httpServletRequest) {
		String context = httpServletRequest.getContextPath();
		StringBuilder sb = new StringBuilder();
		sb.append("<div class=\"rest_login_form_div\">");
		sb.append("<form name='f' action='"+context+"/j_spring_security_check'");
		sb.append("method='POST'>");
		sb.append("<div class=\"rest_login_user_div\" <div class=\"rest_login_user_prompt_div\">Username : <input class=\"rest_login_user_input\" type='text' name='j_username' value=''></div><br/>");
		sb.append("<div class=\"rest_login_password_div\" <div class=\"rest_login_password_prompt_div\">Password : <input class=\"rest_login_password_input\" type='password' name='j_password'/></div>");
		sb.append("<input name=\"redirect\" type=\"hidden\" value=\""+httpServletRequest.getServletPath()+"\"/>");
		sb.append("<div class=\"rest_login_form_remember_prompt_div\">Remember me? <input class=\"rest_login_form_remember_input\" id=\"_spring_security_remember_me\" name=\"_spring_security_remember_me\" type=\"checkbox\" value=\"true\"/></div></div>");
		sb.append("<div class=\"rest_login_form_submit_div\"><input class=\"rest_login_form_submit_input\" name=\"submit\" type=\"submit\" value=\"Login\"/></div>");
		sb.append("</form></div>");
		return sb.toString();
	}

	public String getLogoutForm(HttpServletRequest httpServletRequest) {
		String context = httpServletRequest.getContextPath();
		StringBuilder sb = new StringBuilder();
		sb.append("<div class=\"rest_logout_form_div\">");
		sb.append("<form name='f' action='"+context+"/j_spring_security_logout'");
		sb.append("method='POST'>");
		sb.append("<input name=\"redirect\" type=\"hidden\" value=\""+httpServletRequest.getServletPath()+"\"/>");
		sb.append("<div class=\"rest_logout_form_submit_div\"><input class=\"rest_logout_form_submit_input\" name=\"submit\" type=\"submit\" value=\"Log out\"/></div>");
		sb.append("</form></div>");
		return sb.toString();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if(ObjectUtil.validString(req.getPathInfo())) {
			processGET(req, resp);
		} else {
			StringBuilder sb = new StringBuilder();
			sb.append("<html><body>");
			sb.append("<p>Welcome to the REST INTERFACE</p>");
			sb.append("<p>Please ensure this class is subclassed, and override the doGet method</p>");
			sb.append("<p>To ensure submissions and queries work expectedly, call the setWebServiceRequestInfo method</p>");
			sb.append(getFileUploadForm(req));
			sb.append("</body></html>");
			resp.getOutputStream().write(sb.toString().getBytes());
		}
	}

	// PROCESSING ---------------------------------------------------------------------------------------
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setCharacterEncoding("UTF-8");
		this.processPOST(req, resp);
	}

	protected void processPOST(HttpServletRequest request, HttpServletResponse resp) throws IOException {
		OutputStream out = resp.getOutputStream();
		if (!enabled) {
			throw new IllegalArgumentException("Servlet is not enabled - ensure WebServiceRequestInfo has been set");
		}
		if (manager==null) {
			throw new RuntimeException("Required dependancy MessageProcessManager has not been set on Servlet");
		}

		Request requestWrapper = new HttpRequest(request, true);
		try {
			// Need to investigate the message header to see if it contains information about the response type

			StructureFormat structureFormat = structureFormatManager.getFormat(requestWrapper);
			if(structureFormat == null) {
				structureFormat = webServiceRequestInfo.getStructureFormat();
			}

			WebServiceRequestInfo newWSRI = new WebServiceRequestInfo(structureFormat, webServiceRequestInfo.getDataTypeResponseFormat(), webServiceRequestInfo.getWebServiceSecurityInfo());

			IStructureValidationErrorHandler errorHandler = RequestManagerUtil.shouldSkipInvalid(request) ? new StructureValidationErrorHandler() : null;
			DATASET_ACTION dsAction = determineDatasetAction(requestWrapper);

			POSTRequest postRequest = new POSTRequest(requestWrapper.getReadableDataLocation(), out, newWSRI, true, dsAction, errorHandler);
			processPOST(postRequest, resp);
		} catch (Throwable th) {
			ServletUtil.handleError(request, resp, th);
		} finally {
			requestWrapper.close();
		}
	}

	protected void processPOST(POSTRequest postRequest, HttpServletResponse resp) {
		int sdmxErrorCode = manager.processMessage(postRequest);
		if (sdmxErrorCode == 304) {
			resp.setStatus(200);
		} else {
			resp.setStatus(sdmxErrorCode);
		}
	}

	/**
	 * Call to process a GET request - this is will be processed as a SDMX query
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	protected void processGET(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			processGETWithPath(request, response, request.getPathInfo());
		} catch(Throwable th) {
			ServletUtil.handleError(request, response, th);
		}
	}

	/**
	 * Call to process a GET request - this is will be processed as a SDMX query
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	protected void processGET(HttpServletRequest request, HttpServletResponse response, OutputStream out) throws IOException {
		try {
			processGETWithPath(request, response, request.getPathInfo(), out);
		} catch(Throwable th) {
			ServletUtil.handleError(request, response, th);
		}
	}

	protected void processGETWithPath(HttpServletRequest request, HttpServletResponse response, String restPath) {
		try {
			processGETWithPath(request, response, restPath, response.getOutputStream());
		} catch (IOException e) {
			LOG.error("Error writing response to HttpServletResponse OutputStream: " +e.getMessage());
		}
	}

	protected boolean getPrettyPrint(HttpServletRequest request) {
		String prettyParameter = request.getParameter("prettyPrint");
		boolean prettyPrint = false;
		if(ObjectUtil.validString(prettyParameter) ) {
			prettyPrint = Boolean.parseBoolean(prettyParameter);
		}
		return prettyPrint;
	}

	/**
	 * Call to process a GET request - this is will be processed as a SDMX query
	 * @param request
	 * @param response
	 * @param restPath - alternative to request.getPathInfo()
	 */

	protected void processGETWithPath(HttpServletRequest request, HttpServletResponse response, String restPath, OutputStream out) {
		processGETWithPath(request, response, restPath, out, null);
	}

	protected void processGETWithPath(HttpServletRequest request, HttpServletResponse response, String restPath, OutputStream out, StructureFormat forceFormat) {
		if(!enabled) {
			throw new IllegalArgumentException("Servlet is not enabled - ensure WebServiceRequestInfo has been set");
		}
		if(manager==null) {
			throw new RuntimeException("Required dependancy MessageProcessManager has not been set on Servlet");
		}
		try {
			response.setCharacterEncoding(StandardCharsets.UTF_8.toString());
			request.setCharacterEncoding(StandardCharsets.UTF_8.toString());
			Request requestWrapper = new HttpRequest(request);

			restPath = restPath.replaceFirst("/", "");
			String[] requestSplit = restPath.split("/");

			WebServiceRequestInfo wsReq = getWebServiceRequestInfo(requestWrapper, requestSplit[0]);
			StructureFormat structureFormat = forceFormat != null ? forceFormat : structureFormatManager.getFormat(requestWrapper);
			DataFormat dataFormat = wsReq.getDataTypeResponseFormat(); //obtainDefaultDataFormat(requestWrapper);
			WebServiceRequestInfo wsReqInfo = new WebServiceRequestInfo(structureFormat, dataFormat, wsReq.getWebServiceSecurityInfo());
			if(structureFormat==null) {
				structureFormat = wsReq.getStructureFormat();
			}

			GETRequest getRequest = getGETRequest(response, out, requestWrapper, wsReqInfo, requestSplit);

			if(getRequest.getGetRequestStructureQuery() != null) {
				response.setContentType(structureFormat.getFormatDetails().getMimeType());
			}
			String varyHeader = "Accept,Accept-Language";
			FormatDetails formatDetails = getFormatDetails(getRequest, wsReqInfo);
			String defaultExtension = "";

			response.addHeader("Vary", varyHeader);
			if(formatDetails != null) {
				response.setContentType(formatDetails.getMimeType());
				defaultExtension = formatDetails.getFileExtension();
			}

			applyContentDisposition(request, response, getRequest, requestWrapper, formatDetails);

			manager.processMessage(getRequest);
			if(getRequest != null) {
				StreamUtil.closeStream(getRequest.getOutputStream());  //The output stream from the get request must be closed otherwise if this is a JSONPOutputStream the final ")" will not be written
			}
		} catch(IOException e) {
			throw new RuntimeException("Could not get the output stream", e);
		} finally {
			ThreadLocalUtil.clearFromThread("partial");
		}
	}

	protected DataFormat obtainDefaultDataFormat(Request requestWrapper) {
		return null;
	}

	protected WebServiceRequestInfo getWebServiceRequestInfo(Request request, String resource) {
		StructureFormat structureFormat = getWebServiceRequestInfo().getStructureFormat();

		if(resource.equalsIgnoreCase("data")) {
			throw new SdmxNotImplementedException("Data Queries are not implemented");
		} else {
			structureFormat = structureFormatManager.getFormat(request);
			if(structureFormat == null) {
				structureFormat = getWebServiceRequestInfo().getStructureFormat();
			}
		}
		return new WebServiceRequestInfo(structureFormat, null, getWebServiceRequestInfo().getWebServiceSecurityInfo());
	}


	protected FormatDetails getFormatDetails(GETRequest getRequest, WebServiceRequestInfo wsReq) {
		switch(getRequest.getQueryType()) {
		case STRUCTURE:
			return wsReq.getStructureFormat().getFormatDetails();
		case SCHEMA:
			FormatDetails formatDetails = new FormatDetailsImpl("XSD", "xsd", "application/xml", false);
			return formatDetails;
		case REGISTRATION:
			return null;
		default:  throw new SdmxNotImplementedException(getRequest.getQueryType());
		}
	}

	protected GETRequest getGETRequest(HttpServletResponse response, OutputStream out, Request requestWrapper, WebServiceRequestInfo wsReq, String[] requestSplit) {
		return new GETRequest(response, out, requestWrapper, wsReq, requestSplit, requestWrapper.getParameters(), true);
	}

	/**
	 * Sets the saveFile value on the response object if necessary.
	 * This is based around where the request has a "saveAs" value OR if the file format is a "save only" format.
	 */
	private void applyContentDisposition(HttpServletRequest request, HttpServletResponse response, GETRequest getRequest, Request requestWrapper, FormatDetails formatDetails) throws UnsupportedEncodingException {
		String saveAsFilename = requestWrapper.getParameter(ServletUtil.SAVE_AS_FILENAME_PARAM);
		if (!ObjectUtil.validString(saveAsFilename) && formatDetails != null) {
			String fileName = getRequest.getQueryType().toString();
			if(getRequest.getGetRequestDataQuery() != null) {
				fileName = getRequest.getGetRequestDataQuery().getFlowRef().getMaintainableId();
			}
			saveAsFilename = fileName +  "." + formatDetails.getFileExtension();
		}
		ServletUtil.applyContentDisposition(request, response, saveAsFilename, getRequest, requestWrapper, formatDetails);
	}

	/**
	 * Determines a DATASET_ACTION from the Request, if it has been specified
	 * @return the DATASET_ACTION or null
	 */
	private DATASET_ACTION determineDatasetAction(Request requestWrapper) {
		String action = requestWrapper.getHeader("ACTION");
		DATASET_ACTION dsAction = null;
		if(action != null) {
			try {
				dsAction = DATASET_ACTION.getAction(action);
			} catch(Throwable th) {
				LOG.warn("unknown ACTION header value of : "+action);
			}
		}
		return dsAction;
	}

}
