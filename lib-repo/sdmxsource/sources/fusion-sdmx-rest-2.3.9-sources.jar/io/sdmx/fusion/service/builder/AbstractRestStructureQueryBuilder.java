package io.sdmx.fusion.service.builder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.model.IMaintainableStructureType;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.codelist.HierarchyBean;
import io.sdmx.api.sdmx.model.beans.registry.ContentConstraintBean;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.api.sdmx.model.query.StructureQueryMetadata;
import io.sdmx.im.beans.reference.RESTStructureQueryImpl;
import io.sdmx.im.beans.reference.StructureQueryMetadataImpl;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.MaintainableSDMXStructureType;
import io.sdmx.utils.sdmx.structure.StructureTypes;
import io.sdmx.utils.sdmx.xs.URN;

/**
 * Constructs a RESTStructureQuery object
 */
abstract class AbstractRestStructureQueryBuilder {

	protected static Map<String, String> determineQueryParameters(String restQuery) {
		Map<String, String> queryParameters =new HashMap<>();
		if(restQuery.contains("?")) {
			String[] split = restQuery.split("\\?");
			restQuery = split[0];
			String[] params = split[1].split("&");
			for(String param : params) {
				String[] paramArs = param.split("=");
				queryParameters.put(paramArs[0], paramArs[1]);
			}
		}
		return queryParameters;
	}
	
	protected RESTStructureQuery buildRESTQuery(String queryString, Map<String, String> queryParameters) {
		if(queryString.startsWith("/")) {
			queryString = queryString.substring(1);
		}
		
		if(queryParameters == null) {
			queryParameters = new HashMap<>();
		}
		
		//Parse any additional parameters
		if(queryString.indexOf("?") > 0) {
			String params = queryString.substring(queryString.indexOf("?")+1);
			queryString = queryString.substring(0,queryString.indexOf("?"));

			for(String currentParam : params.split("&")) {
				String[] param = currentParam.split("=");
				queryParameters.put(param[0],param[1]);
			}
		}
		
		String[] args = queryString.split("/");
		IURN<?> structureReference = parserQueryString(args);
		StructureQueryMetadata structureQueryMetadata = new StructureQueryMetadataImpl(args, queryParameters);
		
		return new RESTStructureQueryImpl(structureReference, structureQueryMetadata);
	}
	
	protected IURN<?> parserQueryString(String[] queryString) {
		if(queryString.length < 1) {
			throw new SdmxSemmanticException("Structure Query Expecting at least 1 parameter (structure type)");
		}
		IMaintainableStructureType structureType = getStructureType(queryString[0]);   //TODO this may be an identifiable structure type if there is a subID
		ISDMXStructureType targetStructure = structureType;
		String agencyId = null;
		String id = null;
		String version = null;
		String[] childId = null;
		
		// Check for the length being more than 6 first, or when you come to "queryString.length >= 5" it will always pass and can throw an NPE
		if(queryString.length >= 6) {
			throw new SdmxSemmanticException("Unexpected path parameter: "+queryString[5]);
		}
		
		if(queryString.length >= 2) {
			agencyId = parseQueryString(queryString[1]);
		}
		if(queryString.length >= 3) {
			id = parseQueryString(queryString[2]);
/*
 * FMR:878
 * Important: the following block of code was added in a previous commit: 9e45f0200bb47d7b978567767bd711288f42efb3 with the comment:
 * bug fix when querying for partial lists against structures with fixed ID (data provider scheme)
 * 
 * With the fix, the UI of the Organisation schemes break since a query such as /v2/structure/agencyscheme/* /* /* now fails.
 * This can be mitigated against with defensive code, but when Matt reviewed this code he could not understand why it had been initially committed.
 * The code does not match the queries that are defined in the REST API specification for either V1 or V2.
 * 
 * Since there appears to be no purpose for this code, it has been commented out rather than removed.
 * 
 * 
			if(structureType.hasFixedId() && id != null) {
			    childId = id.split("\\.");
			    targetStructure = obtainStructureType(structureType);
			}
*/
		}
		if(queryString.length >= 4) {
			// No need to concern ourselves with a special-case for "+" for latest
			version = parseVersionString(queryString[3]);
		}
		if(version == null) {
			version = "~";  //latest available version
		}
		
		if(queryString.length >= 5) {
			String queryParam = queryString[4];
			String childParam = parseQueryString(queryParam);
			if (childParam != null) {
				childId = childParam.split("\\.");
			}
			//TODO get child types
			//structureType.
			targetStructure = obtainStructureType(structureType);
		}
		
		return URN.builder().agencyId(agencyId).maintId(id).version(version).structure(targetStructure).identifableId(childId).build();
	}
	
	protected static ISDMXStructureType obtainStructureType(IMaintainableStructureType structureType) {
		List<ISDMXStructureType> childTypes = StructureTypes.getChildTypes(structureType);
		ISDMXStructureType itemScheme = StructureTypes.getAnyStructureType(ItemSchemeBean.class);
		ISDMXStructureType concreteType = null;
		boolean isItemScheme = false;
		for(ISDMXStructureType type : childTypes) {
			if(type.isAbstract()) {
				if(itemScheme == type) {
					isItemScheme = true;
				}
			} else {
				if(concreteType != null) {
					throw new SdmxSemmanticException("Ambiguous concrete subtype");
				}
				concreteType = type;
			}
		}
		if(!isItemScheme) {
			throw new SdmxSemmanticException("Query by identifiable Id is only supported when querying Item Schemes");
		}
		if(concreteType == null) {
			throw new SdmxSemmanticException("Unregistered item type for item scheme: "+structureType);
		}
		return concreteType;
	}
	
	protected static String parseQueryString(String query) {
		if(!ObjectUtil.validString(query)) {
			return null;
		}
		if(query.equalsIgnoreCase("all") || query.equals("*")) {
			return null;
		}
		return query;
	}
	
	protected abstract String parseVersionString(String query);

	protected static IMaintainableStructureType getStructureType(String str) {
		if(str.equalsIgnoreCase("structure") || str.equalsIgnoreCase("*")) {
			return MaintainableSDMXStructureType.ANY;
		}
		IMaintainableStructureType st = StructureTypes.byRESTResource(str.toLowerCase());
		if(st == null) {
			if(str.equals("hierarchicalcodelist")) {
				return StructureTypes.getMaintStructureType(HierarchyBean.class);  //the v1 query
			}
			if(str.equals("contentconstraint")) {
				return StructureTypes.getMaintStructureType(ContentConstraintBean.class);
			}
			throw new SdmxSemmanticException("Unknown REST Resource: "+str);
		}
		return st;
		//
		
//		if(str.equalsIgnoreCase("structure") || str.equalsIgnoreCase("*")) {
//			return SDMX_STRUCTURE_TYPE.ANY;
//		}
//		if(str.equalsIgnoreCase("organisationscheme")) {
//			return SDMX_STRUCTURE_TYPE.ORGANISATION_SCHEME;
//		}
//		else if(str.equalsIgnoreCase("advancereleasecalendar")) {
//			return SDMX_STRUCTURE_TYPE.ADVANCED_RELEASE_CALENDAR;
//		}
//
//		return SDMX_STRUCTURE_TYPE.parseClass(str);
	}
}
