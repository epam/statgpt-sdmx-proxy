package io.sdmx.fusion.service.filter;

import java.io.IOException;

import io.sdmx.utils.core.thread.ThreadLocalUtil;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class EDIFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		ThreadLocalUtil.storeOnThread("EDI_LENIENT_MODE", "TRUE");
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
	}


}
