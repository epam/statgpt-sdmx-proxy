package io.sdmx.fusion.service.manager;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import io.sdmx.api.application.FusionProductInformation;
import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.exception.SDMX_ERROR_CODE;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.utils.http.broker.RestMessageBroker;
import io.sdmx.fusion.security.api.manager.ForgottenDetailsManager;
import io.sdmx.utils.core.object.ObjectUtil;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

/**
 * Interface which makes the calls over REST to the FusionSecurity web service
 */
public class ForgottenDetailsRESTManager implements ForgottenDetailsManager {
	
	private String productName;
	
	@Autowired
	private FusionProductInformationRetrievalManager informationRetrievalManager;
	
	@Autowired
	private FusionSecurityRESTAuthenticationManager securityRESTAuthenticationManager;
	
	// Needs to be of the form: http://[server]:[port]/WebApp/ws/unsecured/forgot/resetPassword
	private String getResetPasswordUrl() {
		String val = securityRESTAuthenticationManager.getRestUrlRaw();
		if (val == null) {
			return null;
		}
		return val + "/ws/unsecured/user/resetPassword";
	}
	
	// Needs to be of the form: http://[server]:[port]/WebApp/ws/unsecured/forgot/forgotPassword
	private String getForgotPasswordUrl() {
		String val = securityRESTAuthenticationManager.getRestUrlRaw();
		if (val == null) {
			return null;
		}
		return val + "/ws/unsecured/user/forgotPassword";
	}
	
	// Needs to be of the form: http://[server]:[port]/WebApp/ws/unsecured/forgot/forgotPasswordGivenEmail
	private String getForgotPasswordHaveEmailUrl() {
		String val = securityRESTAuthenticationManager.getRestUrlRaw();
		if (val == null) {
			return null;
		}
		return val + "/ws/unsecured/user/forgotPasswordGivenEmail";
	}
	
	// Needs to be of the form: http://[server]:[port]/WebApp/ws/unsecured/forgot/forgotUsername
	private String getForgotUsernameUrl() {
		String val = securityRESTAuthenticationManager.getRestUrlRaw();
		if (val == null) {
			return null;
		}
		return val + "/ws/unsecured/user/forgotUsername";
	}
	
	@Override
	public void resetPassword(String verificationGuid, String newPassword, String passwordRepeat) {
		String resetPasswordUrl = getResetPasswordUrl();
		if (resetPasswordUrl == null) {
			throw new SdmxException("No Security Service has been configured");
		}
		sendMessage(resetPasswordUrl+"?uid="+verificationGuid+"&password="+newPassword+"&passwordConfirm="+passwordRepeat);
	}
	
	@Override
	public void emailResetPasswordGivenEmail(String prodName, String email, String redirectURL) {
		String forgotPasswordUrl = getForgotPasswordUrl();
		if (forgotPasswordUrl == null) {
			throw new SdmxException("No Security Service has been configured");
		}
		
		if (StringUtils.isEmpty(email)) {
			throw new IllegalArgumentException("Cannot reset a password without an email address");
		}
		
		String encodedEMail = encode(email);
		String encodedProductName = obtainProductName(prodName);
		String redirectLoc = obtainRedirectLocation(redirectURL);

		String msg = getForgotPasswordHaveEmailUrl() +  
				"?email=" + encodedEMail + 
				"&redirectURL=" + redirectLoc +
				"&productName=" + encodedProductName;
		sendMessage(msg);
	}

	@Override
	public void emailResetPassword(String prodName, String username, String redirectURL) {
		String forgotPasswordUrl = getForgotPasswordUrl(); 
		if(forgotPasswordUrl == null) {
			throw new SdmxException("No Security Service has been configured");
		}
		
		if (StringUtils.isEmpty(username)) {
			throw new IllegalArgumentException("Cannot reset a password without a username");
		}
		
		String encodedUserName = encode(username);
		String encodedProductName = obtainProductName(prodName);
		String redirectLoc = obtainRedirectLocation(redirectURL);
		
		String msg = forgotPasswordUrl +
					"?username=" + encodedUserName +
					"&redirectURL=" + redirectLoc +
					"&productName=" + encodedProductName;
		sendMessage(msg);
	}
	
	private String obtainProductName(String prodName) {
		String pName;
		if (ObjectUtil.validString(prodName)) {
			pName = prodName;
		} else {
			FusionProductInformation fusionProductInformation = informationRetrievalManager.getFusionProductInformation();
			pName = fusionProductInformation.getProductDetails().getProductName();
		}
		String encodedProductName;
		if (pName == null) {
			encodedProductName = "";
		} else {
			encodedProductName = encode(pName);
		}
		return encodedProductName;
	}
	
	private String obtainRedirectLocation(String redirectURL) {
		String redirectLoc;
		if (ObjectUtil.validString(redirectURL)) {
			redirectLoc = redirectURL;
		} else {
			FusionProductInformation fusionProductInformation = informationRetrievalManager.getFusionProductInformation();
			redirectLoc = fusionProductInformation.getApplicationURL() + "/resetPassword.html";
		}
		return redirectLoc;
	}
	
	private String encode(String val) {
		try {
			return URLEncoder.encode(val, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new IllegalArgumentException("Cannot encode the value: " + val);
		}
	}

	@Override
	public void emailUsername(String productName, String emailAddress) {
		String prodName = (productName == null ? this.productName : productName);
		String encodedProductName = encode(prodName);
		String forgotUsernameUrl = getForgotUsernameUrl();
		if(forgotUsernameUrl == null) {
			throw new SdmxException("No Security Service has been configured");
		}
		sendMessage(forgotUsernameUrl+"?email=" + emailAddress + "&productName=" + encodedProductName);
	}
	
	private void sendMessage(String url) {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		
		RestMessageBroker.sendMessage(bos, url);
		
		//Send Message
		try {
			JSONObject response = new JSONObject(new String(bos.toByteArray()));
			if(response.has("error")) {
				String errorMsg = response.getString("error");
				SDMX_ERROR_CODE errorCode = SDMX_ERROR_CODE.INTERNAL_SERVER_ERROR;
				if(response.has("errorcode")) {
					int errorCodeAsInt = response.getInt("errorcode");
					errorCode = SDMX_ERROR_CODE.parseClientCode(errorCodeAsInt);
				}
				throw new SdmxException(errorMsg, errorCode);
			}	
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
	}
}