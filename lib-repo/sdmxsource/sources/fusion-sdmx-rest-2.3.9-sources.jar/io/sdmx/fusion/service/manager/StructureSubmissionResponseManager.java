package io.sdmx.fusion.service.manager;

import java.io.ByteArrayOutputStream;

import org.springframework.stereotype.Service;

import io.sdmx.api.exception.ErrorUtil;
import io.sdmx.api.exception.SdmxNotImplementedException;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.error.IStructureValidationErrorHandler;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNSingle;
import io.sdmx.format.ml.engine.structure.writer.v21.SubmitStructureResponseBuilderV21;
import io.sdmx.format.ml.engine.structure.writer.v3.SubmitStructureResponseBuilderV3;
import io.sdmx.fusion.service.api.manager.IStructureSubmissionResponseManager;
import io.sdmx.fusion.service.api.model.ISdmxResponse;
import io.sdmx.fusion.service.model.request.SdmxResponse;

@Service
public class StructureSubmissionResponseManager implements IStructureSubmissionResponseManager {
	
	@Override
	public ISdmxResponse buildErrorResponse(Throwable th, IURNSingle<?> errorReference, SDMX_SCHEMA schemaVersion) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		if(schemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE) {
			SubmitStructureResponseBuilderV21.getInstance().writeErrorResponse(th, errorReference, out);
		} else if(schemaVersion == SDMX_SCHEMA.VERSION_THREE || schemaVersion ==  SDMX_SCHEMA.JSON) {
			SubmitStructureResponseBuilderV3.getInstance().writeErrorResponse(th, errorReference, out);
		} else {
			throw new SdmxNotImplementedException("Response writer in version:"+schemaVersion);
		}
		return new SdmxResponse(ErrorUtil.getHTTPStatusCode(th), out.toByteArray());
	}

	@Override
	public ISdmxResponse buildSuccessResponse(SdmxBeans beans, SDMX_SCHEMA schemaVersion, IStructureValidationErrorHandler errorHandler) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		//TODO Return JSON success message instead
		if(schemaVersion == SDMX_SCHEMA.VERSION_TWO_POINT_ONE) {
			SubmitStructureResponseBuilderV21.getInstance().buildSuccessResponse(beans, out, errorHandler);
		} else if(schemaVersion == SDMX_SCHEMA.VERSION_THREE || schemaVersion ==  SDMX_SCHEMA.JSON) {
			SubmitStructureResponseBuilderV3.getInstance().buildSuccessResponse(beans, out, errorHandler);
		} else {
			throw new SdmxNotImplementedException("Response writer in version:"+schemaVersion);
		}
		return new SdmxResponse(200, out.toByteArray());
	}
}
