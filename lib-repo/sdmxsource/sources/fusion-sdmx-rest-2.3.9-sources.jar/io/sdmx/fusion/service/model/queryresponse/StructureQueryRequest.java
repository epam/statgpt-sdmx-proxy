package io.sdmx.fusion.service.model.queryresponse;

import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.query.IStructureQueryRequest;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;

public class StructureQueryRequest implements IStructureQueryRequest {
	private RESTStructureQuery structureQueryRequest;
	private Request req; 
	private IResponse resp;
	private StructureFormat format;
	private boolean returnAsRegistryResponse;
	private boolean wasFormatDefaulted;

	public StructureQueryRequest(RESTStructureQuery structureQueryRequest, Request req, IResponse resp, StructureFormat format) {
		this.structureQueryRequest = structureQueryRequest;
		this.req = req;
		this.resp = resp;
		this.format = format;
	}

	public boolean wasFormatDefaulted() {
		return wasFormatDefaulted;
	}

	public void setWasFormatDefaulted(boolean wasFormatDefaulted) {
		this.wasFormatDefaulted = wasFormatDefaulted;
	}

	public StructureQueryRequest setReturnAsRegistryResponse(boolean returnAsRegistryResponse) {
		this.returnAsRegistryResponse = returnAsRegistryResponse;
		return this;
	}

	public boolean isReturnAsRegistryResponse() {
		return returnAsRegistryResponse;
	}
	
	public RESTStructureQuery getStructureQueryRequest() {
		return structureQueryRequest;
	}
	
	public Request getRequest() {
		return req;
	}
	
	public IResponse getResponse() {
		return resp;
	}
	
	public StructureFormat getFormat() {
		return format;
	}
}
