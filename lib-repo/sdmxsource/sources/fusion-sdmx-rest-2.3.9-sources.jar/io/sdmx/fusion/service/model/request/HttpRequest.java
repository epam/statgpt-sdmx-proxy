package io.sdmx.fusion.service.model.request;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.fileupload2.core.DiskFileItemFactory;
import org.apache.commons.fileupload2.core.FileItem;
import org.apache.commons.fileupload2.core.FileUploadException;
import org.apache.commons.fileupload2.jakarta.servlet6.JakartaServletFileUpload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.http.HTTP_METHOD;
import io.sdmx.api.http.ICacheHeaders;
import io.sdmx.api.http.IRESTURL;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.ReadableDataLocationFactory;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.io.WriteableDataLocationFactory;
import io.sdmx.fusion.service.util.ServletUtil;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.http.CacheHeaders;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.HashUtils;
import io.sdmx.utils.core.object.ObjectUtil;
import jakarta.servlet.http.HttpServletRequest;

public class HttpRequest implements Request {
    private static final Logger LOG = LoggerFactory.getLogger(HttpRequest.class);

    private Map<String, String> headers = new HashMap<>();
    private String ip;
    private String hash = null;
    private String path;
    private ReadableDataLocation rdl;
    private HTTP_METHOD method;
    private IRESTURL restUrl;
    private ICacheHeaders cacheHeaders;

    private ReadableDataLocationFactory rdlFactory = SingletonStore.getSingleton(ReadableDataLocationFactory.class);
    private WriteableDataLocationFactory wdlFactory = SingletonStore.getSingleton(WriteableDataLocationFactory.class);

    public HttpRequest(HttpServletRequest request, boolean enforceRdl) {
        this(request);
        if(enforceRdl && rdl == null) {
            throw new SdmxSemmanticException("Data file not supplied.  If content type is set to multipart/form-data the ContentID name must be 'uploadFile'.  If loading data via a stream, set the content "
                    + "type to application/text, application/xml, or application/json");
        }
    }

    public HttpRequest(HttpServletRequest request) {
        this.method = HTTP_METHOD.getMethod(request.getMethod());
        ip = ServletUtil.obtainIpAddress(request);
        path = request.getPathInfo();
        Enumeration<String> e = request.getHeaderNames();
        while(e.hasMoreElements()) {
            String header = e.nextElement();
            headers.put(header.toLowerCase(), request.getHeader(header));
        }
        Map<String, String>  additionalParameters = new HashMap<>();
        if(request.getContentType() != null) {
            try {
                additionalParameters = processContentType(request);
            } catch (IOException e1) {
                e1.printStackTrace();
                throw new RuntimeException(e1);
            }
        }
        Map<String, String[]> parameterMap = request.getParameterMap();
        for(String currentKey : parameterMap.keySet()) {
            String[] values = parameterMap.get(currentKey);
            if(values != null && values.length > 0) {
                String value = values[0];
                additionalParameters.put(currentKey, value);
            }
        }
        this.restUrl = new RESTURL(path, additionalParameters);
    }

    @Override
    public IRESTURL getRestURL() {
        return this.restUrl;
    }

    @Override
    public String getIP() {
        return ip;
    }

    @Override
    public String getHash() {
        if(hash == null) {
            StringBuilder sb = new StringBuilder();
            sb.append(path);
            SortedSet<String> ss = new TreeSet<>(this.restUrl.getParameters().keySet());
            for(String param : ss) {
                String value = this.restUrl.getParameters().get(param);
                sb.append(param.toLowerCase()+"="+value.toLowerCase());
            }
            hash = HashUtils.hashString(sb.toString(), false);
        }
        return hash;
    }


    private Map<String, String> processContentType(HttpServletRequest request) throws IOException, FileUploadException {
        String contentType = request.getContentType();
        InputStream inputStream = null;
        LOG.debug("HttpServletRequest content type is " + contentType);

        Map<String, String> additionalParameters = new HashMap<>();

        for(String currentContentType : contentType.split(";")) {
            currentContentType = currentContentType.trim();
            if (currentContentType.equals("text/plain") ||
                    currentContentType.equals("application/text") ||
                    currentContentType.equals("application/xml") ||
                    currentContentType.equals("application/json") ||
                    currentContentType.contains("csv")) {
                request.setCharacterEncoding("UTF-8");
                inputStream = request.getInputStream();
                break;
            } else if(currentContentType.equals("application/x-www-form-urlencoded")) {
                String xmlString = request.getParameter("xml");
                if(xmlString != null) {
                    inputStream = new ByteArrayInputStream(xmlString.getBytes());
                } else {
                    LOG.debug("No xml parameter found on form");
                }
                break;
            } else if(currentContentType.startsWith("multipart/form-data")) {
                // Create a commons upload handler.
            	DiskFileItemFactory fileItemFactory = DiskFileItemFactory.builder().get();
            	JakartaServletFileUpload fileUpload = new JakartaServletFileUpload(fileItemFactory);
            	final List<FileItem> items;
                try {
                	items = fileUpload.parseRequest(request);
                } catch (FileUploadException e) {
                	throw new RuntimeException(e);
                }

                WriteableDataLocation wdl = wdlFactory.getTemporaryWriteableDataLocation();

                for (FileItem item : items) {
                    String fieldName = item.getFieldName();
                    boolean isFormField = item.isFormField();
                    if (!isFormField && (fieldName.equalsIgnoreCase("uploadFile") || fieldName.equals("Filedata"))) {
                        if (item.getName() == null || (item.getName().trim().equals(""))) {
                            continue;
                        }
                        additionalParameters.put(fieldName, item.getName());
                        StreamUtil.copyStream(item.getInputStream(), wdl.getOutputStream(), true);
                        this.rdl = wdl;
                    } else {
                        StringBuffer sb = new StringBuffer();
                        int c;

                        try ( InputStream is = item.getInputStream()) {
                            while ((c = is.read()) != -1) {
								sb.append((char) c);
							}
                        }
                        String value = sb.toString();
                        additionalParameters.put(fieldName, value);
                    }
                }
                break;
            }
        }

        if(inputStream != null) {
            LOG.debug("Get ReadableDataLocation from stream");
            this.rdl = rdlFactory.getReadableDataLocation(inputStream);
        }
        return additionalParameters;
    }

    @Override
    public HTTP_METHOD getMethod() {
        return method;
    }

    @Override
    public ReadableDataLocation getReadableDataLocation() {
        return rdl;
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public boolean hasHeader(String header) {
        return ObjectUtil.validString(getHeader(header));
    }

    @Override
    public String getHeader(String header) {
        return headers.get(header.toLowerCase());
    }
    
    @Override
	public ICacheHeaders getCacheHeaders() {
		if(cacheHeaders == null) {
			cacheHeaders = new CacheHeaders(this);
		}
		return cacheHeaders;
	}

    @Override
    public Map<String, String> getHeaders() {
        return new HashMap<>(headers);
    }

    @Override
    public void close() {
        if(rdl != null) {
            rdl.close();
        }
    }
}
