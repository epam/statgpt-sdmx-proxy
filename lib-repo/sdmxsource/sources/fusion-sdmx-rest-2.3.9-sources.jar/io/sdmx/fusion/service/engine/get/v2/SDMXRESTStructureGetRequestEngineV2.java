package io.sdmx.fusion.service.engine.get.v2;

import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.manager.structure.IQueryStructureRequestManager;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.fusion.service.builder.RESTStructureQueryBuilder_V2;
import io.sdmx.fusion.service.engine.get.SDMXRESTStructureGetRequestEngineAbstract;
import io.sdmx.utils.sdmx.xs.SdmxVersion;

public class SDMXRESTStructureGetRequestEngineV2 extends SDMXRESTStructureGetRequestEngineAbstract {
	
	
	public SDMXRESTStructureGetRequestEngineV2(IQueryStructureRequestManager queryStructureRequestManager) {
		super(queryStructureRequestManager, SdmxVersion.getInstance(2, 0, 0));
	}

	@Override
	protected RESTStructureQuery buildRESTQuery(Request request) {
		String path = request.getPath();
		if(!path.startsWith("/")) {
			path = "/" + path;
		}
		String[] pathSplit = request.getPath().split("/", 3);
		path = pathSplit.length == 2 ? "*" : request.getPath().split("/", 3)[2];  //Remove the leading /structure from the path
		
		return RESTStructureQueryBuilder_V2.build(path, request.getParameters());
	}

}
