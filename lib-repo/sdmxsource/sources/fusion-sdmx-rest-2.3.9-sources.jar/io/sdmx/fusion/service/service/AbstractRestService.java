package io.sdmx.fusion.service.service;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.codehaus.jettison.json.JSONString;

import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.fusion.service.api.engine.FusionWebServiceExecutor;
import io.sdmx.fusion.service.api.engine.FusionWebServiceExecutorStream;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.json.ErrorUtil;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.ResponseBuilder;
import jakarta.ws.rs.core.StreamingOutput;

public abstract class AbstractRestService {

	protected Response writeToFile(String fileName, InputStream is) {
		try {
			return Response.ok(new ResponseWriter(is), MediaType.APPLICATION_OCTET_STREAM)
					.header("content-disposition", "attachment; filename = "+ fileName)
					.build();
		} catch (Throwable th) {
			throw new WebApplicationException(Response.serverError().entity(th.getMessage()).build());
		}
	}

	protected Response getErrorResponse(Throwable th) {
		int responseStatus = ErrorUtil.getResponseStatus(th);
		String errorMessage = ErrorUtil.getErrorMessage(th, System.lineSeparator());
		JSONObject jsonError = ErrorUtil.getJsonError(errorMessage, responseStatus);
		return getErrorResponse(jsonError, responseStatus);
	}

	protected Response getErrorResponse(JSONObject jsonError, int responseStatus) {
		return Response.status(responseStatus).entity(jsonError.toString()).build();
	}

	/**
	 * <p>do the web-service response checking including wrapping any errors thrown from the Supplier</p>
	 * <p>Please note: any wrapped output streams like a StreamingOutput will not be evaluated for errors as the calling code needs to run "write" first
	 * <p>If you wish to use a StreamingOutput, please make sure you throw a WebApplicationException inside the write method in regards to any error</p>
	 * <p>If you wish to return a custom object, you must extend it to include a MessageBodyWriter, or we switch to <a href="http://genson.io/">genson</a>. see <a href="https://stackoverflow.com/questions/20762109/obtaining-messagebodywriter-not-found-for-media-type-application-json-trying-t/20763003">this</a> for info
	 * <p>{@link io.sdmx.fusion.service.model.customrxjs.metadatatechnology.fusioncore.customrxjs.ByteArrayOutputStreamProvider See this class} for an example of a MessageBodyWriter marshaler
	 * <p>If T does not have a MessageBodyWriter marshaler, then this will fail </p>
	 * <p>Please see implementations of MessageBodyWriter for available marshalers, or add your own</p>
	 * <p>Any exception thrown from the executor will be consumed and re-thrown as an WebApplicationException with the response being the status and the text of determined by ErrorUtil.getResponseStatus and ErrorUtil.getErrorMessage respectively
<pre>
<p>example: </p>
<p><code> return performWebService((response) -> {
	// do some work
	return "done";
}); </code>

Would return the string "done" back to the client with a status of 200 OK
</p>
</pre>
	 * <p>The response media type is determined by the closrue's @Produces annotation
	 * @param executor
	 * @param <T> This will be used as the entity in the response to the client
	 * @param <ResponseBuilder> This is applied to the executed function, you may edit the response at any time, the default response is 200 OK. the response entity will be built with T
	   @throws IOException if T is an ServletOutputStream, this can not be as the ServletOutputStream commits the message before the response builds it
	 * @return
	 */
	protected <T> Response performWebService(FusionWebServiceExecutor<T> executor) {
		T ret = null;
		try {
			final ResponseBuilder response = Response.ok();

			try {
				ret = executor.apply(response);
				if(ret instanceof ServletOutputStream) {
					throw new IOException("Unable to intersect the response with ServletOutputStream");
				}
				if(ret instanceof Response) {
					return (Response)ret;
				}
				ResponseBuilder re = attemptToParse(ret, response);
				if(re != null) {
					return re.build();
				}
				return response.entity(ret).build();
			}catch(Throwable e) {
				if(e instanceof WebApplicationException) {
					throw (WebApplicationException)e;
				}
				// it's an error, we need to change the content type.
				// this needs to be used in conjunction of an @Produces array, if the message body marsheller parses the response payload, you need to make sure it deals with JSON
				response.header("Content-Type", MediaType.APPLICATION_JSON);
				throw new WebApplicationException(getErrorResponse(e));
			}
		}finally {
			if(ret != null && ret instanceof OutputStream) {
				StreamUtil.closeStream((OutputStream) ret);
			}
		}
	}

	protected <T> Response streamWriter(FusionWebServiceExecutorStream executor) {
		final ResponseBuilder response = Response.ok();
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			executor.apply(out);
			ResponseBuilder re = response.entity(out.toByteArray());
			return re.build();
		}catch(Throwable e) {
			if(e instanceof WebApplicationException) {
				throw (WebApplicationException)e;
			}
			// it's an error, we need to change the content type.
			// this needs to be used in conjunction of an @Produces array, if the message body marsheller parses the response payload, you need to make sure it deals with JSON
			response.header("Content-Type", MediaType.APPLICATION_JSON);
			throw new WebApplicationException(getErrorResponse(e));
		}
	}



	/**
	 * attempt to parse classes that do not have a MessageBodyWriter marshaler
	 * This needs to go, but for some reason, things like Env sync can not acsses any of the providers defiend in com.metadatatechnology.fusioncore.customrxjs
	 * @param ret
	 * @param response
	 * @return
	 * @throws IOException
	 */
	private <T> ResponseBuilder attemptToParse(T ret, ResponseBuilder response) throws IOException {
		if(ret instanceof OutputStream) {
			((OutputStream) ret).flush();
			if(ret instanceof ByteArrayOutputStream) {
				return response.entity(((ByteArrayOutputStream)ret).toByteArray());
			}
		}
		if(ret instanceof JSONObject || ret instanceof JSONArray) {
			return response.entity(ret.toString());
		}
		if(ret instanceof JSONString) {
			return response.entity(((JSONString) ret).toJSONString());
		}

		return null;
	}

	protected class ResponseWriter implements StreamingOutput {
		private InputStream is;

		public ResponseWriter(InputStream id) {
			this.is = id;
		}

		@Override
		public void write(OutputStream output) throws IOException, WebApplicationException {
			StreamUtil.copyStream(is, output);
		}
	}

	/**
	 * Returns the String value, or null if the string value equals null, an empty string, is null, or if the key does not exist
	 * @param json
	 * @param key
	 * @return the JSON string or null
	 * @throws JSONException
	 */
	protected String getJsonString(JSONObject json,  String key) throws JSONException {
		if(json.has(key)) {
			String val = json.getString(key);
			if(!ObjectUtil.validString(val) || val.equals("null")) {
				return null;
			}
			return val;
		}
		return null;
	}

	/**
	 * Get the JSON from the header of the HTTP request
	 * @param httpRequest
	 * @return the JSON
	 * @throws IOException
	 */
	protected String getDataFromRequestHeader(HttpServletRequest httpRequest) throws IOException {
		try (BufferedReader reader = httpRequest.getReader();){
			String line;
			StringBuilder sb = new StringBuilder();
			while ((line = reader.readLine()) != null) {
				sb.append(line).append('\n');
			}
			return sb.toString();
		}catch(IllegalStateException e) {
			InputStream inputStream = httpRequest.getInputStream();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			byte buf[] = new byte[1024];
			int letti;
			while ((letti = inputStream.read(buf)) > 0) {
				baos.write(buf, 0, letti);
			}
			return new String(baos.toByteArray());
		}
	}

	protected void writeError(Throwable th, OutputStream out) {
		th.printStackTrace();
		ErrorUtil.writeError(th, out);
	}

	protected void writeError(HttpServletResponse response, Throwable th, OutputStream out) {
		th.printStackTrace();
		response.setStatus(ErrorUtil.getResponseStatus(th));
		ErrorUtil.writeError(th, out);
	}

	protected void writeError(String message, OutputStream out) {
		ErrorUtil.writeError(message, out);
	}

	protected void writeSuccess(OutputStream out) {
		ErrorUtil.writeSuccess(out);
	}

	/**
	 * Return generic JSON Success message.
	 * @return
	 */
	protected String getSuccess() {
		return ErrorUtil.getSuccess().toString();
	}

	/**
	 * Returns JSON of the structures in the format
	 	{
	 		AgencyId : "SDMX"
	 		Id : "Blah"
	 		Name : "This is my name"
	 		Version : "1.0",
	 		Urn : "blah..."
	 	}
	 * @param maint The maintainable bean to convert to JSON form
	 * @return a JSONObject representation of the maintainable
	 */
	protected JSONObject getMaintainableJson(MaintainableBean maint) throws JSONException {
		JSONObject obj = new JSONObject();
		obj.put("AgencyId", maint.getAgencyId());
		obj.put("Id", maint.getId());
		obj.put("Name", maint.getName());
		obj.put("Version", maint.getVersion());
		obj.put("Urn", maint.getUrn());
		return obj;
	}
}
