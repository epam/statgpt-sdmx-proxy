package io.sdmx.fusion.service.api.engine;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.HTTP_METHOD;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;


/**
 * Processes a specific type of SDMX get request (data, structures, metadata, schema)
 */
public interface ISDMXRESTRequestEngine {

	/**
	 * Process the POST request, writing the response to the output stream, in the format defined by the InformationFormat
	 * 
	 * @param responseFormat
	 * @param request
	 * @param out
	 */
	void processRequest(InformationFormat responseFormat, Request request, IResponse response);

	/**
	 * @return resource type that this engine supports
	 */
	IResource getResourceType();

	/**
	 * @return the version of the API this engine supports
	 */
	ISdmxVersion getRestVersion();
	
	/**
	 * @return supported method
	 */
	HTTP_METHOD getSupportedMethod();
}
