package io.sdmx.fusion.service.model.request;


import java.io.OutputStream;
import java.util.Map;

import io.sdmx.api.exception.ExceptionCode;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.BASE_QUERY_MESSAGE_TYPE;
import io.sdmx.api.sdmx.model.query.RESTAvailabilityQuery;
import io.sdmx.api.sdmx.model.query.RESTDataQuery;
import io.sdmx.api.sdmx.model.query.RESTRegistrationQuery;
import io.sdmx.api.sdmx.model.query.RESTSchemaQuery;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.api.sdmx.model.query.RESTTableQuery;
import io.sdmx.fusion.service.builder.RESTStructureQueryBuilder;
import io.sdmx.fusion.service.model.servletresponse.ProxyOutputResponse;
import io.sdmx.im.beans.reference.RESTAvailabilityQueryImpl;
import io.sdmx.im.beans.reference.RESTDataQueryImpl;
import io.sdmx.im.beans.reference.RESTRegistrationQueryImpl;
import io.sdmx.im.beans.reference.RESTSchemaQueryImpl;
import io.sdmx.im.beans.reference.RESTTableQueryImpl;
import io.sdmx.utils.core.http.JSONPOuputSream;
import jakarta.servlet.http.HttpServletResponse;

public class GETRequest extends WebServiceRequest {

	public static final String ALL = "ALL";
	
	protected BASE_QUERY_MESSAGE_TYPE queryType;
	
	private RESTDataQuery getRequestDataQuery;  //IF THIS IS A DATA QUERY
	private RESTStructureQuery getRequestStructureQuery;  //IF THIS IS A STRUCTURE QUERY
	private RESTSchemaQuery getRequestSchemaQuery;
	private RESTRegistrationQuery getRequestRegistrationQuery;
	private RESTAvailabilityQuery restAvailabilityQuery;
	private RESTTableQuery restTableQuery;
	
	protected Request request;
	private IResponse response;

	public GETRequest(HttpServletResponse response, OutputStream outputStream,
			Request request, WebServiceRequestInfo webServiceRequestInfo,
			String[] queryString,
			Map<String, String> queryParameters,
			boolean returnStructuresAsRegistryStructureResponse) {
		super(outputStream, webServiceRequestInfo, returnStructuresAsRegistryStructureResponse);
		this.request = request;
		this.response = new HttpResponse(response, super.getOutputStream());
		String queryAction = queryString[0];
		processQueryParameters(queryAction, queryString, queryParameters);
	}
	
	@Override
	public boolean zipOutput(String fileName) {
		if(super.zipOutput(fileName)) {
			this.response = new ProxyOutputResponse(response, super.getOutputStream());
			return true;
		}
		return false;
	}
	
	public void setResponse(IResponse response) {
		this.response = response;
	}

	@Override
	public OutputStream getOutputStream() {
		return response.getOutputStream();
	}
	
	protected void processQueryParameters(String queryAction, String[] queryString, Map<String, String> queryParameters) {
		if(queryParameters.containsKey("callback")) {
			//JSONP query
			queryParameters.remove("_");
			String callback = queryParameters.get("callback");
			outputStream = new JSONPOuputSream(outputStream, callback);
			super.outputStream = outputStream;
			queryParameters.remove("callback");
		}
		if(queryAction.equalsIgnoreCase("data")) {
			queryType = BASE_QUERY_MESSAGE_TYPE.DATA;
			try {
				getRequestDataQuery = new RESTDataQueryImpl(queryString, queryParameters);
			} catch(SdmxException e) {
				throw new SdmxException(e, ExceptionCode.WEB_SERVICE_INVALID_GET_DATA);
			}
			
		} else if(queryAction.equalsIgnoreCase("schema")) {
			queryType = BASE_QUERY_MESSAGE_TYPE.SCHEMA;
			try {
				getRequestSchemaQuery = new RESTSchemaQueryImpl(queryString, queryParameters);
			} catch(SdmxException e) {
				throw new SdmxException(e, ExceptionCode.WEB_SERVICE_INVALID_GET_SCHEMA);
			}
			
		} else if(queryAction.equalsIgnoreCase("availableconstraint")) {
			queryType = BASE_QUERY_MESSAGE_TYPE.AVAILABILITY;
			try {
				restAvailabilityQuery = new RESTAvailabilityQueryImpl(queryString, queryParameters);
			} catch(SdmxException e) {
				throw new SdmxException(e, ExceptionCode.WEB_SERVICE_INVALID_GET_SCHEMA);
			}
			
		} else if(queryAction.equalsIgnoreCase("table")) {
			queryType = BASE_QUERY_MESSAGE_TYPE.TABLE;
			try {
				restTableQuery = new RESTTableQueryImpl(queryString, queryParameters);
			} catch(SdmxException e) {
				throw new SdmxException(e, ExceptionCode.WEB_SERVICE_INVALID_GET_SCHEMA);
			}
			
		} else if(queryAction.equalsIgnoreCase("registration")) {
			queryType = BASE_QUERY_MESSAGE_TYPE.REGISTRATION;
			try {
				getRequestRegistrationQuery = new RESTRegistrationQueryImpl(queryString, queryParameters);
			} catch(SdmxException e) {
				throw new SdmxException(e, "Invalid Registration Query");
			}
			
		} else {
			queryType = BASE_QUERY_MESSAGE_TYPE.STRUCTURE;
			getRequestStructureQuery = RESTStructureQueryBuilder.build(queryString, queryParameters);
		}
	}
	
	public Request getRequest() {
		return request;
	}
	
	public IResponse getResponse() {
		return response;
	}

	public BASE_QUERY_MESSAGE_TYPE getQueryType() {
		return queryType;
	}

	public RESTDataQuery getGetRequestDataQuery() {
		return getRequestDataQuery;
	}
	
	public RESTAvailabilityQuery getGetRequestAvailabilityQuery() {
		return restAvailabilityQuery;
	}

	public RESTTableQuery getRestTableQuery() {
		return restTableQuery;
	}


	public RESTRegistrationQuery getGetRequestRegistrationQuery() {
		return getRequestRegistrationQuery;
	}

	public RESTStructureQuery getGetRequestStructureQuery() {
		return getRequestStructureQuery;
	}

	public RESTSchemaQuery getGetRequestSchemaQuery() {
		return getRequestSchemaQuery;
	}
}
