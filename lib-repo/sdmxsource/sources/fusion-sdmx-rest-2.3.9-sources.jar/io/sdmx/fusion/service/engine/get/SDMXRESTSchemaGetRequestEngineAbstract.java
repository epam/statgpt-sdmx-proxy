package io.sdmx.fusion.service.engine.get;

import java.io.OutputStream;

import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.sdmx.constants.SDMX_VERSION;
import io.sdmx.api.sdmx.manager.schema.ISdmxSchemaManager;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.api.sdmx.model.format.SchemaFormat;
import io.sdmx.api.sdmx.model.query.RESTSchemaQuery;
import io.sdmx.format.ml.model.SDMX_XSDSchemaFormat;
import io.sdmx.fusion.service.api.engine.ISDMXRESTGetRequestEngine;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.im.beans.reference.RESTSchemaQueryImpl;
import io.sdmx.utils.core.application.FusionSystem;
import io.sdmx.utils.core.io.StreamUtil;

public abstract class SDMXRESTSchemaGetRequestEngineAbstract implements ISDMXRESTGetRequestEngine {
	private final ISdmxVersion REST_VERSION;
	private ISdmxSchemaManager schemaManager;

	public SDMXRESTSchemaGetRequestEngineAbstract(ISdmxSchemaManager schemaManager, ISdmxVersion apiVersion) {
		this.schemaManager = schemaManager;
		this.REST_VERSION = apiVersion;
		if(schemaManager == null) {
			throw new IllegalArgumentException("SDMXRESTSchemaGetRequestEngine missing required ISdmxSchemaManager");
		}
	}

	@Override
	public void processRequest(InformationFormat responseFormat, Request request, IResponse response) {
		if(responseFormat == null) {
			responseFormat = SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V3_0); 
		}
		SchemaFormat format = (SchemaFormat) responseFormat;
		RESTSchemaQuery schemaQuery = new RESTSchemaQueryImpl(request);
		try(WriteableDataLocation wdl = FusionSystem.getWdlFactory().getTemporaryWriteableDataLocation()) {
			OutputStream tmpOut = wdl.getOutputStream();
			schemaManager.generateSchema(format, schemaQuery, tmpOut);
			OutputStream out = response.getOutputStream();
			StreamUtil.copyStream(wdl.getInputStream(), out);
		}
	}

	@Override
	public IResource getResourceType() {
		return SDMX_REST_RESOURCE.SCHEMA.getResource();
	}

	@Override
	public ISdmxVersion getRestVersion() {
		return REST_VERSION;
	}
}
