package io.sdmx.fusion.service.api.manager;

import io.sdmx.api.sdmx.engine.CacheEngine;

/**
 * SDMX web service caching manager
 */
public interface HTTPCacheManager {

	/**
	 * Registers a cache engine with the manager
	 * @param cacheEngine
	 */
	void registerCacheEngine(CacheEngine cacheEngine);
	
	/**
	 * Bans everything
	 */
	void banAll();
	
}
