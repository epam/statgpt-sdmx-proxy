package io.sdmx.fusion.service.servlet;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.format.FormatDetails;
import io.sdmx.api.format.IResponseFormatManager;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.HTTP_METHOD;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.beans.base.ISdmxVersion;
import io.sdmx.fusion.service.api.manager.IServletServiceActivatorManager;
import io.sdmx.fusion.service.constant.SDMX_REST_RESOURCE;
import io.sdmx.fusion.service.model.request.HttpRequest;
import io.sdmx.fusion.service.model.request.HttpResponse;
import io.sdmx.fusion.service.model.request.WebServiceRequest;
import io.sdmx.fusion.service.model.servletresponse.GZIPResponseWrapper;
import io.sdmx.fusion.service.util.InMemoryThresholdingOutputStream;
import io.sdmx.fusion.service.util.ServletUtil;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.io.ContentLengthOutputStream;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.io.UncloseableOutputStream;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.sdmx.audit.SdmxAuditUtil;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Abstract web service layer for SDMX REST API
 * 
 * This abstract class provides the GET, POST, DELETE entry points, and first level routing of information
 * by:
 * <ol>
 *   <li>converting the request to a resource (data, metadata, structure, etc...)  </li>
 *   <li>obtaining the desired response format</li>
 *   <li>determining if the response should be output as a file or a stream (save as) </li>
 *   <li>wraps the output stream to ensure that the first 'n' bytes can be written sucessfully before it flushes the HTTP 200 status to the client</li>
 * </ol>
 * 
 */
public abstract class SDMXAPI extends HttpServlet {
	private ISdmxVersion apiVersion;

	protected Map<String, IResource> allResources = new HashMap<>();
	
	public SDMXAPI(ISdmxVersion apiVersion) {
		this.apiVersion = apiVersion;
		buildResourceMap();
	}
	
	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(SDMXAPI.class);

	private IServletServiceActivatorManager serviceActivatorManager = SingletonStore.getSingleton(IServletServiceActivatorManager.class);
	private IResponseFormatManager responseFormatManager = SingletonStore.getSingleton(IResponseFormatManager.class);
	
	private boolean postSupported = true;
	private boolean getSupported = true;
	private boolean deleteSupported = true;
	private boolean putSupported = true;

	private String options = null;

	protected void setSupportedMethods(HTTP_METHOD... supportedMethods) {
		postSupported = false;
		getSupported = false;
		deleteSupported = false;
		putSupported = false;

		if(supportedMethods != null) {
			for(HTTP_METHOD method : supportedMethods) {
				switch(method) {
				case DELETE:
					deleteSupported = true;
					break;
				case GET:
					getSupported = true;
					break;
				case POST:
					postSupported = true;
					break;
				case PUT:
					putSupported = true;
					break;
				default:
				}
			}
		}
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		if("true".equals(config.getInitParameter("disable-post"))) {
			postSupported = false;
		}
		if("true".equals(config.getInitParameter("disable-get"))) {
			getSupported = false;
		}
		if("true".equals(config.getInitParameter("disable-delete"))) {
			deleteSupported = false;
		}
		if("true".equals(config.getInitParameter("disable-put"))) {
			putSupported = false;
		}
	}
	
	/**
	 * Builds a mapping from the first REST path parameter to a Resource, i.e. /data/ maps to data
	 * for the V1 API /codelist/ maps to 'structure', the base implementation of this method
	 * simply maps the resource name to the resource 'data' maps to data, structure maps to structure.
	 * For the V1 API this method should be overridden as there is no /structure/ path in the query
	 */
	protected void buildResourceMap() {
		for(SDMX_REST_RESOURCE resource : SDMX_REST_RESOURCE.values()) {
			allResources.put(resource.getResource().getResource(), resource.getResource());
		}
	}
	
	/**
	 * @param resourceStr the first path part, e.g. if the servlet API maps to /sdmx/v2 and the URL is http://[webapp]/sdmx/v2/data/dataflow/EXR,
	 *        the resourceStr is 'data' as this is the first path part after the servlet mapping
	 * @return the resource derived from the first part of the path
	 */
	protected IResource getResource(String resourceStr) {
		return allResources.get(resourceStr.toLowerCase());
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
		if(!postSupported) {
			methodNotSupported(resp);
		} else {
			processRequest(req, resp);
		}
	}

	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) {
		if(!deleteSupported) {
			methodNotSupported(resp);
		} else {
			processRequest(req, resp);
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		if(!getSupported) {
			methodNotSupported(resp);
		} else {
			processRequest(req, resp);
		}
	}

	@Override
	protected void doOptions(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if(options == null) {
			StringBuilder sb = new StringBuilder("HEAD, OPTIONS");
			String concat = ", ";
			if(getSupported) {
				sb.append(concat + "GET");
			}
			if(postSupported) {
				sb.append(concat+ "POST");
			}
			if(putSupported) {
				sb.append(concat+ "PUT");
			}
			if(deleteSupported) {
				sb.append(concat+ "DELETE");
			}
			options = sb.toString();
		}
		resp.addHeader("Allow", options);
	}

	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if(!putSupported) {
			methodNotSupported(resp);
		} else {
			processRequest(req, resp);
		}
	}

	private void methodNotSupported(HttpServletResponse resp) {
		resp.setStatus(405);
	}

	private void processRequest(HttpServletRequest req, HttpServletResponse resp)  {
		InMemoryThresholdingOutputStream out = null;
		try {

			resp.setCharacterEncoding(StandardCharsets.UTF_8.toString());
			req.setCharacterEncoding(StandardCharsets.UTF_8.toString());
			Request request = new HttpRequest(req);

			//Isolate the entry point, it will be either data, structure, availability, schema, metadata,
			String path = req.getPathInfo();
			if(path == null) {
				throw new SdmxSemmanticException("REST URL is missing subpath");
			}
			String resourceStr = path.replaceFirst("/", "").split("/", 2)[0];

			IResource resource = getResource(resourceStr);
			
			if(resource == null) {
				throw new SdmxSemmanticException("unknown resource: "+resourceStr);
			}
			InformationFormat responseFormat = responseFormatManager.getInformationFormat(request, resource);
			if(responseFormat != null) {
				resp.setContentType(responseFormat.getFormatDetails().getMimeType());
			}
			ContentLengthOutputStream contentLengthOutput = null;
			OutputStream targetOut = resp.getOutputStream();
			boolean isGZip = ThreadLocalUtil.contains(GZIPResponseWrapper.THREAD_KEY);
			if(request.getMethod() ==  HTTP_METHOD.HEAD) {
				contentLengthOutput = request.getMethod() ==  HTTP_METHOD.HEAD ? new ContentLengthOutputStream() : null;
				if(isGZip) {
					targetOut = new GZIPOutputStream(contentLengthOutput);
				}
			}
			WebServiceRequest wsrequest = new WebServiceRequest(targetOut, null, false);

			String saveAsDefaultName = resource == null ? null : resource.getResource();
			FormatDetails formatDetails = responseFormat == null ? null : responseFormat.getFormatDetails();
			ServletUtil.applyContentDisposition(req, resp, saveAsDefaultName, wsrequest, request, formatDetails);
			out = new InMemoryThresholdingOutputStream(wsrequest.getOutputStream(), 5000);
			UncloseableOutputStream unclosable = new UncloseableOutputStream(out);
			IResponse response = new HttpResponse(resp, unclosable);
			SdmxAuditUtil.startSdmxEvent(resource, request.getMethod(), ()-> {
				response.setHeader(resourceStr, saveAsDefaultName);
				serviceActivatorManager.processRequest(request, resource, response, apiVersion, responseFormat);
			});
			out.close();
			if(contentLengthOutput != null) {
				if(isGZip) {
					response.setHeader("Content-Encoding","gzip");
				}
				response.setHeader("Content-Length", ""+contentLengthOutput.getBytesWritten());
			}
		} catch(Throwable th) {
			if(out == null || !out.isThresholdExceeded()) {
				ServletUtil.handleError(req, resp, th);
			} else {
				LOG.error("REST Error", th);
				StreamUtil.closeStream(out);
			}
		}
	}
}
