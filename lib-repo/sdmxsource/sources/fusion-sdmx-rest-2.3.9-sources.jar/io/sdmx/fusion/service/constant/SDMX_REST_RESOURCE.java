package io.sdmx.fusion.service.constant;

import java.util.HashMap;
import java.util.Map;

import io.sdmx.api.http.IResource;
import io.sdmx.fusion.service.model.request.Resource;

public enum SDMX_REST_RESOURCE {
	AVAILABILITY("availability"),
	DATA("data"),
	SCHEMA("schema"),
	METADATA("metadata"),
	STRUCTURE("structure"),
	REGISTRATION("registration"),
	PUBLICATION_TABLE("table"),
	PUBLICATION_TABLE_AVAILABILITY("tableavailability");
	
	private IResource resource;
	private String resourceStr;
	private static Map<String, SDMX_REST_RESOURCE> byResource = null;

	private SDMX_REST_RESOURCE(String resource) {
		this.resourceStr = resource;
		this.resource = Resource.getInstance(resource);
	}

	public static SDMX_REST_RESOURCE getResource(String resource) {
		if(byResource == null) {
			Map<String, SDMX_REST_RESOURCE> byResource = new HashMap<>(); 
			for(SDMX_REST_RESOURCE currentResource : SDMX_REST_RESOURCE.values()) {
				byResource.put(currentResource.resourceStr, currentResource);
			}
			SDMX_REST_RESOURCE.byResource = byResource;
		}
		return byResource.get(resource);
	}
	
	public IResource getResource() {
		return resource;
	}
}
