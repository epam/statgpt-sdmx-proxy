package io.sdmx.fusion.service.manager;

import java.util.Set;

import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.STRUCTURE_REFERENCE_DETAIL;
import io.sdmx.api.sdmx.manager.structure.CrossReferencedRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.im.beans.reference.RESTStructureQueryImpl;
import io.sdmx.utils.sdmx.structure.MaintainableUtil;

public class WsCrossReferencedRetrievalManager implements CrossReferencedRetrievalManager {
    private final ISdmxBeanRestRetrievalManager beanRetrievalManager;

    public WsCrossReferencedRetrievalManager(ISdmxBeanRestRetrievalManager beanRetrievalManager) {
        this.beanRetrievalManager = beanRetrievalManager;
    }

    @Override
    public <T extends MaintainableBean> Set<T> getCrossReferencedStructures(IURN<?> sourceStructureURN, boolean includeIndirectReferences, boolean fullTreeResolution, Class<T> structuresOfType) {
        STRUCTURE_REFERENCE_DETAIL refDetail = fullTreeResolution ? STRUCTURE_REFERENCE_DETAIL.DESCENDANTS : STRUCTURE_REFERENCE_DETAIL.CHILDREN;
        RESTStructureQuery restQuery = new RESTStructureQueryImpl(STRUCTURE_QUERY_DETAIL.FULL, refDetail, SDMX_STRUCTURE_TYPE.getTypeByClass(structuresOfType), sourceStructureURN);
        SdmxBeans beans = beanRetrievalManager.getMaintainables(restQuery);
        Set<T> maints = MaintainableUtil.filterSet(beans.getAllMaintainables(), structuresOfType);
        return maints;
    }

}
