package io.sdmx.fusion.service.model.request;

import java.io.OutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.error.IStructureValidationErrorHandler;
import io.sdmx.api.sdmx.model.beans.base.SDMXBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.utils.core.io.MutlipleReadableDataLocation;

public class POSTRequest extends WebServiceRequest {
	private ReadableDataLocation inputStream;
	private Collection<SDMXBean> modified = new HashSet<>();
	private Map<RegistrationBean, Throwable> failedModifications = new HashMap<>();
	private DATASET_ACTION action;
	private IStructureValidationErrorHandler errorHandler;

	public POSTRequest(ReadableDataLocation rdl,
					   OutputStream outputStream,
					   WebServiceRequestInfo webServiceRequestInfo,
					   boolean returnStructuresAsRegistryStructureResponse,
					   DATASET_ACTION action,
					   IStructureValidationErrorHandler errorHandler) {
		super(outputStream, webServiceRequestInfo, returnStructuresAsRegistryStructureResponse);
		this.inputStream = rdl;
		this.action = action;
		this.errorHandler = errorHandler;
		
		// If the input is a Zip file with a single entity in it, store the entity from the Zip rather
		// than the Zip itself.  This aids in error reporting.
		if(rdl != null && rdl.splitable()) {
			List<ReadableDataLocation> readableDataLocations = rdl.split(true);
			if(readableDataLocations.size() == 1) {
				this.inputStream = readableDataLocations.get(0);
			} else {
			    this.inputStream = new MutlipleReadableDataLocation(readableDataLocations);
			}
		}
	}

	public ReadableDataLocation getReadableDataLocation() {
		return this.inputStream;
	}
	
	public <T extends SDMXBean> void addModification(T bean) {
		this.modified.add(bean);
	}
	public void addFailedModification(RegistrationBean maint, Throwable th) {
		failedModifications.put(maint, th);
	}
	
	public void setModifications(Collection<? extends SDMXBean> bean) {
		this.modified.addAll(bean);
	}

	public Collection<? extends SDMXBean> getModified() {
		if(modified == null) {
			modified = new HashSet<>();
		}
		return modified;
	}

	public Map<RegistrationBean, Throwable> getFailedRegistrations() {
		return failedModifications;
	}
	
	public DATASET_ACTION getAction() {
		return action;
	}
	
	/**
	 * @return the error handler - may be null
	 */
	public IStructureValidationErrorHandler getErrorHandler() {
		return errorHandler;
	}
}
