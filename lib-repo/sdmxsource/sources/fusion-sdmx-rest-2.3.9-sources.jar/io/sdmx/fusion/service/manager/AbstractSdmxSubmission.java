package io.sdmx.fusion.service.manager;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.error.ErrorList;
import io.sdmx.api.exception.SDMX_ERROR_CODE;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.io.ReadableDataLocation;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.io.WriteableDataLocationFactory;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.MESSAGE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.http.api.model.IAuthentication;
import io.sdmx.utils.http.broker.HTTPQueryEngine;
import io.sdmx.utils.http.model.BasicAuthentication;
import io.sdmx.utils.http.model.RESTRequest;
import io.sdmx.utils.http.model.RESTResponse;
import io.sdmx.utils.sdmx.structure.SdmxMessageUtil;

public abstract class AbstractSdmxSubmission {
	private static final Logger LOG = LoggerFactory.getLogger(AbstractSdmxSubmission.class);

	protected WriteableDataLocationFactory wdlFactory = SingletonStore.getSingleton(WriteableDataLocationFactory.class);

	protected IAuthentication authentication;
	private String webService;
	private HTTPQueryEngine httpQueryEngine = new HTTPQueryEngine();

	public AbstractSdmxSubmission(String restService, String username, String password) {
		if(ObjectUtil.validString(username, password)) {
			this.authentication = new BasicAuthentication(username, password);
		}
		this.webService = restService;
	}

	public AbstractSdmxSubmission(String restService, IAuthentication authentication, int responseTimeoutSeconds) {
		this.authentication = authentication;
		this.webService = restService;
		if(responseTimeoutSeconds > 0) {
			httpQueryEngine.setResponseTimeout(responseTimeoutSeconds);
		}
	}
	
	public AbstractSdmxSubmission(String restService) {
		this.webService = restService;
	}

	/**
	 * Send to the default service
	 * @param object
	 * @return
	 */
	protected Map<DATASET_ACTION, Set<IURNMaintainable<?>>> performSubmission(Object object, DATASET_ACTION action)  {
		return performSubmission(object, null, action);
	}
	/**
	 * Performs the submission, validates that the response is both XML, and contains no error status,
	 * if it does an exception will be thrown.
	 * @param object - can be an XMLObject, ByteArrayInputStream, ReadableDataLocation
	 * @return
	 * @throw ValidationException if the response is either not XML, or if there is an error Status in the response
	 */
	protected Map<DATASET_ACTION, Set<IURNMaintainable<?>>> performSubmission(Object object, String service, DATASET_ACTION action)  {
		
		try(WriteableDataLocation writeableDataLocation = wdlFactory.getTemporaryWriteableDataLocation();){
			try {
				RESTRequest request = new RESTRequest(object, service == null ? webService : service).setAuthentication(authentication);
				request.setReadTimeout(httpQueryEngine.getReadTimeout());
				if(action != null) {
					request.addHeaderParam("ACTION", action.getAction());
				}
				LOG.info("Submit Request: " +request.getUrl());
				RESTResponse response = httpQueryEngine.sendMessage(request, writeableDataLocation.getOutputStream());
				
				//DEV-1904 STAT uses the SDMX Error message to convey that everything went well and there
				//is nothing to worry about. This means we can not rely on the SDMX Error message to mean error anymore.
				//Instead we need to check first if the the HTTP response status was not a HTTP 200 - if this is the case
				//then we can interpret the SDMX Error message as an actual error has occured
				if(response.getStatus() != 200) {
					validateSdmxResponse(writeableDataLocation);
				}
				LOG.info("Server Response Received");
				// Default behaviour is to return NULL. WsStructurePersistence will override this
				return null;
			} finally {
				ThreadLocalUtil.clearFromThread("Authorization");
			}
		}
	}
	
	public HTTPQueryEngine getHttpQueryEngine() {
		return httpQueryEngine;
	}
	
	public String getWebService() {
		return webService;
	}

	protected Map<DATASET_ACTION, Set<StructureReferenceBean>> validateSdmxResponse(ReadableDataLocation dataLocation) {
		LOG.info("Validating Server Response");
		if(SdmxMessageUtil.getMessageType(dataLocation) == MESSAGE_TYPE.ERROR) {
			try {
				SdmxMessageUtil.parseSdmxErrorMessage(dataLocation);
			}catch (SdmxException e) {
				if(e.getSdmxErrorCode() == SDMX_ERROR_CODE.NOT_MODIFIED) {
					return new HashMap<>();
				}
				throw e;
			}
		}
		// Default behaviour is to return NULL. WsStructurePersistence will override this
		return null;
	}

	protected void throwError(ErrorList errorList) {
		StringBuilder sb = new StringBuilder();
		for(String currentError : errorList.getErrorMessage()) {
			sb.append(currentError);
			sb.append(System.lineSeparator());
		}
		throw new SdmxException(sb.toString());
	}
}
