package io.sdmx.fusion.service.api.model;

import java.io.OutputStream;

/**
 * Represents the response to a SDMX web service post action, such as submit structures or submit registration
 */
public interface ISdmxResponse {

	/**
	 * @return the HTTP Status
	 */
	int getHttpStatusCode();
	
	/**
	 * @param out writes the response to the output stream
	 */
	void writeResponse(OutputStream out);
	
}
