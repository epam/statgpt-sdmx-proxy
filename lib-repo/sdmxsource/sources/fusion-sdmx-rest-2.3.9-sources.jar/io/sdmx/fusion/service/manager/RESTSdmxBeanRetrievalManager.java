package io.sdmx.fusion.service.manager;

import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.fusion.service.api.engine.RESTQueryBrokerEngine;
import io.sdmx.fusion.service.constant.REST_API_VERSION;
import io.sdmx.utils.core.application.SingletonStore;

public class RESTSdmxBeanRetrievalManager implements ISdmxBeanRestRetrievalManager {
	private String restURL;
	
	private StructureFormat structureFormat;
	private REST_API_VERSION apiVersion;

	/**
	 * @param restURL
	 * @param apiVersion the version of the REST API to query see API_VERSION
	 */
	public RESTSdmxBeanRetrievalManager(String restURL, REST_API_VERSION apiVersion) {
		super();
		this.restURL = restURL;
		this.apiVersion = apiVersion;
	}

	public RESTSdmxBeanRetrievalManager(String restURL, StructureFormat structureFormat, REST_API_VERSION apiVersion) {
		this(restURL, apiVersion);
		this.structureFormat = structureFormat;
	}

	@Override
	public SdmxBeans getMaintainables(RESTStructureQuery sQuery) {
		return SingletonStore.getSingleton(RESTQueryBrokerEngine.class).getMaintainables(this.restURL, apiVersion, sQuery, structureFormat);
	}
	
	public String getRestURL() {
		return restURL;
	}
}
