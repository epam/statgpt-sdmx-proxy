package io.sdmx.fusion.service.model.queryresponse;

import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.model.format.IMetadataFormat;
import io.sdmx.api.sdmx.model.query.IMetadataQueryRequest;
import io.sdmx.api.sdmx.model.query.IRESTMetadataQuery;

public class MetadataQueryRequest implements IMetadataQueryRequest {
	private boolean wasFormatDefaulted;
	private IRESTMetadataQuery metadataQueryRequest;
	private Request request;
	private IResponse response;
	private IMetadataFormat format;
	
	public MetadataQueryRequest(IRESTMetadataQuery metadataQueryRequest, Request req, IResponse resp, IMetadataFormat format) {
		this.metadataQueryRequest = metadataQueryRequest;
		this.request = req;
		this.response = resp;
		this.format = format;
	}

	@Override
	public boolean wasFormatDefaulted() {
		return wasFormatDefaulted;
	}
	
	public void setWasFormatDefaulted(boolean wasFormatDefaulted) {
		this.wasFormatDefaulted = wasFormatDefaulted;
	}

	@Override
	public IRESTMetadataQuery getMetadataQueryRequest() {
		return metadataQueryRequest;
	}

	@Override
	public Request getRequest() {
		return request;
	}

	@Override
	public IResponse getResponse() {
		return response;
	}

	@Override
	public IMetadataFormat getFormat() {
		return format;
	}
}
