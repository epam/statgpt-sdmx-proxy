package io.sdmx.fusion.service.service.fusionxl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.codehaus.jettison.json.JSONObject;

import com.opencsv.CSVWriter;

import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.exception.SDMX_ERROR_CODE;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.data.DataFormat;
import io.sdmx.api.service.fusionxl.IExcelPluginServiceActivator;
import io.sdmx.core.sdmx.api.factory.data.DataFormatManager;
import io.sdmx.fusion.service.model.request.HttpRequest;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.xs.URN;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.StreamingOutput;

/**
 * Supports all the methods (structures ONLY) from the FusionXL Excel Plugin.
 */
@Path("/excel/plugin/")
public class FusionXLService {

	private IExcelPluginServiceActivator service = SingletonStore.getSingleton(IExcelPluginServiceActivator.class);
	private FusionProductInformationRetrievalManager productInfo = SingletonStore.getSingleton(FusionProductInformationRetrievalManager.class);
	private DataFormatManager dataFormatManager = SingletonStore.getSingleton(DataFormatManager.class);

	protected String getRealm() {
		return productInfo.getFusionProductInformation().getProductDetails().getProductName();
	}

	@GET
	@Path("getDataFlowsForUser")
	@Produces("text/csv; charset=utf-8")
	/**
	 * Returns all the dataflows for the given user
	 */
	public StreamingOutput getDataflowMenu(final @Context HttpServletResponse httpResponse, final @QueryParam("provider") String providerUrn) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					service.writeDataflows(providerUrn, out);
				} catch(Throwable th) {
					handleGETException(th, httpResponse);
				}
			}
		};
	}

	@GET
	@Path("getDataProviders")
	@Produces("text/csv; charset=utf-8")
	/**
	 *  Returns all the data providers for the current user that have at lease ONE provision agreement, if an admin user, returns all the data providers
	 **/
	public StreamingOutput getDataProviderMenu(final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					service.writeDataProviders(out);
				} catch(Throwable th) {
					handleGETException(th, httpResponse);
				}
			}
		};
	}

	@GET
	@Path("getProvisions")
	@Produces("text/csv; charset=utf-8")
	/**
	 * Returns the Provision Agreements for the Data Provider and flow combination (or Admin User)
	 * @param flowUrn
	 * @param providerUrn
	 * @param httpResponse
	 * @return
	 */
	public StreamingOutput getProvisions(final @QueryParam("flow") String flowUrn,
			final @QueryParam("provider") String providerUrn,
			final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					service.writeProvisions(flowUrn, providerUrn, out);
				} catch(Throwable th) {
					handleGETException(th, httpResponse);
				}
			}
		};
	}


	@GET
	@Path("createDataset")
	@Produces("text/csv; charset=utf-8")
	/**
	 * Writes out dataset columns for the given Dataflow (dimension ids, attribute ids, time periods) in a single CSV line
	 */
	public StreamingOutput createDataset(final @Context HttpServletResponse httpResponse,
			final @QueryParam("flow") String flowUrn,
			final @QueryParam("provider") String providerUrn,
			final @QueryParam("freq") String freq,
			final @QueryParam("startDate") String startDate,
			final @QueryParam("endDate") String endDate,
			final @QueryParam("fixedValues") String fixedValues,
			final @QueryParam("attrsToExclude") String attrsToExclude,
			final @QueryParam("maxCodes") String codeLimitStr) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					Map<String, String> fixedValueMap =  toFixedValue(fixedValues);
					Set<String> attributesToExclude = toSet(attrsToExclude);
					int codeLimit = ObjectUtil.toInteger(codeLimitStr, -1);
					service.writeDatasetDetails(startDate, endDate, freq, flowUrn, providerUrn, fixedValueMap, attributesToExclude, codeLimit, out);
				} catch(Throwable th) {
					handleGETException(th, httpResponse);
				}
			}
		};
	}

	@GET
	@Path("createTemplate")
	/**
	 * Writes an Excel Data File, either as a template for authoring new data, or with existing data contained (based on period and frequency)
	 */
	public Response createTemplate(final @Context HttpServletResponse httpResponse,
			final @QueryParam("dsd") String ref,
			final @QueryParam("freq") String freq,
			final @QueryParam("startDate") String startDate,
			final @QueryParam("endDate") String endDate,
			final @QueryParam("includeData") Boolean includeData,
			final @QueryParam("fixedValues") String fixedValues,
			final @QueryParam("attrsToExclude") String attrsToExclude) {
		try {
			Map<String, String> fixedValueMap =  toFixedValue(fixedValues);
			Set<String> attributesToExclude = toSet(attrsToExclude);
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			service.writeExcelDataTemplate(startDate, endDate, freq, ref, includeData, fixedValueMap, attributesToExclude, out);
			return getResponse(ref.split("=")[1].replaceAll("\\.", "_") +".xlsx", new ByteArrayInputStream(out.toByteArray()));
		} catch(Throwable th) {
			th.printStackTrace();
			return Response.serverError().entity(th.getMessage().toString()).build();
		}
	}

	@GET
	@Path("writeFilteredCodelist")
	@Produces("text/csv; charset=utf-8")
	/**
	 * Writes a Codelist's codes which match the provided filter term:
	 * Example CSV format: "A - Annual", "M - Monthly"
	 * @param urn
	 * @param componentId
	 * @param filterTerm
	 * @param httpResponse
	 * @return
	 */
	public StreamingOutput writeFiteredCodelist(final @QueryParam("ref") String urn,
			final @QueryParam("componentId") String componentId,
			final @QueryParam("filterTerm") String filterTerm,
			final @QueryParam("maxCodes") String codeLimitStr,
			final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					int codeLimit = ObjectUtil.toInteger(codeLimitStr, -1);
					service.writeFilteredCodelist(urn, componentId, filterTerm, out, codeLimit);
				} catch(Throwable th) {
					handleGETException(th, httpResponse);
				}
			}
		};
	}

	private Map<String, String> toFixedValue(String fixedValues) {
		Map<String, String> fixedValueMap = Collections.emptyMap();
		if (ObjectUtil.validString(fixedValues)) {
			String[] parts = fixedValues.split(",");
			fixedValueMap = new HashMap<>(parts.length);
			for (String keyValue : parts) {
				String[] splitValue = keyValue.split("=");
				if (splitValue.length != 2) {
					throw new SdmxException("Illegal value submitted for fixedValues. Value was: " + fixedValues);
				}
				fixedValueMap.put(splitValue[0], splitValue[1]);
			}
		}
		return fixedValueMap;
	}

	private Set<String> toSet(String attrsToExclude) {
		if (ObjectUtil.validString(attrsToExclude)) {
			return CollectionUtil.arrayToSet(attrsToExclude.split(","));
		}
		return  Collections.emptySet();
	}



	@POST
	@Path("validateData")
	public StreamingOutput validateData(
			final @QueryParam("urn") String urn,
			final @Context HttpServletRequest request,
			final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					Request req = new HttpRequest(request);
					service.validateData(req.getReadableDataLocation(), urn, out);
				} catch(Throwable th) {
					String response = handlePOSTException(th, httpResponse);
					out.write(response.getBytes());
				}
			}
		};
	}

	@POST
	@Path("loadData")
	/**
	 * Loads SDMX (or other) data either returning the Dataset converted to Excel for display, or if the dataset could not be read,
	 * a response requests for more details, or an error is reported
	 * @param request
	 * @param httpResponse
	 * @return
	 */
	public StreamingOutput loadData(
			final @Context HttpServletRequest request,
			final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					Request req = new HttpRequest(request);
					service.loadData(req.getReadableDataLocation(), out);
				} catch(Throwable th) {
					String response = handlePOSTException(th, httpResponse);
					out.write(response.getBytes());
				}
			}
		};
	}

	@POST
	@Path("exportData")
	/**
	 * @param urn
	 * @param senderId
	 * @param request
	 * @param httpResponse
	 * @return
	 */
	public StreamingOutput exportData(
			final @QueryParam("urn") String urn,
			final @QueryParam("senderId") String senderId,
			final @QueryParam("attachment") String attachment,
			final @Context HttpServletRequest request,
			final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					Request req = new HttpRequest(request);
					httpResponse.addHeader("content-disposition", "attachment; filename = foo.xml");
					httpResponse.setContentType(MediaType.APPLICATION_OCTET_STREAM);
					DataFormat df = dataFormatManager.getFormat(req);
					SDMX_STRUCTURE_TYPE attachmentStructure = attachment == null ? null : SDMX_STRUCTURE_TYPE.parseClass(attachment);
					service.exportData(req.getReadableDataLocation(), urn, senderId, df, attachmentStructure, out);
				} catch(Throwable th) {
					String response = handlePOSTException(th, httpResponse);
					out.write(response.getBytes());
				}
			}
		};
	}

	@GET
	@Path("provideDataDetails")
	/**
	 * Provides more details so that a previously loaded dataset can be read.
	 *
	 * @param flowUrn
	 * @param providerUrn
	 * @param uid
	 * @param httpResponse
	 * @return
	 */
	public StreamingOutput provideDataDetails(
			final @QueryParam("flowUrn") String flowUrn,
			final @QueryParam("providerUrn") String providerUrn,
			final @QueryParam("uid") String uid,
			final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					service.provideDataDetails(uid, flowUrn, providerUrn, out);
				} catch(Throwable th) {
					handleGETException(th, httpResponse);
				}
			}
		};
	}


	@GET
	@Path("supportedStructures")
	@Produces("text/csv")
	/**
	 * Writes the supported structures as a menu in the following format (ClassName:Human Name)
	 * @return
	 */
	public StreamingOutput getSupportedStructures() {
		return new StreamingOutput() {

			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				service.getSupportedStructures(out);
			}
		};
	}

	@GET
	@Path("agencies")
	@Produces("text/csv")
	/**
	 * Writes the agencies to the output stream, in the format "SDMX:SDMX", "ECB:European Central Bank"
	 * @return
	 */
	public StreamingOutput getAgenciesStructures() {
		return new StreamingOutput() {

			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				service.getAgenciesStructures(out);
			}
		};
	}


	@GET
	@Path("locales/{type}/{agencyId}/{id}/{version}")
	@Produces("text/csv")
	/**
	 * Writes the locales that have labels for the given structure in the format: "en","fr"
	 *
	 * @param type
	 */
	public StreamingOutput getLocales(final @PathParam("type") String type,
			final @PathParam("agencyId") String agencyId,
			final @PathParam("id") String id,
			final @PathParam("version") String version,
			final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {

			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					service.getLocales(getStructureReferenceBean(type, agencyId, id, version), out);
				} catch(Throwable th) {
					handleGETException(th, httpResponse);
				}
			}
		};
	}

	@GET
	@Path("crossReferences/{type}/{agencyId}/{id}/{version}")
	@Produces("text/csv")
	/**
	 * Writes the cross references for a structure to the output stream in the format
	 *
	 * "1", "Dataflow", "ECB", "FlowID", "Flow Version", "Dataflow Name"
	 * "2", "Provision Agreement", "ECB", "ProvID", "Prov Version", "Prov Name"
	 */
	public StreamingOutput getCrossReferences(final @PathParam("type") String type,
			final @PathParam("agencyId") String agencyId,
			final @PathParam("id") String id,
			final @PathParam("version") String version,
			final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {

			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					service.getCrossReferences(getStructureReferenceBean(type, agencyId, id, version), out);
				} catch(Throwable th) {
					handleGETException(th, httpResponse);
				}
			}
		};
	}

	@GET
	@Path("getMaintainableOptions")
	@Produces("text/csv")
	/**
	 *
	 * Writes the structures that exist for the given agency of 'structure type' as CSV in the following format
	 * "urn","My Codelist"
	 * "urn","My Codelist 2"
	 *
	 * @param agencyId
	 * @param structureType
	 * @param httpResponse
	 * @return
	 */
	public StreamingOutput getMaintainableOptions(final @QueryParam("agencyId") String agencyId,
			final @QueryParam("structureType") String structureType,
			final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {

			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				if (structureType == null) {
					handleGETException(new IllegalArgumentException("The structureType may not be null"), httpResponse);
				} else {
					SDMX_STRUCTURE_TYPE type;
					try {
						type = SDMX_STRUCTURE_TYPE.parseClass(structureType);
					} catch (Exception e) {
						handleGETException(new IllegalArgumentException("Illegal structureType specified: " + structureType), httpResponse);
						return;
					}
					try {
						service.getMaintainableOptions(agencyId, type, out);
					} catch (Throwable th) {
						handleGETException(th, httpResponse);
					}
				}
			}
		};
	}


	@POST
	@Path("createStructure")
	@Produces("text/csv")
	/**
	 * Posts a request for a structure to be created, includes all the mandatory parameters of: agency,id,version, and name
	 *
	 * Responds in CSV with ObjectType,AgencyId,Id,Version
	 *
	 * @param postMsg JSON in the format
	 *  {
	 *   StructureType:"Codelist",
	 *   AgencyId:"SDMX",
	 *   Id:"CL_FREQ",
	 *   Version:"1.0",
	 *   Name:"Frequency Codelist"
	 *  }
	 *
	 * @param postMsg
	 * @param req
	 * @param httpResponse
	 * @return
	 */
	public StreamingOutput createStructure(final String postMsg, final @Context HttpServletRequest req, final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					service.createStructure(new JSONObject(postMsg), out);
				} catch (Throwable th) {
					out.write(handlePOSTException(th, httpResponse).getBytes());
				}
			}
		};
	}

	@GET
	@Path("search")
	@Produces("text/csv")
	/**
	 * Performs a search and returns the results to the output stream in the following format
	 * <p/>
	 * StructureType, agencyId, Id, Version, Name
	 *
	 * @param queryString
	 * @param httpResponse
	 * @return
	 */
	public StreamingOutput search(final @QueryParam("query") String queryString,
			final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {

			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					service.search(queryString, out);
				} catch(Throwable th) {
					handleGETException(th, httpResponse);
				}
			}
		};
	}

	@POST
	@Path("save")
	@Produces("text/csv")
	public StreamingOutput save(final String postMsg, final @Context HttpServletRequest req, final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException, WebApplicationException {
				SdmxBeans beans = null;
				try {
					beans = (SdmxBeans)req.getSession().getAttribute("SdmxBeans");
					service.save(postMsg, beans, out);
				} catch(Throwable th) {
					if(th instanceof SdmxException) {
						SdmxException e = (SdmxException) th;
						if(e.getSdmxErrorCode() == SDMX_ERROR_CODE.UNAUTHORISED) {
							req.getSession().setAttribute("SdmxBeans", beans);
						}
					}
					out.write(handlePOSTException(th, httpResponse).getBytes());
				}
			}
		};
	}

	@POST
	@Path("deleteStructure/{type}/{agencyId}/{id}/{version}")
	@Produces("text/csv")
	public StreamingOutput deleteStructure(final @PathParam("type") String type,
			final @PathParam("agencyId") String agencyId,
			final @PathParam("id") String id,
			final @PathParam("version") String version,
			final @Context HttpServletRequest req,
			final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					service.deleteStructure(getStructureReferenceBean(type, agencyId, id, version), out);
				} catch(Throwable th) {
					out.write(handlePOSTException(th, httpResponse).getBytes());
				}
			}
		};
	}

	protected String handlePOSTException(Throwable th, HttpServletResponse httpResponse) throws IOException {
		SDMX_ERROR_CODE errorCode = SDMX_ERROR_CODE.INTERNAL_SERVER_ERROR;
		String errorMessage = th.getMessage();
		if(th instanceof SdmxException) {
			SdmxException e = (SdmxException) th;
			errorMessage = e.getFullMessage();
			errorCode = e.getSdmxErrorCode();
			if(errorCode == SDMX_ERROR_CODE.UNAUTHORISED) {
				httpResponse.addHeader("WWW-Authenticate", "Basic realm=\""+getRealm()+"\"");
				httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED, th.getMessage());
				//return;
			}
		}
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		Writer w = new OutputStreamWriter(bos, StandardCharsets.UTF_8);
		CSVWriter writer = new CSVWriter(w);
		writer.writeNext(new String[]{errorCode.getClientErrorCode().toString(), errorMessage});
		writer.close();
		return new String(bos.toByteArray());

	}

	protected void handleGETException(Throwable th, HttpServletResponse httpResponse) throws IOException {
		SDMX_ERROR_CODE errorCode = SDMX_ERROR_CODE.INTERNAL_SERVER_ERROR;
		//		String errorMessage = th.getMessage();
		if(th instanceof SdmxException) {
			SdmxException e = (SdmxException) th;
			//			String errorMessage = e.getFullMessage();
			errorCode = e.getSdmxErrorCode();
			if(errorCode == SDMX_ERROR_CODE.UNAUTHORISED) {
				httpResponse.addHeader("WWW-Authenticate", "Basic realm=\""+getRealm()+"\"");
			}
		}
		httpResponse.sendError(errorCode.getHttpRestErrorCode(), th.getMessage());
	}

	@GET
	@Path("auth")
	@Produces("text/csv")
	/**
	 * Forces Excel to show an authenticate form
	 */
	public StreamingOutput getAuth(final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				if(!service.getAuth(out)) {
					httpResponse.addHeader("WWW-Authenticate", "Basic realm=\""+getRealm()+"\"");
					httpResponse.sendError(SDMX_ERROR_CODE.UNAUTHORISED.getHttpRestErrorCode(), "Authenticate");
				}
			}
		};
	}

	@GET
	@Path("menu")
	@Produces("application/xml")
	/**
	 * Writes CSV used to build the structure menu as a hierarchy (structure type,agency id, structures)
	 */
	public StreamingOutput getStructureMenu(final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					service.getStructureMenu(out);
				} catch(Throwable th) {
					handleGETException(th, httpResponse);
				}
			}
		};
	}


	@GET
	@Path("lookupMenu")
	@Produces("application/xml")
	/**
	 * Writes the Lookup Structure Menu (DSD by Concept/DSD By Codelist/Dataflow by DSD)
	 *
	 * "Dataflow by Data Structure", "IMF", "NA Main(1.0)", "Dataflow/IMF/NAG_GNA/1.0", "Dataflow 1"<br/>
	 * "Dataflow by Data Structure", "IMF", "NA Main(1.0)", "Dataflow/IMF/NAG_GNA/1.0", "Dataflow 2"<br/>
	 * "Dataflow by Data Structure", "IMF", "NA Main(1.0)", "Dataflow/IMF/NAG_GNA/1.0", "Dataflow 3"<br/>
	 * @param out
	 */
	public StreamingOutput getLookupMenu(final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					service.getLookupMenu(out);
				} catch(Throwable th) {
					handleGETException(th, httpResponse);
				}
			}
		};
	}

	@GET
	@Path("history/{type}/{agencyId}/{id}/{version}")
	@Produces("text/csv")
	/**
	 * Writes the history of a structure to the output stream in the format
	 *
	 * "12", "2002-01-01T20:32:23", "user1", "Append"
	 * "13", "2002-02-01T20:32:23", "user1", "Delete"
	 * "14", "2002-03-01T20:32:23", "user1", "Append"
	 *
	 */
	public StreamingOutput getStructureHistory(final @QueryParam("txId") Integer txId,
			final @PathParam("type") String type,
			final @PathParam("agencyId") String agencyId,
			final @PathParam("id") String id,
			final @PathParam("version") String version,
			final @Context HttpServletResponse httpResponse) {
		return new StreamingOutput() {
			@Override
			public void write(OutputStream out) throws IOException,WebApplicationException {
				try {
					service.getStructureHistory(txId, type, agencyId, id, version, out);
				} catch(Throwable th) {
					handleGETException(th, httpResponse);
				}
			}
		};
	}

	protected Response getResponse(String fileName, InputStream is) {
		try {
			return Response.ok(new ResponseWriter(is), MediaType.APPLICATION_OCTET_STREAM)
					.header("content-disposition", "attachment; filename = "+ fileName)
					.build();
		} catch (Throwable th) {
			throw new WebApplicationException(
					Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR)
					.entity(th.getMessage()).build());
		}
	}

	protected class ResponseWriter implements StreamingOutput {
		private InputStream is;

		public ResponseWriter(InputStream id) {
			this.is = id;
		}

		@Override
		public void write(OutputStream output) throws IOException, WebApplicationException {
			StreamUtil.copyStream(is, output);
		}
	}

	private IURNMaintainable<?> getStructureReferenceBean(String type, String agencyId, String id, String version) {
		return URN.builder(SDMX_STRUCTURE_TYPE.parseClass(type), agencyId, id, version).buildMaintainable();
	}
}
