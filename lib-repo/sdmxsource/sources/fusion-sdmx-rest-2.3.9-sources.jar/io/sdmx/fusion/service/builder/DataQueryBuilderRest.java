package io.sdmx.fusion.service.builder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.sdmx.constants.DATA_QUERY_DETAIL;
import io.sdmx.api.sdmx.constants.MATCH_FUNCTION;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DataStructureBean;
import io.sdmx.api.sdmx.model.beans.datastructure.DimensionBean;
import io.sdmx.api.sdmx.model.data.query.DataQuery;
import io.sdmx.api.sdmx.model.data.query.DataQuerySelection;
import io.sdmx.fusion.service.constant.REST_API_VERSION;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.date.DateUtil;
import io.sdmx.utils.core.object.ObjectUtil;


public class DataQueryBuilderRest {


	public static String buildDataQuery(DataQuery query, REST_API_VERSION apiVersion) {
		if(query == null) {
			throw new IllegalArgumentException("DataQueryBuilderRest.buildRestDataQuery DataQuery is required, null was passed");
		}
		boolean v2Api = apiVersion.getVersion().getMajor() == 2;
		
		DataStructureBean dsd = query.getDataStructure();
		StringBuilder sb = new StringBuilder();
		sb.append("data/");

		if(query.getDataflow() != null) {
			if(v2Api) {
				sb.append("dataflow/");
			}
			String concat = v2Api ? "/" : ",";
			appendMaintainable(sb, query.getDataflow(), concat);
		} else {
			if(v2Api) {
				sb.append("datastructure/");
				appendMaintainable(sb, dsd, "/");
			} else {
				throw new IllegalArgumentException("A REST query requires a dataflow to be set - no dataflow found for query");
			}
		}
		Map<String, Set<String>> selections = new HashMap<>();

		Date dateFrom = null;
		Date dateTo = null;

		if(query.hasSelections()) {
			if(query.getStartPeriod() != null) {
				dateFrom = query.getStartPeriod().getDate();
			}
			if(query.getEndPeriod() != null) {
				dateTo = query.getEndPeriod().getDate();
			}
			for(DataQuerySelection currentSelection : query.getSelections()) {
				if(currentSelection.getMatchFunction() != MATCH_FUNCTION.EQUALS) {
					throw new SdmxSemmanticException("Can not process "+currentSelection.getMatchFunction().toString()+":"+currentSelection.getComponentId()+" SDMX web service v1 only supports the equals match function");
				}
				selections.put(currentSelection.getComponentId(), currentSelection.getValues());
			}
		}
		boolean firstAppend=true;
		
		if(ObjectUtil.validCollection(query.getSeries())) {
			if(v2Api) {
				String concat = "";
				for(String series : query.getSeries()) {
					sb.append(concat+series);
					concat = ",";
				}
			}
		}
		if(selections.size() == 0) {
			if(!v2Api) {
				sb.append("all");
			}
		} else {
			String concatPeriod = "";
			if(v2Api) {
				//Build the component filters
				List<String> sortedList = new ArrayList<>(selections.keySet());
				Collections.sort(sortedList);
				for(String compId : sortedList) {
					String joinedSelections = CollectionUtil.join(",", "", selections.get(compId));
					appendParam(firstAppend, "c%5B"+compId+"%5D", joinedSelections, sb);
					firstAppend = false;
				}
			} else {
				//Build the key
				for(DimensionBean dim : dsd.getDimensions(SDMX_STRUCTURE_TYPE.DIMENSION)) {
					sb.append(concatPeriod);
					String conceptId = dim.getId();
					if(selections.containsKey(conceptId)) {
						String concatPlus = "";
						for(String currentSelection : selections.get(conceptId)) {
							sb.append(concatPlus);
							sb.append(currentSelection);
							concatPlus = "+";
						}
					} 
					concatPeriod = ".";
				}
			}
		}

		if(!v2Api) {
			String providerAgency = null;
			String providerId = null;
			if(query.getDataProvider() != null) {
				for(DataProviderBean currentProvider : query.getDataProvider()) {
					if(providerAgency != null && !providerAgency.equals(currentProvider.getMaintainableParent().getAgencyId())) {
						providerAgency = "*";
					} else {
						providerAgency = currentProvider.getMaintainableParent().getAgencyId();
					}
					if(providerId != null && !providerId.equals(currentProvider.getId())) {
						providerId = "all";
					} else {
						providerId = currentProvider.getId();
					}
				}
			}
			if(!"all".equals(providerId) && (providerId != null)) {
				if(!"all".equals(providerAgency) && (providerAgency != null)) {
					sb.append("/"+providerAgency+","+providerId+"/");
				} else {
					sb.append("/"+providerId+"/");
				}
			} else {
				sb.append("/all/");
			}
		}


		
		if(query.getFirstNObservations() != null) {
			appendParam(firstAppend, "firstNObservations", query.getFirstNObservations(), sb);
			firstAppend = false;
		}
		if(query.getLastNObservations() != null) {
			appendParam(firstAppend, "lastNObservations", query.getLastNObservations(), sb);
			firstAppend = false;
		}
		if(query.getDataQueryDetail() != null && query.getDataQueryDetail() != DATA_QUERY_DETAIL.FULL) {
			appendParam(firstAppend, "detail", query.getDataQueryDetail().getRestParam(), sb);
			firstAppend = false;
		}
		if(dateFrom != null) {
			appendParam(firstAppend, "startPeriod", DateUtil.formatDate(dateFrom), sb);
			firstAppend = false;
		}
		if(dateTo != null) {
			appendParam(firstAppend, "endPeriod", DateUtil.formatDate(dateTo), sb);
			firstAppend = false;
		}
		if(query.getLastUpdatedDate() != null) {
			appendParam(firstAppend, "updatedAfter", query.getLastUpdatedDate(), sb);
			firstAppend = false;
		}
		return sb.toString();
	}

	private static void appendMaintainable(StringBuilder sb, MaintainableBean maint, String concat) {
		sb.append(maint.getAgencyId());
		sb.append(concat);
		sb.append(maint.getId());
		sb.append(concat);
		sb.append(maint.getVersion());
		sb.append("/");
	}
	
	private static void appendParam(boolean firstAppend, String param, Object value, StringBuilder sb) {
		if(firstAppend) {
			sb.append("?");
		} else {
			sb.append("&");
		}
		sb.append(param+"="+value);
	}
}
