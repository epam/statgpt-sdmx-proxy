package io.sdmx.fusion.service.api.engine;

import jakarta.ws.rs.core.Response.ResponseBuilder;

/**
 * Functional Interface to apply lambda expressions as used in web services, this is different to a Function in that it forces a thowable to be caught
 * This is always be applied with a ResponseBuilder, and returned type of T
 *
 * @param <T> - The return type of this function
 */
@FunctionalInterface
public interface FusionWebServiceExecutor<T> {
	T apply(ResponseBuilder t) throws Throwable;
}
