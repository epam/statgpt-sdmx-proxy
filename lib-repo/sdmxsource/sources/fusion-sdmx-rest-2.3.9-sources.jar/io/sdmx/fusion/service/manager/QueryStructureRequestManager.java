package io.sdmx.fusion.service.manager;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import io.sdmx.api.application.ApplicationCacheInfoManager;
import io.sdmx.api.date.TIME_FORMAT;
import io.sdmx.api.exception.SdmxNoResultsException;
import io.sdmx.api.exception.SdmxNotAcceptableException;
import io.sdmx.api.http.HTTP_METHOD;
import io.sdmx.api.http.IResponse;
import io.sdmx.api.http.Request;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.io.WriteableDataLocationFactory;
import io.sdmx.api.lang.LanguageInformationManager;
import io.sdmx.api.process.IProcessWithArgument;
import io.sdmx.api.sdmx.constants.DATASET_ACTION;
import io.sdmx.api.sdmx.constants.SDMX_SCHEMA;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.constants.STRUCTURE_OUTPUT_FORMAT;
import io.sdmx.api.sdmx.constants.STRUCTURE_QUERY_DETAIL;
import io.sdmx.api.sdmx.manager.output.StructureWriterManager;
import io.sdmx.api.sdmx.manager.structure.CrossReferencingRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.IQueryStructureRequestManager;
import io.sdmx.api.sdmx.manager.structure.ISdmxBeanRestRetrievalManager;
import io.sdmx.api.sdmx.manager.structure.StrucutreInformationManager;
import io.sdmx.api.sdmx.model.beans.SdmxBeans;
import io.sdmx.api.sdmx.model.beans.base.AnnotableBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNAbsolute;
import io.sdmx.api.sdmx.model.beans.base.MaintainableBean;
import io.sdmx.api.sdmx.model.beans.categoryscheme.CategorisationBean;
import io.sdmx.api.sdmx.model.beans.codelist.CodelistBean;
import io.sdmx.api.sdmx.model.beans.registry.RegistrationBean;
import io.sdmx.api.sdmx.model.format.StructureFormat;
import io.sdmx.api.sdmx.model.mutable.codelist.CodeMutableBean;
import io.sdmx.api.sdmx.model.mutable.codelist.CodelistMutableBean;
import io.sdmx.api.sdmx.model.query.IStructureQueryRequest;
import io.sdmx.core.sdmx.api.manager.structure.ExternalReferenceManager;
import io.sdmx.core.sdmx.format.SdmxStructureFormat;
import io.sdmx.fusion.service.util.RequestManagerUtil;
import io.sdmx.im.beans.container.SdmxBeansImpl;
import io.sdmx.im.mutable.codelist.CodeMutableBeanImpl;
import io.sdmx.im.mutable.codelist.CodelistMutableBeanImpl;
import io.sdmx.utils.core.io.StreamUtil;
import io.sdmx.utils.core.thread.ThreadLocalUtil;
import io.sdmx.utils.sdmx.xs.URN;

public class QueryStructureRequestManager implements IQueryStructureRequestManager {
    private static final Logger LOG = LoggerFactory.getLogger(QueryStructureRequestManager.class);

	private final IURNAbsolute<CodelistBean> LANG_REF = URN.builder("METATECH", "LANG", "1.0").buildAbsolute(CodelistBean.class);
	private final IURNAbsolute<CodelistBean> FREQ_REF = URN.builder("METATECH", "FREQ", "1.0").buildAbsolute(CodelistBean.class);

	@Autowired
	private StructureWriterManager structureWritingManager;

	@Autowired
	private ExternalReferenceManager externalReferenceManager;

	@Autowired
	private WriteableDataLocationFactory writeableDataLocationFactory;

	@Autowired(required=false)
	private ApplicationCacheInfoManager cacheInfoManager;

	private CrossReferencingRetrievalManager crossReferencingRetrievalManager;

	private ISdmxBeanRestRetrievalManager beanRetrievalManager;
	private StrucutreInformationManager infoManager;

	@Autowired(required=false)
	private LanguageInformationManager langInformationManager;

	public QueryStructureRequestManager(CrossReferencingRetrievalManager crossReferencingRetrievalManager,
										ISdmxBeanRestRetrievalManager beanRetrievalManager,
										StrucutreInformationManager infoManager) {
		this.crossReferencingRetrievalManager = crossReferencingRetrievalManager;
		this.beanRetrievalManager = beanRetrievalManager;
		this.infoManager = infoManager;
	}
	
	@Override
	public void processQuery(IStructureQueryRequest structureQueryRequest) {
		try {
			processQueryInternal(structureQueryRequest);
		} finally {
			ThreadLocalUtil.clearFromThread(AnnotableBean.INCLUDE_INTERNAL_KEY);
		}
	}
	
	private void processQueryInternal(IStructureQueryRequest structureQueryRequest) {
		if(beanRetrievalManager == null) {
			LOG.error("processQueryStructureRequest received, no beanRetrievalManager is set - query can not be processed");
			throw new IllegalArgumentException("Structure Queries are not supported on this interface");
		}

		if(structureQueryRequest.getStructureQueryRequest() != null) {
			IURN<?> structureReference = structureQueryRequest.getStructureQueryRequest().getStructureReference();
			if(structureReference != null && !structureReference.isWildcard()) {
				if(LANG_REF.isMatch(structureReference) && langInformationManager != null) {
					processInternalLangaugeCodelistRequest(structureQueryRequest);
					return;
				} else if(FREQ_REF.isMatch(structureReference) && langInformationManager != null) {
					processInternalFreqCodelistRequest(structureQueryRequest);
					return;
				}
			}
		}

		ISdmxBeanRestRetrievalManager beanRetrievalManager = this.beanRetrievalManager;

		LOG.debug("Process REST GET for Structures");
		SdmxBeans queryResult = beanRetrievalManager.getMaintainables(structureQueryRequest.getStructureQueryRequest());
		boolean resolveRefs= structureQueryRequest.getStructureQueryRequest().getStructureQueryMetadata().getStructureQueryDetail() == STRUCTURE_QUERY_DETAIL.FULL;

		if(resolveRefs && externalReferenceManager != null) {
			LOG.debug("Resolve External References");
			externalReferenceManager.resolveExternalReferences(queryResult, true, true);
		}
		if(structureQueryRequest.getRequest().getMethod() == HTTP_METHOD.DELETE) {
			LOG.debug("Method Delete");
			queryResult.setAction(DATASET_ACTION.DELETE);
			processResult(queryResult, structureQueryRequest);

		} else {
			// FR-1009: If there are any registrations, remove them. It is non-sensical to return Structures and Registrations in a single SDMX message
			Set<RegistrationBean> registrations = queryResult.getRegistrations();
			if (registrations != null && !registrations.isEmpty()) {
				for (RegistrationBean registrationBean : registrations) {
					queryResult.removeMaintainable(registrationBean);
				}
			}

			try {
				String includeAllAnnotations = structureQueryRequest.getRequest().getParameter("includeAllAnnotations");
				if(includeAllAnnotations != null && includeAllAnnotations.equalsIgnoreCase("true")) {
					ThreadLocalUtil.storeOnThread(AnnotableBean.INCLUDE_INTERNAL_KEY, Boolean.TRUE);
				}
				processResult(queryResult, structureQueryRequest);
			} finally {
				ThreadLocalUtil.clearFromThread(AnnotableBean.INCLUDE_INTERNAL_KEY);
			}
		}
	}
	
	/**
	 * This is a codelist of locales whose values are derived from the locales that are stored in the available structural metadata
	 * @param structureQueryRequest
	 */
	private void processInternalLangaugeCodelistRequest(IStructureQueryRequest structureQueryRequest) {
		processInternalCodelist(LANG_REF, structureQueryRequest, (codelist) -> {
			codelist.addName("en", "Internal Language Codelist");
			Set<String> supportedLanguages = langInformationManager.getSupportedLanguages();
			for (String lang : supportedLanguages) {
				Locale loc = new Locale(lang);
				addCode(codelist, lang, lang, loc.getDisplayLanguage(loc));
			}
		});
	}
	
	/**
	 * This is a codelist of frequencies whose values are derived from the standard frequencies, taking into account H can mean Hourly or Half yearly depending on how the product is run
	 * @param structureQueryRequest
	 */
	private void processInternalFreqCodelistRequest(IStructureQueryRequest structureQueryRequest) {
		processInternalCodelist(FREQ_REF, structureQueryRequest, (codelist) -> {
			codelist.addName("en", "Internal Frequency Codelist");
			Set<String> processedCodeIds = new HashSet<>();
			for(TIME_FORMAT tf : TIME_FORMAT.values()) {
				if(processedCodeIds.add(tf.getFrequencyCodeId())) {
					addCode(codelist, tf.getFrequencyCodeId(), "en", tf.getReadableCode());
				}
			}
		});
	}
	
	private void addCode(CodelistMutableBean codelist, String id, String locale, String name) {
		CodeMutableBean code = new CodeMutableBeanImpl();
		code.setId(id);
		code.addName(locale, name);
		codelist.addItem(code);
	}
	
	private void processInternalCodelist(IURNAbsolute<CodelistBean> sRef,
										IStructureQueryRequest structureQueryRequest,
										IProcessWithArgument<CodelistMutableBean> populator) {
		String agencyId = sRef.getAgencyId();
		String maintainableId = sRef.getMaintainableId();
		String version = sRef.getVersion().toString();
		CodelistMutableBean codelist = new CodelistMutableBeanImpl();
		codelist.setId(maintainableId);
		codelist.setAgencyId(agencyId);
		codelist.setVersion(version);
		populator.runProcess(codelist);
		SdmxBeans beans = new SdmxBeansImpl();
		beans.addIdentifiable(codelist.getImmutableInstance());
		processResult(beans, structureQueryRequest);
	}

	protected void processResult(SdmxBeans queryResult, IStructureQueryRequest structureQueryRequest) {
		if(queryResult == null || queryResult.getAllMaintainables().isEmpty()) {
			throw new SdmxNoResultsException("No Results Found");
		}
		StructureFormat structureFormat = structureQueryRequest.getFormat();
		boolean isFormatDefaulted = structureQueryRequest.wasFormatDefaulted();
		if(structureFormat == null) {
			isFormatDefaulted = true;
			structureFormat = new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V21_STRUCTURE_DOCUMENT);
		}

		if(structureQueryRequest.isReturnAsRegistryResponse()) {
			structureFormat = new SdmxStructureFormat(STRUCTURE_OUTPUT_FORMAT.SDMX_V21_REGISTRY_SUBMIT_DOCUMENT);
		}
		if(structureFormat.getSdmxOutputFormat() != null) {
			SDMX_SCHEMA schemaVersion = structureFormat.getSdmxOutputFormat().getOutputVersion();
			if(schemaVersion == SDMX_SCHEMA.VERSION_ONE || schemaVersion == SDMX_SCHEMA.VERSION_TWO) {
				//FOR VERSION ONE OR TWO QUERIES - RELINK THE CATEGORISATIONS
				for(MaintainableBean maint : queryResult.getAllMaintainables()) {
					if(!maint.isExternalReference()) {
						if(maint.getStructureType() == SDMX_STRUCTURE_TYPE.DATAFLOW || maint.getStructureType() == SDMX_STRUCTURE_TYPE.CATEGORY_SCHEME) {
							for(CategorisationBean xsRefcat : crossReferencingRetrievalManager.getCrossReferencingStructures(maint.getURN(), false, CategorisationBean.class)) {
								queryResult.addIdentifiable(xsRefcat);
							}
						}
					}
				}
			}
		}

		//This code was put in to fix FR-2562, the problem is if the user requests a structure such as a ValidationScheme
				//which can only be represented in JSON, and if the request does not specify an output format, then the response should be the
				//default format for the structure type requested.  This fix means that now the user gets an error, as we do not have
				//a concept of if the response format was explicitally requested, or defaulted
//				boolean anySupported = false;
//				for(SDMX_STRUCTURE_TYPE st : queryResult.getDistinctTypes()) {
//					if(structureWritingManager.isSupported(st, structureFormat)) {
//						anySupported = true;
//					}
//				}
//				if(!anySupported) {
//					//FR-2562 Requesting an Excel file via the Web Service for an unsupported type creates an invalid XLSX file
//					Set<SDMX_STRUCTURE_TYPE> uniqueTypes = queryResult.getDistinctTypes();
//					StringBuilder error = new StringBuilder();
//					error.append("structure");
//					if(uniqueTypes.size() > 1) {
//						error.append("s");
//					}
//					String concat = " '";
//					for(SDMX_STRUCTURE_TYPE st : uniqueTypes) {
//						error.append(concat+st.getType());
//						concat = ", ";
//					}
//					error.append("' in format "+structureFormat.getFormatDetails().getFormatAsString());
//					throw new SdmxNotImplementedException(error);
//				}

		WriteableDataLocation dataLocation = writeableDataLocationFactory.getTemporaryWriteableDataLocation();
		try {
			if(processHttp304(structureQueryRequest.getRequest(), structureQueryRequest.getResponse(), queryResult)) {
				return;
			}
			if(queryResult.getAllMaintainables().isEmpty()) {
				throw new SdmxNoResultsException("No Results Found");
			}
			StructureFormat toWriteFormat = structureWritingManager.getSupported(queryResult, structureFormat);
			if(toWriteFormat == null || (!toWriteFormat.equals(structureFormat) && !isFormatDefaulted)) {
				//The user explicitly requested one format but we are unable to satisfy that request because none of the structures
				//are compatible with that format
				throw new SdmxNotAcceptableException(structureFormat.getFormatDetails().getFormatAsString() +" is not supported as an output format by any of the structures in the query response");
			}
			structureQueryRequest.getResponse().setContentType(toWriteFormat.getFormatDetails().getMimeType());
			structureWritingManager.writeStructures(queryResult, toWriteFormat, dataLocation.getOutputStream());
			//write the response
			StreamUtil.copyStream(dataLocation.getInputStream(), structureQueryRequest.getResponse().getOutputStream(), false);
		} finally {
			dataLocation.close();
		}
	}

	private boolean processHttp304(Request request, IResponse response, SdmxBeans queryResult) {
		if(cacheInfoManager != null && cacheInfoManager.isNotModifiedEanbled()) {
			return RequestManagerUtil.processIfModifiedSince(infoManager, request, response, queryResult.getAllMaintainables() ) ||
					RequestManagerUtil.processEtag(infoManager, request, response, queryResult.getAllMaintainables() );
		}
		return false;
    }

	

}
