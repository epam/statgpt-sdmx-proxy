package io.sdmx.fusion.service.service.security;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import io.sdmx.api.exception.SdmxException;
import io.sdmx.api.service.security.IForgottenDetailsService;
import io.sdmx.utils.core.application.SingletonStore;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Response;

@Path("/user")
public class ForgottenDetailsService {

	private IForgottenDetailsService forgottenDetailsService = SingletonStore.getSingleton(IForgottenDetailsService.class);
		
	@GET
	@Produces("application/json")
	@Path("/forgotPassword")
	public Response sendReminderByUsername(
				@QueryParam("productName") final String productName,
				@QueryParam("username") final String username,
				@QueryParam("redirectURL") final String redirectURL) {
		try {
			forgottenDetailsService.emailResetPassword(productName, username, redirectURL);
			return createResponse();
		} catch(Throwable th) {
			return createResponse(th);
		}
	}
	
	@GET
	@Produces("application/json")
	@Path("/forgotPasswordGivenEmail")
	public Response sendReminderByEmail(
				@QueryParam("productName") final String productName,
				@QueryParam("email") final String email,
				@QueryParam("redirectURL") final String redirectURL) {
		try {
			forgottenDetailsService.emailResetPasswordGivenEmail(productName, email, redirectURL);
			return createResponse();
		} catch(Throwable th) {
			return createResponse(th);
		}
	}
	
	@GET
	@Produces("application/json")
	@Path("/forgotUsername")
	public Response sendUsernameReminderByEmail(
			@QueryParam("productName") final String productName,
			@QueryParam("email") final String email) {
		try {
			forgottenDetailsService.emailUsername(productName, email);
			return createResponse();
		} catch(Throwable th) {
			return createResponse(th);
		}
	}
	
	@GET
	@Produces("application/json")
	@Path("/resetPassword")
	public Response resetPassword(@QueryParam("uid") final String verificationGuid,
										 @QueryParam("password") final String newPassword,
										 @QueryParam("passwordConfirm") final String passwordConfirm) {
		try {
			forgottenDetailsService.resetPassword(verificationGuid, newPassword, passwordConfirm);
			return createResponse();
		} catch(Throwable th) {
			return createResponse(th);
		}
	}
	
    @GET
    @Produces("application/json")
    @Path("/resetPasswordRequest")
    public Response requestededResetLinkByEmail(@QueryParam("userCredentials") final String userCredentials) {
    	try {
    		// Determine if the information supplied is an email address or a username
    		if (userCredentials.contains("@")) {
    			forgottenDetailsService.emailResetPasswordGivenEmail(null, userCredentials, null);
    		} else {
    			forgottenDetailsService.emailResetPassword(null, userCredentials, null);
    		}
    		return createResponse();
    	} catch(Throwable th) {
    		return createResponse(th);
    	}
    }
	
	private Response createResponse() {
		return createResponse(null);
	}
	
	private Response createResponse(Throwable th) {
		JSONObject json = new JSONObject();
		if(th != null) {
			try {
				if(th instanceof SdmxException) {
					SdmxException ex = (SdmxException)th;
					json.put("errorcode", ex.getSdmxErrorCode().getClientErrorCode());
					
				}
				json.put("error", th.getMessage());
			} catch (JSONException e) {
				throw new RuntimeException(e);
			}
		}
		return Response.ok(json.toString()).build();
	}
}