package io.sdmx.fusion.service.model.request;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.api.http.ClientRequest;
import io.sdmx.fusion.service.util.ServletUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import jakarta.servlet.http.HttpServletRequest;

public class ClientRequestImpl implements ClientRequest {
	private static final Logger LOG = LoggerFactory.getLogger(ClientRequestImpl.class);
	
	private static final long serialVersionUID = -5056158834884190901L;
	private int serverPort;
	private String scheme;
	private String serverName;
	private String serverContext;
	private String clientIp;
	private String pathInfo;
	private String servletPath;
	private Locale locale;
	private HttpServletRequest request;

	public ClientRequestImpl(HttpServletRequest request) {
		if(ObjectUtil.validString(request.getParameter("locale"))) {
			String filterLocale = request.getParameter("locale");
			locale = Locale.forLanguageTag(filterLocale);
		} else if(request.getSession().getAttribute("locale") != null){
			locale = Locale.forLanguageTag((String)request.getSession().getAttribute("locale"));
		} else {
			locale = request.getLocale();
		}
		this.request = request;
		serverName = request.getServerName();        //example: localhost
		serverPort = request.getServerPort();  			//example: 8080
		serverContext = request.getContextPath();    //example: /FusionRegistry
		
		clientIp = ServletUtil.obtainIpAddress(request);
		
		servletPath = request.getServletPath();	    //example: /ws/servletService
		pathInfo = request.getPathInfo();            //example: /agencyScheme/ALL/ALL/ALL
		scheme = request.getScheme();				//example: http/https/ftp
		
		if(LOG.isDebugEnabled()) {
			LOG.debug("***Client Request Properties****");
			LOG.debug("scheme "+scheme);
			LOG.debug("serverPort "+serverPort);
			LOG.debug("serverName "+serverName);
			LOG.debug("serverContext "+serverContext);
			LOG.debug("clientIp "+clientIp);
			LOG.debug("pathInfo "+pathInfo);
			LOG.debug("servletPath "+servletPath);
			LOG.debug("locale "+locale);
			
			LOG.debug("***Client Request Getters****");
			LOG.debug("getRequestPath(true) "+getRequestPath(true));
			LOG.debug("getRequestPath(false) "+getRequestPath(false));
			LOG.debug("getServerUrl "+getServerUrl());
		}
	}
	
	public HttpServletRequest getHttpServletRequest() {
		return request;
	}

	@Override
	public Locale getLocale() {
		return locale;
	}

	@Override
	public String getServerUrl() {
		return scheme+"://"+serverName + ":" + serverPort + serverContext;
	}
	
	@Override
	public String getServletPath() {
		return servletPath;
	}

	@Override
	public String getRequestPath(boolean includePath) {
		String requestPath = getServerUrl()+servletPath;
		if(includePath && pathInfo != null) {
			requestPath += pathInfo;
		}
		return requestPath;
	}
	
	@Override
	public String getPathInfo() {
		return pathInfo;
	}

	@Override
	public int getServerPort() {
		return serverPort;
	}

	@Override
	public String getServerName() {
		return serverName;
	}

	@Override
	public String getServerContext() {
		return serverContext;
	}

	@Override
	public String getScheme() {
		return scheme;
	}

	@Override
	public String getClientIP() {
		return clientIp;
	}
}
