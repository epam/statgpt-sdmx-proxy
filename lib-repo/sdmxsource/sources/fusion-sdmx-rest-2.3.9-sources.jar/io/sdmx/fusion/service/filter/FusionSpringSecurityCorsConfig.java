package io.sdmx.fusion.service.filter;

import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;

import io.sdmx.api.cache.Cache;
import io.sdmx.api.http.CORSBase;
import io.sdmx.api.http.CORSSettingsRetrievalManager;
import io.sdmx.api.notification.Listener;
import io.sdmx.utils.core.collection.CollectionUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import jakarta.servlet.http.HttpServletRequest;

public class FusionSpringSecurityCorsConfig implements Listener<List<CORSBase>>, CorsConfigurationSource, Cache {

	private static final Logger LOG = LoggerFactory.getLogger(FusionSpringSecurityCorsConfig.class);

	private CORSSettingsRetrievalManager corsManager;
	private Map<String, CORSBase> domainMap;

	public FusionSpringSecurityCorsConfig(CORSSettingsRetrievalManager corsManager) {
		this.corsManager = corsManager;
		rebuildDomainMap(corsManager.getCORSSettings());
		corsManager.registerListener(this);
	}

	@Override
	public CorsConfiguration getCorsConfiguration(HttpServletRequest request) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Request Received");

			Enumeration<String> names = request.getHeaderNames();

			while (names.hasMoreElements()) {
				String name = names.nextElement();
				String value = request.getHeader(name);

				LOG.debug(name + ": " + value);
			}
		}
		
		if (domainMap == null) {
			rebuildDomainMap(corsManager.getCORSSettings());
		}

		// prob want to use a UrlBasedCorsConfigurationSource
		//		CorsConfiguration configuration = new CorsConfiguration();
		//		configuration.setAllowedOrigins(ImmutableList.of("*"));
		//		configuration.setAllowedMethods(ImmutableList.of("*"));
		//		configuration.setAllowCredentials(true);
		//		configuration.setAllowedHeaders(ImmutableList.of("*"));
		//		return configuration;

		//		// prob want to use a UrlBasedCorsConfigurationSource

		CorsConfiguration configuration = new CorsConfiguration();
		String origin = request.getHeader("Origin");

		if (ObjectUtil.validString(origin)) {
			CORSBase corsEntry = domainMap.get(origin.toLowerCase());

			if (corsEntry == null) {
				corsEntry = domainMap.get("*");
			}

			if (corsEntry != null) {
				configuration.setAllowedOrigins(CollectionUtil.getImmutableList(corsEntry.getUrl()));
				configuration.setAllowedMethods(Collections.unmodifiableList(corsEntry.getMethods()));
				configuration.setAllowCredentials(corsEntry.getAllowCreds());
				configuration.setAllowedHeaders(Collections.unmodifiableList(corsEntry.getHeaders()));
				configuration.setExposedHeaders(corsEntry.getExposedHeaders());
				configuration.setMaxAge(Long.valueOf(1800));
			}
		}

		return configuration;
	}

	@Override
	public void invoke(List<CORSBase> settings) {
		rebuildDomainMap(settings);
	}

	private void rebuildDomainMap(List<CORSBase> settings) {
		Map<String, CORSBase> newDomainMap = new HashMap<>();

		for(CORSBase entry : settings) {
			newDomainMap.put(entry.getUrl().toLowerCase(), entry);
		}
		this.domainMap = newDomainMap;
	}

	@Override
	public void clearCache() {
		domainMap = null;
	}

}
