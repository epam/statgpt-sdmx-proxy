package io.sdmx.fusion.service.manager;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.io.WriteableDataLocation;
import io.sdmx.api.io.WriteableDataLocationFactory;
import io.sdmx.api.sdmx.constants.MESSAGE_TYPE;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.ISDMXStructureType;
import io.sdmx.api.sdmx.model.beans.base.IMetadataProviderBean;
import io.sdmx.api.sdmx.model.beans.base.IURN;
import io.sdmx.api.sdmx.model.beans.base.IURNMaintainable;
import io.sdmx.api.sdmx.model.beans.base.ItemSchemeBean;
import io.sdmx.api.sdmx.model.beans.metadatastructure.MetadataFlowBean;
import io.sdmx.api.sdmx.model.beans.reference.ICrossReferenceBeanBase;
import io.sdmx.api.sdmx.model.beans.refmetadata.IReportedMetadataSetBean;
import io.sdmx.core.sdmx.api.manager.metadata.IReferenceMetadataReaderManager;
import io.sdmx.core.structure.api.manager.IMetadataRetrievalManager;
import io.sdmx.fusion.service.util.SDMXRestQueryUtil;
import io.sdmx.utils.core.application.SingletonStore;
import io.sdmx.utils.core.io.SdmxSourceWriteableDataLocationFactory;
import io.sdmx.utils.http.api.engine.IHTTPQueryEngine;
import io.sdmx.utils.http.api.model.IAuthentication;
import io.sdmx.utils.http.api.model.IHTTPResponse;
import io.sdmx.utils.http.model.RESTRequest;
import io.sdmx.utils.sdmx.structure.SdmxMessageUtil;

/**
 * Converts references to web service queries against a version 2.0 SDMX API
 */
public class WsMetadataRetrievalManager implements IMetadataRetrievalManager {
	private String baseURL;
	private IAuthentication authentication;
	private IHTTPQueryEngine http;
	private IReferenceMetadataReaderManager metadataReaderManager;
	
	/**
	 * @param authentication nullable, if provided will use to authenticate the user with the end service
	 * @param baseURL required - the entry point to the SDMX web service
	 * @param http - the query engine
	 * @param metadataReaderManager - to parse the response message
	 */
	public WsMetadataRetrievalManager(IAuthentication authentication, String baseURL, IHTTPQueryEngine http, IReferenceMetadataReaderManager metadataReaderManager) {
		this.authentication = authentication;
		if(!baseURL.endsWith("/")) {
			baseURL += "/";
		}
		this.baseURL = baseURL;
		this.http = http;
		this.metadataReaderManager = metadataReaderManager;
	}

	@Override
	/**
	 * Syntax : protocol://ws-entry-point/metadata/metadataset/{providerID}/{metadatasetID}/{version}?{detail}
	 * <br/>
	 * Parameters:
	 * <ol>
	 *   <li><b>providerID</b> deault(*) -> The id of the data provider who maintains the Metadata Set. It is possible to set more than one id, using , as separator (e.g. UK1,UK2)   </li>
	 *   <li><b>metadatasetID</b> deault(*) ->  </li>
	 *   <li><b>version</b> deault(*) -> </li>
	 *   <li><b>detail</b> deault(*) ->  </li>
	 * </ol>
	 * 
	 * Examples:
	 * <ul>
	 *  <li>https://ws-entry-point/metadata/metadataset/ECB/QUALITY_REPORT/1.0.0</li>
	 *  <li>https://ws-entry-point/metadata/metadataset/ECB/?detail=allstubs</li>
	 * </ul>
	 */
	public Set<IReportedMetadataSetBean> findByMetadataSet(IURN<IReportedMetadataSetBean> ref, SdmxDate asOf) {
		StringBuilder postfix = getStringBuilder(ref, "metadataset");
		if(asOf != null) {
			postfix.append("?asOf="+asOf.getDateInSdmxFormat());
		}
		return runQuery(postfix.toString());
	}

	@Override
	/**
	 * These queries enable clients to request all metadata sets which are reported against one or more structures, as such the syntax for defining which structures to find metadata for follows the same syntax as the structure resource.
	 * <p/>
	 * Syntax : protocol://ws-entry-point/metadata/structure/{artefactType}/{agencyID}/{resourceID}/{version}?{detail}
	 * <p/>
	 * Parameters:
	 * <ol>
	 *   <li><b>artefactType</b> deault(*) -> One of the following types: datastructure, metadatastructure, categoryscheme, conceptscheme, codelist, hierarchy, hierarchyassociation, valuelist, organisationscheme, agencyscheme, dataproviderscheme, dataconsumerscheme, organisationunitscheme, dataflow, metadataflow, reportingtaxonomy, provisionagreement, structuremap, representationmap, conceptschememap,categoryschememap, organisationschememap, process, categorisation, dataconstraint, metadataconstraint, transformationscheme, rulesetscheme, userdefinedoperatorscheme, customtypescheme, namepersonalisationscheme, vtlmappingscheme   </li>
	 *   <li><b>agencyID</b> deault(*) ->  The agency maintaining the artefact to be returned. It is possible to set more than one agency, using , as separator (e.g. BIS,ECB).</li>
	 *   <li><b>resourceID</b> deault(*) -> The id of the artefact to be returned. It is possible to set more than one id, using , as separator (e.g. CL_FREQ,CL_CONF_STATUS).</li>
	 *   <li><b>version</b> deault(*) ->  The version of the artefact to be returned. It is possible to set more than one version, using , as separator (e.g. 1.0.0,2.1.7).</li>
	 *   <li><b>detail</b> deault(*) -> This attribute specifies the desired amount of information to be returned. For example, it is possible to instruct the web service to return only basic information about the metadataset (i.e.: id, dataprovider id, version and name). Most notably, metadata attributes of a metadataset will not be returned Possible values are: (1) full: all available information for all returned metadatasets should be returned. (2) allstubs: all returned metadatasets should be returned as stubs, i.e. only containing identification information and the metadataset' name. </li>
	 * </ol>
	 * 
	 * Examples:
	 * <ul>
	 *  <li>https://ws-entry-point/metadata/datastructure/ECB/ECB_EXR1/1.0.0references=children&detail=referencepartial</li>
	 *  <li>https://ws-entry-point/metadata/datastructure/ECB/ECB_EXR1</li>
	 * </ul>
	 */
	public Set<IReportedMetadataSetBean> findByStructure(IURN<?> urn, SdmxDate asOf) {
		String artefactType = "*";
		boolean isItemScheme = false;
		boolean isMaintRef = true;
		if(urn != null && urn.getSdmxStructure() != SDMX_STRUCTURE_TYPE.ANY) {
		    ISDMXStructureType maintainableStructureType =  urn.getMaintainableURN().getStructureType();
		    isItemScheme = maintainableStructureType.matchesType(ItemSchemeBean.class);
		    isMaintRef = urn.getStructureType().isMaintainable();
			artefactType = maintainableStructureType.getUrnClass().toLowerCase();
		}
		
		StringBuilder postfix = getStringBuilder(urn, "structure/"+artefactType);
		if(!isMaintRef && isItemScheme) {
		    postfix.append("/"+urn.getFullIdentifiableId());
        }
		if(asOf != null) {
			postfix.append("?asOf="+asOf.getDateInSdmxFormat());
		}
		Set<IReportedMetadataSetBean> response = runQuery(postfix.toString());
		if(!isMaintRef && !isItemScheme) {
		    Set<IReportedMetadataSetBean> filteredResponse = new HashSet<>(response.size());
		    for(IReportedMetadataSetBean mds :response) {
		        if(isMatch(mds, urn)) {
		            filteredResponse.add(mds);
		        }
		    }
		    response = filteredResponse;
		}
		return response;
	}
	
	private boolean isMatch(IReportedMetadataSetBean mds, IURN<?> target) {
	    for(ICrossReferenceBeanBase xs : mds.getTargets()) {
	        if(xs.getReference().isMatch(target)) {
	            return true;
	        }
	    }
	    return false;
	}

	@Override
	public IReportedMetadataSetBean getMetadata(IURNMaintainable<IReportedMetadataSetBean> urn, SdmxDate asOf) {
		if(urn == null) {
			throw new SdmxSemmanticException("getMetadata requires IURN");
		}
		Set<IReportedMetadataSetBean> metadata = findByMetadataSet(urn, asOf);
		return metadata.size() > 0 ? (IReportedMetadataSetBean) metadata.toArray()[0] : null;
	}

	@Override
	/**
	 * These queries enable clients to find metadatasets by the collection (metadataflow), optionally filtered by the metadata provider.
	 * <p/>
	 * Syntax :protocol://ws-entry-point/metadata/metadataflow/{flowAgencyID}/{flowID}/{flowVersion}/{providerRef}?{detail}
	 * <p/>
	 * Parameters:
	 * <ol>
	 *   <li><b>flowAgencyID</b> deault(*) -> The agency maintaining the metadataflow for which metadata have been reported.  </li>
	 *   <li><b>flowID</b> deault(*) -> The id of the metadataflow for which metadata have been reported.</li>
	 *   <li><b>flowVersion</b> deault(*) ->The version of the metadataflow for which data have been reported.</li>
	 *   <li><b>providerRef</b> default(*) -> A string identifying the metadata provider. The syntax is agency id, provider id, separated by a ",". For example: AGENCY_ID,PROVIDER_ID. In case the string only contains one out of these 2 elements, it is considered to be the provider id, i.e. all,PROVIDER_ID.
	 *                                        The provider of the data (or metadata) to be retrieved. If not supplied, the returned message will contain data (or metadata) provided by any provider. Its a common use case in SDMX-based web services that the provider id is sufficient to uniquely identify a data provider. Should this not be the case, the agency can be used, in conjunction with the provider id, in order to uniquely identify a data provider. The OR operator is supported using the + character. For example, the following value can be used to indicate that the metadataset should be provided by the Swiss National Bank (CH2) or Central Bank of Norway (NO2): CH2+NO2.
	 *   <li><b>detail</b> deault(*) -> This attribute specifies the desired amount of information to be returned. For example, it is possible to instruct the web service to return only basic information about the metadataset (i.e.: id, dataprovider id, version and name). Most notably, metadata attributes of a metadataset will not be returned Possible values are: (1) full: all available information for all returned metadatasets should be returned. (2) allstubs: all returned metadatasets should be returned as stubs, i.e. only containing identification information and the metadataset' name. </li>
	 * </ol>
	 * 
	 * Examples:
	 * <ul>
	 *  <li>https://ws-entry-point/metadata/metadataflow/ECB/METHODOLOGY/* /FR2</li>
	 *  <li>https://ws-entry-point/metadata/metadataflow/* /METHODOLOGY/+/?detail=allstubs</li>
	 * </ul>
	 */
	public Set<IReportedMetadataSetBean> findByMetadataflow(IURN<MetadataFlowBean> ref, IURN<IMetadataProviderBean> providerRef, SdmxDate asOf) {
		StringBuilder postfix = getStringBuilder(ref, "metadataflow");
		if(providerRef != null) {
			postfix.append("/");
			if(providerRef.getAgencyId() != null) {
				postfix.append(providerRef.getAgencyId()+",");
			}
			postfix.append(providerRef.getFullIdentifiableId().replaceAll(",", "+"));
		}
		if(asOf != null) {
			postfix.append("?asOf="+asOf.getDateInSdmxFormat());
		}
		return runQuery(postfix.toString());
	}

//
	/**
	 * Returns a string builder, pre-populated with /metadata/[resource]/[acy ids]/[ids]/[version]
	 * @param ref
	 * @param resource
	 * @return
	 */
	private StringBuilder getStringBuilder(IURN<?> ref, String resource) {
		StringBuilder postfix = new StringBuilder();
		postfix.append("metadata/"+resource);
		SDMXRestQueryUtil.buildMaintainablePath(ref, postfix, "*");
		postfix.append("/"+ref.getVersion().toString());

		return postfix;
	}
	
	private Set<IReportedMetadataSetBean> runQuery(String urlPostfix) {
		String url = baseURL + urlPostfix;
		WriteableDataLocationFactory wdlFactory = SingletonStore.getSingleton(WriteableDataLocationFactory.class);
		if(wdlFactory == null) {
			wdlFactory = new SdmxSourceWriteableDataLocationFactory();
			SingletonStore.registerInstance(wdlFactory);
		}
		WriteableDataLocation wdl = wdlFactory.getTemporaryWriteableDataLocation();
		try {
			RESTRequest request = new RESTRequest(null, url).setAuthentication(authentication);
			IHTTPResponse response = http.sendMessage(request, wdl.getOutputStream());
			if(response.getStatus() == 404) {
				return Collections.emptySet();
			}
			MESSAGE_TYPE messageType = SdmxMessageUtil.getMessageType(wdl);
			if(messageType == MESSAGE_TYPE.ERROR) {
				SdmxMessageUtil.parseSdmxErrorMessage(wdl);
				return Collections.emptySet();
			}
			return metadataReaderManager.parse(wdl).getReferenceMetadata();
		} finally {
			wdl.close();
		}
	}

}
