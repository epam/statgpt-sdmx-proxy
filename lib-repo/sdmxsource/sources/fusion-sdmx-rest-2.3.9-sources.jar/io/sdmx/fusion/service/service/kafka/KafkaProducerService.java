package io.sdmx.fusion.service.service.kafka;

import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Configurable;

import io.sdmx.api.service.kafka.IKafkaSettingsService;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;

/**
 * Provides access to public Kafka information
 */
@Configurable
@Path("/kafka")
public class KafkaProducerService extends AbstractRestService {

    private static final Logger LOG = LoggerFactory.getLogger(KafkaProducerService.class);

    private IKafkaSettingsService kafkaSettingsService = SingletonStore.getSingleton(IKafkaSettingsService.class);

    /**
     * Returns the producer status as a boolean:
     * {
     *   "Running" : true
     * }
     */
    @GET
    @Path("/producer/status/{id}")
    @Produces("application/json")
    public final Response getProducerStatus(final @PathParam("id") String producerId) {
        LOG.debug("getProducerStatus request");
        return super.performWebService(response -> {
            JSONObject returnObject = new JSONObject();
            returnObject.put("Running", kafkaSettingsService.getProducerStatus(producerId));
            return returnObject;
        });
    }
}
