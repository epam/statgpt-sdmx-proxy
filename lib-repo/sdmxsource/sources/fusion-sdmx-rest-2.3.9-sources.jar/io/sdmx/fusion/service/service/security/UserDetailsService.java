package io.sdmx.fusion.service.service.security;

import java.io.ByteArrayOutputStream;

import io.sdmx.api.service.security.IUserDetailsService;
import io.sdmx.fusion.service.service.AbstractRestService;
import io.sdmx.utils.core.application.SingletonStore;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.StreamingOutput;

/**
 * Service allowing authenticated user to find out who they are
 *
 */
@Path("/currentuser")
@Produces("application/json")
public class UserDetailsService extends AbstractRestService {

	private IUserDetailsService userDetailsService = SingletonStore.getSingleton(IUserDetailsService.class);

	@GET
	@Path("/details")
	/**
	 * Simple user details
	 * {
	  		"username": "root",
			"name": "root",
			"authenticated": true
	 * }
	 *
	 * @return
	 */
	public StreamingOutput whoAmI() {
		return output -> {
			try {
				userDetailsService.writeCurrentUserDetailsShort(output);
			} catch (Throwable th) {
				writeError(th, output);
			}
		};
	}

	@GET
	@Path("/user")
	/**
	 * Returns full user details:
	 * {
	 * 		{
				"isRoot": true,
				"isAdmin": true,
				"name": "root",
				"username": "root",
				"email": "root@fusionregistry.org",
				"modifyStatus": "loggedInWithModifyPermissions",
				"domains": [
					{
						"alias": "ROOT",
						"uri": "ROOT"
					}
				],
					"dataConsumers": [],
					"dataProviders": [],
					"roles": [],
					"agencies": [
					"urn:sdmx:org.sdmx.infomodel.base.Agency=SECURITY_ADMIN"
				]
			}
	 * }
	 *
	 * @return
	 */
	public Response user() {
		return super.performWebService((response) -> {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			userDetailsService.writeCurrentUserDetailsFull(out);
			return out;
	    });
	}
	

	@GET
	@Path("/dataprovisions")
	/**
	 * @return an array of provision agreement URNs ["urn1", "urn2", "urn3", ...] that the user can report data for
	 */
	public Response getDataProvisions() {
		return super.performWebService((response) -> {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			userDetailsService.writeCurrentUserProvisions(out);
			return out;
	    });
	}
}

