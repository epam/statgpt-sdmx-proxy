package io.sdmx.fusion.service.builder;

import java.util.List;

import io.sdmx.api.date.SdmxDate;
import io.sdmx.api.exception.SdmxSemmanticException;
import io.sdmx.api.http.IRESTURL;
import io.sdmx.api.sdmx.constants.SDMX_STRUCTURE_TYPE;
import io.sdmx.api.sdmx.model.beans.base.DataProviderSchemeBean;
import io.sdmx.api.sdmx.model.beans.reference.StructureReferenceBean;
import io.sdmx.api.sdmx.model.query.RESTRegistrationQuery;
import io.sdmx.im.beans.reference.RESTRegistrationQueryImpl;
import io.sdmx.utils.core.date.SdmxDateImpl;
import io.sdmx.utils.sdmx.xs.StructureReferenceBeanImpl;

/**
 * Builds a RESTRegistrationQuery based on the SDMX V2 Web Service rules - defined in the version 3 SDMX standard
 */
public class RESTRegistrationQueryBuilder_V2 {
	private static final String UPDATED_BEFORE = "updatedBefore";
	private static final String UPDATED_AFTER = "updatedAfter";
	
	/**
	 * Builds from the path, expected to start from /registration/[rest of path] 
	 * @param restUrl expects the syntax to be
	 * 
	 * registration/[context]/[agency id]/[id]/[version]?[updatedBefore|updatedAfter]=[period]
	 * 
	 * Where context is either:
	 * id - by registration ID
	 * datastructure
	 * dataflow
	 * provider
	 * provision
	 * 
	 * [agency id] is not required when context is id 
	 * [version] is not required when context is id or provider
	 * 
	 * updatedBefore|updatedAfter are optional and mutually exclusive
	 * 
	 * @return
	 */
	public static RESTRegistrationQuery build(IRESTURL restUrl) {
		List<String> pathParts = restUrl.getPathParts();
		if(!pathParts.get(0).equals("registration")) {
			throw new SdmxSemmanticException("Registration query - 'registration' is required as first path part");
		}
		String context =  pathParts.size() < 2 ? "id" : pathParts.get(1);  //All by ID
		String agencyId = null;
		String maintId = null;
		String maintVersion = null;
		String identifiableId = null;
		String defaultValue = "*";
		
		SDMX_STRUCTURE_TYPE byStructure = null;
		switch(context) {
		case "datastructure" :
			byStructure = SDMX_STRUCTURE_TYPE.DSD;
			break;
		case "dataflow" :
			byStructure = SDMX_STRUCTURE_TYPE.DATAFLOW;
			break;
		case "provision" :
			byStructure = SDMX_STRUCTURE_TYPE.PROVISION_AGREEMENT;
			break;
		case "provider" :
			byStructure = SDMX_STRUCTURE_TYPE.DATA_PROVIDER;
			maintId = DataProviderSchemeBean.FIXED_ID;
			maintVersion = DataProviderSchemeBean.FIXED_VERSION;
			agencyId = getPathPart(pathParts, 2, defaultValue);
			identifiableId = getPathPart(pathParts, 3, defaultValue);
			break;
		case "id" :
			byStructure = SDMX_STRUCTURE_TYPE.REGISTRATION;
			maintId = getPathPart(pathParts, 2, defaultValue);
			break;
		default: throw new SdmxSemmanticException("Unsupported Registration Query '"+restUrl.getUrl()+"' unknown context '"+context+"': supported values are: 'id', 'datastructure', 'dataflow', 'provider'");		
		}
		if(byStructure  != SDMX_STRUCTURE_TYPE.REGISTRATION && byStructure.isMaintainable()) {
			agencyId = getPathPart(pathParts, 2, defaultValue);
			maintId = getPathPart(pathParts, 3, defaultValue);
			maintVersion = getPathPart(pathParts, 4, defaultValue);
		}
		String updatedBefore = restUrl.getParameter(UPDATED_BEFORE);
		String updatedAfter = restUrl.getParameter(UPDATED_AFTER);
			
		if(updatedBefore != null && updatedAfter != null) {
			throw new SdmxSemmanticException(UPDATED_BEFORE + " and " + UPDATED_AFTER +  " are mutually exclusive query parameters");
		}
		
		StructureReferenceBean structureReferenceBean = new StructureReferenceBeanImpl(agencyId, maintId, maintVersion, byStructure, identifiableId);
		SdmxDate updatedBeforeDate = updatedBefore == null ? null : new SdmxDateImpl(updatedBefore, true); //start of period 
		SdmxDate updatedAfterDate = updatedAfter == null ? null : new SdmxDateImpl(updatedAfter, false); //end of period
		return new RESTRegistrationQueryImpl(structureReferenceBean, updatedBeforeDate, updatedAfterDate);
	}
	
	private static String getPathPart(List<String> list, int idx, String defaultValue) {
		if(list.size() <= idx) {
			return defaultValue;
		}
		String value = list.get(idx);
		if(value == null || value.length() == 0) {
			return defaultValue;
		}
		return value;
	}
}
