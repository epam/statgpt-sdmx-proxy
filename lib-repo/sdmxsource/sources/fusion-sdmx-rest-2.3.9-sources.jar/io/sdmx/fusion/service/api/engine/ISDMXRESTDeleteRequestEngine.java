package io.sdmx.fusion.service.api.engine;

import io.sdmx.api.http.HTTP_METHOD;


/**
 * Processes a specific type of SDMX DELETE request (data, structures, metadata, schema)
 */
public interface ISDMXRESTDeleteRequestEngine extends ISDMXRESTRequestEngine {
	
	default HTTP_METHOD getSupportedMethod() {
		return HTTP_METHOD.DELETE;
	}
}
