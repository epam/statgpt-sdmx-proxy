package io.sdmx.fusion.service.model.servletresponse;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import io.sdmx.api.io.IGzipResponseWrapper;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletResponseWrapper;

public class GZIPResponseWrapper extends HttpServletResponseWrapper implements IGzipResponseWrapper {
	private HttpServletResponse origResponse;
	private ServletOutputStream stream;
	private PrintWriter writer;

	public GZIPResponseWrapper(HttpServletResponse response) {
		super(response);
		origResponse = response;
	}
	

	public HttpServletResponse getOrigResponse() {
		return origResponse;
	}

	public ServletOutputStream createOutputStream() throws IOException {
		return new GZIPResponseStream(origResponse);
	}

	public void finishResponse() {
		try {
			if (writer != null) {
				writer.close();
			} else {
				if (stream != null) {
					stream.close();
				}
			}
		} catch (IOException e) {
			// Do nothing.
		}
	}

	@Override
	public void flushBuffer() throws IOException {
		if(stream != null) {
			stream.flush();
		}
	}

	@Override
	public ServletOutputStream getOutputStream() throws IOException {
		if (writer != null) {
			throw new IllegalStateException("The method: getWriter() has already been invoked!");
		}

		if (stream == null) {
			stream = createOutputStream();
		}
		return stream;
	}

	@Override
	public PrintWriter getWriter() throws IOException {
		if (writer != null) {
			return writer;
		}

		if (stream != null) {
			throw new IllegalStateException("The method: getOutputStream() has already been invoked!");
		}

		stream = createOutputStream();
		writer = new PrintWriter(new OutputStreamWriter(stream, "UTF-8"));
		return writer;
	}

	@Override
	public void setContentLength(int length) {
		// No operations required here
	}
}