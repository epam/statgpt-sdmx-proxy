package io.sdmx.fusion.service.factory;

import io.sdmx.api.format.IResponseFormatFactory;
import io.sdmx.api.format.InformationFormat;
import io.sdmx.api.http.IResource;
import io.sdmx.api.http.Request;
import io.sdmx.api.sdmx.constants.SDMX_VERSION;
import io.sdmx.api.sdmx.manager.schema.ISchemaFormatManager;
import io.sdmx.api.sdmx.model.format.SchemaFormat;
import io.sdmx.core.sdmx.api.manager.metadata.IMetadataFormatManager;
import io.sdmx.core.sdmx.api.manager.structure.StructureFormatManager;
import io.sdmx.format.ml.model.SDMX_XSDSchemaFormat;

/**
 *  Handles response formats for structures, registrations, and schema queries
 */
public class SdmxStructureResponseFormatFactory implements IResponseFormatFactory {
	private StructureFormatManager structureFormatManager;
	private ISchemaFormatManager schemaFormatManager;
	private IMetadataFormatManager metadataFormatManager;
	
	public SdmxStructureResponseFormatFactory(StructureFormatManager structureFormatManager, 
			IMetadataFormatManager metadataFormatManager, ISchemaFormatManager schemaFormatManager) {
		this.structureFormatManager = structureFormatManager;
		this.schemaFormatManager = schemaFormatManager;
		this.metadataFormatManager = metadataFormatManager;
	}

	@Override
	public InformationFormat getInformationFormat(Request request, IResource resource) {
		switch(resource.getResource()) {
		case "structure" :
		case "registration" :
			return structureFormatManager.getFormat(request);
		case "schema" :
			SchemaFormat schemaFormat = schemaFormatManager.getFormat(request);
			if(schemaFormat == null) {
				schemaFormat = SDMX_XSDSchemaFormat.getInstance(SDMX_VERSION.V3_0);
			}
			return schemaFormat;
		case "metadata" :
			return metadataFormatManager.getFormat(request);
		default :
			return null;
		}
	}

	@Override
	public void setDefaultFormat(String resource, String vndHeader) throws IllegalArgumentException {
		//not implemented
	}

	@Override
	public String getDefaultFormat(String resource) {
		return null;
	}
	
	

}
