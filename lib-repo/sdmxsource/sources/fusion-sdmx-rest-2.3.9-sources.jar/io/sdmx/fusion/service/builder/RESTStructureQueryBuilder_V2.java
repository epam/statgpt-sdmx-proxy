package io.sdmx.fusion.service.builder;

import java.util.Map;

import io.sdmx.api.sdmx.model.query.RESTStructureQuery;
import io.sdmx.utils.core.object.ObjectUtil;

/**
 * RESTStructureQuery builder which uses the V2 Web Service - defined in the version 3 SDMX standard
 */
public class RESTStructureQueryBuilder_V2 extends AbstractRestStructureQueryBuilder {
	
	private static RESTStructureQueryBuilder_V2 INSTANCE = new RESTStructureQueryBuilder_V2();
	
	private RESTStructureQueryBuilder_V2() { }
	
	/**
	 * Constructs a RESTStructureQuery from the rest query string
	 * @param restQuery a rest query such as : /dataflow/SDMX/DF_1/+
	 * @return a RESTStructureQuery object
	 */
	public static RESTStructureQuery build(String restQuery) {
		return build(restQuery, determineQueryParameters(restQuery));
	}

	/**
	 * Constructs a RESTStructureQuery from the rest query string and query parameters
	 * @param restQuery a rest query such as : /dataflow/SDMX/DF_1/+
	 * @param queryParameters
	 * @return a RESTStructureQuery object
	 */
	public static RESTStructureQuery build(String restQuery, Map<String, String> queryParameters) {
		return INSTANCE.buildRESTQuery(restQuery, queryParameters);
	}
	
	@Override
	protected String parseVersionString(String query) {
		// No need to provide a use-case for "+" as the use of "latest".  This is handled in code later
		if(!ObjectUtil.validString(query)) {
			return null;
		}
		// Convert the word "latest" into a "+" symbol so it will be processed correctly
		if(query.equalsIgnoreCase("latest")) {
			return "+";
		}
		if(query.equalsIgnoreCase("all")) {
			return "*";
		}
		return query;
	}
}
