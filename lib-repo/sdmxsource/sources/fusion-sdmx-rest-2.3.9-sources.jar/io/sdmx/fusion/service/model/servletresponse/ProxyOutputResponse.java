package io.sdmx.fusion.service.model.servletresponse;

import java.io.OutputStream;

import io.sdmx.api.http.IResponse;

public class ProxyOutputResponse extends ProxyResponse {
	private OutputStream out;

	public ProxyOutputResponse(IResponse proxy, OutputStream out) {
		super(proxy);
		this.out = out;
	}

	@Override
	public OutputStream getOutputStream() {
		return out;
	}
	
}