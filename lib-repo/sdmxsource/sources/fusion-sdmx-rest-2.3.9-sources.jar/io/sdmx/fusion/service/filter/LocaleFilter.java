package io.sdmx.fusion.service.filter;

import java.io.IOException;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.sdmx.utils.core.audit.AuditUtil;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.sdmx.structure.TextTypeUtil;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;

public class LocaleFilter implements Filter {
    private static final Logger LOG = LoggerFactory.getLogger(LocaleFilter.class);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	    // Left intentionally empty
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		Locale locale = null;
		if(req instanceof HttpServletRequest) {
			final HttpServletRequest request = (HttpServletRequest) req;

			
			if(ObjectUtil.validString(request.getParameter("locale"))) {
				String filterLocale = request.getParameter("locale");
				LOG.debug("Locale from request parameter: "+filterLocale);
				locale = Locale.forLanguageTag(filterLocale);
			} else {
				String accLang = request.getHeader("Accept-Language");
				if (ObjectUtil.validString(accLang)) {
					locale = request.getLocale();
					LOG.debug("Locale from Accept-Language Header: " + locale);
				} else {
					locale = null;
				}
			}
			String localeLanguage = locale == null ? null : locale.getLanguage();
			if(localeLanguage == null) {
				LOG.debug("Locale Langauge null, do not use locale filter");
				locale = null;
			} else if(localeLanguage.equals("*") || !ObjectUtil.validString(localeLanguage) || localeLanguage.equals("all")) {
				LOG.debug("Locale Langauge Wildcarded, do not use locale filter");
				locale = null;
			}
		}
		try {
			if(locale != null) {
				LOG.debug("Set Locale filter: "+locale);
				TextTypeUtil.setLocaleFilter(locale);
				AuditUtil.addAuditProperty("Locale", locale);
			}
			chain.doFilter(req, response);
		} finally {
			TextTypeUtil.clearLocaleFilter();
		}
	}

	@Override
	public void destroy() {
	    // Left intentionally empty
	}
}