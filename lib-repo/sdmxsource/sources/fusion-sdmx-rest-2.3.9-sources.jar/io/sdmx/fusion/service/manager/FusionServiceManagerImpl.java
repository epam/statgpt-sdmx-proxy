package io.sdmx.fusion.service.manager;

import io.sdmx.api.application.FusionProductInformation;
import io.sdmx.api.application.FusionProductInformationRetrievalManager;
import io.sdmx.api.exception.SdmxException;
import io.sdmx.utils.sdmx.application.FUSION_PRODUCT;
import io.sdmx.utils.sdmx.application.FusionServiceManager;
import io.sdmx.utils.core.object.ObjectUtil;
import io.sdmx.utils.core.version.VersionableUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class FusionServiceManagerImpl implements FusionServiceManager {
	private static final Logger LOG = LoggerFactory.getLogger(FusionServiceManagerImpl.class);

	@Override
	public void validateService(FUSION_PRODUCT product, String serviceUrl) {
		validateService(product, serviceUrl, null);
	}

	@Override
	public void validateService(FUSION_PRODUCT product, String serviceUrl, String minVersion) {
		if(ObjectUtil.validString(serviceUrl)) {
			//1. Verify URL is okay
			FusionProductInformationRetrievalManager productInfoRetrieval = new FusionProductInformationRetrievalManagerRest(serviceUrl);
			FusionProductInformation productInfo = productInfoRetrieval.getFusionProductInformation();
			if(productInfo.getProductDetails().getProduct().equals("$PRODUCT$")) {
				LOG.warn("Service is referencing a develpoment version of a Fusion Product and therfore product can not be verified");
			} else {
				try {
					FUSION_PRODUCT actualProduct = FUSION_PRODUCT.parseString(productInfo.getProductDetails().getProduct());
					if(actualProduct != product) {
						throw new SdmxException("The given URL does not reference the expected Fusion Product.  Expected: '"+product.getHumanName()+"' Actual: '"+actualProduct.getHumanName()+"' ");
					}
					if(minVersion != null) {
						if(VersionableUtil.isHigherVersion(minVersion, productInfo.getProductDetails().getVersion())) {
							throw new SdmxException("The '"+product.getHumanName()+"' version '"+productInfo.getProductDetails().getVersion()+"' is lower then the supported version of '"+minVersion+"'");
						}
					}
					
				} catch(IllegalArgumentException e) {
					throw new SdmxException("The given URL does not reference the expected Fusion Product.  Expected: '"+product.getHumanName()+"' Actual: '"+productInfo.getProductDetails().getProduct()+"' ");
				}
			}
		}
	}
	
}
